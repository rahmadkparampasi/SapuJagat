<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\UmMdl;

class Setrmr extends BaseController
{
    use ResponseTrait;
    protected $MdlU;
    protected $AI;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_setrmr', 'rs_setrmr_id_ex');
        $this->AI = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeng',
            'pAct' => 'pAPeng',
            'cAct' => 'cArmref',
            'cmAct' => '',
            'scAct' => '',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA SETUP RUANGAN';
        $this->data['PageTitle'] = 'Data Setup Ruangan';
        $this->data['BasePage'] = 'setrmr';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData';
        $this->data['IdForm'] = 'setrmrAddData';
        $this->data['UrlForm'] = 'setrmr';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);


        $this->data['Setrmr'] = $this->setDB();

        echo view('Setrmr/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }

    public function editData($rs_setrmr_id_ex = '')
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA SETUP RUANGAN';
        $this->data['PageTitle'] = 'Data Setup Ruangan';
        $this->data['BasePage'] = 'setrmr';
        $this->data['ButtonMethod'] = 'UBAH';
        $this->data['MethodForm'] = 'updateData/' . $rs_setrmr_id_ex;
        $this->data['IdForm'] = 'setrmrAddData';
        $this->data['UrlForm'] = 'setrmr';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);

        $this->data['Setrmr'] = $this->setDB();

        if ($rs_setrmr_id_ex === null || $rs_setrmr_id_ex == '') {
            return redirect()->to('/' . $this->data['BasePage']);
        } else {
            $this->data['fillUpdate'] = $this->setDB('fillUpdate', $rs_setrmr_id_ex);

            echo view('Setrmr/index', $this->data);
            echo view('Templates/anotherScript');
            echo view('Templates/ajaxInsert', $this->data);
            echo view('Templates/loadData');
        }
    }

    public function getAll()
    {
        return $this->setDB('getAll');
    }

    public function insertData()
    {

        $rs_setrmr_id_ex = $this->setDB('idEx', $this->AI->getRandStr(3));
        $rs_setrmr_nm = $this->request->getPost('rs_setrmr_nm');
        $rs_setrmr_rmr = $this->request->getPost('rs_setrmr_rmr');
        $rs_setrmr_ket = $this->request->getPost('rs_setrmr_ket');

        $data = [
            'rs_setrmr_id_ex' => $rs_setrmr_id_ex,
            'rs_setrmr_nm' => $rs_setrmr_nm,
            'rs_setrmr_rmr' => $rs_setrmr_rmr,
            'rs_setrmr_ket' => $rs_setrmr_ket,
        ];

        $insertData = $this->MdlU->insertData($data);
        if ($insertData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Setup Ruangan Berhasil Disimpan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Setup Ruangan Tidak Dapat Disimpan'];
        }

        return $this->respond($data, $data['status']);
    }


    public function updateData($rs_setrmr_id_ex = '')
    {
        $rs_setrmr_nm = $this->request->getPost('rs_setrmr_nm');
        $rs_setrmr_rmr = $this->request->getPost('rs_setrmr_rmr');
        $rs_setrmr_ket = $this->request->getPost('rs_setrmr_ket');
        $rs_setrmr_id_ex = $this->request->getPost('rs_setrmr_id_ex');
        $data = [
            'rs_setrmr_nm' => $rs_setrmr_nm,
            'rs_setrmr_rmr' => $rs_setrmr_rmr,
            'rs_setrmr_ket' => $rs_setrmr_ket,
        ];
        $updateData = $this->MdlU->updateData($data, $rs_setrmr_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Setup Ruangan Berhasil Diubah'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Setup Ruangan Tidak Dapat Diubah'];
        }
        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_setrmr_id_ex';
        $id = 'rs_setrmr_id';
        $length = 2;
        $typeGet = 'result';

        $fillUpdate = 'rs_setrmr_id_ex, rs_setrmr_nm, rs_setrmr_rmr, rs_rmr_nm, rs_setrmr_ket';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [],
                //order by
                [
                    0 => ['id' => 'rs_setrmr_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmr', 'string' => 'rs_rmr.rs_rmr_id_ex = rs_setrmr.rs_setrmr_rmr', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_setrmr_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmr', 'string' => 'rs_rmr.rs_rmr_id_ex = rs_setrmr.rs_setrmr_rmr', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}