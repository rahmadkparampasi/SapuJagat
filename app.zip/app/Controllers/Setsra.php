<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\UmMdl;

class Setsra extends BaseController
{
    use ResponseTrait;
    protected $MdlU;
    protected $AI;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_setsra', 'rs_setsra_id_ex');
        $this->AI = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeng',
            'pAct' => 'pAPeng',
            'cAct' => 'cArmref',
            'cmAct' => 'cmArmref',
            'scAct' => 'scAsetsra',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA JENIS ANTRIAN';
        $this->data['PageTitle'] = 'Data Jenis Antrian';
        $this->data['BasePage'] = 'setsra';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData';
        $this->data['IdForm'] = 'setsraAddData';
        $this->data['UrlForm'] = 'setsra';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);


        $this->data['Setsra'] = $this->setDB();

        echo view('Setsra/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }

    public function getAll()
    {
        return $this->setDB('getAll');
    }
    public function getByNm($data)
    {
        $new =  $this->setDB('getByNm', $data);
        return $new['rs_setsra_v'];
    }

    public function insertData()
    {
        $validated = $this->validate([
            'rs_setsra_v' => 'uploaded[rs_setsra_v]|mime_in[rs_setsra_v,audio/mpeg,audio/mpg,audio/mpeg3,audio/mp3]|max_size[rs_setsra_v,2048]'
        ]);
        if ($validated == FALSE) {
            // Kembali ke function index supaya membawa data uploads dan validasi
            $data = ['status' => 415, 'response' => "error", 'message' => 'Berkas Yang Diunggah Tidak Sesuai Spesifikasi'];
        } else {
            $rs_setsra_id_ex = $this->setDB('idEx', $this->AI->getRandStr(3));
            $rs_setsra_v = $this->request->getFile('rs_setsra_v');
            $rs_setsra_nm = $this->request->getPost('rs_setsra_nm');

            $new_rs_setsra_v = "Setsra-" . $rs_setsra_id_ex . "-"  . date("YmdHis") . "." . $rs_setsra_v->getClientExtension();
            $data = [
                'rs_setsra_id_ex' => $rs_setsra_id_ex,
                'rs_setsra_v' => $new_rs_setsra_v,
                'rs_setsra_nm' => $rs_setsra_nm
            ];

            $insertData = $this->MdlU->insertData($data);
            if ($insertData) {
                $rs_setsra_v->move('uploads', $new_rs_setsra_v);
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Jenis Antrian Berhasil Disimpan'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Jenis Antrian Tidak Dapat Disimpan'];
            }
        }


        return $this->respond($data, $data['status']);
    }

    

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_setsra_id_ex';
        $id = 'rs_setsra_id';
        $length = 2;
        $typeGet = 'result';

        $fillUpdate = 'rs_setsra_id_ex, rs_setsra_nm, rs_setsra_v';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [],
                //order by
                [
                    0 => ['id' => 'rs_setsra_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        }elseif ($request == 'getByNm') {
            return $this->MdlU->getAll(
                //type result / row
                'row',
                // select *
                'rs_setsra_v',
                //where
                [
                    0 => ['idEx' => 'rs_setsra_nm', 'idExV' => $data]
                ],
                //order by
                [
                    0 => ['id' => 'rs_setsra_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'getAllByAct') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => ['idEx' => 'rs_setsra_sts', 'idExV' => '1']
                ],
                //order by
                [
                    0 => ['id' => 'rs_setsra_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_setsra_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}
