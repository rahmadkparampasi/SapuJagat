<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\UmMdl;

class Rmpresrb extends BaseController
{
    use ResponseTrait;

    protected $MdlU;
    protected $Rmap;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_rmpresrb', 'rs_rmpresrb_id');
        $this->Rmap = new Rmap;
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOIgd',
            'pAct' => 'pAIgd',
            'cAct' => 'cArmpmsk',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {

        return redirect()->to('./rmpmsk');
    }



    public function getAll($rs_rmpresrb_rmpresr)
    {
        $this->data['Rmpresrb'] = $this->setDB('getAll', $rs_rmpresrb_rmpresr);

        return  $this->data['Rmpresrb'];
    }

    public function insertData($rs_rmpresrb_rmpresr, $rs_rmpresrb_rmb, $rs_rmpresrb_jmlh)
    {
        $success = 0;
        $error = 0;
        for ($i = 0; $i < count($rs_rmpresrb_rmb); $i++) {
            $data = [
                'rs_rmpresrb_rmpresr' => $rs_rmpresrb_rmpresr,
                'rs_rmpresrb_rmb' => $rs_rmpresrb_rmb[$i],
                'rs_rmpresrb_jmlh' => $rs_rmpresrb_jmlh[$i],
            ];
            $insertData = $this->MdlU->insertData($data);
            if ($insertData) {
                $success = $success + 1;
            } else {
                $error = $error + 1;
            }
        }

        return [$success, $error];
    }

    public function deleteData($rs_rmpresrb_id = '')
    {
        if ($rs_rmpresrb_id === null || $rs_rmpresrb_id == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlU->deleteData($rs_rmpresrb_id);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Obat E-Resep Racik Pasien Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Obat E-Resep Racik Pasien Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmpresrb_id';
        $id = 'rs_rmpresrb_id';
        $length = 3;
        $typeGet = 'result';

        $fillUpdate = '*';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmpresrb_rmpresr',
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpresrb_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmb', 'string' => 'rs_rmb.rs_rmb_id_ex = rs_rmpresrb.rs_rmpresrb_rmb', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpresrb_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}