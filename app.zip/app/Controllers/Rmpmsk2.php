<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\RmaMdl;
use App\Models\RmphMdl;
use App\Models\RmpmskMdl;
use App\Models\RmppMdl;
use App\Models\RmprMdl;

class Rmpmsk extends BaseController
{
    use ResponseTrait;
    protected $MdlRmpmsk;
    protected $MdlRmpp;
    protected $MdlRmph;
    protected $MdlRmpr;
    protected $MdlRma;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlRmpmsk = new RmpmskMdl();
        $this->MdlRmpp = new RmppMdl();
        $this->MdlRmph = new RmphMdl();
        $this->MdlRmpr = new RmprMdl();
        $this->MdlRma = new RmaMdl();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOIgd',
            'pAct' => 'pAIgd',
            'cAct' => 'cArmpmsk',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA PASIEN INSTALASI GAWAT DARURAT';
        $this->data['PageTitle'] = 'Data Pasien Instalasi Gawat Darurat';
        $this->data['BasePage'] = 'rmpmsk';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData';
        $this->data['IdForm'] = 'rmpmskAddData';
        $this->data['UrlForm'] = 'rmpmsk';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);

        $this->data['Rmpmsk'] = $this->MdlRmpmsk->getAllRmpmsk();

        $this->data['Rma'] = $this->MdlRma->getAllRma();

        for ($i = 0; $i < count($this->data['Rmpmsk']); $i++) {
            $this->data['d'] = (string)date('d', strtotime($this->data['Rmpmsk'][$i]['rs_rmpmsk_tgl']));
            $this->data['F'] = (string)date('F', strtotime($this->data['Rmpmsk'][$i]['rs_rmpmsk_tgl']));
            $this->data['F'] = $this->Another_Include->monthConv($this->data['F']);
            $this->data['Y'] = (string)date('Y', strtotime($this->data['Rmpmsk'][$i]['rs_rmpmsk_tgl']));
            $this->data['Rmpmsk'][$i]['rs_rmpmsk_tgl'] = strtoupper($this->data['d'] . " " . $this->data['F'] . " " . $this->data['Y']);

            $this->data['d'] = (string)date('d', strtotime($this->data['Rmpmsk'][$i]['rs_rmpp_tgl_lhr']));
            $this->data['F'] = (string)date('F', strtotime($this->data['Rmpmsk'][$i]['rs_rmpp_tgl_lhr']));
            $this->data['F'] = $this->Another_Include->monthConv($this->data['F']);
            $this->data['Y'] = (string)date('Y', strtotime($this->data['Rmpmsk'][$i]['rs_rmpp_tgl_lhr']));
            $this->data['Rmpmsk'][$i]['rs_rmpp_tgl_lhr'] = strtoupper($this->data['d'] . " " . $this->data['F'] . " " . $this->data['Y']);

            if ($this->data['Rmpmsk'][$i]['rs_rmpp_jk'] == "L") {
                $this->data['Rmpmsk'][$i]['rs_rmpp_jk'] = "LAKI-LAKI";
            } else {
                $this->data['Rmpmsk'][$i]['rs_rmpp_jk'] = "PEREMPUAN";
            }
        }

        echo view('Rmpmsk/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }

    public function insertDataRmpp()
    {
        $rs_rmph_id_ex = $this->Another_Include->getRandStr(35);
        $rs_rmph_rmpp = $this->request->getPost('rs_rmpmsk_rmpp');
        $rs_rmph_ppeg = $this->data['rs_ppeg_id_ex'];
        $rs_rmph_jns = "PR";


        $rs_rmpmsk_rmpp = $this->request->getPost('rs_rmpmsk_rmpp');
        $rs_rmpmsk_id_ex = $this->MdlRmpmsk->getIdExRmpmsk($this->Another_Include->getRandStr(30));
        $rs_rmpmsk_tgl = $this->request->getPost('rs_rmpmsk_tgl');
        $rs_rmpmsk_jam = $this->request->getPost('rs_rmpmsk_jam');
        $rs_rmpmsk_rmph =  $rs_rmph_id_ex;

        $rs_rmpr_rmpmsk = $rs_rmpmsk_id_ex;
        $rs_rmpr_rmr = "6bekDgv";
        $rs_rmpr_rmr_ppeg = $this->data['rs_ppeg_id_ex'];
        $rs_rmpr_rmph = $rs_rmph_id_ex;

        $dataRmph = [
            'rs_rmph_id_ex' => $rs_rmph_id_ex,
            'rs_rmph_rmpp' => $rs_rmph_rmpp,
            'rs_rmph_ppeg' => $rs_rmph_ppeg,
            'rs_rmph_jns' => $rs_rmph_jns
        ];

        $dataRmpmsk = [
            'rs_rmpmsk_id_ex' => $rs_rmpmsk_id_ex,
            'rs_rmpmsk_rmpp' => $rs_rmpmsk_rmpp,
            'rs_rmpmsk_tgl' => $rs_rmpmsk_tgl,
            'rs_rmpmsk_jam' => $rs_rmpmsk_jam,
            'rs_rmpmsk_rmph' => $rs_rmpmsk_rmph
        ];

        $dataRmpr = [
            'rs_rmpr_rmpmsk' => $rs_rmpr_rmpmsk,
            'rs_rmpr_rmr' => $rs_rmpr_rmr,
            'rs_rmpr_rmr_ppeg' => $rs_rmpr_rmr_ppeg,
            'rs_rmpr_rmph' => $rs_rmpr_rmph
        ];

        $insertDataRmph = $this->MdlRmph->insertData($dataRmph);
        if ($insertDataRmph) {
            $insertDataRmpmsk = $this->MdlRmpmsk->insertData($dataRmpmsk);
            if ($insertDataRmpmsk) {
                $insertDataRmpr = $this->MdlRmpr->insertData($dataRmpr);
                if ($insertDataRmpr) {
                    $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Pasien Masuk Berhasil Disimpan'];
                } else {
                    $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Ruangan Pasien Masuk Tidak Dapat Disimpan'];
                }
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Pasien Masuk Tidak Dapat Disimpan'];
            }
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Histori Pasien Tidak Dapat Disimpan'];
        }

        return $this->respond($data, $data['status']);
    }

    public function getRmpmskByJson()
    {
        header('Content-Type: application/json');
        header("Access-Control-Allow-Origin: *");
        $this->data['data']['data'] = $this->MdlRmpmsk->getAllRmpmsk();

        for ($i = 0; $i < count($this->data['data']['data']); $i++) {
            $this->data['d'] = (string)date('d', strtotime($this->data['data']['data'][$i]['rs_rmpmsk_tgl']));
            $this->data['F'] = (string)date('F', strtotime($this->data['data']['data'][$i]['rs_rmpmsk_tgl']));
            $this->data['F'] = $this->Another_Include->monthConv($this->data['F']);
            $this->data['Y'] = (string)date('Y', strtotime($this->data['data']['data'][$i]['rs_rmpmsk_tgl']));
            $this->data['data']['data'][$i]['rs_rmpmsk_tgl'] = strtoupper($this->data['d'] . " " . $this->data['F'] . " " . $this->data['Y']);

            $this->data['d'] = (string)date('d', strtotime($this->data['data']['data'][$i]['rs_rmpp_tgl_lhr']));
            $this->data['F'] = (string)date('F', strtotime($this->data['data']['data'][$i]['rs_rmpp_tgl_lhr']));
            $this->data['F'] = $this->Another_Include->monthConv($this->data['F']);
            $this->data['Y'] = (string)date('Y', strtotime($this->data['data']['data'][$i]['rs_rmpp_tgl_lhr']));
            $this->data['data']['data'][$i]['rs_rmpp_tgl_lhr'] = strtoupper($this->data['d'] . " " . $this->data['F'] . " " . $this->data['Y']);

            if ($this->data['data']['data'][$i]['rs_rmpp_jk'] == "L") {
                $this->data['data']['data'][$i]['rs_rmpp_jk'] = "LAKI-LAKI";
            } else {
                $this->data['data']['data'][$i]['rs_rmpp_jk'] = "PEREMPUAN";
            }
        }
        return $this->respond($this->data['data'], 200);
    }



    public function insertData()
    {

        $rs_rmpp_ppeg = $this->data['rs_ppeg_id_ex'];

        $array = $this->request->getPost();
        unset($array['datatableKirana_length']);
        $arrayFlip = array_keys($array);
        $arrayFlipV = array_values($arrayFlip);
        $arrayV = array_values($array);

        $rs_rmpp_id_ex = $this->MdlRmpp->getIdExRmpp($this->Another_Include->getRandStr(30));

        $dataRmpp = [];
        $dataRmpp['rs_rmpp_id_ex'] = $rs_rmpp_id_ex;
        $dataRmpp['rs_rmpp_ppeg'] = $rs_rmpp_ppeg;
        $dataRmpp['rs_rmpp_rm'] = $this->getNoRm();

        $rs_rmph_id_ex = $this->Another_Include->getRandStr(35);
        $rs_rmph_rmpp = $rs_rmpp_id_ex;
        $rs_rmph_ppeg = $this->data['rs_ppeg_id_ex'];
        $rs_rmph_jns = "PR";

        $dataRmph = [
            'rs_rmph_id_ex' => $rs_rmph_id_ex,
            'rs_rmph_rmpp' => $rs_rmph_rmpp,
            'rs_rmph_ppeg' => $rs_rmph_ppeg,
            'rs_rmph_jns' => $rs_rmph_jns
        ];


        $rs_rmpmsk_id_ex = $this->MdlRmpmsk->getIdExRmpmsk($this->Another_Include->getRandStr(30));

        $rs_rmpr_rmpmsk = $rs_rmpmsk_id_ex;
        $rs_rmpr_rmr = "6bekDgv";
        $rs_rmpr_rmr_ppeg = $this->data['rs_ppeg_id_ex'];
        $rs_rmpr_rmph = $rs_rmph_id_ex;

        $dataRmpmsk = [];

        $dataRmpmsk = [
            'rs_rmpmsk_id_ex' => $rs_rmpmsk_id_ex,
            'rs_rmpmsk_rmpp' => $rs_rmpp_id_ex,
            'rs_rmpmsk_rmph' => $rs_rmph_id_ex
        ];

        $dataRmpr = [
            'rs_rmpr_rmpmsk' => $rs_rmpr_rmpmsk,
            'rs_rmpr_rmr' => $rs_rmpr_rmr,
            'rs_rmpr_rmr_ppeg' => $rs_rmpr_rmr_ppeg,
            'rs_rmpr_rmph' => $rs_rmpr_rmph
        ];


        for ($i = 0; $i < count($arrayV); $i++) {
            if (substr($arrayFlipV[$i], 0, 7) == "rs_rmpp") {
                $dataRmpp[$arrayFlipV[$i]] = $arrayV[$i];
                # code...
            } else {
                $dataRmpmsk[$arrayFlipV[$i]] = $arrayV[$i];
            }
        }

        if ($dataRmpmsk['rs_rmpmsk_rma'] == "") {
            $dataRmpmsk['rs_rmpmsk_rma'] = null;
        }

        // dd($array, $arrayFlip, $arrayFlipV, $arrayV, $dataRmpp, $dataRmpmsk);

        $insertDataRmpp = $this->MdlRmpp->insertData($dataRmpp);
        if ($insertDataRmpp) {
            $insertDataRmph = $this->MdlRmph->insertData($dataRmph);
            if ($insertDataRmph) {
                $insertDataRmpmsk = $this->MdlRmpmsk->insertData($dataRmpmsk);
                if ($insertDataRmpmsk) {
                    $insertDataRmpr = $this->MdlRmpr->insertData($dataRmpr);
                    if ($insertDataRmpr) {
                        $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Pasien Masuk Berhasil Disimpan'];
                    } else {
                        $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Ruangan Pasien Masuk Tidak Dapat Disimpan'];
                    }
                } else {
                    $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Pasien Masuk Tidak Dapat Disimpan'];
                }
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Histori Pasien Tidak Dapat Disimpan'];
            }
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Pasien Tidak Dapat Disimpan'];
        }


        return $this->respond($data, $data['status']);
    }

    public function getNoRm()
    {
        $rs_rmpp_rm_l = (int)$this->MdlRmpp->getLastNoRm();
        $rs_rmpp_rm_n = $rs_rmpp_rm_l + 1;
        return $rs_rmpp_rm_n;
    }
}
