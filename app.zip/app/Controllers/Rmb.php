<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\UmMdl;
use PhpOffice\PhpSpreadsheet\Reader\Xls as Reader;

class Rmb extends BaseController
{
    use ResponseTrait;
    protected $MdlU;
    protected $Rmgz;
    protected $Rmmrk;
    protected $Rmjk;
    protected $Rmst;
    protected $Rmpyd;
    protected $AI;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_rmb', 'rs_rmb_id_ex');
        $this->Rmgz = new Rmgz;
        $this->Rmmrk = new Rmmrk;
        $this->Rmjk = new Rmjk;
        $this->Rmst = new Rmst;
        $this->Rmpyd = new Rmpyd;
        $this->AI = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeng',
            'pAct' => 'pAPeng',
            'cAct' => 'cArmb',
            'cmAct' => '',
            'scAct' => '',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA BARANG';
        $this->data['PageTitle'] = 'Data Barang';
        $this->data['BasePage'] = 'rmb';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertFile';
        $this->data['IdForm'] = 'rmbAddData';
        $this->data['UrlForm'] = 'rmb';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);


        $this->data['Rmb'] = $this->setDB();
        $this->data['Rmgz'] = $this->Rmgz->getAll();
        $this->data['Rmmrk'] = $this->Rmmrk->getAll();
        $this->data['Rmjk'] = $this->Rmjk->getAll();
        $this->data['Rmst'] = $this->Rmst->getAll();
        $this->data['Rmpyd'] = $this->Rmpyd->getAll();

        echo view('Rmb/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }

    public function editData($rs_rmb_id_ex = '')
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA BARANG';
        $this->data['PageTitle'] = 'Data Barang';
        $this->data['BasePage'] = 'rmb';
        $this->data['ButtonMethod'] = 'UBAH';
        $this->data['MethodForm'] = 'updateData/' . $rs_rmb_id_ex;
        $this->data['IdForm'] = 'rmbAddData';
        $this->data['UrlForm'] = 'rmb';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);

        $this->data['Rmb'] = $this->setDB();

        if ($rs_rmb_id_ex === null || $rs_rmb_id_ex == '') {
            return redirect()->to('/' . $this->data['BasePage']);
        } else {
            $this->data['fillUpdate'] = $this->setDB('fillUpdate', $rs_rmb_id_ex);

            echo view('Rmb/index', $this->data);
            echo view('Templates/anotherScript');
            echo view('Templates/ajaxInsert', $this->data);
            echo view('Templates/loadData');
        }
    }

    public function getAll()
    {
        return $this->setDB('getAllByAct');
    }

    public function getRmbByJson($rs_rmr_id_ex)
    {
        header('Content-Type: application/json');
        header("Access-Control-Allow-Origin: *");
        $this->data['data']['data'] = $this->setDB();
        $no = 0;
        for ($i = 0; $i < count($this->data['data']['data']); $i++) {
            $no++;

            $this->data['data']['data'][$i]['button'] = "<button class='btn bg-gradient-success' title='Tambahkan Barang Ke Dalam Ruangan' onclick='addWF(\"Menambahkan " . $this->data['data']['data'][$i]['rs_rmb_nm'] . " Dalam Data Ruangan\", \"/" . "rmrrmb/insertData/" . $rs_rmr_id_ex . "/" . $this->data['data']['data'][$i]['rs_rmb_id_ex'] . "\", loadTabBrg)'><i class='fas fa-check'></i></button>";
            $this->data['data']['data'][$i]['no'] = $no;
        }
        return $this->respond($this->data['data'], 200);
    }

    public function getAllRmbByJson($name = '', $idEx = '', $hrg = '')
    {
        header('Content-Type: application/json');
        header("Access-Control-Allow-Origin: *");

        $this->data['data']['data'] =  $this->setDB('getAll');
        $no = 0;
        for ($i = 0; $i < count($this->data['data']['data']); $i++) {
            $no++;
            $this->data['data']['data'][$i]['no'] = $no;

            $this->data['data']['data'][$i]['button'] = "<button class='btn bg-gradient-success' title='Tambahkan Obat Daftar Rencana Kebutuhan Barang Detail' data-dismiss='modal' onclick='addFill(\"" . $name . "\", \"" . $this->data['data']['data'][$i]['rs_rmb_nm'] . "\"); addFill(\"" . $idEx . "\", \"" . $this->data['data']['data'][$i]['rs_rmb_id_ex'] . "\"); addFill(\"" . $hrg . "\", \"" . $this->data['data']['data'][$i]['rs_rmb_hb'] . "\"); destroyRmb(); closeModal(\"modalViewRmb\")'><i class='fas fa-check'></i></button>";

            $this->data['data']['data'][$i]['check'] = "<input type='checkbox' name='" . $name . "[]' id='rs_rmpresnr_rmb" . $no . "' class='form-control' value='" . $this->data['data']['data'][$i]['rs_rmb_id_ex'] . "'/>";
        }

        return $this->respond($this->data['data'], 200);
    }
    public function insertData()
    {

        $rs_rmb_id_ex = $this->setDB('idEx', $this->AI->getRandStr(3));
        $rs_rmb_nm = $this->request->getPost('rs_rmb_nm');
        $rs_rmb_stk = $this->request->getPost('rs_rmb_stk');
        $rs_rmb_rmgz = $this->request->getPost('rs_rmb_rmgz');
        $rs_rmb_rmmrk = $this->request->getPost('rs_rmb_rmmrk');
        $rs_rmb_rmjk = $this->request->getPost('rs_rmb_rmjk');
        $rs_rmb_rmst = $this->request->getPost('rs_rmb_rmst');
        $rs_rmb_rmpyd = $this->request->getPost('rs_rmb_rmpyd');
        $rs_rmb_po = $this->request->getPost('rs_rmb_po');
        $rs_rmb_jg = $this->request->getPost('rs_rmb_jg');
        $rs_rmb_for = $this->request->getPost('rs_rmb_for');
        $rs_rmb_kt = $this->request->getPost('rs_rmb_kt');

        $data = [
            'rs_rmb_id_ex' => $rs_rmb_id_ex,
            'rs_rmb_nm' => $rs_rmb_nm,
            'rs_rmb_stk' => $rs_rmb_stk,
            'rs_rmb_rmgz' => $rs_rmb_rmgz,
            'rs_rmb_rmmrk' => $rs_rmb_rmmrk,
            'rs_rmb_rmjk' => $rs_rmb_rmjk,
            'rs_rmb_rmst' => $rs_rmb_rmst,
            'rs_rmb_rmpyd' => $rs_rmb_rmpyd,
            'rs_rmb_po' => $rs_rmb_po,
            'rs_rmb_jg' => $rs_rmb_jg,
            'rs_rmb_for' => $rs_rmb_for,
            'rs_rmb_kt' => $rs_rmb_kt,
        ];

        $insertData = $this->MdlU->insertData($data);
        if ($insertData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Barang Berhasil Disimpan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Barang Tidak Dapat Disimpan'];
        }

        return $this->respond($data, $data['status']);
    }


    public function updateData($rs_rmb_id_ex = '')
    {
        $rs_rmb_nm = $this->request->getPost('rs_rmb_nm');
        $rs_rmb_stk = $this->request->getPost('rs_rmb_stk');
        $rs_rmb_rmgz = $this->request->getPost('rs_rmb_rmgz');
        $rs_rmb_rmmrk = $this->request->getPost('rs_rmb_rmmrk');
        $rs_rmb_rmjk = $this->request->getPost('rs_rmb_rmjk');
        $rs_rmb_rmst = $this->request->getPost('rs_rmb_rmst');
        $rs_rmb_rmpyd = $this->request->getPost('rs_rmb_rmpyd');
        $rs_rmb_po = $this->request->getPost('rs_rmb_po');
        $rs_rmb_jg = $this->request->getPost('rs_rmb_jg');
        $rs_rmb_for = $this->request->getPost('rs_rmb_for');
        $rs_rmb_kt = $this->request->getPost('rs_rmb_kt');
        $rs_rmb_id_ex = $this->request->getPost('rs_rmb_id_ex');
        $data = [
            'rs_rmb_nm' => $rs_rmb_nm,
            'rs_rmb_stk' => $rs_rmb_stk,
            'rs_rmb_rmgz' => $rs_rmb_rmgz,
            'rs_rmb_rmmrk' => $rs_rmb_rmmrk,
            'rs_rmb_rmjk' => $rs_rmb_rmjk,
            'rs_rmb_rmst' => $rs_rmb_rmst,
            'rs_rmb_rmpyd' => $rs_rmb_rmpyd,
            'rs_rmb_po' => $rs_rmb_po,
            'rs_rmb_jg' => $rs_rmb_jg,
            'rs_rmb_for' => $rs_rmb_for,
            'rs_rmb_kt' => $rs_rmb_kt,
        ];
        $updateData = $this->MdlU->updateData($data, $rs_rmb_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Barang Berhasil Diubah'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Barang Tidak Dapat Diubah'];
        }
        return $this->respond($data, $data['status']);
    }
    public function updateDataHrg()
    {
        $rs_rmb_hb = $this->request->getPost('rs_rmb_hb');
        $rs_rmb_hj = $this->request->getPost('rs_rmb_hj');
        $rs_rmb_ppn = $this->request->getPost('rs_rmb_ppn');
        $rs_rmb_mb = $this->request->getPost('rs_rmb_mb');
        $rs_rmb_id_ex = $this->request->getPost('rs_rmb_id_ex1');
        $data = [
            'rs_rmb_hb' => $rs_rmb_hb,
            'rs_rmb_hj' => $rs_rmb_hj,
            'rs_rmb_ppn' => $rs_rmb_ppn,
            'rs_rmb_mb' => $rs_rmb_mb,
        ];
        $updateData = $this->MdlU->updateData($data, $rs_rmb_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Harga Barang Berhasil Diubah'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Harga Barang Tidak Dapat Diubah'];
        }
        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmb_id_ex = '')
    {
        if ($rs_rmb_id_ex === null || $rs_rmb_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlU->deleteData($rs_rmb_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Barang Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Barang Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function block($rs_rmb_id_ex = '')
    {
        $data = [
            'rs_rmb_sts' => "0",
        ];
        $updateData = $this->MdlU->updateData($data, $rs_rmb_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Status Barang Berhasil Di Dinonaktifkan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Status Barang Tidak Dapat Di Dinonaktifkan'];
        }
        return $this->respond($data, $data['status']);
    }

    public function unblock($rs_rmb_id_ex = '')
    {
        $data = [
            'rs_rmb_sts' => "1",
        ];
        $updateData = $this->MdlU->updateData($data, $rs_rmb_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Status Barang Berhasil Aktifkan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Status Barang Tidak Dapat Aktifkan'];
        }
        return $this->respond($data, $data['status']);
    }

    public function insertFile()
    {
        
        date_default_timezone_set("Asia/Makassar");

        $ExcelReader = new Reader();

        $file = $this->request->getFile('file');
        $fileLocation = $file->getTempName();
        $objPhpExcel = $ExcelReader->load($fileLocation);
        $sheet = $objPhpExcel->getActiveSheet()->toArray(null, true, true, true);
        $success = 0;
        $error = 0;
        $count = count($sheet) + 1;
        $data = [];
        for ($i = 1; $i < $count; $i++) {
            
            $sheet[$i]['A'] = str_replace('\'', '', $sheet[$i]['A']);

            
            $sheet[$i]['K'] = str_replace(',', '', (string)$sheet[$i]['K']);
            $sheet[$i]['L'] = str_replace(',', '', (string)$sheet[$i]['L']);
            // $sheet[$i]['O'] = str_replace('/', '-', $sheet[$i]['O']);
            // $sheet[$i]['O'] = preg_split('|(?<!\\\)/|', $sheet[$i]['O']);


            $sheet[$i]['O'] = explode('/', (string)$sheet[$i]['N']);
            for ($j=0; $j < count($sheet[$i]['O']); $j++) { 
                if (strlen($sheet[$i]['O'][$j])==1) {
                    $sheet[$i]['O'][$j] = "0".$sheet[$i]['O'][$j];
                }
            }
            
            if ($sheet[$i]['N']!=""||$sheet[$i]['N']!=null) {
                $sheet[$i]['P'] = $sheet[$i]['O'][2]."-".$sheet[$i]['O'][0]."-".$sheet[$i]['O'][1];
            }else{
                $sheet[$i]['P'] = "0000-00-00";
            }
            
            $rs_rmb_id_ex = $this->setDB('idEx', $this->AI->getRandStr(3));

            $data = [
                'rs_rmb_id_ex' => $rs_rmb_id_ex,
                'rs_rmb_nm' => $sheet[$i]['A'],
                'rs_rmb_rmgz' => $sheet[$i]['B'],
                'rs_rmb_rmmrk' => $sheet[$i]['C'],
                'rs_rmb_rmjk' => $sheet[$i]['D'],
                'rs_rmb_rmpyd' => $sheet[$i]['E'],
                'rs_rmb_rmst' => $sheet[$i]['F'],
                'rs_rmb_po' => $sheet[$i]['G'],
                'rs_rmb_jg' => $sheet[$i]['H'],
                'rs_rmb_for' => $sheet[$i]['I'],
                'rs_rmb_hb' => $sheet[$i]['K'],
                'rs_rmb_hj' => $sheet[$i]['L'],
                'rs_rmb_mb' => $sheet[$i]['P']
            ];
            // dd($data);
            

            $insertData = $this->MdlU->insertData($data);
            if ($insertData) {
                $success += 1;
            } else {
                $error += 1;

            }     
        }

        // dd($sheet);


        // dd($sheet, $data);
        $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Berhasil Diproses, Dengan Data Yang Berhasil Berjumlah ' . (string)$success . ' Data, Dan Yang Tidak Berhasil Berjumlah ' . (string)$error . ' Data'];
        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmb_id_ex';
        $id = 'rs_rmb_id';
        $length = 2;
        $typeGet = 'result';

        $fillUpdate = 'rs_rmb_id_ex, rs_rmb_nm, rs_rmb_stk, rs_rmb_rmgz, rs_rmb_rmmrk, rs_rmb_rmjk, rs_rmb_rmst, rs_rmb_rmpyd, rs_rmb_po, rs_rmb_jg, rs_rmb_for, rs_rmb_kt';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [],
                //order by
                [
                    0 => ['id' => 'rs_rmb_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmgz', 'string' => 'rs_rmgz.rs_rmgz_id_ex = rs_rmb.rs_rmb_rmgz', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_rmmrk', 'string' => 'rs_rmmrk.rs_rmmrk_id_ex = rs_rmb.rs_rmb_rmmrk', 'type' => 'LEFT'],
                    2 => ['tableName' => 'rs_rmjk', 'string' => 'rs_rmjk.rs_rmjk_id_ex = rs_rmb.rs_rmb_rmjk', 'type' => 'LEFT'],
                    3 => ['tableName' => 'rs_rmst', 'string' => 'rs_rmst.rs_rmst_id_ex = rs_rmb.rs_rmb_rmst', 'type' => 'LEFT'],
                    4 => ['tableName' => 'rs_rmpyd', 'string' => 'rs_rmpyd.rs_rmpyd_id_ex = rs_rmb.rs_rmb_rmpyd', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'getAllByAct') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => ['idEx' => 'rs_rmb_sts', 'idExV' => '1']
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmb_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmb_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}