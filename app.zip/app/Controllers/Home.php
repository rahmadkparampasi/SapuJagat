<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;

class Home extends BaseController
{
	use ResponseTrait;
	protected $Rmpp;
	protected $Ppeg;
	protected $data;

	public function __construct()
	{
		$this->Rmpp = new Rmpp();
		$this->Ppeg = new Ppeg();
		$this->session = \Config\Services::session();
		$this->data = [
			'mOp' => 'mOPeg',
			'pAct' => 'pAHome',
			'cAct' => '',
			'cmAct' => '',
			'scAct' => '',


			'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
			'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
			'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
			'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
		];
		if ($this->data['rs_ppeg_pic'] == "") {
			$this->data['rs_ppeg_pic'] = "/images/user.png";
		} else {
			$this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
		}
	}
	public function index()
	{
		if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
			return redirect()->to('./msk');
		}
		$this->data['Rmpp'] = $this->Rmpp->countRmpp();
		$this->data['Ppeg'] = $this->Ppeg->countPpeg();

		$this->data['WebTitle'] = 'Beranda';
		$this->data['PageTitle'] = 'Beranda';
		$this->data['BasePage'] = '';
		echo view('Hm/index', $this->data);
		echo view('Templates/anotherScript');
	}
}
