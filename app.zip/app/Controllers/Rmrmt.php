<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\RmrMdl;
use App\Models\RmrmtMdl;

class Rmrmt extends BaseController
{
    use ResponseTrait;
    protected $MdlRmrmt;
    protected $MdlRmr;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlRmrmt = new RmrmtMdl();
        $this->MdlRmr = new RmrMdl();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeng',
            'pAct' => 'pAPeng',
            'cAct' => 'cArmr',
            'cmAct' => '',
            'scAct' => '',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
    }

    public function viewData($rs_rmrmt_rmr = '')
    {
        if ($rs_rmrmt_rmr == '') {
            echo "<span class='badge badge-danger'>Tidak Ada Daftar Mutu Dalam Ruangan</span>";
        } else {
            $this->data['Rmr'] = $this->MdlRmr->getAllRmr($rs_rmrmt_rmr);
            $this->data['WebTitle'] = 'DATA MUTU DALAM RUANGAN ' . strtoupper($this->data['Rmr']['rs_rmr_nm']);
            $this->data['PageTitle'] = 'Data Mutu Dalam Ruangan ' . $this->data['Rmr']['rs_rmr_nm'];
            $this->data['BasePage'] = 'rmrmt';
            $this->data['ButtonMethod'] = 'SIMPAN';
            $this->data['MethodForm'] = 'insertView/' . $rs_rmrmt_rmr;
            $this->data['IdForm'] = 'rmrmtAddData';
            $this->data['UrlForm'] = 'rmrmt';
            $this->data['Rmrmt'] = $this->MdlRmrmt->getAll($rs_rmrmt_rmr);
            echo view('Rmrmt/index', $this->data);
            echo view('Templates/ajaxInsert', $this->data);
        }
    }

    public function insertData($rs_rmrmt_rmr, $rs_rmrmt_rmmt)
    {
        if ($rs_rmrmt_rmr === null || $rs_rmrmt_rmr == '' || $rs_rmrmt_rmmt === null || $rs_rmrmt_rmmt == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'TIdak Ada ID Rujukan'];
        } else {
            $data = [
                'rs_rmrmt_rmr' => $rs_rmrmt_rmr,
                'rs_rmrmt_rmmt' => $rs_rmrmt_rmmt,
            ];
            $this->data['Rmrmt'] = $this->MdlRmrmt->getAllByRmmtAndRmr($rs_rmrmt_rmr, $rs_rmrmt_rmmt);
            if (count($this->data['Rmrmt']) > 0) {
                // $deleteData = $this->MdlPpr->deleteData($rs_ppr_ppeg);
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Mutu Dalam Ruangan Ini Sudah Ada'];
            } else {
                $insertData = $this->MdlRmrmt->insertData($data);

                if ($insertData) {
                    $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Mutu Dalam Ruangan Berhasil Disimpan'];
                } else {
                    $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Mutu Dalam Ruangan Tidak Dapat Disimpan'];
                }
            }
        }

        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_ppr_id = '')
    {
        if ($rs_ppr_id === null || $rs_ppr_id == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlPpr->deleteData($rs_ppr_id);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Mutu Dalam Ruangan Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Mutu Dalam Ruangan Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }
}