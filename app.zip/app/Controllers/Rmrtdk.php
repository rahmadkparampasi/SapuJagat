<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\RmrMdl;
use App\Models\RmrtdkMdl;

class Rmrtdk extends BaseController
{
    use ResponseTrait;
    protected $MdlRmrtdk;
    protected $MdlRmr;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlRmrtdk = new RmrtdkMdl();
        $this->MdlRmr = new RmrMdl();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeng',
            'pAct' => 'pAPeng',
            'cAct' => 'cArmr',
            'cmAct' => '',
            'scAct' => '',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
    }

    public function viewData($rs_rmrtdk_rmr = '')
    {
        if ($rs_rmrtdk_rmr == '') {
            echo "<span class='badge badge-danger'>Tidak Ada Daftar Tindakan Dalam Ruangan</span>";
        } else {
            $this->data['Rmr'] = $this->MdlRmr->getAllRmr($rs_rmrtdk_rmr);
            $this->data['WebTitle'] = 'DATA TINDAKAN DALAM RUANGAN ' . strtoupper($this->data['Rmr']['rs_rmr_nm']);
            $this->data['PageTitle'] = 'Data Tindakan Dalam Ruangan ' . $this->data['Rmr']['rs_rmr_nm'];
            $this->data['BasePage'] = 'rmrtdk';
            $this->data['ButtonMethod'] = 'SIMPAN';
            $this->data['MethodForm'] = 'insertView/' . $rs_rmrtdk_rmr;
            $this->data['IdForm'] = 'rmrtdkAddData';
            $this->data['UrlForm'] = 'rmrtdk';
            $this->data['Rmrtdk'] = $this->MdlRmrtdk->getAll($rs_rmrtdk_rmr);
            echo view('Rmrtdk/index', $this->data);
            echo view('Templates/ajaxInsert', $this->data);
        }
    }

    public function getAllForSelectByRmr($rs_rmrtdk_rmr)
    {
        header("Content-Type:application/json;charset=utf-8");
        header("Access-Control-Allow-Origin: *");


        $data = $this->MdlRmrtdk->getAll($rs_rmrtdk_rmr);
        for ($i = 0; $i < count($data); $i++) {
            $data[$i]['optText'] = $data[$i]['rs_rmtdk_nm'];
            $data[$i]['optValue'] = $data[$i]['rs_rmtdk_id_ex'];
        }
        return $this->respond($data, 200);
    }

    public function getRmtdkByJson($rs_rmrtdk_rmr = '', $name = '', $idEx = '')
    {
        header('Content-Type: application/json');
        header("Access-Control-Allow-Origin: *");

        // if ($name == "" || $idEx == "") {
        //     $this->data['data']['data'] = [];
        // } else {
        // }
        $this->data['data']['data'] =  $this->MdlRmrtdk->getAll($rs_rmrtdk_rmr);
        $no = 0;
        for ($i = 0; $i < count($this->data['data']['data']); $i++) {
            $no++;
            $this->data['data']['data'][$i]['no'] = $no;
            if ($this->data['data']['data'][$i]['rs_rmktdk_nm'] == "") {
                $this->data['data']['data'][$i]['rs_rmktdk_nm'] = "Tidak Ada Kategori";
            }
            $this->data['data']['data'][$i]['button'] = "<button class='btn bg-gradient-success' title='Tambahkan Tindakan Ke Layanan Pasien' data-dismiss='modal' onclick='addFill(\"" . $name . "\", \"" . $this->data['data']['data'][$i]['rs_rmtdk_nm'] . "\"); addFill(\"" . $idEx . "\", \"" . $this->data['data']['data'][$i]['rs_rmtdk_id_ex'] . "\"); destroyTdk(); closeModal(\"modalViewRmTdk\")'><i class='fas fa-check'></i></button>";

            $this->data['data']['data'][$i]['check'] = "<input type='checkbox' name='rs_rmplabt_rmtdk[]' id='rs_rmplabt_rmtdk" . $no . "' class='form-control' value='" . $this->data['data']['data'][$i]['rs_rmtdk_id_ex'] . "'/>";
        }

        return $this->respond($this->data['data'], 200);
    }

    public function insertData($rs_rmrtdk_rmr, $rs_rmrtdk_rmtdk)
    {
        if ($rs_rmrtdk_rmr === null || $rs_rmrtdk_rmr == '' || $rs_rmrtdk_rmtdk === null || $rs_rmrtdk_rmtdk == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'TIdak Ada ID Rujukan'];
        } else {
            $data = [
                'rs_rmrtdk_id_ex' => $this->MdlRmrtdk->getIdEx($this->Another_Include->getRandStr(4)),
                'rs_rmrtdk_rmr' => $rs_rmrtdk_rmr,
                'rs_rmrtdk_rmtdk' => $rs_rmrtdk_rmtdk,
            ];
            $this->data['Rmrtdk'] = $this->MdlRmrtdk->getAllByRmtdkAndRmr($rs_rmrtdk_rmr, $rs_rmrtdk_rmtdk);
            if (count($this->data['Rmrtdk']) > 0) {
                // $deleteData = $this->MdlPpr->deleteData($rs_ppr_ppeg);
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Tindakan Dalam Ruangan Ini Sudah Ada'];
            } else {
                $insertData = $this->MdlRmrtdk->insertData($data);

                if ($insertData) {
                    $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Tindakan Dalam Ruangan Berhasil Disimpan'];
                } else {
                    $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Tindakan Dalam Ruangan Tidak Dapat Disimpan'];
                }
            }
        }

        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmrtdk_id_ex = '')
    {
        if ($rs_rmrtdk_id_ex === null || $rs_rmrtdk_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlRmrtdk->deleteData($rs_rmrtdk_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data TIndakan Dalam Ruangan Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data TIndakan Dalam Ruangan Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }
}