<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\UmMdl;

class Setmnt extends BaseController
{
    use ResponseTrait;
    protected $MdlU;
    protected $Rmja;
    protected $AI;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_setmnt', 'rs_setmnt_id_ex');
        $this->Rmja = new Rmja();
        $this->AI = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeng',
            'pAct' => 'pAPeng',
            'cAct' => 'cArmref',
            'cmAct' => '',
            'scAct' => '',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA SETUP ANTRIAN';
        $this->data['PageTitle'] = 'Data Setup Antrian';
        $this->data['BasePage'] = 'setmnt';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData';
        $this->data['IdForm'] = 'setmntAddData';
        $this->data['UrlForm'] = 'setmnt';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);


        $this->data['Setmnt'] = $this->setDB();
        for ($i=0; $i < count($this->data['Setmnt']); $i++) { 
            if($this->data['Setmnt'][$i]['rs_setmnt_plh'] == "1")
            {
                $this->data['Setmnt'][$i]['rs_setmnt_plh'] = "YA";
            }else{
                $this->data['Setmnt'][$i]['rs_setmnt_plh'] = "TIDAK";
            }
        }

        echo view('Setmnt/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }

    public function getAll()
    {
        return $this->setDB('getAllByActAndPlh');
    }

    public function insertData()
    {
        
        $rs_setmnt_id_ex = $this->setDB('idEx', $this->AI->getRandStr(3));
        $rs_setmnt_rmr = $this->request->getPost('rs_setmnt_rmr');
        $rs_setmnt_plh = $this->request->getPost('rs_setmnt_plh');

       

        $data = [
            'rs_setmnt_id_ex' => $rs_setmnt_id_ex,
            'rs_setmnt_rmr' => $rs_setmnt_rmr,
            'rs_setmnt_plh' => $rs_setmnt_plh,

        ];

        $insertData = $this->MdlU->insertData($data);
        if ($insertData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Setup Permintaan Berhasil Disimpan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Setup Permintaan Tidak Dapat Disimpan'];
        }
        
        return $this->respond($data, $data['status']);
    }


    public function deleteData($rs_setmnt_id_ex = '')
    {
        if ($rs_setmnt_id_ex === null || $rs_setmnt_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlU->deleteData($rs_setmnt_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Setup Permintaan Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Setup Permintaan Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function block($rs_setmnt_id_ex = '')
    {
        $data = [
            'rs_setmnt_sts' => "0",
        ];
        $updateData = $this->MdlU->updateData($data, $rs_setmnt_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Status Setup Permintaan Berhasil Di Dinonaktifkan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Status Setup Permintaan Tidak Dapat Di Dinonaktifkan'];
        }
        return $this->respond($data, $data['status']);
    }

    public function unblock($rs_setmnt_id_ex = '')
    {
        $data = [
            'rs_setmnt_sts' => "1",
        ];
        $updateData = $this->MdlU->updateData($data, $rs_setmnt_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Status Setup Permintaan Berhasil Aktifkan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Status Setup Permintaan Tidak Dapat Aktifkan'];
        }
        return $this->respond($data, $data['status']);
    }


    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_setmnt_id_ex';
        $id = 'rs_setmnt_id';
        $length = 2;
        $typeGet = 'result';

        $fillUpdate = 'rs_setmnt_id_ex, rs_setmnt_rmr, rs_setmnt_plh';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [],
                //order by
                [
                    0 => ['id' => 'rs_setmnt_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmr', 'string' => 'rs_rmr.rs_rmr_id_ex = rs_setmnt.rs_setmnt_rmr', 'type' => 'LEFT'],
                ]
            );
        }elseif ($request == 'getAllByAct') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_setmnt_sts',
                        'idExV' => '1'
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_setmnt_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmr', 'string' => 'rs_rmr.rs_rmr_id_ex = rs_setmnt.rs_setmnt_rmr', 'type' => 'LEFT'],
                ]
            );
        }elseif ($request == 'getAllByActAndPlh') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_setmnt_sts',
                        'idExV' => '1'
                    ],
                    1 => [
                        'idEx' => 'rs_setmnt_plh',
                        'idExV' => '1'
                    ],
                ],
                //order by
                [
                    0 => ['id' => 'rs_setmnt_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmr', 'string' => 'rs_rmr.rs_rmr_id_ex = rs_setmnt.rs_setmnt_rmr', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_setmnt_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmr', 'string' => 'rs_rmr.rs_rmr_id_ex = rs_setmnt.rs_setmnt_rmr', 'type' => 'LEFT'],

                ]
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}
