<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\PsbMdl;
use App\Models\PspMdl;

class Psb extends BaseController
{
    use ResponseTrait;
    protected $MdlPsb;
    protected $MdlPsp;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlPsb = new PsbMdl();
        $this->MdlPsp = new PspMdl();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeg',
            'pAct' => 'pAPeg',
            'cAct' => 'cAPpeg',
            'cmAct' => '',
            'scAct' => '',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index($rs_psb_psp = false)
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }

        if ($rs_psb_psp === false) {
            return redirect()->to('/psp');
        }
        $this->data['rs_psb_psp'] = $rs_psb_psp;
        $this->data['Psp'] = $this->MdlPsp->getAllPsp($rs_psb_psp);
        $this->data['WebTitle'] = 'DATA STATUS BERKAS ' . $this->data['Psp']['rs_psp_nm'];
        $this->data['PageTitle'] = 'Data Status Berkas ' . $this->data['Psp']['rs_psp_nm'];
        $this->data['BasePage'] = 'psb';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData/' . $rs_psb_psp;
        $this->data['IdForm'] = 'psbAddData';
        $this->data['UrlForm'] = 'psb/' . $rs_psb_psp;

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);

        $this->data['Psb'] = $this->MdlPsb->getAllPsb($rs_psb_psp);

        echo view('Psb/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }

    public function editData($rs_psb_psp = '', $rs_psb_id_ex = '')
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }

        if ($rs_psb_psp === '') {
            return redirect()->to('/psp');
        }

        if ($rs_psb_id_ex === '') {
            return redirect()->to('/psb/' . $rs_psb_psp);
        }

        $this->data['rs_psb_psp'] = $rs_psb_psp;
        $this->data['Psp'] = $this->MdlPsp->getAllPsp($rs_psb_psp);
        if (empty($this->data['Psp'])) {
            return redirect()->to('/psp');
        }
        $this->data['WebTitle'] = 'DATA STATUS BERKAS KATEGORI ' . $this->data['Psp']['rs_psp_nm'];
        $this->data['PageTitle'] = 'Data Status Berkas Kategori ' . $this->data['Psp']['rs_psp_nm'];
        $this->data['BasePage'] = 'psb';
        $this->data['ButtonMethod'] = 'UBAH';
        $this->data['MethodForm'] = 'updateData/' . $rs_psb_psp;
        $this->data['IdForm'] = 'psbAddData';
        $this->data['UrlForm'] = 'psb/' . $rs_psb_psp;

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);

        $this->data['fillUpdate'] = $this->MdlPsb->getAllPsb($rs_psb_psp, $rs_psb_id_ex);
        $this->data['Psb'] = $this->MdlPsb->getAllPsb($rs_psb_psp);
        echo view('Psb/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
        echo view('Templates/loadData');
    }

    public function insertData($rs_psb_psp)
    {
        $rs_psb_id_ex = $this->Another_Include->getRandStr(5);
        $rs_psb_nm = $this->request->getPost('rs_psb_nm');

        $data = [
            'rs_psb_id_ex' => $rs_psb_id_ex,
            'rs_psb_psp' => $rs_psb_psp,
            'rs_psb_nm' => $rs_psb_nm,
        ];
        $insertData = $this->MdlPsb->insertData($data);
        if ($insertData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Status Berkas Pegawai Berhasil Disimpan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Status Berkas Pegawai Tidak Dapat Disimpan'];
        }
        return $this->respond($data, $data['status']);
    }

    public function updateData()
    {
        $rs_psb_nm = $this->request->getPost('rs_psb_nm');
        $rs_psb_id_ex = $this->request->getPost('rs_psb_id_ex');
        $data = [
            'rs_psb_nm' => $rs_psb_nm,

        ];
        $updateData = $this->MdlPsb->updateData($data, $rs_psb_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Status Berkas Pegawai Berhasil Diubah'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Status Berkas Pegawai Tidak Dapat Diubah'];
        }
        return $this->respond($data, $data['status']);
    }


    public function deleteData($rs_psb_id_ex = '')
    {
        if ($rs_psb_id_ex === null || $rs_psb_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlPsb->deleteData($rs_psb_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Status Berkas Pegawai Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Status Berkas Pegawai Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }
}
