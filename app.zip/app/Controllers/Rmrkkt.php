<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\RmrkkMdl;
use App\Models\RmrkktMdl;
use App\Models\RmrkMdl;
use App\Models\RmrMdl;
use App\Models\UmMdl;

class Rmrkkt extends BaseController
{
    use ResponseTrait;
    protected $MdlU;
    protected $MdlRmrkkt;
    protected $MdlRmrk;
    protected $MdlRmr;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_rmrkkt', 'rs_rmrkkt_id_ex');
        $this->MdlRmrkkt = new RmrkktMdl();
        $this->MdlRmrk = new RmrkMdl();
        $this->MdlRmr = new RmrMdl();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeng',
            'pAct' => 'pAPeng',
            'cAct' => 'cArmr',
            'cmAct' => '',
            'scAct' => '',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
    }

    public function getRmrkktByJson($rs_rmrk_rmr = '', $id = '', $v = '')
    {
        // header('Content-Type: application/json');
        // header("Access-Control-Allow-Origin: *");

        $this->data['data']['data'] =  $this->setDB('getAllByRmr', $rs_rmrk_rmr);
        $no = 0;
        for ($i = 0; $i < count($this->data['data']['data']); $i++) {
            $no++;
            $this->data['data']['data'][$i]['no'] = $no;

            $this->data['data']['data'][$i]['rs_rmrkkt_nm'] = $this->data['data']['data'][$i]['rs_rmr_nm'] . " / " . $this->data['data']['data'][$i]['rs_rmk_nm'] . ". " . $this->data['data']['data'][$i]['rs_rmrkk_nm'] . "-" . $this->data['data']['data'][$i]['rs_rmrkkt_nm'];

            $this->data['data']['data'][$i]['buttonFill'] = "<button type='button' data-dismiss='modal' class='btn btn-success' onclick='addFill(\"" . $id . "\", \"" . $this->data['data']['data'][$i]['rs_rmrkkt_id_ex'] . "\"); addFill(\"" . $v . "\", \"" . $this->data['data']['data'][$i]['rs_rmrkkt_nm'] . "\");'><i class='fa fa-check'></i></button>";
        }

        return $this->respond($this->data['data'], 200);
    }

    public function insertData()
    {
        $rs_rmrkkt_id_ex = $this->MdlRmrkkt->getIdEx($this->Another_Include->getRandStr(4));
        $rs_rmrkkt_rmrkk = $this->request->getPost('rs_rmrkkt_rmrkk');
        $rs_rmrkkt_nm = $this->request->getPost('rs_rmrkkt_nm');

        $data = [
            'rs_rmrkkt_id_ex' => $rs_rmrkkt_id_ex,
            'rs_rmrkkt_rmrkk' => $rs_rmrkkt_rmrkk,
            'rs_rmrkkt_nm' => $rs_rmrkkt_nm,
        ];

        $insertData = $this->MdlRmrkkt->insertData($data);
        if ($insertData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Tempat Tidur Dalam Ruangan Berhasil Disimpan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Tempat Tidur Dalam Ruangan Tidak Dapat Disimpan'];
        }

        return $this->respond($data, $data['status']);
    }



    public function blockRmrkkt($rs_rmrkkt_id_ex = '')
    {
        $data = [
            'rs_rmrkkt_sts' => "0",
        ];
        $updateData = $this->MdlRmrkkt->updateData($data, $rs_rmrkkt_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Tempat Tidur Dalam Ruangan Berhasil Di Dinonaktifkan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Tempat Tidur Dalam Ruangan Tidak Dapat Di Dinonaktifkan'];
        }
        return $this->respond($data, $data['status']);
    }

    public function unblockRmrkkt($rs_rmrkkt_id_ex = '')
    {
        $data = [
            'rs_rmrkkt_sts' => "1",
        ];
        $updateData = $this->MdlRmrkkt->updateData($data, $rs_rmrkkt_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Tempat Tidur Dalam Ruangan Berhasil Aktifkan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Tempat Tidur Dalam Ruangan Tidak Dapat Aktifkan'];
        }
        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmrkkt_id_ex';
        $id = 'rs_rmrkkt_id';
        $length = 3;
        $typeGet = 'result';

        $fillUpdate = 'rs_rmrkkt_id_ex';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [],
                //order by
                [
                    0 => ['id' => 'rs_rmrkkt_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'getAllByRmr') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmrk_rmr',
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmrkkt_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmrkk', 'string' => 'rs_rmrkk.rs_rmrkk_id_ex = rs_rmrkkt.rs_rmrkkt_rmrkk', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_rmrk', 'string' => 'rs_rmrk.rs_rmrk_id_ex = rs_rmrkk.rs_rmrkk_rmrk', 'type' => 'LEFT'],
                    2 => ['tableName' => 'rs_rmr', 'string' => 'rs_rmr.rs_rmr_id_ex = rs_rmrk.rs_rmrk_rmr', 'type' => 'LEFT'],
                    3 => ['tableName' => 'rs_rmk', 'string' => 'rs_rmk.rs_rmk_id_ex = rs_rmrk.rs_rmrk_rmk', 'type' => 'LEFT'],
                ],
                //like
                []
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmrkkt_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}