<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\RmpcpptdMdl;
use App\Models\RmpcpptMdl;
use App\Models\RmphMdl;
use App\Models\RmpmskMdl;

class Rmpcppt extends BaseController
{
    use ResponseTrait;
    protected $MdlRmpmsk;
    protected $MdlRmpcppt;
    protected $MdlRmpcpptd;
    protected $MdlRmph;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlRmpmsk = new RmpmskMdl();
        $this->MdlRmpcppt = new RmpcpptMdl();
        $this->MdlRmph = new RmphMdl();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOIgd',
            'pAct' => 'pAIgd',
            'cAct' => 'cArmpmsk',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {

        return redirect()->to('./rmpmsk');
    }

    public function insertData($rs_rmpcppt_rmpmsk)
    {
        $this->data['Rmpmsk'] = $this->MdlRmpmsk->getAllRmpmsk($rs_rmpcppt_rmpmsk);

        $rs_rmph_id_ex = $this->Another_Include->getRandStr(35);
        $rs_rmph_rmpp = $this->data['Rmpmsk']['rs_rmpmsk_rmpp'];
        $rs_rmph_ppeg = $this->data['rs_ppeg_id_ex'];
        $rs_rmph_jns = "CT";

        $rs_rmpcppt_id_ex = $this->MdlRmpcppt->getIdExRmpcppt($this->Another_Include->getRandStr(35));
        $rs_rmpcppt_tgl = $this->request->getPost('rs_rmpcppt_tgl');
        $rs_rmpcppt_jam = $this->request->getPost('rs_rmpcppt_jam');
        $rs_rmpcppt_s = $this->request->getPost('rs_rmpcppt_s');
        $rs_rmpcppt_o = $this->request->getPost('rs_rmpcppt_o');
        $rs_rmpcppt_a = $this->request->getPost('rs_rmpcppt_a');
        $rs_rmpcppt_p = $this->request->getPost('rs_rmpcppt_p');

        $dataRmpcppt = [
            'rs_rmpcppt_id_ex' => $rs_rmpcppt_id_ex,
            'rs_rmpcppt_rmpmsk' => $rs_rmpcppt_rmpmsk,
            'rs_rmpcppt_rmph' => $rs_rmph_id_ex,
            'rs_rmpcppt_ppeg' => $this->data['rs_ppeg_id_ex'],
            'rs_rmpcppt_tgl' => $rs_rmpcppt_tgl,
            'rs_rmpcppt_jam' => $rs_rmpcppt_jam,
            'rs_rmpcppt_s' => $rs_rmpcppt_s,
            'rs_rmpcppt_o' => $rs_rmpcppt_o,
            'rs_rmpcppt_a' => $rs_rmpcppt_a,
            'rs_rmpcppt_p' => $rs_rmpcppt_p,
        ];

        $dataRmph = [
            'rs_rmph_id_ex' => $rs_rmph_id_ex,
            'rs_rmph_rmpp' => $rs_rmph_rmpp,
            'rs_rmph_ppeg' => $rs_rmph_ppeg,
            'rs_rmph_jns' => $rs_rmph_jns
        ];

        $insertDataRmph = $this->MdlRmph->insertData($dataRmph);
        if ($insertDataRmph) {
            $insertDataRmpcppt = $this->MdlRmpcppt->insertData($dataRmpcppt);
            if ($insertDataRmpcppt) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data CPPT Pasien Berhasil Disimpan'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data CPPT Pasien Tidak Dapat Disimpan'];
            }
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Histori Pasien Tidak Dapat Disimpan'];
        }



        return $this->respond($data, $data['status']);
    }

    public function updateData()
    {
        $rs_rmpcppt_tgl = $this->request->getPost('rs_rmpcppt_tgl');
        $rs_rmpcppt_id_ex = $this->request->getPost('rs_rmpcppt_id_ex');
        $data = [
            'rs_rmpcppt_tgl' => $rs_rmpcppt_tgl,
        ];
        $updateData = $this->MdlRmpcppt->updateData($data, $rs_rmpcppt_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data CPPT Pasien Berhasil Diubah'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data CPPT Pasien Tidak Dapat Diubah'];
        }
        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmpcppt_id_ex = '')
    {
        if ($rs_rmpcppt_id_ex === null || $rs_rmpcppt_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlRmpcppt->deleteData($rs_rmpcppt_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data CPPT Pasien Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data CPPT Pasien Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }
}
