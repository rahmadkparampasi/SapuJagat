<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\RmrMdl;

class Rmps extends BaseController
{
    use ResponseTrait;
    protected $MdlRmr;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlRmr = new RmrMdl();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
        ];
    }

    public function index()
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA RUANGAN';
        $this->data['PageTitle'] = 'Data Ruangan';
        $this->data['BasePage'] = 'rmr';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData';
        $this->data['IdForm'] = 'rmrAddData';
        $this->data['UrlForm'] = 'rmr';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);
        $this->data['Rmr'] = $this->MdlRmr->getAllRmr();

        echo view('Rmr/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }

    public function editData($rs_rmr_id_ex = '')
    {
        // if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
        //     return redirect()->to('./msk');
        // }
        $this->data['WebTitle'] = 'DATA RUANGAN';
        $this->data['PageTitle'] = 'Data Ruangan';
        $this->data['BasePage'] = 'rmr';
        $this->data['ButtonMethod'] = 'UBAH';
        $this->data['MethodForm'] = 'updateData/' . $rs_rmr_id_ex;
        $this->data['IdForm'] = 'rmrAddData';
        $this->data['UrlForm'] = 'rmr';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);


        $this->data['Rmr'] = $this->MdlRmr->getAllRmr();
        if ($rs_rmr_id_ex === null || $rs_rmr_id_ex == '') {
            return redirect()->to('/' . $this->data['BasePage']);
        } else {
            $this->data['fillUpdate'] = $this->MdlRmr->getAllRmr($rs_rmr_id_ex);

            echo view('Rmr/index', $this->data);
            echo view('Templates/anotherScript');
            echo view('Templates/ajaxInsert', $this->data);
            echo view('Templates/loadData');
        }
    }

    public function insertData()
    {

        $rs_rmr_id_ex = $this->Another_Include->getRandStr(7);
        $rs_rmr_nm = $this->request->getPost('rs_rmr_nm');
        $rs_rmr_k = $this->request->getPost('rs_rmr_k');

        $data = [
            'rs_rmr_id_ex' => $rs_rmr_id_ex,
            'rs_rmr_nm' => $rs_rmr_nm,
            'rs_rmr_k' => $rs_rmr_k,
        ];

        $insertData = $this->MdlRmr->insertData($data);
        if ($insertData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Ruangan Berhasil Disimpan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Ruangan Tidak Dapat Disimpan'];
        }

        return $this->respond($data, $data['status']);
    }

    public function updateData($rs_rmr_id_ex = '')
    {
        $rs_rmr_nm = $this->request->getPost('rs_rmr_nm');
        $rs_rmr_k = $this->request->getPost('rs_rmr_k');
        $rs_rmr_id_ex = $this->request->getPost('rs_rmr_id_ex');
        $data = [
            'rs_rmr_nm' => $rs_rmr_nm,
            'rs_rmr_k' => $rs_rmr_k,
        ];
        $updateData = $this->MdlRmr->updateData($data, $rs_rmr_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Ruangan Berhasil Diubah'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Ruangan Tidak Dapat Diubah'];
        }
        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmr_id_ex = '')
    {
        if ($rs_rmr_id_ex === null || $rs_rmr_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlRmr->deleteData($rs_rmr_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Ruangan Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Ruangan Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }
}