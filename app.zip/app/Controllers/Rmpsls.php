<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\RmpmskMdl;
use App\Models\UmMdl;

class Rmpsls extends BaseController
{
    use ResponseTrait;
    protected $MdlRmpmsk;
    protected $MdlU;
    protected $Rmph;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlRmpmsk = new RmpmskMdl();
        $this->MdlU = new UmMdl('rs_rmpsls', 'rs_rmpsls_id_ex');
        $this->Rmph = new Rmph();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOIgd',
            'pAct' => 'pAIgd',
            'cAct' => 'cArmpmsk',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {

        return redirect()->to('./rmpmsk');
    }

    public function getAll($rs_rmpsls_rmpmsk)
    {
        $data = $this->setDB('getAll', $rs_rmpsls_rmpmsk);
        $data = $this->Another_Include->changeDateWF($data, ['rs_rmpsls_tgl']);

        return $data;
    }

    public function insertData($rs_rmpsls_rmpmsk)
    {
        $this->data['Rmpmsk'] = $this->MdlRmpmsk->getAllRmpmsk($rs_rmpsls_rmpmsk);

        $insertDataRmph = $this->Rmph->iDH($this->data['Rmpmsk']['rs_rmpmsk_rmpp'], "CT");
        if ($insertDataRmph[0]) {
            $rs_rmpsls_id_ex = $this->setDB('idEx', $this->Another_Include->getRandStr(10));
            $rs_rmpsls_tgl = $this->request->getPost('rs_rmpsls_tgl');
            $rs_rmpsls_jam = $this->request->getPost('rs_rmpsls_jam');
            $rs_rmpsls_ket = $this->request->getPost('rs_rmpsls_ket');

            $dataRmpsls = [
                'rs_rmpsls_id_ex' => $rs_rmpsls_id_ex,
                'rs_rmpsls_rmpmsk' => $rs_rmpsls_rmpmsk,
                'rs_rmpsls_rmph' => $insertDataRmph[1],
                'rs_rmpsls_tgl' => $rs_rmpsls_tgl,
                'rs_rmpsls_jam' => $rs_rmpsls_jam,
                'rs_rmpsls_ket' => $rs_rmpsls_ket,
            ];
            $dataRmpmsk = [
                'rs_rmpmsk_plg' => '1'
            ];
            $updateDataRmpmsk = $this->MdlRmpmsk->updateData($dataRmpmsk, $rs_rmpsls_rmpmsk);
            if ($updateDataRmpmsk) {
                $insertDataRmpsls = $this->MdlU->insertData($dataRmpsls);
                if ($insertDataRmpsls) {
                    $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Pasien Berhasil Diproses'];
                } else {
                    $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Selesai Pasien Tidak Dapat Disimpan'];
                }
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Pasien Masuk Pasien Tidak Dapat Disimpan'];
            }
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Histori Pasien Tidak Dapat Disimpan'];
        }
        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmpsls_id_ex = '')
    {
        if ($rs_rmpsls_id_ex === null || $rs_rmpsls_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlU->deleteData($rs_rmpsls_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Selesai Pasien Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Selesai Pasien Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmpsls_id_ex';
        $id = 'rs_rmpsls_id';
        $length = 4;
        $typeGet = 'result';

        $fillUpdate = '*';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmpsls_rmpmsk',
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpsls_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpsls_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}