<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\RmrMdl;
use App\Models\UmMdl;

class Rmrrmb extends BaseController
{
    use ResponseTrait;
    protected $MdlU;
    protected $Rmb;
    protected $MdlRmr;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_rmrrmb', 'rs_rmrrmb_id');
        $this->Rmb = new Rmb;
        $this->MdlRmr = new RmrMdl();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeng',
            'pAct' => 'pAPeng',
            'cAct' => 'cArmr',
            'cmAct' => '',
            'scAct' => '',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
    }

    public function viewJByRmr($rs_rmrrmb_rmr)
    {
        if ($rs_rmrrmb_rmr == '') {
            echo "<span class='badge badge-danger'>Tidak Ada Daftar Obat Dalam Ruangan</span>";
        } else {
            $this->data['rs_rmrrmb_rmr'] = $rs_rmrrmb_rmr;
            $this->data['Rmr'] = $this->MdlRmr->getAllRmr($rs_rmrrmb_rmr);
            $this->data['WebTitle'] = 'DATA OBAT DALAM DEPO ' . strtoupper($this->data['Rmr']['rs_rmr_nm']);
            $this->data['PageTitle'] = 'Data Obat Dalam Depo ' . $this->data['Rmr']['rs_rmr_nm'];
            $this->data['BasePage'] = 'rmrrmb';
            $this->data['ButtonMethod'] = 'SIMPAN';
            $this->data['MethodForm'] = 'insertView/' . $rs_rmrrmb_rmr;
            $this->data['IdForm'] = 'rmrrmbAddData';
            $this->data['UrlForm'] = 'rmrrmb';
            $this->data['Rmrrmb'] = $this->setDB('getAll', $rs_rmrrmb_rmr);
            echo view('Rmrrmb/indexD', $this->data);
            echo view('Templates/ajaxInsert', $this->data);
        }
    }

    public function viewData($rs_rmrtdk_rmr = '')
    {
        if ($rs_rmrtdk_rmr == '') {
            echo "<span class='badge badge-danger'>Tidak Ada Daftar Obat Dalam Ruangan</span>";
        } else {
            $this->data['rs_rmrtdk_rmr'] = $rs_rmrtdk_rmr;
            $this->data['Rmr'] = $this->MdlRmr->getAllRmr($rs_rmrtdk_rmr);
            $this->data['WebTitle'] = 'DATA OBAT DALAM RUANGAN ' . strtoupper($this->data['Rmr']['rs_rmr_nm']);
            $this->data['PageTitle'] = 'Data Obat Dalam Ruangan ' . $this->data['Rmr']['rs_rmr_nm'];
            $this->data['BasePage'] = 'rmrrmb';
            $this->data['ButtonMethod'] = 'SIMPAN';
            $this->data['MethodForm'] = 'insertView/' . $rs_rmrtdk_rmr;
            $this->data['IdForm'] = 'rmrrmbAddData';
            $this->data['UrlForm'] = 'rmrrmb';
            $this->data['Rmrrmb'] = $this->setDB('getAll', $rs_rmrtdk_rmr);
            echo view('Rmrrmb/index', $this->data);
            echo view('Templates/ajaxInsert', $this->data);
        }
    }

    public function getAll($rs_rmr_id_ex)
    {
        return $this->setDB('getAllByRmr', $rs_rmr_id_ex);
    }
    public function getByRmrAndRmb($rs_rmrrmb_rmr, $rs_rmrrmb_rmb)
    {
        return $this->setDB('getByRmrAndRmb', [$rs_rmrrmb_rmr, $rs_rmrrmb_rmb]);
    }

    public function getAllForSelectByRmr($rs_rmr_id_ex)
    {
        header('Content-Type: application/json');
        header("Access-Control-Allow-Origin: *");

        $data = $this->setDB('getAllByRmr', $rs_rmr_id_ex);
        for ($i = 0; $i < count($data); $i++) {
            $data[$i]['optText'] = $data[$i]['rs_rmb_nm'];
            $data[$i]['optValue'] = $data[$i]['rs_rmb_id_ex'];
        }
        return $this->respond($data, 200);
    }

    public function getRmbByJson($rs_rmrtdk_rmr = '', $name = '', $idEx = '')
    {
        header('Content-Type: application/json');
        header("Access-Control-Allow-Origin: *");

        $this->data['data']['data'] =  $this->setDB('getAllByRmr', $rs_rmrtdk_rmr);
        $no = 0;
        for ($i = 0; $i < count($this->data['data']['data']); $i++) {
            $no++;
            $this->data['data']['data'][$i]['no'] = $no;

            $this->data['data']['data'][$i]['button'] = "<button class='btn bg-gradient-success' title='Tambahkan Obat Ke E-Resep Pasien' data-dismiss='modal' onclick='addFill(\"" . $name . "\", \"" . $this->data['data']['data'][$i]['rs_rmb_nm'] . "\"); addFill(\"" . $idEx . "\", \"" . $this->data['data']['data'][$i]['rs_rmb_id_ex'] . "\"); destroyRmb(); closeModal(\"modalViewRmRmb\")'><i class='fas fa-check'></i></button>";

            $this->data['data']['data'][$i]['check'] = "<input type='checkbox' name='" . $name . "[]' id='rs_rmpresnr_rmb" . $no . "' class='form-control' value='" . $this->data['data']['data'][$i]['rs_rmb_id_ex'] . "'/>";
        }

        return $this->respond($this->data['data'], 200);
    }

    public function insertData($rs_rmrrmb_rmr, $rs_rmrrmb_rmb)
    {
        if ($rs_rmrrmb_rmr === null || $rs_rmrrmb_rmr == '' || $rs_rmrrmb_rmb === null || $rs_rmrrmb_rmb == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'TIdak Ada ID Rujukan'];
        } else {
            $data = [
                'rs_rmrrmb_rmr' => $rs_rmrrmb_rmr,
                'rs_rmrrmb_rmb' => $rs_rmrrmb_rmb,
            ];
            $this->data['Rmrrmb'] = $this->setDB('getAllByRmbAndRmr', [$rs_rmrrmb_rmr, $rs_rmrrmb_rmb]);
            if (count($this->data['Rmrrmb']) > 0) {
                // $deleteData = $this->MdlPpr->deleteData($rs_ppr_ppeg);
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Barang Dalam Ruangan Ini Sudah Ada'];
            } else {
                $insertData = $this->MdlU->insertData($data);

                if ($insertData) {
                    $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Barang Dalam Ruangan Berhasil Disimpan'];
                } else {
                    $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Barang Dalam Ruangan Tidak Dapat Disimpan'];
                }
            }
        }

        return $this->respond($data, $data['status']);
    }
    public function updateData($data, $rs_rmrrmb_id)
    {
        return $this->MdlU->updateData($data, $rs_rmrrmb_id);
    }

    public function insertDataAll($rs_rmrrmb_rmr = '')
    {
        $this->data['Rmb'] = $this->Rmb->getAll();
        $success = 0;
        $error = 0;
        $data = [];
        for ($i = 1; $i < count($this->data['Rmb']); $i++) {
            
            $data = [
                'rs_rmrrmb_rmr' => $rs_rmrrmb_rmr,
                'rs_rmrrmb_rmb' => $this->data['Rmb'][$i]['rs_rmb_id_ex'],
            ];
            $this->data['Rmrrmb'] = $this->setDB('getAllByRmbAndRmr', [$rs_rmrrmb_rmr, $this->data['Rmb'][$i]['rs_rmb_id_ex']]);
            if (count($this->data['Rmrrmb']) > 0) {
                // $deleteData = $this->MdlPpr->deleteData($rs_ppr_ppeg);
                $error += 1;
            } else {
                $insertData = $this->MdlU->insertData($data);
                if ($insertData) {
                    $success += 1;
                } else {
                    $error += 1;
                }
            }    
        }

        // dd($sheet);


        // dd($sheet, $data);
        $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Berhasil Diproses, Dengan Data Yang Berhasil Berjumlah ' . (string)$success . ' Data, Dan Yang Tidak Berhasil Berjumlah ' . (string)$error . ' Data'];
        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmrrmb_id = '')
    {
        if ($rs_rmrrmb_id === null || $rs_rmrrmb_id == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlU->deleteData($rs_rmrrmb_id);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Barang Dalam Ruangan Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Barang Dalam Ruangan Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmrrmb_id';
        $id = 'rs_rmrrmb_id';
        $length = 2;
        $typeGet = 'result';

        $fillUpdate = 'rs_rmrrmb_id, rs_rmrrmb_rmr, rs_rmrrmb_rmb';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => ['idEx' => 'rs_rmrrmb_rmr', 'idExV' => $data]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmrrmb_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmb', 'string' => 'rs_rmb.rs_rmb_id_ex = rs_rmrrmb.rs_rmrrmb_rmb', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_rmgz', 'string' => 'rs_rmgz.rs_rmgz_id_ex = rs_rmb.rs_rmb_rmgz', 'type' => 'LEFT'],
                    2 => ['tableName' => 'rs_rmmrk', 'string' => 'rs_rmmrk.rs_rmmrk_id_ex = rs_rmb.rs_rmb_rmmrk', 'type' => 'LEFT'],
                    3 => ['tableName' => 'rs_rmjk', 'string' => 'rs_rmjk.rs_rmjk_id_ex = rs_rmb.rs_rmb_rmjk', 'type' => 'LEFT'],
                    4 => ['tableName' => 'rs_rmst', 'string' => 'rs_rmst.rs_rmst_id_ex = rs_rmb.rs_rmb_rmst', 'type' => 'LEFT'],
                    5 => ['tableName' => 'rs_rmpyd', 'string' => 'rs_rmpyd.rs_rmpyd_id_ex = rs_rmb.rs_rmb_rmpyd', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'getAllByRmbAndRmr') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => ['idEx' => 'rs_rmrrmb_rmr', 'idExV' => $data[0]],
                    1 => ['idEx' => 'rs_rmrrmb_rmb', 'idExV' => $data[1]],
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmrrmb_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'getAllByRmr') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => ['idEx' => 'rs_rmrrmb_rmr', 'idExV' => $data],
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmrrmb_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmb', 'string' => 'rs_rmb.rs_rmb_id_ex = rs_rmrrmb.rs_rmrrmb_rmb', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_rmjk', 'string' => 'rs_rmjk.rs_rmjk_id_ex = rs_rmb.rs_rmb_rmjk', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'getByRmrAndRmb') {
            return $this->MdlU->getAll(
                //type result / row
                'row',
                // select *
                '*',
                //where
                [
                    0 => ['idEx' => 'rs_rmrrmb_rmr', 'idExV' => $data[0]],
                    1 => ['idEx' => 'rs_rmrrmb_rmb', 'idExV' => $data[1]],
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmrrmb_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmb', 'string' => 'rs_rmb.rs_rmb_id_ex = rs_rmrrmb.rs_rmrrmb_rmb', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_rmjk', 'string' => 'rs_rmjk.rs_rmjk_id_ex = rs_rmb.rs_rmb_rmjk', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmrrmb_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}