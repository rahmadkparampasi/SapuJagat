<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\UmMdl;

class Rmplabtw extends BaseController
{
    use ResponseTrait;

    protected $MdlU;
    protected $Rmplabt;
    protected $Rmplabtwp;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_rmplabtw', 'rs_rmplabtw_id_ex');
        $this->Rmplabt = new Rmplabt;
        $this->Rmplabtwp = new Rmplabtwp;
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOIgd',
            'pAct' => 'pAIgd',
            'cAct' => 'cArmpmsk',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {

        return redirect()->to('./rmpmsk');
    }

    public function viewData($rs_rmplabtw_rmplabt = '', $rs_rmplab_tgl = '', $rs_rmplab_jam = '', $rs_rmtdk_nm = '')
    {
        if ($rs_rmplabtw_rmplabt == '') {
            echo "<span class='badge badge-danger'>Tidak Ada Daftar Tindakan Yang Dimaksud</span>";
        } else {
            $this->data['rs_rmplabtw_rmplabt'] = $rs_rmplabtw_rmplabt;
            $this->data['rs_rmplab_tgl'] = $rs_rmplab_tgl;
            $this->data['rs_rmplab_jam'] = $rs_rmplab_jam;
            $this->data['rs_rmtdk_nm'] = $rs_rmtdk_nm;
            $this->data['WebTitle'] = 'DAFTAR ORDER LABORATORIUM, TANGGAL ORDER : ' . strtoupper( $rs_rmplab_tgl . ', JAM ORDER : ' . $rs_rmplab_jam. ', DOKTER : ' . $rs_rmtdk_nm);
            $this->data['PageTitle'] = 'Daftar Order Laboratorium, Tanggal Order : ' . $rs_rmplab_tgl . ', Jam Order : ' . $rs_rmplab_jam. ', Dokter : ' . $rs_rmtdk_nm;
            $this->data['BasePage'] = 'rmplabtw';
            $this->data['ButtonMethod'] = 'SIMPAN';
            $this->data['MethodForm'] = 'insertView/' . $rs_rmplabtw_rmplabt;
            $this->data['IdForm'] = 'rmplabtwAddData';
            $this->data['UrlForm'] = 'rmplabtw';
            $this->data['Rmplabtw'] = $this->setDB('getAll', $rs_rmplabtw_rmplabt);
            for ($i=0; $i < count($this->data['Rmplabtw']); $i++) { 
                $this->data['Rmplabtw'][$i]['Rmplabtwp'] = $this->Rmplabtwp->getAll($this->data['Rmplabtw'][$i]['rs_rmplabtw_id_ex']);
            }
            echo view('Rmplabtw/index', $this->data);
        }
    }

    public function getAll($rs_rmplabtw_rmplabt)
    {
        $this->data['Rmplabtw'] = $this->setDB('getAll', $rs_rmplabtw_rmplabt);

        return  $this->data['Rmplabtw'];
    }
    

    public function insertView($rs_rmplabtw_rmplabt)
    {
        $rs_rmplabtw_tgl = $this->request->getPost('rs_rmplabtw_tgl');
        $rs_rmplabtw_jam = $this->request->getPost('rs_rmplabtw_jam');
        

        $data = [
            'rs_rmplabtw_id_ex' => $this->setDB('idEx', $this->Another_Include->getRandStr(9)),
            'rs_rmplabtw_rmplabt' => $rs_rmplabtw_rmplabt,
            'rs_rmplabtw_tgl' => $rs_rmplabtw_tgl,
            'rs_rmplabtw_jam' => $rs_rmplabtw_jam,
        ];
        $dataRmplabt = [
            'rs_rmplabt_stj' => '1'
        ];

        
        $updateDataRmplabt = $this->Rmplabt->MdlU->updateData($dataRmplabt, $rs_rmplabtw_rmplabt);
        if ($updateDataRmplabt) {
            $insertDataupdateDataRmplabtw = $this->MdlU->insertData($data);
            if ($insertDataupdateDataRmplabtw) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Waktu Pemberian Tindakan Pasien Berhasil Disimpan'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Waktu Pemberian Tindakan Pasien Tidak Dapat Disimpan'];
            }
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Pasien Masuk Pasien Tidak Dapat Disimpan'];
        }

        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmplabtw_id_ex = '')
    {
        if ($rs_rmplabtw_id_ex === null || $rs_rmplabtw_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlU->deleteData($rs_rmplabtw_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Waktu Pemberian Tindakan Pasien Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Waktu Pemberian Tindakan Pasien Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmplabtw_id_ex';
        $id = 'rs_rmplabtw_id';
        $length = 3;
        $typeGet = 'result';

        $fillUpdate = '*';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmplabtw_rmplabt',
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmplabtw_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmplabt', 'string' => 'rs_rmplabt.rs_rmplabt_id_ex = rs_rmplabtw.rs_rmplabtw_rmplabt', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_rmplab', 'string' => 'rs_rmplab.rs_rmplab_id_ex = rs_rmplabt.rs_rmplabt_rmplab', 'type' => 'LEFT'],
                ]
            );
        }elseif ($request == 'getAllByRmpmsk') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmplab_rmpmsk',
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmplabt_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmplab', 'string' => 'rs_rmplab.rs_rmplab_id_ex = rs_rmplabt.rs_rmplabt_rmplab', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_ppeg', 'string' => 'rs_ppeg.rs_ppeg_id_ex = rs_rmplab.rs_rmplab_ppeg', 'type' => 'LEFT'],
                    2 => ['tableName' => 'rs_rmtdk', 'string' => 'rs_rmtdk.rs_rmtdk_id_ex = rs_rmplabt.rs_rmplabt_rmtdk', 'type' => 'LEFT'],
                    3 => ['tableName' => 'rs_rmktdk', 'string' => 'rs_rmktdk.rs_rmktdk_id_ex = rs_rmtdk.rs_rmtdk_rmktdk', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'getAllByRmplabAndTdk') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmplabt_rmplab',
                        'idExV' => $data[0]
                    ],
                    1 => [
                        'idEx' => 'rs_rmplabt_rmtdk',
                        'idExV' => $data[1]
                    ]
                ],
                //order by
                [],
                //join
                []
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmplabt_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}