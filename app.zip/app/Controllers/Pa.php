<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\PaMdl;
use App\Models\PpiMdl;
use App\Models\PpsMdl;
use App\Models\PpegMdl;
use App\Models\PpsbbMdl;
use App\Models\PsbbMdl;
use App\Models\PspMdl;
use App\Models\PpsbMdl;
use App\Models\PsbMdl;
use App\Models\PkpMdl;
use App\Models\PkbbMdl;
use App\Models\PpkbbMdl;
use App\Models\UmMdl;

class Pa extends BaseController
{
    use ResponseTrait;
    protected $MdlU;
    protected $MdlPa;
    protected $MdlPpi;
    protected $MdlPps;
    protected $Ppeg;
    protected $MdlPpeg;
    protected $MdlPpsbb;
    protected $MdlPsbb;
    protected $MdlPsp;
    protected $MdlPpsb;
    protected $MdlPsb;
    protected $MdlPkp;
    protected $MdlPkbb;
    protected $MdlPpkbb;
    protected $Rmag;
    protected $Rmgd;
    protected $Rmsts;

    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_pa', 'rs_pa_id_ex');
        $this->MdlPpeg = new PpegMdl();
        $this->MdlPa = new PaMdl();
        $this->MdlPpi = new PpiMdl();
        $this->MdlPps = new PpsMdl();
        $this->MdlPpsbb = new PpsbbMdl();
        $this->MdlPsbb = new PsbbMdl();
        $this->MdlPsp = new PspMdl();
        $this->MdlPpsb = new PpsbMdl();
        $this->MdlPsb = new PsbMdl();
        $this->MdlPkp = new PkpMdl();
        $this->MdlPkbb = new PkbbMdl();
        $this->MdlPpkbb = new PpkbbMdl();
        $this->Rmag = new Rmag();
        $this->Rmgd = new Rmgd();
        $this->Rmsts = new Rmsts();

        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPa',
            'pAct' => 'pAPa',
            'cAct' => '',
            'cmAct' => '',
            'scAct' => '',


            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }


    public function index()
    {
        $this->Ppeg = new Ppeg();

        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA PROFIL PEGAWAI';
        $this->data['PageTitle'] = 'Data Profil Pegawai';
        $this->data['BasePage'] = 'pa';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData';
        $this->data['IdForm'] = 'paAddData';
        $this->data['UrlForm'] = 'pa';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);

        $this->data['Ppeg'] = $this->Ppeg->getByIdEx($this->data['rs_ppeg_id_ex']);
        $this->data['Psbb'] = $this->MdlPsbb->getAllPsbb($this->data['Ppeg']['rs_ppeg_psp']);
        $this->data['Psb'] = $this->MdlPsb->getAllPsb($this->data['Ppeg']['rs_ppeg_psp']);
        $this->data['Pkbb'] = $this->MdlPkbb->getAllPkbb($this->data['Ppeg']['rs_ppeg_pkp']);

        $this->data['PpegU'] = $this->MdlPpeg->getPpegByIdEx($this->data['rs_ppeg_id_ex']);
        $this->data['Ppi'] = $this->MdlPpi->getAllPpi($this->data['rs_ppeg_id_ex']);
        $this->data['Pps'] = $this->MdlPps->getAllPps($this->data['rs_ppeg_id_ex']);
        $this->data['Psp'] = $this->MdlPsp->getAllPsp($this->data['rs_ppeg_id_ex']);
        $this->data['Ppsbb'] = $this->MdlPpsbb->getAllPpsbb($this->data['rs_ppeg_id_ex']);
        $this->data['Ppsb'] = $this->MdlPpsb->getAllPpsb($this->data['rs_ppeg_id_ex']);
        $this->data['Pkp'] = $this->MdlPkp->getAllPkp($this->data['rs_ppeg_id_ex']);
        $this->data['Ppkbb'] = $this->MdlPpkbb->getAllPpkbb($this->data['rs_ppeg_id_ex']);
        $this->data['Rmag'] = $this->Rmag->getAll();
        $this->data['Rmgd'] = $this->Rmgd->getAll();
        $this->data['Rmsts'] = $this->Rmsts->getAll();


        $this->data['d'] = (string)date('d', strtotime($this->data['Ppeg']['rs_ppeg_tgl_lhr']));
        $this->data['F'] = (string)date('F', strtotime($this->data['Ppeg']['rs_ppeg_tgl_lhr']));
        $this->data['F'] = $this->Another_Include->monthConv($this->data['F']);
        $this->data['Y'] = (string)date('Y', strtotime($this->data['Ppeg']['rs_ppeg_tgl_lhr']));
        $this->data['Ppeg']['rs_ppeg_tgl_lhr'] = strtoupper($this->data['d'] . " " . $this->data['F'] . " " . $this->data['Y']);


        if ($this->data['Ppeg']['rs_ppeg_jk'] == "L") {
            $this->data['Ppeg']['rs_ppeg_jk'] = "LAKI-LAKI";
        } else {
            $this->data['Ppeg']['rs_ppeg_jk'] = "PEREMPUAN";
        }

        if ($this->data['Ppeg']['rs_ppeg_nmd'] != "") {
            $this->data['Ppeg']['rs_ppeg_nm'] = ". " . $this->data['Ppeg']['rs_ppeg_nm'];
        }

        if ($this->data['Ppeg']['rs_ppeg_nmb'] != "") {
            $this->data['Ppeg']['rs_ppeg_nm'] = $this->data['Ppeg']['rs_ppeg_nm'] . ", ";
        }

        

        


        $this->data['Ppeg']['rs_ppeg_nm'] = $this->data['Ppeg']['rs_ppeg_nmd'] . $this->data['Ppeg']['rs_ppeg_nm'] . $this->data['Ppeg']['rs_ppeg_nmb'];

        echo view('Pa/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }


    public function changeFotoPeg($rs_ppeg_id_ex = '')
    {
        $validated = $this->validate([
            'rs_ppeg_pic' => 'uploaded[rs_ppeg_pic]|mime_in[rs_ppeg_pic,image/jpg,image/jpeg,image/gif,image/png]|max_size[rs_ppeg_pic,2048]'
        ]);
        if ($rs_ppeg_id_ex === null || $rs_ppeg_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            if ($validated == FALSE) {
                // Kembali ke function index supaya membawa data uploads dan validasi
                $data = ['status' => 415, 'response' => "error", 'message' => 'Gambar Yang Diunggah Tidak Sesuai Spesifikasi'];
            } else {
                $rs_ppeg_pic = $this->request->getFile('rs_ppeg_pic');
                $new_rs_ppeg_pic = "pic-pegawai-" . $rs_ppeg_id_ex . "-" . date("YmdHis") . "." . $rs_ppeg_pic->getClientExtension();
                $data = [
                    'rs_ppeg_pic' => $new_rs_ppeg_pic
                ];
                $updateData = $this->MdlPpeg->updateData($data, $rs_ppeg_id_ex);
                if ($updateData) {
                    $rs_ppeg_pic->move('uploads', $new_rs_ppeg_pic);
                    $data = ['status' => 200, 'response' => 'success', 'message' => 'Foto Peserta Berhasil Diubah'];
                    $this->session->set('rs_ppeg_pic', $new_rs_ppeg_pic);
                } else {
                    $data = ['status' => 400, 'response' => 'error', 'message' => 'Foto Peserta Tidak Dapat Diubah'];
                }
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function insertData($data = [])
    {
        $rs_pa_id_ex = $this->setDB('idEx', $this->Another_Include->getRandStr(12));
        $data['rs_pa_id_ex'] = $rs_pa_id_ex;

        return $this->MdlU->insertData($data);
        
    }


    public function insertDataPpi()
    {
        $validated = $this->validate([
            'rs_ppi_fl' => 'uploaded[rs_ppi_fl]|mime_in[rs_ppi_fl,application/msword,application/vnd.ms-office,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/zip,application/msword,application/x-zip,application/pdf,application/force-download,application/x-download,binary/octet-stream,text/html,text/plain]|max_size[rs_ppi_fl,2048]'
        ]);
        if ($validated == FALSE) {
            // Kembali ke function index supaya membawa data uploads dan validasi
            $data = ['status' => 415, 'response' => "error", 'message' => 'Dokumen Yang Diunggah Tidak Sesuai Spesifikasi'];
        } else {
            $rs_ppi_id_ex = $this->Another_Include->getRandStr(20);


            $rs_ppi_t = $this->request->getPost('rs_ppi_t');
            $rs_ppi_msk = $this->request->getPost('rs_ppi_msk');
            $rs_ppi_klr = $this->request->getPost('rs_ppi_klr');
            $rs_ppi_inst = $this->request->getPost('rs_ppi_inst');
            $rs_ppi_nmr = $this->request->getPost('rs_ppi_nmr');
            $rs_ppi_ket = $this->request->getPost('rs_ppi_ket');

            $rs_ppi_fl = $this->request->getFile('rs_ppi_fl');
            $new_rs_ppi_fl = "Ppi-" . $rs_ppi_id_ex . "-"  . date("YmdHis") . "." . $rs_ppi_fl->getClientExtension();

            $data = [
                'rs_ppi_id_ex' => $rs_ppi_id_ex,
                'rs_ppi_ppeg' =>  $this->data['rs_ppeg_id_ex'],

                'rs_ppi_t' => $rs_ppi_t,
                'rs_ppi_msk' => $rs_ppi_msk,
                'rs_ppi_klr' => $rs_ppi_klr,
                'rs_ppi_inst' => $rs_ppi_inst,
                'rs_ppi_nmr' => $rs_ppi_nmr,
                'rs_ppi_ket' => $rs_ppi_ket,

                'rs_ppi_fl' => $new_rs_ppi_fl
            ];
            $insertData = $this->MdlPpi->insertData($data);
            if ($insertData) {
                $rs_ppi_fl->move('uploads', $new_rs_ppi_fl);
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Pendidikan Pegawai Berhasil Disimpan'];
            } else {
                $data = ['status' => 400, 'response' => 'error', 'message' => 'Data Pendidikan Pegawai Tidak Dapat Disimpan'];
            }
        }
        return $this->respond($data, $data['status']);
    }


    public function insertDataPps()
    {
        $validated = $this->validate([
            'rs_pps_fl' => 'uploaded[rs_pps_fl]|mime_in[rs_pps_fl,application/msword,application/vnd.ms-office,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/zip,application/msword,application/x-zip,application/pdf,application/force-download,application/x-download,binary/octet-stream,text/html,text/plain]|max_size[rs_pps_fl,2048]'
        ]);
        if ($validated == FALSE) {
            // Kembali ke function index supaya membawa data uploads dan validasi
            $data = ['status' => 415, 'response' => "error", 'message' => 'Dokumen Yang Diunggah Tidak Sesuai Spesifikasi'];
        } else {
            $rs_pps_id_ex = $this->Another_Include->getRandStr(20);

            $rs_pps_jns = $this->request->getPost('rs_pps_jns');
            $rs_pps_thn = $this->request->getPost('rs_pps_thn');
            $rs_pps_inst = $this->request->getPost('rs_pps_inst');
            $rs_pps_nmr = $this->request->getPost('rs_pps_nmr');
            $rs_pps_ket = $this->request->getPost('rs_pps_ket');


            $rs_pps_fl = $this->request->getFile('rs_pps_fl');
            $new_rs_pps_fl = "Pps-" . $rs_pps_id_ex . "-"  . date("YmdHis") . "." . $rs_pps_fl->getClientExtension();

            $data = [
                'rs_pps_id_ex' => $rs_pps_id_ex,
                'rs_pps_ppeg' =>  $this->data['rs_ppeg_id_ex'],

                'rs_pps_jns' => $rs_pps_jns,
                'rs_pps_thn' => $rs_pps_thn,
                'rs_pps_inst' => $rs_pps_inst,
                'rs_pps_nmr' => $rs_pps_nmr,
                'rs_pps_ket' => $rs_pps_ket,

                'rs_pps_fl' => $new_rs_pps_fl
            ];
            $insertData = $this->MdlPps->insertData($data);
            if ($insertData) {
                $rs_pps_fl->move('uploads', $new_rs_pps_fl);
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Sertifikat Pegawai Berhasil Disimpan'];
            } else {
                $data = ['status' => 400, 'response' => 'error', 'message' => 'Data Sertifikat Pegawai Tidak Dapat Disimpan'];
            }
        }
        return $this->respond($data, $data['status']);
    }


    public function insertDataPpsbb()
    {
        $validated = $this->validate([
            'rs_ppsbb_fl' => 'uploaded[rs_ppsbb_fl]|mime_in[rs_ppsbb_fl,application/msword,application/vnd.ms-office,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/zip,application/msword,application/x-zip,application/pdf,application/force-download,application/x-download,binary/octet-stream,text/html,text/plain]|max_size[rs_ppsbb_fl,2048]'
        ]);
        if ($validated == FALSE) {
            // Kembali ke function index supaya membawa data uploads dan validasi
            $data = ['status' => 415, 'response' => "error", 'message' => 'Dokumen Yang Diunggah Tidak Sesuai Spesifikasi'];
        } else {

            $rs_ppsbb_pkbb = $this->request->getPost('rs_ppsbb_pkbb');
            $rs_ppsbb_nmr = $this->request->getPost('rs_ppsbb_nmr');
            $rs_ppsbb_tgl_s = $this->request->getPost('rs_ppsbb_tgl_s');
            $rs_ppsbb_tgl_e = $this->request->getPost('rs_ppsbb_tgl_e');
            $rs_ppsbb_ket = $this->request->getPost('rs_ppsbb_ket');

            $rs_ppsbb_fl = $this->request->getFile('rs_ppsbb_fl');
            $new_rs_ppsbb_fl = "Ppsbb-" . $rs_ppsbb_nmr . "." . date("YmdHis") . "." . $rs_ppsbb_fl->getClientExtension();

            $data = [

                'rs_ppsbb_ppeg' =>  $this->data['rs_ppeg_id_ex'],

                'rs_ppsbb_pkbb' => $rs_ppsbb_pkbb,
                'rs_ppsbb_nmr' => $rs_ppsbb_nmr,
                'rs_ppsbb_tgl_s' => $rs_ppsbb_tgl_s,
                'rs_ppsbb_tgl_e' => $rs_ppsbb_tgl_e,
                'rs_ppsbb_ket' => $rs_ppsbb_ket,

                'rs_ppsbb_fl' => $new_rs_ppsbb_fl
            ];
            $insertData = $this->MdlPpsbb->insertData($data);
            if ($insertData) {
                $rs_ppsbb_fl->move('uploads', $new_rs_ppsbb_fl);
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Berkas Berkala Pegawai Berhasil Disimpan'];
            } else {
                $data = ['status' => 400, 'response' => 'error', 'message' => 'Data Berkas Berkala Pegawai Tidak Dapat Disimpan'];
            }
        }
        return $this->respond($data, $data['status']);
    }


    public function insertDataPpsb()
    {
        $validated = $this->validate([
            'rs_ppsb_fl' => 'uploaded[rs_ppsb_fl]|mime_in[rs_ppsb_fl,application/msword,application/vnd.ms-office,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/zip,application/msword,application/x-zip,application/pdf,application/force-download,application/x-download,binary/octet-stream,text/html,text/plain]|max_size[rs_ppsb_fl,2048]'
        ]);
        if ($validated == FALSE) {
            // Kembali ke function index supaya membawa data uploads dan validasi
            $data = ['status' => 415, 'response' => "error", 'message' => 'Dokumen Yang Diunggah Tidak Sesuai Spesifikasi'];
        } else {

            $rs_ppsb_pkb = $this->request->getPost('rs_ppsb_pkb');
            $rs_ppsb_nmr = $this->request->getPost('rs_ppsb_nmr');
            $rs_ppsb_ket = $this->request->getPost('rs_ppsb_ket');

            $rs_ppsb_fl = $this->request->getFile('rs_ppsb_fl');
            $new_rs_ppsb_fl = "Ppsbb-" . $rs_ppsb_nmr . "." . date("YmdHis") . "." . $rs_ppsb_fl->getClientExtension();

            $data = [

                'rs_ppsb_ppeg' =>  $this->data['rs_ppeg_id_ex'],

                'rs_ppsb_pkb' => $rs_ppsb_pkb,
                'rs_ppsb_nmr' => $rs_ppsb_nmr,
                'rs_ppsb_ket' => $rs_ppsb_ket,

                'rs_ppsb_fl' => $new_rs_ppsb_fl
            ];
            $insertData = $this->MdlPpsb->insertData($data);
            if ($insertData) {
                $rs_ppsb_fl->move('uploads', $new_rs_ppsb_fl);
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Status Berkas Pegawai Berhasil Disimpan'];
            } else {
                $data = ['status' => 400, 'response' => 'error', 'message' => 'Data Status Berkas Pegawai Tidak Dapat Disimpan'];
            }
        }
        return $this->respond($data, $data['status']);
    }



    public function insertDataPpkbb()
    {
        $validated = $this->validate([
            'rs_ppkbb_fl' => 'uploaded[rs_ppkbb_fl]|mime_in[rs_ppkbb_fl,application/msword,application/vnd.ms-office,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/zip,application/msword,application/x-zip,application/pdf,application/force-download,application/x-download,binary/octet-stream,text/html,text/plain]|max_size[rs_ppkbb_fl,2048]'
        ]);
        if ($validated == FALSE) {
            // Kembali ke function index supaya membawa data uploads dan validasi
            $data = ['status' => 415, 'response' => "error", 'message' => 'Dokumen Yang Diunggah Tidak Sesuai Spesifikasi'];
        } else {

            $rs_ppkbb_pkbb = $this->request->getPost('rs_ppkbb_pkbb');
            $rs_ppkbb_nmr = $this->request->getPost('rs_ppkbb_nmr');
            $rs_ppkbb_tgl_s = $this->request->getPost('rs_ppkbb_tgl_s');
            $rs_ppkbb_tgl_e = $this->request->getPost('rs_ppkbb_tgl_e');
            $rs_ppkbb_ket = $this->request->getPost('rs_ppkbb_ket');

            $rs_ppkbb_fl = $this->request->getFile('rs_ppkbb_fl');
            $new_rs_ppkbb_fl = "Ppkbb-" . $rs_ppkbb_nmr . "." . date("YmdHis") . "." . $rs_ppkbb_fl->getClientExtension();

            $data = [

                'rs_ppkbb_ppeg' =>  $this->data['rs_ppeg_id_ex'],

                'rs_ppkbb_pkbb' => $rs_ppkbb_pkbb,
                'rs_ppkbb_nmr' => $rs_ppkbb_nmr,
                'rs_ppkbb_tgl_s' => $rs_ppkbb_tgl_s,
                'rs_ppkbb_tgl_e' => $rs_ppkbb_tgl_e,
                'rs_ppkbb_ket' => $rs_ppkbb_ket,

                'rs_ppkbb_fl' => $new_rs_ppkbb_fl
            ];
            $insertData = $this->MdlPpkbb->insertData($data);
            if ($insertData) {
                $rs_ppkbb_fl->move('uploads', $new_rs_ppkbb_fl);
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Kategori Berkas Berkala Pegawai Berhasil Disimpan'];
            } else {
                $data = ['status' => 400, 'response' => 'error', 'message' => 'Data Kategori Berkas Berkala Pegawai Tidak Dapat Disimpan'];
            }
        }
        return $this->respond($data, $data['status']);
    }


    public function changePpeg($rs_ppeg_id_ex = '')
    {
        $rs_ppeg_nmd = $this->request->getPost('rs_ppeg_nmd');
        $rs_ppeg_nm = $this->request->getPost('rs_ppeg_nm');
        $rs_ppeg_nmb = $this->request->getPost('rs_ppeg_nmb');
        $rs_ppeg_nip = $this->request->getPost('rs_ppeg_nip');
        $rs_ppeg_tmpt_lhr = $this->request->getPost('rs_ppeg_tmpt_lhr');
        $rs_ppeg_tgl_lhr = $this->request->getPost('rs_ppeg_tgl_lhr');
        $rs_ppeg_nik = $this->request->getPost('rs_ppeg_nik');
        $rs_ppeg_alt = $this->request->getPost('rs_ppeg_alt');
        $rs_ppeg_jk = $this->request->getPost('rs_ppeg_jk');
        $rs_ppeg_npwp = $this->request->getPost('rs_ppeg_npwp');
        $rs_ppeg_bpjs = $this->request->getPost('rs_ppeg_bpjs');
        $rs_ppeg_hp = $this->request->getPost('rs_ppeg_hp');
        $rs_ppeg_mail = $this->request->getPost('rs_ppeg_mail');
        $rs_ppeg_rmag = $this->request->getPost('rs_ppeg_rmag');
        $rs_ppeg_rmsts = $this->request->getPost('rs_ppeg_rmsts');
        $rs_ppeg_rmgd = $this->request->getPost('rs_ppeg_rmgd');


        $data = [
            'rs_ppeg_nmd' => $rs_ppeg_nmd,
            'rs_ppeg_nm' => $rs_ppeg_nm,
            'rs_ppeg_nmb' => $rs_ppeg_nmb,
            'rs_ppeg_nip' => $rs_ppeg_nip,
            'rs_ppeg_tmpt_lhr' => $rs_ppeg_tmpt_lhr,
            'rs_ppeg_tgl_lhr' => $rs_ppeg_tgl_lhr,
            'rs_ppeg_nik' => $rs_ppeg_nik,
            'rs_ppeg_alt' => $rs_ppeg_alt,
            'rs_ppeg_jk' => $rs_ppeg_jk,
            'rs_ppeg_npwp' => $rs_ppeg_npwp,
            'rs_ppeg_bpjs' => $rs_ppeg_bpjs,
            'rs_ppeg_hp' => $rs_ppeg_hp,
            'rs_ppeg_mail' => $rs_ppeg_mail,
            'rs_ppeg_rmag' => $rs_ppeg_rmag,
            'rs_ppeg_rmsts' => $rs_ppeg_rmsts,
            'rs_ppeg_rmgd' => $rs_ppeg_rmgd,

        ];
        $updateData = $this->MdlPpeg->updateData($data, $rs_ppeg_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Pegawai Berhasil Diubah'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Pegawai Tidak Dapat Diubah'];
        }
        return $this->respond($data, $data['status']);
    }


    public function changePaPass($rs_pa_id_ex = '')
    {
        $options = [
            'cost' => 10,
        ];
        if ($rs_pa_id_ex === null || $rs_pa_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $password_old = $this->request->getPost('password_old');
            $password_new = $this->request->getPost('password_new');
            $password_new1 = $this->request->getPost('password_new1');

            $rs_pa_pass_baru = password_hash($this->request->getPost('password_new'), PASSWORD_BCRYPT, $options);

            $data = [
                'rs_pa_pass' => $rs_pa_pass_baru,
            ];

            $this->data['Pa'] = $this->MdlPa->getAllPaByIdEx($rs_pa_id_ex);
            $countLenghtKataSandi = strlen($password_new);

            if (password_verify($password_old, $this->data['Pa']['rs_pa_pass'])) {

                if ($password_new != $password_new1) {
                    $data = ['status' => 417, 'response' => 'error', 'message' => 'Kata Sandi Baru Tidak Cocok'];
                } else {
                    if ($countLenghtKataSandi < 6) {
                        $data = ['status' => 411, 'response' => 'error', 'message' => 'Kata Sandi Harus Lebih Dari 6 Huruf Atau Angka'];
                    } else {
                        if (ctype_space($password_new)) {
                            $data = ['status' => 412, 'response' => 'error', 'message' => 'Kata Sandi Tidak Dapat Menggunakan Spasi'];
                        } else {
                            if (preg_match('/[\'^£$%&*()}{@#~?><>,|=_+¬-]/', $password_new)) {
                                $data = ['status' => 412, 'response' => 'error', 'message' => 'Kata Sandi Hanya Dapat Menggunakan Huruf Dan Angka'];
                            } else {
                                $updateData = $this->MdlPa->updateData($data, $rs_pa_id_ex);
                                if ($updateData) {
                                    $this->session->destroy();
                                    $data = ['status' => 200, 'response' => 'success', 'message' => 'Kata Sandi Berhasil Diubah'];
                                } else {
                                    $data = ['status' => 400, 'response' => 'error', 'message' => 'Kata Sandi Tidak Dapat Diubah'];
                                }
                            }
                        }
                    }
                }
            } else {
                $data = ['status' => 417, 'response' => 'error', 'message' => 'Kata Sandi Lama Salah'];
            }
        }
        return $this->respond($data, $data['status']);
    }


    public function deleteDataPpi($rs_ppi_id_ex = '', $rs_ppi_fl)
    {
        if ($rs_ppi_id_ex === null || $rs_ppi_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlPpi->deleteData($rs_ppi_id_ex);
            if ($deleteData) {
                unlink('uploads/' . $rs_ppi_fl);
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Tidak Dapat Dihapus'];
            }
        }

        return $this->respond($data, $data['status']);
    }


    public function deleteDataPps($rs_pps_id_ex = '', $rs_pps_fl)
    {
        if ($rs_pps_id_ex === null || $rs_pps_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlPps->deleteData($rs_pps_id_ex);
            if ($deleteData) {
                unlink('uploads/' . $rs_pps_fl);
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Tidak Dapat Dihapus'];
            }
        }

        return $this->respond($data, $data['status']);
    }


    public function deleteDataPpsbb($rs_ppsbb_id = '', $rs_ppsbb_fl)
    {
        if ($rs_ppsbb_id === null || $rs_ppsbb_id == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlPpsbb->deleteData($rs_ppsbb_id);
            if ($deleteData) {
                unlink('uploads/' . $rs_ppsbb_fl);
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Tidak Dapat Dihapus'];
            }
        }

        return $this->respond($data, $data['status']);
    }


    public function deleteDataPpsb($rs_ppsb_id = '', $rs_ppsb_fl)
    {
        if ($rs_ppsb_id === null || $rs_ppsb_id == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlPpsb->deleteData($rs_ppsb_id);
            if ($deleteData) {
                unlink('uploads/' . $rs_ppsb_fl);
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Tidak Dapat Dihapus'];
            }
        }

        return $this->respond($data, $data['status']);
    }


    public function deleteDataPpkbb($rs_ppkbb_id = '', $rs_ppkbb_fl)
    {
        if ($rs_ppkbb_id === null || $rs_ppkbb_id == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlPpkbb->deleteData($rs_ppkbb_id);
            if ($deleteData) {
                unlink('uploads/' . $rs_ppkbb_fl);
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Tidak Dapat Dihapus'];
            }
        }

        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_pa_id_ex';
        $id = 'rs_pa_id';
        $length = 3;
        $typeGet = 'result';

        $fillUpdate = 'rs_pa_id_ex';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [],
                //order by
                [
                    0 => ['id' => 'rs_pa_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'getAllByIdEx') {
            return $this->MdlU->getAll(
                //type result / row
                'row',
                // select *
                '*',
                //where
                [
                    0 => ['idEx' => 'rs_pa_id_ex', 'idExV' => $data]
                ],
                //order by
                [
                    0 => ['id' => 'rs_pa_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    
                ]
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        } 
    }
}
