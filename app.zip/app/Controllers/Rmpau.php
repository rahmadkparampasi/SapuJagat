<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Controllers\Rmph;
use App\Models\RmpauMdl;
use App\Models\RmpmskMdl;

class Rmpau extends BaseController
{
    use ResponseTrait;
    protected $MdlRmpmsk;
    protected $MdlRmpau;
    protected $Rmph;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlRmpmsk = new RmpmskMdl();
        $this->MdlRmpau = new RmpauMdl();
        $this->Rmph = new Rmph();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOIgd',
            'pAct' => 'pAIgd',
            'cAct' => 'cArmpmsk',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {

        return redirect()->to('./rmpmsk');
    }

    public function insertData($rs_rmpau_rmpmsk)
    {
        $this->data['Rmpmsk'] = $this->MdlRmpmsk->getAllRmpmsk($rs_rmpau_rmpmsk);

        $insertDataRmph = $this->Rmph->iDH($this->data['Rmpmsk']['rs_rmpmsk_rmpp'], "CT");
        if ($insertDataRmph[0]) {
            $rs_rmpau_id_ex = $this->MdlRmpau->getIdEx($this->Another_Include->getRandStr(10));
            $rs_rmpau_au = $this->request->getPost('rs_rmpau_au');

            $dataRmpAu = [
                'rs_rmpau_id_ex' => $rs_rmpau_id_ex,
                'rs_rmpau_rmpmsk' => $rs_rmpau_rmpmsk,
                'rs_rmpau_rmph' => $insertDataRmph[1],
                'rs_rmpau_au' => $rs_rmpau_au
            ];
            $insertDataRmpAu = $this->MdlRmpau->insertData($dataRmpAu);
            if ($insertDataRmpAu) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Anamnesis Umum Pasien Berhasil Disimpan'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Anamnesis Umum Pasien Tidak Dapat Disimpan'];
            }
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Histori Pasien Tidak Dapat Disimpan'];
        }

        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmpau_id_ex = '')
    {
        if ($rs_rmpau_id_ex === null || $rs_rmpau_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlRmpau->deleteData($rs_rmpau_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Anamnesis Umum Pasien Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Anamnesis Umum Pasien Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }
}
