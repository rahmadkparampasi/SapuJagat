<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Controllers\Rmph;
use App\Models\RmpmskMdl;
use App\Models\RmpnldMdl;

class Rmpnld extends BaseController
{
    use ResponseTrait;
    protected $MdlRmpmsk;
    protected $MdlRmpnld;
    protected $Rmph;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlRmpmsk = new RmpmskMdl();
        $this->MdlRmpnld = new RmpnldMdl();
        $this->Rmph = new Rmph();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOIgd',
            'pAct' => 'pAIgd',
            'cAct' => 'cArmpmsk',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {

        return redirect()->to('./rmpmsk');
    }

    public function insertData($rs_rmpnld_rmpmsk)
    {
        $this->data['Rmpmsk'] = $this->MdlRmpmsk->getAllRmpmsk($rs_rmpnld_rmpmsk);

        $insertDataRmph = $this->Rmph->iDH($this->data['Rmpmsk']['rs_rmpmsk_rmpp'], "CT");
        if ($insertDataRmph[0]) {
            $rs_rmpnld_id_ex = $this->MdlRmpnld->getIdEx($this->Another_Include->getRandStr(10));
            $rs_rmpnld_dia = $this->request->getPost('rs_rmpnld_dia');

            $dataRmpNlD = [
                'rs_rmpnld_id_ex' => $rs_rmpnld_id_ex,
                'rs_rmpnld_rmpmsk' => $rs_rmpnld_rmpmsk,
                'rs_rmpnld_rmph' => $insertDataRmph[1],
                'rs_rmpnld_dia' => $rs_rmpnld_dia
            ];
            $insertDataRmpNlD = $this->MdlRmpnld->insertData($dataRmpNlD);
            if ($insertDataRmpNlD) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Penilaian Diagnosis Pasien Berhasil Disimpan'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Penilaian Diagnosis Pasien Tidak Dapat Disimpan'];
            }
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Histori Pasien Tidak Dapat Disimpan'];
        }

        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmpnld_id_ex = '')
    {
        if ($rs_rmpnld_id_ex === null || $rs_rmpnld_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlRmpnld->deleteData($rs_rmpnld_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Penilaian Diagnosis Pasien Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Penilaian Diagnosis Pasien Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }
}
