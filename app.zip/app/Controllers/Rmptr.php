<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\RmphMdl;
use App\Models\RmpmskMdl;
use App\Models\RmptrMdl;

class Rmptr extends BaseController
{
    use ResponseTrait;
    protected $MdlRmpmsk;
    protected $MdlRmptr;
    protected $MdlRmph;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlRmpmsk = new RmpmskMdl();
        $this->MdlRmptr = new RmptrMdl();
        $this->MdlRmph = new RmphMdl();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOIgd',
            'pAct' => 'pAIgd',
            'cAct' => 'cArmpmsk',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {

        return redirect()->to('./rmpmsk');
    }

    public function viewData($rs_rmptr_rmpmsk = '')
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['Rmpmsk'] = $this->MdlRmpmsk->getAllRmpmsk($rs_rmptr_rmpmsk);

        $this->data['d'] = (string)date('d', strtotime($this->data['Rmpmsk']['rs_rmpmsk_tgl']));
        $this->data['F'] = (string)date('F', strtotime($this->data['Rmpmsk']['rs_rmpmsk_tgl']));
        $this->data['F'] = $this->Another_Include->monthConv($this->data['F']);
        $this->data['Y'] = (string)date('Y', strtotime($this->data['Rmpmsk']['rs_rmpmsk_tgl']));
        $this->data['Rmpmsk']['rs_rmpmsk_tgl'] = strtoupper($this->data['d'] . " " . $this->data['F'] . " " . $this->data['Y']);

        $this->data['d'] = (string)date('d', strtotime($this->data['Rmpmsk']['rs_rmpp_tgl_lhr']));
        $this->data['F'] = (string)date('F', strtotime($this->data['Rmpmsk']['rs_rmpp_tgl_lhr']));
        $this->data['F'] = $this->Another_Include->monthConv($this->data['F']);
        $this->data['Y'] = (string)date('Y', strtotime($this->data['Rmpmsk']['rs_rmpp_tgl_lhr']));
        $this->data['Rmpmsk']['rs_rmpp_tgl_lhr'] = strtoupper($this->data['d'] . " " . $this->data['F'] . " " . $this->data['Y']);

        $this->data['Rmpmsk']['rs_rmpp_alt'] = substr($this->data['Rmpmsk']['rs_rmpp_alt'], 0, 15) . '...';

        if ($this->data['Rmpmsk']['rs_rmpp_jk'] == "L") {
            $this->data['Rmpmsk']['rs_rmpp_jk'] = "LAKI-LAKI";
        } else {
            $this->data['Rmpmsk']['rs_rmpp_jk'] = "PEREMPUAN";
        }

        $this->data['WebTitle'] = 'DATA TRIASE GAWAT DARURAT';
        $this->data['PageTitle'] = 'Data Triase Gawat Darurat';
        $this->data['BasePage'] = 'rmptr';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData/' . $rs_rmptr_rmpmsk;
        $this->data['IdForm'] = 'rmptrAddData';
        $this->data['UrlForm'] = 'rmptr/viewData/' . $rs_rmptr_rmpmsk;

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);

        $this->data['Rmptr'] = $this->MdlRmptr->getAllRmptr($rs_rmptr_rmpmsk);
        $this->data['Rmptr'] = $this->changeText($this->data['Rmptr']);

        if ($rs_rmptr_rmpmsk === null || $rs_rmptr_rmpmsk == '') {
            return redirect()->to('/' . $this->data['BasePage']);
        } else {
            echo view('Rmptr/index', $this->data);
            echo view('Templates/anotherScript');
            echo view('Templates/ajaxInsert', $this->data);
        }
    }

    public function editData($rs_rmptr_id_ex = '')
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['Rpmtr'] = $this->MdlRmptr->getAllRmptr(false, $rs_rmptr_id_ex);
        $rs_rmptr_rmpmsk = $this->data['Rpmtr']['rs_rmptr_rmpmsk'];
        $this->data['Rmpmsk'] = $this->MdlRmpmsk->getAllRmpmsk($rs_rmptr_rmpmsk);

        $this->data['d'] = (string)date('d', strtotime($this->data['Rmpmsk']['rs_rmpmsk_tgl']));
        $this->data['F'] = (string)date('F', strtotime($this->data['Rmpmsk']['rs_rmpmsk_tgl']));
        $this->data['F'] = $this->Another_Include->monthConv($this->data['F']);
        $this->data['Y'] = (string)date('Y', strtotime($this->data['Rmpmsk']['rs_rmpmsk_tgl']));
        $this->data['Rmpmsk']['rs_rmpmsk_tgl'] = strtoupper($this->data['d'] . " " . $this->data['F'] . " " . $this->data['Y']);

        $this->data['d'] = (string)date('d', strtotime($this->data['Rmpmsk']['rs_rmpp_tgl_lhr']));
        $this->data['F'] = (string)date('F', strtotime($this->data['Rmpmsk']['rs_rmpp_tgl_lhr']));
        $this->data['F'] = $this->Another_Include->monthConv($this->data['F']);
        $this->data['Y'] = (string)date('Y', strtotime($this->data['Rmpmsk']['rs_rmpp_tgl_lhr']));
        $this->data['Rmpmsk']['rs_rmpp_tgl_lhr'] = strtoupper($this->data['d'] . " " . $this->data['F'] . " " . $this->data['Y']);

        $this->data['Rmpmsk']['rs_rmpp_alt'] = substr($this->data['Rmpmsk']['rs_rmpp_alt'], 0, 15) . '...';

        if ($this->data['Rmpmsk']['rs_rmpp_jk'] == "L") {
            $this->data['Rmpmsk']['rs_rmpp_jk'] = "LAKI-LAKI";
        } else {
            $this->data['Rmpmsk']['rs_rmpp_jk'] = "PEREMPUAN";
        }

        $this->data['WebTitle'] = 'DATA TRIASE GAWAT DARURAT';
        $this->data['PageTitle'] = 'Data Triase Gawat Darurat';
        $this->data['BasePage'] = 'rmptr';
        $this->data['ButtonMethod'] = 'UBAH';
        $this->data['MethodForm'] = 'updateData/' . $rs_rmptr_id_ex;
        $this->data['IdForm'] = 'rmptrAddData';
        $this->data['UrlForm'] = 'rmptr/viewData/' . $rs_rmptr_rmpmsk;

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);

        $this->data['Rmptr'] = $this->MdlRmptr->getAllRmptr($rs_rmptr_rmpmsk);
        $this->data['Rmptr'] = $this->changeText($this->data['Rmptr']);

        if ($rs_rmptr_rmpmsk === null || $rs_rmptr_rmpmsk == '') {
            return redirect()->to('/' . $this->data['BasePage']);
        } else {
            $this->data['fillUpdate'] = $this->MdlRmptr->getRmptrByIdEx($rs_rmptr_id_ex);
            echo view('Rmptr/index', $this->data);
            echo view('Templates/anotherScript');
            echo view('Templates/ajaxInsert', $this->data);
            echo view('Templates/loadData');
        }
    }

    public function insertData($rs_rmptr_rmpmsk)
    {
        $this->data['Rmpmsk'] = $this->MdlRmpmsk->getAllRmpmsk($rs_rmptr_rmpmsk);

        $rs_rmph_id_ex = $this->MdlRmph->getIdExRmph($this->Another_Include->getRandStr(35));
        $rs_rmph_rmpp = $this->data['Rmpmsk']['rs_rmpmsk_rmpp'];
        $rs_rmph_ppeg = $this->data['rs_ppeg_id_ex'];
        $rs_rmph_jns = "CT";

        $rs_rmptr_id_ex = $this->MdlRmpmsk->getIdExRmpmsk($this->Another_Include->getRandStr(35));
        $rs_rmptr_rmsmf = $this->request->getPost('rs_rmptr_rmsmf');
        $rs_rmptr_rmkt = $this->request->getPost('rs_rmptr_rmkt');
        $rs_rmptr_tgl = $this->request->getPost('rs_rmptr_tgl');
        $rs_rmptr_jam = $this->request->getPost('rs_rmptr_jam');

        $dataRmptr = [
            'rs_rmptr_id_ex' => $rs_rmptr_id_ex,
            'rs_rmptr_rmpmsk' => $rs_rmptr_rmpmsk,
            'rs_rmptr_rmph' => $rs_rmph_id_ex,
            'rs_rmptr_rmsmf' => $rs_rmptr_rmsmf,
            'rs_rmptr_rmkt' => $rs_rmptr_rmkt,
            'rs_rmptr_tgl' => $rs_rmptr_tgl,
            'rs_rmptr_jam' => $rs_rmptr_jam
        ];

        $dataRmph = [
            'rs_rmph_id_ex' => $rs_rmph_id_ex,
            'rs_rmph_rmpp' => $rs_rmph_rmpp,
            'rs_rmph_ppeg' => $rs_rmph_ppeg,
            'rs_rmph_jns' => $rs_rmph_jns
        ];

        $insertDataRmph = $this->MdlRmph->insertData($dataRmph);
        if ($insertDataRmph) {
            $insertDataRmptr = $this->MdlRmptr->insertData($dataRmptr);
            if ($insertDataRmptr) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Triage Pasien Berhasil Disimpan'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Histori Pasien Tidak Dapat Disimpan'];
            }
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Histori Pasien Tidak Dapat Disimpan'];
        }

        return $this->respond($data, $data['status']);
    }

    public function updateData($rs_rmptr_id_ex = '')
    {
        $array = $this->request->getPost();
        unset($array['datatableKirana_length']);
        unset($array['rs_rmptr_id_ex']);
        $arrayFlip = array_keys($array);
        $arrayFlipV = array_values($arrayFlip);
        $arrayV = array_values($array);

        $rs_rmptr = [];

        for ($i = 0; $i < count($arrayV); $i++) {
            $rs_rmptr[$arrayFlipV[$i]] = $arrayV[$i];
        }

        $insertDataRmptr = $this->MdlRmptr->updateData($rs_rmptr, $rs_rmptr_id_ex);
        if ($insertDataRmptr) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Triage Pasien Berhasil Diubah'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Histori Pasien Tidak Dapat Diubah'];
        }

        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmr_id_ex = '')
    {
        if ($rs_rmr_id_ex === null || $rs_rmr_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlRmr->deleteData($rs_rmr_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Ruangan Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Ruangan Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function changeText($data)
    {
        for ($i = 0; $i < count($data); $i++) {
            $this->data['d'] = (string)date('d', strtotime($data[$i]['rs_rmptr_tgl']));
            $this->data['F'] = (string)date('F', strtotime($data[$i]['rs_rmptr_tgl']));
            $this->data['F'] = $this->Another_Include->monthConv($this->data['F']);
            $this->data['Y'] = (string)date('Y', strtotime($data[$i]['rs_rmptr_tgl']));
            $data[$i]['rs_rmptr_tgl'] = strtoupper($this->data['d'] . " " . $this->data['F'] . " " . $this->data['Y']);


            if ($data[$i]['rs_rmptr_jn'] == "SR") {
                $data[$i]['rs_rmptr_jn'] = "<span class='badge badge-danger'>Sumbatan (Obstruction) - Resusitasi</span><br>";
            } elseif ($data[$i]['rs_rmptr_jn'] == "BE") {
                $data[$i]['rs_rmptr_jn'] = "<span class='badge badge-warning'>Bebas - Emergency</span><br>";
            } elseif ($data[$i]['rs_rmptr_jn'] == "BU") {
                $data[$i]['rs_rmptr_jn'] = "<span class='badge badge-warning'>Bebas - Urgent</span><br>";
            } elseif ($data[$i]['rs_rmptr_jn'] == "BLU") {
                $data[$i]['rs_rmptr_jn'] = "<span class='badge badge-success'>Bebas - Less Urgent</span><br>";
            } elseif ($data[$i]['rs_rmptr_jn'] == "BNU") {
                $data[$i]['rs_rmptr_jn'] = "<span class='badge badge-success'>Bebas - Non Urgent</span><br>";
            }

            if ($data[$i]['rs_rmptr_pfr'] == "FR") {
                $data[$i]['rs_rmptr_pfr'] = "<span class='badge badge-danger'>Frek. Nafas (RR) <10x/mnt - Resusitasi</span><br>";
            } elseif ($data[$i]['rs_rmptr_pfr'] == "FE") {
                $data[$i]['rs_rmptr_pfr'] = "<span class='badge badge-warning'>Frek. Nafas (RR) >32x/mnt - Emergency</span><br>";
            } elseif ($data[$i]['rs_rmptr_pfr'] == "FU") {
                $data[$i]['rs_rmptr_pfr'] = "<span class='badge badge-warning'>Frek. Nafas (RR) 24-32x/mnt - Urgent</span><br>";
            } elseif ($data[$i]['rs_rmptr_pfr'] == "FLU") {
                $data[$i]['rs_rmptr_pfr'] = "<span class='badge badge-success'>Frek. Nafas (RR) 21-32x/mnt - Less Urgent</span><br>";
            } elseif ($data[$i]['rs_rmptr_pfr'] == "FNU") {
                $data[$i]['rs_rmptr_pfr'] = "<span class='badge badge-success'>Frek. Nafas (RR) 16-20x/mnt - Non Urgent</span><br>";
            } else {
                $data[$i]['rs_rmptr_pfr'] = "";
            }

            if ($data[$i]['rs_rmptr_whz'] == "0") {
                $data[$i]['rs_rmptr_whz'] = "";
            } elseif ($data[$i]['rs_rmptr_whz'] == "WE") {
                $data[$i]['rs_rmptr_whz'] = "<span class='badge badge-warning'>Wheezing - Emergency</span><br>";
            } elseif ($data[$i]['rs_rmptr_whz'] == "WU") {
                $data[$i]['rs_rmptr_whz'] = "<span class='badge badge-warning'>Wheezing - Urgent</span><br>";
            }

            if ($data[$i]['rs_rmptr_hn'] == "0") {
                $data[$i]['rs_rmptr_hn'] = "";
            } elseif ($data[$i]['rs_rmptr_hn'] == "1") {
                $data[$i]['rs_rmptr_hn'] = "<span class='badge badge-danger'>Henti Nafas (Breathing Arrest) - Resusitasi</span><br>";
            }

            if ($data[$i]['rs_rmptr_sia'] == "0") {
                $data[$i]['rs_rmptr_sia'] = "";
            } elseif ($data[$i]['rs_rmptr_sia'] == "1") {
                $data[$i]['rs_rmptr_sia'] = "<span class='badge badge-danger'>Sianosis - Resusitasi</span><br>";
            }

            if ($data[$i]['rs_rmptr_pfn'] == "0") {
                $data[$i]['rs_rmptr_pfn'] = "";
            } elseif ($data[$i]['rs_rmptr_pfn'] == "FE") {
                $data[$i]['rs_rmptr_pfn'] = "<span class='badge badge-warning'>Frek. Nadi (HR) <50x/mnt - Emergency</span><br>";
            } elseif ($data[$i]['rs_rmptr_pfn'] == "FU") {
                $data[$i]['rs_rmptr_pfn'] = "<span class='badge badge-warning'>Frek. Nadi (HR) 120-150x/mnt - Urgent</span><br>";
            } elseif ($data[$i]['rs_rmptr_pfn'] == "FLU") {
                $data[$i]['rs_rmptr_pfn'] = "<span class='badge badge-success'>Frek. Nadi (HR) 100-120x/mnt - Less Urgent</span><br>";
            } elseif ($data[$i]['rs_rmptr_pfn'] == "FNU") {
                $data[$i]['rs_rmptr_pfn'] = "<span class='badge badge-success'>Frek. Nadi (HR) 80-100x/mnt - Non Urgent</span><br>";
            }

            if ($data[$i]['rs_rmptr_sis'] == "0") {
                $data[$i]['rs_rmptr_sis'] = "";
            } elseif ($data[$i]['rs_rmptr_sis'] == "SU") {
                $data[$i]['rs_rmptr_sis'] = "<span class='badge badge-warning'>TD Sistol &#8805;160 mmHg - Urgent</span><br>";
            } elseif ($data[$i]['rs_rmptr_sis'] == "SLU") {
                $data[$i]['rs_rmptr_sis'] = "<span class='badge badge-success'>TD Sistol <160 mmHg - Less Urgent</span><br>";
            } elseif ($data[$i]['rs_rmptr_sis'] == "SNU") {
                $data[$i]['rs_rmptr_sis'] = "<span class='badge badge-success'>TD Sistol <120 mmHg - Non Urgent</span><br>";
            }

            if ($data[$i]['rs_rmptr_dia'] == "0") {
                $data[$i]['rs_rmptr_dia'] = "";
            } elseif ($data[$i]['rs_rmptr_dia'] == "DU") {
                $data[$i]['rs_rmptr_dia'] = "<span class='badge badge-warning'>TD Distole &#8805;100 mmHg - Urgent</span><br>";
            } elseif ($data[$i]['rs_rmptr_dia'] == "DLU") {
                $data[$i]['rs_rmptr_dia'] = "<span class='badge badge-success'>TD Distole <100 mmHg - Less Urgent</span><br>";
            } elseif ($data[$i]['rs_rmptr_dia'] == "DNU") {
                $data[$i]['rs_rmptr_dia'] = "<span class='badge badge-success'>TD Distole <50 mmHg - Non Urgent</span><br>";
            }

            if ($data[$i]['rs_rmptr_hj'] == "0") {
                $data[$i]['rs_rmptr_hj'] = "";
            } elseif ($data[$i]['rs_rmptr_hj'] == "1") {
                $data[$i]['rs_rmptr_hj'] = "<span class='badge badge-danger'>Henti Jantung - Resusitasi</span><br>";
            }

            if ($data[$i]['rs_rmptr_na'] == "0") {
                $data[$i]['rs_rmptr_na'] = "";
            } elseif ($data[$i]['rs_rmptr_na'] == "NTT") {
                $data[$i]['rs_rmptr_na'] = "<span class='badge badge-danger'>Nadi Tidak Terasa - Resusitasi</span><br>";
            } elseif ($data[$i]['rs_rmptr_na'] == "NTL") {
                $data[$i]['rs_rmptr_na'] = "<span class='badge badge-warning'>Nadi Terasa Lemah - Emergency</span><br>";
            }

            if ($data[$i]['rs_rmptr_pc'] == "0") {
                $data[$i]['rs_rmptr_pc'] = "";
            } elseif ($data[$i]['rs_rmptr_pc'] == "1") {
                $data[$i]['rs_rmptr_pc'] = "<span class='badge badge-danger'>Pucat - Resusitasi</span><br>";
            }

            if ($data[$i]['rs_rmptr_ak'] == "0") {
                $data[$i]['rs_rmptr_ak'] = "";
            } elseif ($data[$i]['rs_rmptr_ak'] == "1") {
                $data[$i]['rs_rmptr_ak'] = "<span class='badge badge-danger'>Akral Dingin - Resusitasi</span><br>";
            }

            if ($data[$i]['rs_rmptr_ks'] == "KSR") {
                $data[$i]['rs_rmptr_ks'] = "<span class='badge badge-danger'>GCS < 9 - Resusitasi</span><br>";
            } elseif ($data[$i]['rs_rmptr_ks'] == "KSE") {
                $data[$i]['rs_rmptr_ks'] = "<span class='badge badge-warning'>GCS 9 - 12 - Emergency</span><br>";
            } elseif ($data[$i]['rs_rmptr_ks'] == "KSU") {
                $data[$i]['rs_rmptr_ks'] = "<span class='badge badge-warning'>GCS > 12 - Urgent</span><br>";
            } elseif ($data[$i]['rs_rmptr_ks'] == "KSLU") {
                $data[$i]['rs_rmptr_ks'] = "<span class='badge badge-success'>GCS 15 - Less Urgent</span><br>";
            } elseif ($data[$i]['rs_rmptr_ks'] == "KSNU") {
                $data[$i]['rs_rmptr_ks'] = "<span class='badge badge-success'>GCS 15 - Non Urgent</span><br>";
            } else {
                $data[$i]['rs_rmptr_ks'] = "";
            }

            if ($data[$i]['rs_rmptr_doa'] == "0") {
                $data[$i]['rs_rmptr_doa'] = "<span class='badge badge-success'>Tidak</span><br>";
            } elseif ($data[$i]['rs_rmptr_doa'] == "1") {
                $data[$i]['rs_rmptr_doa'] = "<span class='badge badge-danger'>Ya</span><br>";
            }

            if ($data[$i]['rs_rmptr_ats'] == "1") {
                $data[$i]['rs_rmptr_ats'] = "<span class='badge badge-danger'>Kategori 1 (Segera) - Resusitasi</span><br>";
            } elseif ($data[$i]['rs_rmptr_ats'] == "2") {
                $data[$i]['rs_rmptr_ats'] = "<span class='badge badge-warning'>Kategori 2 (10 Menit) - Emergency / Gawat Darurat</span><br>";
            } elseif ($data[$i]['rs_rmptr_ats'] == "3") {
                $data[$i]['rs_rmptr_ats'] = "<span class='badge badge-warning'>Kategori 3 (30 Menit) - Urgent / Darurat</span><br>";
            } elseif ($data[$i]['rs_rmptr_ats'] == "4") {
                $data[$i]['rs_rmptr_ats'] = "<span class='badge badge-success'>Kategori 4 (60 Menit) - Semi Darurat</span><br>";
            } elseif ($data[$i]['rs_rmptr_ats'] == "5") {
                $data[$i]['rs_rmptr_ats'] = "<span class='badge badge-success'>Kategori 5 (120 Menit) - Tidak Darurat</span><br>";
            } else {
                $data[$i]['rs_rmptr_ats'] = "<span class='badge badge-primary'>Tidak Berkategori</span><br>";
            }
        }
        return $data;
    }
}