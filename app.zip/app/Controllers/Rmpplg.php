<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\RmphMdl;
use App\Models\RmpmskMdl;
use App\Models\UmMdl;

class Rmpplg extends BaseController
{
    use ResponseTrait;
    protected $MdlRmpmsk;
    protected $MdlU;
    protected $MdlRmph;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlRmpmsk = new RmpmskMdl();
        $this->MdlU = new UmMdl('rs_rmpplg', 'rs_rmpplg_id_ex');
        $this->MdlRmph = new RmphMdl();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOIgd',
            'pAct' => 'pAIgd',
            'cAct' => 'cArmpmsk',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {

        return redirect()->to('./rmpmsk');
    }

    public function getAll($rs_rmpplg_rmpmsk)
    {
        $data = $this->setDB('getAll', $rs_rmpplg_rmpmsk);
        $data = $this->Another_Include->changeDateWF($data, ['rs_rmpplg_tgl']);
        for ($i = 0; $i < count($data); $i++) {
            if ($data[$i]['rs_ppeg_nmd'] != "") {
                $data[$i]['rs_ppeg_nm'] = $data[$i]['rs_ppeg_nmd'] . ". " . $data[$i]['rs_ppeg_nm'];
            }

            if ($data[$i]['rs_ppeg_nmb'] != "") {
                $data[$i]['rs_ppeg_nm'] = $data[$i]['rs_ppeg_nm'] . ", " . $data[$i]['rs_ppeg_nmb'];
            }
        }
        return $data;
    }

    public function insertData($rs_rmpplg_rmpmsk)
    {
        $this->data['Rmpmsk'] = $this->MdlRmpmsk->getAllRmpmsk($rs_rmpplg_rmpmsk);

        $rs_rmph_id_ex = $this->Another_Include->getRandStr(35);
        $rs_rmph_rmpp = $this->data['Rmpmsk']['rs_rmpmsk_rmpp'];
        $rs_rmph_ppeg = $this->data['rs_ppeg_id_ex'];
        $rs_rmph_jns = "CT";

        $rs_rmpplg_id_ex = $this->setDB('idEx', $this->Another_Include->getRandStr(11));
        $rs_rmpplg_tgl = $this->request->getPost('rs_rmpplg_tgl');
        $rs_rmpplg_jam = $this->request->getPost('rs_rmpplg_jam');
        $rs_rmpplg_rmck = $this->request->getPost('rs_rmpplg_rmck');
        $rs_rmpplg_rmkk = $this->request->getPost('rs_rmpplg_rmkk');
        $rs_rmpplg_ppeg = $this->request->getPost('rs_rmpplg_ppeg');
        $rs_rmpplg_diag = $this->request->getPost('rs_rmpplg_diag');

        $dataRmpplg = [
            'rs_rmpplg_id_ex' => $rs_rmpplg_id_ex,
            'rs_rmpplg_rmpmsk' => $rs_rmpplg_rmpmsk,
            'rs_rmpplg_rmph' => $rs_rmph_id_ex,
            'rs_rmpplg_tgl' => $rs_rmpplg_tgl,
            'rs_rmpplg_jam' => $rs_rmpplg_jam,
            'rs_rmpplg_rmck' => $rs_rmpplg_rmck,
            'rs_rmpplg_rmkk' => $rs_rmpplg_rmkk,
            'rs_rmpplg_ppeg' => $rs_rmpplg_ppeg,
            'rs_rmpplg_diag' => $rs_rmpplg_diag,
        ];
        $dataRmpmsk = [
            'rs_rmpmsk_plg' => '1'
        ];

        $dataRmph = [
            'rs_rmph_id_ex' => $rs_rmph_id_ex,
            'rs_rmph_rmpp' => $rs_rmph_rmpp,
            'rs_rmph_ppeg' => $rs_rmph_ppeg,
            'rs_rmph_jns' => $rs_rmph_jns
        ];
        $updateDataRmpmsk = $this->MdlRmpmsk->updateData($dataRmpmsk, $rs_rmpplg_rmpmsk);
        if ($updateDataRmpmsk) {
            $insertDataRmph = $this->MdlRmph->insertData($dataRmph);
            if ($insertDataRmph) {
                $insertDataRmpplg = $this->MdlU->insertData($dataRmpplg);
                if ($insertDataRmpplg) {
                    $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Pulang Pasien Berhasil Disimpan'];
                } else {
                    $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Pulang Pasien Tidak Dapat Disimpan'];
                }
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Histori Pasien Tidak Dapat Disimpan'];
            }
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Pasien Masuk Pasien Tidak Dapat Disimpan'];
        }



        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmpplg_id_ex = '')
    {
        if ($rs_rmpplg_id_ex === null || $rs_rmpplg_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlU->deleteData($rs_rmpplg_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Pulang Pasien Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Pulang Pasien Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmpplg_id_ex';
        $id = 'rs_rmpplg_id';
        $length = 4;
        $typeGet = 'result';

        $fillUpdate = '*';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmpplg_rmpmsk',
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpplg_id', 'orderType' => 'ASC'],
                ],
                //join
                [

                    0 => ['tableName' => 'rs_rmck', 'string' => 'rs_rmck.rs_rmck_id_ex = rs_rmpplg.rs_rmpplg_rmck', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_ppeg', 'string' => 'rs_ppeg.rs_ppeg_id_ex = rs_rmpplg.rs_rmpplg_ppeg', 'type' => 'LEFT'],
                    2 => ['tableName' => 'rs_rmkk', 'string' => 'rs_rmkk.rs_rmkk_id_ex = rs_rmpplg.rs_rmpplg_rmkk', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpplg_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}