<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\MkTableModel;
use App\Models\CheckDBMdl;

class MkTable extends BaseController
{
    use ResponseTrait;
    protected $TableMkTable;
    protected $TableCheckDB;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->TableMkTable = new MkTableModel();
        $this->TableCheckDB = new CheckDBMdl();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
        ];
    }

    public function index()
    {
        $this->data['WebTitle'] = 'SETUP DATABASE';
        $this->data['PageTitle'] = 'Setup Database';
        $this->data['BasePage'] = 'mkTable';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData';
        $this->data['IdForm'] = 'mkTableAddData';
        $this->data['UrlForm'] = '';
        echo view('MkTable/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }

    public function cekDb()
    {
        $teks = "";
        $teks = $teks . "<div class='card-footer'>
            <p class='login-box-msg'>Daftar Kesalahan</p>";

        $table = $this->TableMkTable->checkDB();
        $success = 0;
        $error = 0;
        $errorEmpty = 0;
        $errorSameDB = 0;
        $errorCountDB = 0;
        $TableConfirm = $this->TableCheckDB->checkDB();
        $TableConfirm = $TableConfirm->getResultArray();
        $countTableOn = count($table);
        $countTableOff = count($TableConfirm);
        for ($i = 0; $i < count($table); $i++) {
            if (empty($TableConfirm)) {
                $errorEmpty += 1;
                $error += 1;
                $teks = $teks . "<h6><span class='badge badge-danger'>Error Table Kosong</span></h6><br>";
                break;
            }
            if ($countTableOn != $countTableOff) {
                $errorCountDB += 1;
                $error += 1;
                $teks = $teks . "<h6><span class='badge badge-danger'>Error Jumlah Table Tidak Sama</span></h6><br>";
                break;
            }
        }
        if ($errorEmpty == 0 && $errorCountDB == 0) {
            for ($i = 0; $i < count($table); $i++) {
                if ($TableConfirm[$i]['Tables_in_rs'] != $table[$i]['TableName']) {
                    $errorSameDB += 1;
                    $teks = $teks . "<h6><span class='badge badge-danger'>Error Pada Nama Table Tidak Sama (" . $TableConfirm[$i]['Tables_in_rs'] . ")</span></h6><br>";
                    $teks = $teks . "<h6><span class='badge badge-danger'>Error " . $TableConfirm[$i]['Tables_in_rs'] . " != " . $table[$i]['TableName'] . "</span></h6><br>";
                    break;
                } else {
                    continue;
                }
            }
            if ($errorSameDB > 0) {
                $error += 1;
                $teks = $teks . "<h6><span class='badge badge-danger'>Error Pada Kesamaan Nama Table</span></h6><br>";
            } else {
                for ($i = 0; $i < count($table); $i++) {

                    $TableConfirm = $this->TableCheckDB->checkDBWithField($table[$i]['TableName']);
                    for ($j = 0; $j < count($table[$i]['field']); $j++) {
                        if ($table[$i]['field'][$j] == $TableConfirm[$j]) {
                            $success += 1;
                        } else {
                            $teks = $teks . "<h6><span class='badge badge-danger'>Error Table " . $table[$i]['TableName'] . ", Field " . $table[$i]['field'][$j] . "</span></h6><br>";
                            $teks = $teks . "<h6><span class='badge badge-danger'>Field Pada Table Tidak Sama</span></h6><br>";
                            $error += 1;
                        }
                    }
                }
            }
        }
        if ($error == 0) {
            $teks = $teks . "<h6><span class='badge badge-success'>Tidak Ada Kesalahan</span></h6><br>";
        }
        $teks = $teks . "</div>";

        $data = ['status' => 200, 'response' => 'success', 'message' => $teks];
        return $this->respond($data, 200);
    }

    public function insertData()
    {
        $TableConfirm = $this->TableCheckDB->checkDB();
        $TableConfirm = $TableConfirm->getResultArray();
        if (!empty($TableConfirm)) {
            for ($j = 0; $j < count($TableConfirm); $j++) {
                $this->TableMkTable->dropTable($TableConfirm[$j]['Tables_in_rs']);
            }
        }
        $file = $this->request->getFile('file');
        $file = file_get_contents($file);
        $sqls = explode(';', $file);
        array_pop($sqls);
        foreach ($sqls as $statement) {
            $statment = $statement . ";";
            $this->data['Inst'] = $this->TableMkTable->createTable($statment);
        }

        $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Berhasil Disimpan'];
        return $this->respond($data, $data['status']);
    }
}
