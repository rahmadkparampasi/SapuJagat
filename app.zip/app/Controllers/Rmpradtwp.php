<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\UmMdl;

class Rmpradtwp extends BaseController
{
    use ResponseTrait;

    protected $MdlU;
    protected $Rmpradt;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_rmpradtwp', 'rs_rmpradtwp_id');
        $this->Rmpradt = new Rmpradt;
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOIgd',
            'pAct' => 'pAIgd',
            'cAct' => 'cArmpmsk',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {

        return redirect()->to('./rmpmsk');
    }

    public function getAll($rs_rmpradtwp_rmpradtw)
    {
        $this->data['Rmpradtwp'] = $this->setDB('getAll', $rs_rmpradtwp_rmpradtw);
        for ($i = 0; $i < count($this->data['Rmpradtwp']); $i++) {
            
            if ($this->data['Rmpradtwp'][$i]['rs_ppeg_nmd'] != "") {
                $this->data['Rmpradtwp'][$i]['rs_ppeg_nm'] = $this->data['Rmpradtwp'][$i]['rs_ppeg_nmd'] . ". " . $this->data['Rmpradtwp'][$i]['rs_ppeg_nm'];
            }

            if ($this->data['Rmpradtwp'][$i]['rs_ppeg_nmb'] != "") {
                $this->data['Rmpradtwp'][$i]['rs_ppeg_nm'] = $this->data['Rmpradtwp'][$i]['rs_ppeg_nm'] . ", " . $this->data['Rmpradtwp'][$i]['rs_ppeg_nmb'];
            }
        }
        return  $this->data['Rmpradtwp'];
    }
    

    public function insertData()
    {
        $rs_rmpradtwp_rmpradtw = $this->request->getPost('rs_rmpradtwp_rmpradtw');
        $rs_rmplp_ppeg = $this->request->getPost('rs_rmplp_ppeg');
        if ($rs_rmplp_ppeg == null || empty($rs_rmplp_ppeg)) {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Pilih Terlebih Dahulu Data Tenaga Medis'];
        } else {
            $success = 0;
            $error = 0;
            foreach ($this->request->getPost('rs_rmplp_ppeg') as $key) {
                $this->data['Rmpradtwp'] = $this->setDB('getAllByRmpradtwAndPpeg', [$rs_rmpradtwp_rmpradtw, $key]);
                if ($this->data['Rmpradtwp'] != null || count($this->data['Rmpradtwp']) > 0) {
                    $error = $error + 1;
                } else {
                    $data = [];

                    $data = [
                        'rs_rmpradtwp_rmpradtw' => $rs_rmpradtwp_rmpradtw,
                        'rs_rmpradtwp_ppeg' => $key,
                    ];
                    $insertData = $this->MdlU->insertData($data);
                    if ($insertData) {
                        $success = $success + 1;
                    } else {
                        $error = $error + 1;
                    }
                }
            }
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Tenaga Medis Dalam Tindakan Berhasil Diproses, Dengan Jumlah Data Yang Berhasil Disimpan Berjumlah ' . (string)$success . ' Data, Dan Yang Gagal Disimpan Berjumlah ' . (string)$error . ' Data'];
        }

        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmpradtwp_id = '')
    {
        if ($rs_rmpradtwp_id === null || $rs_rmpradtwp_id == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlU->deleteData($rs_rmpradtwp_id);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Tenaga Medis Dalam Tindakan Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Tenaga Medis Dalam Tindakan Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmpradtwp_id';
        $id = 'rs_rmpradtwp_id';
        $length = 3;
        $typeGet = 'result';

        $fillUpdate = '*';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmpradtwp_rmpradtw',
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpradtwp_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_ppeg', 'string' => 'rs_ppeg.rs_ppeg_id_ex = rs_rmpradtwp.rs_rmpradtwp_ppeg', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'getAllByRmpradtwAndPpeg') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmpradtwp_rmpradtw',
                        'idExV' => $data[0]
                    ],
                    1 => [
                        'idEx' => 'rs_rmpradtwp_ppeg',
                        'idExV' => $data[1]
                    ]
                ],
                //order by
                [],
                //join
                []
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpradt_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}