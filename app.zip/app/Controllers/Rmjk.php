<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\UmMdl;

class Rmjk extends BaseController
{
    use ResponseTrait;
    protected $MdlU;
    protected $Rmkb;
    protected $AI;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_rmjk', 'rs_rmjk_id_ex');
        $this->Rmkb = new Rmkb();
        $this->AI = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeng',
            'pAct' => 'pAPeng',
            'cAct' => 'cArmref',
            'cmAct' => '',
            'scAct' => '',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function viewData($rs_rmjk_rmkb)
    {
        $this->data['rs_rmjk_rmkb'] = $rs_rmjk_rmkb;
        $this->data['WebTitle'] = 'DATA JENIS KATEGORI';
        $this->data['PageTitle'] = 'Data Jenis Kategori';
        $this->data['BasePage'] = 'rmjk';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertView';
        $this->data['IdForm'] = 'rmjkAddData';
        $this->data['UrlForm'] = 'rmjk';
        $this->data['Rmjk'] = $this->setDB('getAll', $rs_rmjk_rmkb);
        $this->data['Rmkb'] = $this->Rmkb->getByIdEx($rs_rmjk_rmkb);


        echo view('Rmjk/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }

    public function getAll()
    {
        return $this->setDB('getAllByAct');
    }

    public function getAllForSelect($rs_rmjk_rmkb)
    {

        header("Content-Type:application/json;charset=utf-8");
        header("Access-Control-Allow-Origin: *");


        $data = $this->setDB('getAllByAct', $rs_rmjk_rmkb);
        for ($i = 0; $i < count($data); $i++) {
            $data[$i]['optText'] = $data[$i]['rs_rmjk_nm'];
            $data[$i]['optValue'] = $data[$i]['rs_rmjk_id_ex'];
        }
        return $this->respond($data, 200);
    }

    public function insertData()
    {

        $rs_rmjk_id_ex = $this->setDB('idEx', $this->AI->getRandStr(3));
        $rs_rmjk_nm = $this->request->getPost('rs_rmjk_nm');
        $rs_rmjk_rmkb = $this->request->getPost('rs_rmjk_rmkb');

        $data = [
            'rs_rmjk_id_ex' => $rs_rmjk_id_ex,
            'rs_rmjk_nm' => $rs_rmjk_nm,
            'rs_rmjk_rmkb' => $rs_rmjk_rmkb,
        ];

        $insertData = $this->MdlU->insertData($data);
        if ($insertData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Jenis Kategori Barang Berhasil Disimpan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Jenis Kategori Barang Tidak Dapat Disimpan'];
        }

        return $this->respond($data, $data['status']);
    }

    public function block($rs_rmjk_id_ex = '')
    {
        $data = [
            'rs_rmjk_sts' => "0",
        ];
        $updateData = $this->MdlU->updateData($data, $rs_rmjk_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Status Jenis Kategori Barang Berhasil Di Dinonaktifkan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Status Jenis Kategori Barang Tidak Dapat Di Dinonaktifkan'];
        }
        return $this->respond($data, $data['status']);
    }

    public function unblock($rs_rmjk_id_ex = '')
    {
        $data = [
            'rs_rmjk_sts' => "1",
        ];
        $updateData = $this->MdlU->updateData($data, $rs_rmjk_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Status Jenis Kategori Barang Berhasil Aktifkan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Status Jenis Kategori Barang Tidak Dapat Aktifkan'];
        }
        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmjk_id_ex';
        $id = 'rs_rmjk_id';
        $length = 2;
        $typeGet = 'result';

        $fillUpdate = 'rs_rmjk_id_ex, rs_rmkb_nm';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => ['idEx' => 'rs_rmjk_rmkb', 'idExV' => $data]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmjk_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'getAllByAct') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => ['idEx' => 'rs_rmjk_sts', 'idExV' => '1'],
                    1 => ['idEx' => 'rs_rmjk_rmkb', 'idExV' => $data]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmjk_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmjk_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}