<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\RmphMdl;
use App\Models\RmpmskMdl;
use App\Models\RmpmtMdl;

class Rmpmt extends BaseController
{
    use ResponseTrait;
    protected $MdlRmpmsk;
    protected $MdlRmpmt;
    protected $MdlRmph;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlRmpmsk = new RmpmskMdl();
        $this->MdlRmpmt = new RmpmtMdl();
        $this->MdlRmph = new RmphMdl();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOIgd',
            'pAct' => 'pAIgd',
            'cAct' => 'cArmpmsk',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {

        return redirect()->to('./rmpmsk');
    }

    public function insertData($rs_rmpmt_rmpmsk)
    {
        $this->data['Rmpmsk'] = $this->MdlRmpmsk->getAllRmpmsk($rs_rmpmt_rmpmsk);

        $rs_rmph_id_ex = $this->Another_Include->getRandStr(35);
        $rs_rmph_rmpp = $this->data['Rmpmsk']['rs_rmpmsk_rmpp'];
        $rs_rmph_ppeg = $this->data['rs_ppeg_id_ex'];
        $rs_rmph_jns = "CT";

        $rs_rmpmt_id_ex = $this->MdlRmpmt->getIdEx($this->Another_Include->getRandStr(25));
        $rs_rmpmt_rmicdt = $this->request->getPost('rs_rmpmt_rmicdt');
        $rs_rmpmt_pri = $this->request->getPost('rs_rmpmt_pri');
        $rs_rmpmt_dia = $this->request->getPost('rs_rmpmt_dia');

        $dataRmpmt = [
            'rs_rmpmt_id_ex' => $rs_rmpmt_id_ex,
            'rs_rmpmt_rmpmsk' => $rs_rmpmt_rmpmsk,
            'rs_rmpmt_rmph' => $rs_rmph_id_ex,
            'rs_rmpmt_rmicdt' => $rs_rmpmt_rmicdt,
            'rs_rmpmt_pri' => $rs_rmpmt_pri,
            'rs_rmpmt_dia' => $rs_rmpmt_dia,
        ];

        $dataRmph = [
            'rs_rmph_id_ex' => $rs_rmph_id_ex,
            'rs_rmph_rmpp' => $rs_rmph_rmpp,
            'rs_rmph_ppeg' => $rs_rmph_ppeg,
            'rs_rmph_jns' => $rs_rmph_jns
        ];

        $insertDataRmph = $this->MdlRmph->insertData($dataRmph);
        if ($insertDataRmph) {
            $insertDataRmpMt = $this->MdlRmpmt->insertData($dataRmpmt);
            if ($insertDataRmpMt) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Penyebab Kematian Pasien Berhasil Disimpan'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Penyebab Kematian Pasien Tidak Dapat Disimpan'];
            }
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Histori Pasien Tidak Dapat Disimpan'];
        }



        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmpmt_id_ex = '')
    {
        if ($rs_rmpmt_id_ex === null || $rs_rmpmt_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlRmpmt->deleteData($rs_rmpmt_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Penyebab Kematian Pasien Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Penyebab Kematian Pasien Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }
}
