<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\RmphMdl;
use App\Models\RmpmskMdl;
use App\Models\RmptdkMdl;

class Rmptdk extends BaseController
{
    use ResponseTrait;
    protected $MdlRmpmsk;
    protected $MdlRmtdk;
    protected $MdlRmph;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlRmpmsk = new RmpmskMdl();
        $this->MdlRmtdk = new RmptdkMdl();
        $this->MdlRmph = new RmphMdl();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOIgd',
            'pAct' => 'pAIgd',
            'cAct' => 'cArmpmsk',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {

        return redirect()->to('./rmpmsk');
    }

    public function insertData($rs_rmptdk_rmpmsk)
    {
        $this->data['Rmpmsk'] = $this->MdlRmpmsk->getAllRmpmsk($rs_rmptdk_rmpmsk);

        $rs_rmph_id_ex = $this->Another_Include->getRandStr(35);
        $rs_rmph_rmpp = $this->data['Rmpmsk']['rs_rmpmsk_rmpp'];
        $rs_rmph_ppeg = $this->data['rs_ppeg_id_ex'];
        $rs_rmph_jns = "CT";

        $rs_rmptdk_id_ex = $this->MdlRmtdk->getIdEx($this->Another_Include->getRandStr(25));
        $rs_rmptdk_rmicdn = $this->request->getPost('rs_rmptdk_rmicdn');
        $rs_rmptdk_tdk = $this->request->getPost('rs_rmptdk_tdk');

        $dataRmptdk = [
            'rs_rmptdk_id_ex' => $rs_rmptdk_id_ex,
            'rs_rmptdk_rmpmsk' => $rs_rmptdk_rmpmsk,
            'rs_rmptdk_rmph' => $rs_rmph_id_ex,
            'rs_rmptdk_rmicdn' => $rs_rmptdk_rmicdn,
            'rs_rmptdk_tdk' => $rs_rmptdk_tdk
        ];

        $dataRmph = [
            'rs_rmph_id_ex' => $rs_rmph_id_ex,
            'rs_rmph_rmpp' => $rs_rmph_rmpp,
            'rs_rmph_ppeg' => $rs_rmph_ppeg,
            'rs_rmph_jns' => $rs_rmph_jns
        ];

        $insertDataRmph = $this->MdlRmph->insertData($dataRmph);
        if ($insertDataRmph) {
            $insertDataRmpTdk = $this->MdlRmtdk->insertData($dataRmptdk);
            if ($insertDataRmpTdk) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Tindakan (ICD 9) Pasien Berhasil Disimpan'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Tindakan (ICD 9) Pasien Tidak Dapat Disimpan'];
            }
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Histori Pasien Tidak Dapat Disimpan'];
        }



        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmptdk_id_ex = '')
    {
        if ($rs_rmptdk_id_ex === null || $rs_rmptdk_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlRmtdk->deleteData($rs_rmptdk_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Tindakan (ICD 9) Pasien Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Tindakan (ICD 9) Pasien Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }
}
