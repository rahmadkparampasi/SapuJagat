<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use Faker\Factory;

class Cmps extends BaseController
{
    use ResponseTrait;
    protected $data;

    public function __construct()
    {

        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeg',
            'pAct' => 'pAHome',
            'cAct' => '',
            'cmAct' => '',
            'scAct' => '',


            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }
    public function index()
    {

        $faker = Factory::create('id_ID');
        // $faker->addProvider(new Faker\Provider\es_ES\Person($faker));
        echo $faker->name('female');
        $this->spacer();
        echo $faker->address();
        $this->spacer();
        echo $faker->numberBetween(1000000000000000, 9999999999999999);
        $this->spacer();
        echo $faker->city();
        $this->spacer();
        echo $faker->dateTimeThisCentury->format('Y-m-d');
        $this->spacer();
        echo $faker->e164PhoneNumber();
    }

    function spacer()
    {
        echo "<br />";
    }
}