<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\RmrMdl;

class Rmr extends BaseController
{
    use ResponseTrait;
    protected $MdlRmr;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlRmr = new RmrMdl();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeng',
            'pAct' => 'pAPeng',
            'cAct' => 'cArmr',

            'cmAct' => '',
            'scAct' => '',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-fixed layout-footer-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA RUANGAN';
        $this->data['PageTitle'] = 'Data Ruangan';
        $this->data['BasePage'] = 'rmr';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData';
        $this->data['IdForm'] = 'rmrAddData';
        $this->data['UrlForm'] = 'rmr';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);
        $this->data['Rmr'] = $this->MdlRmr->getAllRmr();

        echo view('Rmr/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }

    public function editData($rs_rmr_id_ex = '')
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA RUANGAN';
        $this->data['PageTitle'] = 'Data Ruangan';
        $this->data['BasePage'] = 'rmr';
        $this->data['ButtonMethod'] = 'UBAH';
        $this->data['MethodForm'] = 'updateData/' . $rs_rmr_id_ex;
        $this->data['IdForm'] = 'rmrAddData';
        $this->data['UrlForm'] = 'rmr';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);


        $this->data['Rmr'] = $this->MdlRmr->getAllRmr();
        if ($rs_rmr_id_ex === null || $rs_rmr_id_ex == '') {
            return redirect()->to('/' . $this->data['BasePage']);
        } else {
            $this->data['fillUpdate'] = $this->MdlRmr->getAllRmr($rs_rmr_id_ex);

            echo view('Rmr/index', $this->data);
            echo view('Templates/anotherScript');
            echo view('Templates/ajaxInsert', $this->data);
            echo view('Templates/loadData');
        }
    }

    public function getRmrByJson($rs_ppeg_id_ex, $BasePage)
    {
        header('Content-Type: application/json');
        header("Access-Control-Allow-Origin: *");

        $this->data['data']['data'] = $this->MdlRmr->getAllRmr();
        $no = 0;
        for ($i = 0; $i < count($this->data['data']['data']); $i++) {
            $no++;
            $this->data['data']['data'][$i]['no'] = $no;

            $this->data['data']['data'][$i]['button'] = "<button class='btn bg-gradient-success' title='Tambahkan Data Ruangan Pegawai' onclick='callOther(\"Menambahkan Data Ruangan " . $this->data['data']['data'][$i]['rs_rmr_nm'] . " Dalam Data Pegawai\", \"/" . $BasePage . "/addRmrToPpeg/" . $this->data['data']['data'][$i]['rs_rmr_id_ex'] . "/" . $rs_ppeg_id_ex . "\")'><i class='fas fa-check'></i></button>";
        }
        return $this->respond($this->data['data'], 200);
    }

    public function getAllForSelectByPrt($rs_rmr_id_ex)
    {
        header("Content-Type:application/json;charset=utf-8");
        header("Access-Control-Allow-Origin: *");


        $data = $this->MdlRmr->getByParent($rs_rmr_id_ex);
        for ($i = 0; $i < count($data); $i++) {
            $data[$i]['optText'] = $data[$i]['rs_rmr_nm'];
            $data[$i]['optValue'] = $data[$i]['rs_rmr_id_ex'];
        }
        return $this->respond($data, 200);
    }

    public function getParentByJson()
    {
        $parent_category_id = "";
        $dataByParent = $this->MdlRmr->getAllRmr();
        foreach ($dataByParent as $val) {
            $data = $this->get_node_data($parent_category_id);
        }

        return $this->respond($data, 200);
    }

    public function get_node_data($rs_rmr_prnt = '')
    {
        $dataByParent = $this->MdlRmr->getByParent($rs_rmr_prnt);
        $output = array();
        foreach ($dataByParent as $row) {
            $sub_array = array();
            if ($row['rs_rmr_sts'] == "0") {
                $sub_array['text'] = "<span class='badge badge-danger'>" . $row['rs_rmr_nm'] . "</span>";
            } else {
                $sub_array['text'] = $row['rs_rmr_nm'];
            }
            $sub_array['textAlt'] = $row['rs_rmr_nm'];
            $sub_array['sts'] = $row['rs_rmr_sts'];
            $sub_array['idEx'] = $row['rs_rmr_id_ex'];
            $sub_array['str'] = $row['rs_rmr_str'];


            $sub_array['nodes'] = array_values($this->get_node_data($row['rs_rmr_id_ex']));
            $sub_array['tags'] = [(string)count($sub_array['nodes'])];
            if (empty($sub_array['nodes'])) {
                unset($sub_array['nodes']);
            }
            $output[] = $sub_array;
        }
        return $output;
    }

    public function insertData()
    {

        $rs_rmr_id_ex = $this->MdlRmr->getIdEx($this->Another_Include->getRandStr(5));
        $rs_rmr_nm = $this->request->getPost('rs_rmr_nm');
        $rs_rmr_prnt = $this->request->getPost('rs_rmr_prnt');
        $rs_rmr_bag = $this->request->getPost('rs_rmr_bag');
        $rs_rmr_str = $this->request->getPost('rs_rmr_str');
        $rs_rmr_str = (int)$rs_rmr_str + 1;

        $data = [
            'rs_rmr_id_ex' => $rs_rmr_id_ex,
            'rs_rmr_nm' => $rs_rmr_nm,
            'rs_rmr_prnt' => $rs_rmr_prnt,
            'rs_rmr_bag' => $rs_rmr_bag,
            'rs_rmr_str' => $rs_rmr_str,
        ];

        $insertData = $this->MdlRmr->insertData($data);
        if ($insertData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Ruangan Berhasil Disimpan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Ruangan Tidak Dapat Disimpan'];
        }

        return $this->respond($data, $data['status']);
    }

    public function updateData($rs_rmr_id_ex = '')
    {
        $rs_rmr_nm = $this->request->getPost('rs_rmr_nm');
        $rs_rmr_k = $this->request->getPost('rs_rmr_k');
        $rs_rmr_id_ex = $this->request->getPost('rs_rmr_id_ex');
        $data = [
            'rs_rmr_nm' => $rs_rmr_nm,
            'rs_rmr_k' => $rs_rmr_k,
        ];
        $updateData = $this->MdlRmr->updateData($data, $rs_rmr_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Ruangan Berhasil Diubah'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Ruangan Tidak Dapat Diubah'];
        }
        return $this->respond($data, $data['status']);
    }

    public function blockRmr($rs_rmr_id_ex = '')
    {
        $data = [
            'rs_rmr_sts' => "0",
        ];
        $updateData = $this->MdlRmr->updateData($data, $rs_rmr_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Ruangan Berhasil Dinonaktifkan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Ruangan Tidak Dapat Dinonaktifkan'];
        }
        return $this->respond($data, $data['status']);
    }

    public function ublockRmr($rs_rmr_id_ex = '')
    {
        $data = [
            'rs_rmr_sts' => "1",
        ];
        $updateData = $this->MdlRmr->updateData($data, $rs_rmr_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Ruangan Berhasil Dinonaktifkan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Ruangan Tidak Dapat Dinonaktifkan'];
        }
        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmr_id_ex = '')
    {
        if ($rs_rmr_id_ex === null || $rs_rmr_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlRmr->deleteData($rs_rmr_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Ruangan Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Ruangan Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }
}