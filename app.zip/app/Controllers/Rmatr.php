<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\UmMdl;

class Rmatr extends BaseController
{
    use ResponseTrait;
    protected $MdlU;
    protected $Setant;
    protected $Setsra;
    protected $AI;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_rmatr', 'rs_rmatr_id_ex');
        $this->Setant = new Setant;
        $this->Setsra = new Setsra;
        $this->AI = new Another_Include();
        $this->session = \Config\Services::session();
        date_default_timezone_set("Asia/Makassar");
        $this->data = [
            'mOp' => 'mOAtr',
            'pAct' => 'pAAtr',
            'cAct' => '',
            'cmAct' => '',
            'scAct' => '',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
            'rs_ppr_rmr' => $this->session->get('rs_ppr_rmr'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {

        $this->data['WebTitle'] = 'ANTRIAN';
        $this->data['PageTitle'] = 'Antrian';
        $this->data['BasePage'] = 'rmatr';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'viewForm';
        $this->data['IdForm'] = 'rmatrAddData';
        $this->data['UrlForm'] = 'rmatr';

        $this->data['Setant'] = $this->Setant->getAll();
        // dd($this->data['Setant']);
        echo view('Rmatr/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }

    public function viewData()
    {
        $this->data['WebTitle'] = 'ANTRIAN';
        $this->data['PageTitle'] = 'Antrian';
        $this->data['BasePage'] = 'rmatr';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'viewForm';
        $this->data['IdForm'] = 'rmatrAddData';
        $this->data['UrlForm'] = 'rmatr';

        $this->data['Rmatr'] = $this->setDB('getAllByDate', date("Y-m-d"));
        $this->data['Rmatr'] = $this->AI->changeDateWF($this->data['Rmatr'], ['rs_rmatr_tgl']);
        for ($i=0; $i < count($this->data['Rmatr']); $i++) { 
            $this->data['Rmatr'][$i]['rs_rmatr_kd_new'] = substr($this->data['Rmatr'][$i]['rs_rmatr_kd'], 2, 4);
            $this->data['Rmatr'][$i]['atr'] = str_split($this->data['Rmatr'][$i]['rs_rmatr_kd_new']);
            $this->data['Rmatr'][$i]['m'] = [];
            for ($j=0; $j < count($this->data['Rmatr'][$i]['atr']); $j++) { 
                array_push($this->data['Rmatr'][$i]['m'], $this->Setsra->getByNm($this->data['Rmatr'][$i]['atr'][$j]));
            }

            //jangan lupa samakan dengan ruangan pegawai
            $this->data['Rmatr'][$i]['me'] = $this->Setant->getVByRmr($this->data['rs_ppr_rmr']);
        }

        // dd($this->data['Rmatr']);
        $this->data['Setsra'] = $this->Setsra->getAll();
        // dd($this->data['Setant']);
        echo view('Rmatr/indexVD', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }

    public function ctk($rs_rmatr_id_ex = '')
    {
        if ($rs_rmatr_id_ex == "") {
            return redirect()->to('/rmatr');
        }
        $this->data['WebTitle'] = 'ANTRIAN';
        $this->data['PageTitle'] = 'Antrian';
        $this->data['BasePage'] = 'rmatr';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'viewForm';
        $this->data['IdForm'] = 'rmatrAddData';
        $this->data['UrlForm'] = 'rmatr';

        $this->data['Rmatr'] = $this->setDB('getAllByIdEx', $rs_rmatr_id_ex);
        $this->data['Rmatr']['rs_rmatr_tgl'] = $this->AI->changeDateNF($this->data['Rmatr']['rs_rmatr_tgl']);
        // dd($this->data['Rmatr']);
        echo view('Rmatr/indexCtk', $this->data);
        // echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }



    public function getAll()
    {
        return $this->setDB('getAllByAct');
    }

    public function insertData($rs_rmatr_rmr, $rs_rmja_nm, $rs_rmatr_rmja)
    {

        $rs_rmatr_id_ex = $this->setDB('idEx', $this->AI->getRandStr(7));
        $rs_rmatr_tgl = date('Y-m-d');
        // $rs_rmatr_tgl = "2021-10-04";
        $rs_rmatr_jam = date('H:i:s');
        $rs_rmatr_kd = $this->setDB('getKode', [$rs_rmatr_tgl,$rs_rmatr_rmja, $rs_rmja_nm]);
        $rs_rmatr_rmr = $rs_rmatr_rmr;
        $rs_rmatr_rmja = $rs_rmatr_rmja;

        // dd($rs_rmatr_kd);

        $data = [
            'rs_rmatr_id_ex' => $rs_rmatr_id_ex,
            'rs_rmatr_tgl' => $rs_rmatr_tgl,
            'rs_rmatr_jam' => $rs_rmatr_jam,
            'rs_rmatr_kd' => $rs_rmatr_kd,
            'rs_rmatr_rmr' => $rs_rmatr_rmr,
            'rs_rmatr_rmja' => $rs_rmatr_rmja,
        ];

        $insertData = $this->MdlU->insertData($data);
        if ($insertData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Nomor Antrian Anda '.$rs_rmatr_kd, 'idEx'=>$rs_rmatr_id_ex];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Antrian Tidak Dapat Diproses'];
        }

        return $this->respond($data, $data['status']);
    }


    public function processRmatr($rs_rmatr_id_ex = '', $rs_rmatr_sts = '0')
    {
        $data = [
            'rs_rmatr_sts' => "1",

        ];
        $updateData = $this->MdlU->updateData($data, $rs_rmatr_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Status Jenis Staf Medis Fungsional Berhasil Di Dinonaktifkan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Status Jenis Staf Medis Fungsional Tidak Dapat Di Dinonaktifkan'];
        }
        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmatr_id_ex';
        $id = 'rs_rmatr_id';
        $length = 3;
        $typeGet = 'result';

        $fillUpdate = 'rs_rmatr_id_ex, rs_rmatr_nm';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [],
                //order by
                [
                    0 => ['id' => 'rs_rmatr_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        }elseif ($request == 'getAllByDate') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => ['idEx' => 'rs_rmatr_tgl', 'idExV' => $data]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmatr_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmr', 'string' => 'rs_rmr.rs_rmr_id_ex = rs_rmatr.rs_rmatr_rmr', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_rmja', 'string' => 'rs_rmja.rs_rmja_id_ex = rs_rmatr.rs_rmatr_rmja', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'getAllByIdEx') {
            return $this->MdlU->getAll(
                //type result / row
                'row',
                // select *
                '*',
                //where
                [
                    0 => ['idEx' => 'rs_rmatr_id_ex', 'idExV' => $data]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmatr_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmr', 'string' => 'rs_rmr.rs_rmr_id_ex = rs_rmatr.rs_rmatr_rmr', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_rmja', 'string' => 'rs_rmja.rs_rmja_id_ex = rs_rmatr.rs_rmatr_rmja', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        } elseif ($request == 'getKode') {
            return $this->MdlU->getKode('rs_rmatr_kd', $data[2], $id, $length, [0 => ['idEx' => 'rs_rmatr_tgl', 'idExV' => $data[0]], 1 => ['idEx' => 'rs_rmatr_rmja', 'idExV' => $data[1]]]);
        }
    }
}
