<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\RmpaepMdl;
use App\Models\RmpakspMdl;
use App\Models\RmpakuMdl;
use App\Models\RmpapgMdl;
use App\Models\RmparaMdl;
use App\Models\RmparoMdl;
use App\Models\RmparpMdl;
use App\Models\RmpasfMdl;
use App\Models\RmpauMdl;
use App\Models\RmpcpptMdl;
use App\Models\RmpdiaMdl;
use App\Models\RmpedMdl;
use App\Models\RmphMdl;
use App\Models\RmpjkMdl;
use App\Models\RmpmskMdl;
use App\Models\RmpmtMdl;
use App\Models\RmpnldMdl;
use App\Models\RmpnlfMdl;
use App\Models\RmpnlnMdl;
use App\Models\RmpnlsMdl;
use App\Models\RmpprkfMdl;
use App\Models\RmpprkfuMdl;
use App\Models\RmpprknMdl;
use App\Models\RmpprktMdl;
use App\Models\RmprMdl;
use App\Models\RmprmtMdl;
use App\Models\RmprtMdl;
use App\Models\RmptdkMdl;
use App\Models\RmptrMdl;
use App\Models\RmrmtMdl;

class Rmpmskd extends BaseController
{
    use ResponseTrait;
    protected $MdlRmpmsk,
        $MdlRmptr,
        $MdlRmprt,
        $MdlRmpjk,
        $MdlRmph,
        $MdlRmpdia,
        $MdlRmptdk,
        $MdlRmpmt,
        $MdlRmpprkt,
        $MdlRmpprkf,
        $MdlRmpprkfu,
        $MdlRmpprkn,
        $MdlRmpcppt,
        $MdlRmped,
        $MdlRmpnlf,
        $MdlRmpnln,
        $MdlRmpnld,
        $MdlRmpnls,
        $MdlRmpau,
        $MdlRmparp,
        $MdlRmpara,
        $MdlRmparo,
        $MdlRmpaku,
        $MdlRmpasf,
        $MdlRmpapg,
        $MdlRmpaep,
        $MdlRmpaksp,
        $MdlRmrmt,
        $MdlRmprmt,
        $MdlRmpr,
        $Rmpmskpj,
        $Rmpjt,
        $Rmpl,
        $Rmplab,
        $Rmplabt,
        $Rmprad,
        $Rmpradt,
        $Rmpres,
        $Rmprk,
        $Rmpsls,
        $Rmpplg,
        $Setrmr,
        $AI,
        $data,
        $session;

    public function __construct()
    {
        $this->MdlRmpmsk = new RmpmskMdl();
        $this->MdlRmptr = new RmptrMdl();
        $this->MdlRmprt = new RmprtMdl();
        $this->MdlRmpjk = new RmpjkMdl();
        $this->MdlRmph = new RmphMdl();
        $this->MdlRmpdia = new RmpdiaMdl();
        $this->MdlRmptdk = new RmptdkMdl();
        $this->MdlRmpmt = new RmpmtMdl();
        $this->MdlRmpprkt = new RmpprktMdl();
        $this->MdlRmpprkf = new RmpprkfMdl();
        $this->MdlRmpprkfu = new RmpprkfuMdl();
        $this->MdlRmpprkn = new RmpprknMdl();
        $this->MdlRmpcppt = new RmpcpptMdl();
        $this->MdlRmped = new RmpedMdl();
        $this->MdlRmpnlf = new RmpnlfMdl();
        $this->MdlRmpnln = new RmpnlnMdl();
        $this->MdlRmpnld = new RmpnldMdl();
        $this->MdlRmpnls = new RmpnlsMdl();
        $this->MdlRmpau = new RmpauMdl();
        $this->MdlRmparp = new RmparpMdl();
        $this->MdlRmpara = new RmparaMdl();
        $this->MdlRmparo = new RmparoMdl();
        $this->MdlRmpaku = new RmpakuMdl();
        $this->MdlRmpasf = new RmpasfMdl();
        $this->MdlRmpapg = new RmpapgMdl();
        $this->MdlRmpaep = new RmpaepMdl();
        $this->MdlRmpaksp = new RmpakspMdl();
        $this->MdlRmrmt = new RmrmtMdl();
        $this->MdlRmprmt = new RmprmtMdl();
        $this->MdlRmpr = new RmprMdl();
        $this->Rmpmskpj = new Rmpmskpj();
        $this->Rmpjt = new Rmpjt();
        $this->Rmpl = new Rmpl();
        $this->Rmplab = new Rmplab();
        $this->Rmplabt = new Rmplabt();
        $this->Rmprad = new Rmprad();
        $this->Rmpradt = new Rmpradt();
        $this->Rmpres = new Rmpres();
        $this->Rmprk = new Rmprk();
        $this->Rmpsls = new Rmpsls();
        $this->Rmpplg = new Rmpplg();
        $this->Setrmr = new Setrmr();
        $this->AI = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data['setRmr'] = $this->Setrmr->getAll();
        $this->data = [
            'mOp' => 'mOIgd',
            'pAct' => 'pAIgd',
            'cAct' => 'cArmpmsk',
            'cmAct' => '',
            'scAct' => '',

            'tabParent' => $this->session->get('tabParent'),
            'tabLeftParent' => $this->session->get('tabLeftParent'),
            'tabItem' => $this->session->get('tabItem'),

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),

            'setRmr' => [
                'setRmrPl' => $this->data['setRmr'][0]['rs_setrmr_rmr'],
                'setRmrIgdU' => $this->data['setRmr'][1]['rs_setrmr_rmr'],
                'setRmrLab' => $this->data['setRmr'][2]['rs_setrmr_rmr'],
                'setRmrRad' => $this->data['setRmr'][3]['rs_setrmr_rmr'],
                'setRmrApt' => $this->data['setRmr'][4]['rs_setrmr_rmr'],
                'setRmrIri' => $this->data['setRmr'][5]['rs_setrmr_rmr'],
            ]
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {

        return redirect()->to('./rmpmsk');
    }

    public function viewData($rs_rmpmsk_id_ex = '')
    {
        // dd($this->session->get());
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['eEdit'] = '';
        $this->data['Rmpmsk'] = $this->MdlRmpmsk->getAllRmpmskWJ($rs_rmpmsk_id_ex);
        if ($this->data['Rmpmsk']['rs_rmpmsk_plg'] === "1") {
            $this->data['eEdit'] = 'd-none';
        }

        $this->data['Rmpmskpj'] = $this->Rmpmskpj->getByRmpmsk($rs_rmpmsk_id_ex);
        $this->data['Rmpr'] = $this->MdlRmpr->getByRmpmsk($rs_rmpmsk_id_ex);

        $this->data['Rmpmsk']['rs_rmpmsk_tgl'] = $this->AI->changeDateNF($this->data['Rmpmsk']['rs_rmpmsk_tgl']);
        $this->data['Rmpmsk']['rs_rmpp_tgl_lhr'] = $this->AI->changeDateNF($this->data['Rmpmsk']['rs_rmpp_tgl_lhr']);
        $this->data['Rmpmsk'] = $this->changeTextRmpmsk($this->data['Rmpmsk']);
        if ($this->data['Rmpmsk']=="1"||$this->data['Rmpmskpj']!=null) {
            $this->data['Rmpmskpj'] = $this->changeTextRmpmskPj($this->data['Rmpmskpj']);
        }



        $this->data['WebTitle'] = 'DATA PASIEN MASUK ' . strtoupper($this->data['Rmpmsk']['rs_rmpmsk_tgl'] . "-" . $this->data['Rmpmsk']['rs_rmpmsk_jam']);
        $this->data['PageTitle'] = 'Data Pasien Masuk ' . $this->data['Rmpmsk']['rs_rmpmsk_tgl'] . "-" . $this->data['Rmpmsk']['rs_rmpmsk_jam'];
        $this->data['BasePage'] = 'rmpmskd';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData/' . $rs_rmpmsk_id_ex;
        $this->data['IdForm'] = 'rmpmskdAddData';
        $this->data['UrlForm'] = 'rmpmskd/viewData/' . $rs_rmpmsk_id_ex;

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);

        $this->data['Rmptr'] = $this->MdlRmptr->getAllRmptr($rs_rmpmsk_id_ex);
        $this->data['Rmptr'] = $this->changeTextRmptr($this->data['Rmptr']);

        $this->data['Rmprt'] = $this->MdlRmprt->getAllRmprt($rs_rmpmsk_id_ex);

        $this->data['Rmpjk'] = $this->MdlRmpjk->getAllRmpjk($rs_rmpmsk_id_ex);
        $this->data['Rmpjk'] = $this->AI->changeDateWF($this->data['Rmpjk'], ['rs_rmpjk_tgl']);


        $this->data['Rmpdia'] = $this->MdlRmpdia->getAll($rs_rmpmsk_id_ex);
        $this->data['Rmptdk'] = $this->MdlRmptdk->getAll($rs_rmpmsk_id_ex);
        $this->data['Rmpmt'] = $this->MdlRmpmt->getAll($rs_rmpmsk_id_ex);

        $this->data['Rmpprkt'] = $this->MdlRmpprkt->getAll($rs_rmpmsk_id_ex);
        $this->data['Rmpprkt'] = $this->AI->changeDateWF($this->data['Rmpprkt'], ['rs_rmpprkt_tgl']);
        $this->data['Rmpprkt'] = $this->AI->replaceTextWF($this->data['Rmpprkt'], ['rs_rmpprkt_sh'], '.', ',');
        $this->data['Rmpprkf'] = $this->MdlRmpprkf->getAll($rs_rmpmsk_id_ex);
        $this->data['Rmpprkfu'] = $this->MdlRmpprkfu->getAll($rs_rmpmsk_id_ex);
        $this->data['Rmpprkn'] = $this->MdlRmpprkn->getAll($rs_rmpmsk_id_ex);
        $this->data['Rmpprkn'] = $this->AI->replaceTextWF($this->data['Rmpprkn'], ['rs_rmpprkn_bb', 'rs_rmpprkn_tb', 'rs_rmpprkn_imt', 'rs_rmpprkn_lk'], '.', ',');


        $this->data['Cppt'] = $this->MdlRmpcppt->getAllRmpcppt($rs_rmpmsk_id_ex);
        $this->data['Cppt'] = $this->AI->changeDateWF($this->data['Cppt'], ['rs_rmpcppt_tgl']);

        $this->data['Rmped'] = $this->MdlRmped->getAll($rs_rmpmsk_id_ex);

        $this->data['Rmpnlf'] = $this->MdlRmpnlf->getAll($rs_rmpmsk_id_ex);
        $this->data['Rmpnln'] = $this->MdlRmpnln->getAll($rs_rmpmsk_id_ex);
        $this->data['Rmpnln'] = $this->MdlRmpnln->convert($this->data['Rmpnln']);

        $this->data['Rmpnld'] = $this->MdlRmpnld->getAll($rs_rmpmsk_id_ex);
        $this->data['Rmpnls'] = $this->MdlRmpnls->getAll($rs_rmpmsk_id_ex);
        $this->data['Rmpnls'] = $this->MdlRmpnls->convert($this->data['Rmpnls']);
        $this->data['Rmpnls'] = $this->AI->cBWF($this->data['Rmpnls'], 'rs_rmpnls_sts', ['danger', 'success', 'warning']);

        $this->data['Rmpau'] = $this->MdlRmpau->getAll($rs_rmpmsk_id_ex);
        $this->data['Rmparp'] = $this->MdlRmparp->getAll($rs_rmpmsk_id_ex);
        $this->data['Rmpara'] = $this->MdlRmpara->getAll($rs_rmpmsk_id_ex);
        $this->data['Rmparo'] = $this->MdlRmparo->getAll($rs_rmpmsk_id_ex);
        $this->data['Rmpaku'] = $this->MdlRmpaku->getAll($rs_rmpmsk_id_ex);
        $this->data['Rmpasf'] = $this->MdlRmpasf->getAll($rs_rmpmsk_id_ex);
        $this->data['Rmpasf'] = $this->MdlRmpasf->convert($this->data['Rmpasf']);

        $this->data['Rmpapg'] = $this->MdlRmpapg->getAll($rs_rmpmsk_id_ex);
        $this->data['Rmpapg'] = $this->MdlRmpapg->convert($this->data['Rmpapg']);

        $this->data['Rmpaep'] = $this->MdlRmpaep->getAll($rs_rmpmsk_id_ex);
        $this->data['Rmpaep'] = $this->MdlRmpaep->convert($this->data['Rmpaep']);

        $this->data['Rmpaksp'] = $this->MdlRmpaksp->getAll($rs_rmpmsk_id_ex);



        $this->data['Rmmt'] = $this->MdlRmrmt->getAll($this->data['Rmpr']['rs_rmpr_rmr']);
        $this->data['Rmprmt'] = $this->MdlRmprmt->getAll($rs_rmpmsk_id_ex);
        $this->data['Rmprmt'] = $this->AI->changeDateWF($this->data['Rmprmt'], ['rs_rmprmt_tgl']);
        $this->data['Rmpjt'] = $this->Rmpjt->getAll($rs_rmpmsk_id_ex);
        for ($i = 0; $i < count($this->data['Rmpjt']); $i++) {
            if ($this->data['Rmpjt'][$i]['rs_ppeg_nmd'] != "") {
                $this->data['Rmpjt'][$i]['rs_ppeg_nm'] = $this->data['Rmpjt'][$i]['rs_ppeg_nmd'] . ". " . $this->data['Rmpjt'][$i]['rs_ppeg_nm'];
            }

            if ($this->data['Rmpjt'][$i]['rs_ppeg_nmb'] != "") {
                $this->data['Rmpjt'][$i]['rs_ppeg_nm'] = $this->data['Rmpjt'][$i]['rs_ppeg_nm'] . ", " . $this->data['Rmpjt'][$i]['rs_ppeg_nmb'];
            }
        }
        $this->data['Rmpl'] = $this->Rmpl->getAll($rs_rmpmsk_id_ex);
        $this->data['Rmplab'] = $this->Rmplab->getAll($rs_rmpmsk_id_ex);
        $this->data['Rmprad'] = $this->Rmprad->getAll($rs_rmpmsk_id_ex);
        $this->data['Rmpres'] = $this->Rmpres->getAll($rs_rmpmsk_id_ex);
        $this->data['Rmprk'] = $this->Rmprk->getAll($rs_rmpmsk_id_ex);
        $this->data['Rmpplg'] = $this->Rmpplg->getAll($rs_rmpmsk_id_ex);
        $this->data['Rmpsls'] = $this->Rmpsls->getAll($rs_rmpmsk_id_ex);

        $this->data['Rmplabt'] = $this->Rmplabt->getAllByRmpmsk($rs_rmpmsk_id_ex);
        $this->data['Rmpradt'] = $this->Rmpradt->getAllByRmpmsk($rs_rmpmsk_id_ex);


        // dd($this->data);



        if ($rs_rmpmsk_id_ex === null || $rs_rmpmsk_id_ex == '') {
            return redirect()->to('/' . $this->data['BasePage']);
        } else {
            echo view('Rmpmskd/index', $this->data);
            echo view('Templates/anotherScript');
            echo view('Templates/ajaxInsert', $this->data);
        }
    }

    public function insertData($rs_rmptr_rmpmsk)
    {
        $this->data['Rmpmsk'] = $this->MdlRmpmsk->getAllRmpmsk($rs_rmptr_rmpmsk);

        $rs_rmph_id_ex = $this->AI->getRandStr(35);
        $rs_rmph_rmpp = $this->data['Rmpmsk']['rs_rmpmsk_rmpp'];
        $rs_rmph_ppeg = $this->data['rs_ppeg_id_ex'];
        $rs_rmph_jns = "CT";

        $array = $this->request->getPost();
        unset($array['datatableKirana_length']);
        $arrayFlip = array_keys($array);
        $arrayFlipV = array_values($arrayFlip);
        $arrayV = array_values($array);

        $rs_rmptr = [];

        $rs_rmptr_id_ex = $this->AI->getRandStr(35);

        $rs_rmptr['rs_rmptr_id_ex'] = $rs_rmptr_id_ex;
        $rs_rmptr['rs_rmptr_rmpmsk'] = $rs_rmptr_rmpmsk;
        $rs_rmptr['rs_rmptr_rmph'] = $rs_rmph_id_ex;
        for ($i = 0; $i < count($arrayV); $i++) {
            $rs_rmptr[$arrayFlipV[$i]] = $arrayV[$i];
        }

        $dataRmph = [
            'rs_rmph_id_ex' => $rs_rmph_id_ex,
            'rs_rmph_rmpp' => $rs_rmph_rmpp,
            'rs_rmph_ppeg' => $rs_rmph_ppeg,
            'rs_rmph_jns' => $rs_rmph_jns
        ];

        $insertDataRmph = $this->MdlRmph->insertData($dataRmph);
        if ($insertDataRmph) {
            $insertDataRmptr = $this->MdlRmptr->insertData($rs_rmptr);
            if ($insertDataRmptr) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Triage Pasien Berhasil Disimpan'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Histori Pasien Tidak Dapat Disimpan'];
            }
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Histori Pasien Tidak Dapat Disimpan'];
        }

        return $this->respond($data, $data['status']);
    }

    public function updateData($rs_rmptr_id_ex = '')
    {
        $array = $this->request->getPost();
        unset($array['datatableKirana_length']);
        unset($array['rs_rmptr_id_ex']);
        $arrayFlip = array_keys($array);
        $arrayFlipV = array_values($arrayFlip);
        $arrayV = array_values($array);

        $rs_rmptr = [];

        for ($i = 0; $i < count($arrayV); $i++) {
            $rs_rmptr[$arrayFlipV[$i]] = $arrayV[$i];
        }

        $insertDataRmptr = $this->MdlRmptr->updateData($rs_rmptr, $rs_rmptr_id_ex);
        if ($insertDataRmptr) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Triage Pasien Berhasil Diubah'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Histori Pasien Tidak Dapat Diubah'];
        }

        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmr_id_ex = '')
    {
        if ($rs_rmr_id_ex === null || $rs_rmr_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlRmr->deleteData($rs_rmr_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Ruangan Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Ruangan Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function changeTextRmptr($data)
    {
        for ($i = 0; $i < count($data); $i++) {
            $data[$i]['rs_rmptr_tgl'] = $this->AI->changeDateNF($data[$i]['rs_rmptr_tgl']);
        }
        return $data;
    }

    public function changeTextRmpmsk($data)
    {
        if ($data['rs_rmpmsk_pj'] == "0") {
            $data['rs_rmpmsk_pj'] = "Tidak Ada";
        } elseif ($data['rs_rmpmsk_pj'] == "1") {
            $data['rs_rmpmsk_pj'] = "Ada";
        }

        $data['rs_rmpmsk_alt1'] = substr($data['rs_rmpmsk_alt'], 0, 30) . '...';
        $data = $this->AI->convertJKNF($data, 'rs_rmpp_jk');

        if ($data['rs_rmpp_altn'] != "") {
            $data['rs_rmpp_altn'] = ", No. " . $data['rs_rmpp_altn'];
        }
        if ($data['rs_rmpp_altr'] != "") {
            $data['rs_rmpp_altr'] = ", RT/RW. " . $data['rs_rmpp_altr'];
        } else {
            $data['rs_rmpp_altr'] = ", RT/RW. -";
        }
        if ($data['rs_rmpp_altkk'] != "") {
            $data['rs_rmpp_altkk'] = ", Kelurahan/Kecamatan: " . $data['rs_rmpp_altkk'];
        } else {
            $data['rs_rmpp_altkk'] = ", Kelurahan/Kecamatan: - ";
        }

        if ($data['rs_rmpp_altkp'] != "") {
            $data['rs_rmpp_altkp'] = ", Kota/Kode Pos: " . $data['rs_rmpp_altkp'];
        } else {
            $data['rs_rmpp_altkp'] = ", Kota/Kode Pos: - ";
        }

        if ($data['rs_rmpp_altth'] != "") {
            $data['rs_rmpp_altth'] = ", Telepon/HP: " . $data['rs_rmpp_altth'];
        } else {
            $data['rs_rmpp_altth'] = ", Telepon/HP: - ";
        }

        if ($data['rs_rmpp_altktp'] != "") {
            $data['rs_rmpp_altktp'] = $data['rs_rmpp_altktp'] . $data['rs_rmpp_altn'] . $data['rs_rmpp_altr'] . $data['rs_rmpp_altkk'] . $data['rs_rmpp_altkp'] . $data['rs_rmpp_altth'];
        }


        if ($data['rs_rmpmsk_pr'] == "0") {
            $data['rs_rmpmsk_pr'] = "Tidak Dipilih";
        } elseif ($data['rs_rmpmsk_pr'] == "1") {
            $data['rs_rmpmsk_pr'] = "Tidak";
        } elseif ($data['rs_rmpmsk_pr'] == "2") {
            $data['rs_rmpmsk_pr'] = "Ya, " . $data['rs_rmpmsk_rd'];
        }
        if ($data['rs_rmpmsk_pp'] == "0") {
            $data['rs_rmpmsk_pp'] = "Tidak";
        } elseif ($data['rs_rmpmsk_pp'] == "1") {
            $data['rs_rmpmsk_pp'] = "Ya";
        }



        if ($data['rs_rmpmsk_cp'] == "TN") {
            $data['rs_rmpmsk_cp'] = "Tunai";
        } elseif ($data['rs_rmpmsk_cp'] == "AS") {
            $data['rs_rmpmsk_cp'] = "Asuransi: " . $data['rs_rma_nm'] . ", No. Asuransi : " . $data['rs_rmpmsk_anmr'];
        }


        return $data;
    }

    public function changeTextRmpmskPj($data)
    {

        $data = $this->AI->convertJKNF($data, 'rs_rmpmskpj_jk');


        



        if ($data['rs_rmpmskpj_altn'] != "") {
            $data['rs_rmpmskpj_altn'] = ", No. " . $data['rs_rmpmskpj_altn'];
        }
        if ($data['rs_rmpmskpj_altr'] != "") {
            $data['rs_rmpmskpj_altr'] = ", RT/RW. " . $data['rs_rmpmskpj_altr'];
        } else {
            $data['rs_rmpmskpj_altr'] = ", RT/RW. -";
        }
        if ($data['rs_rmpmskpj_altkk'] != "") {
            $data['rs_rmpmskpj_altkk'] = ", Kelurahan/Kecamatan: " . $data['rs_rmpmskpj_altkk'];
        } else {
            $data['rs_rmpmskpj_altkk'] = ", Kelurahan/Kecamatan: - ";
        }

        if ($data['rs_rmpmskpj_altkp'] != "") {
            $data['rs_rmpmskpj_altkp'] = ", Kota/Kode Pos: " . $data['rs_rmpmskpj_altkp'];
        } else {
            $data['rs_rmpmskpj_altkp'] = ", Kota/Kode Pos: - ";
        }

        if ($data['rs_rmpmskpj_altth'] != "") {
            $data['rs_rmpmskpj_altth'] = ", Telepon/HP: " . $data['rs_rmpmskpj_altth'];
        } else {
            $data['rs_rmpmskpj_altth'] = ", Telepon/HP: - ";
        }

        if ($data['rs_rmpmskpj_altktp'] != "") {
            $data['rs_rmpmskpj_altktp'] = $data['rs_rmpmskpj_altktp'] . $data['rs_rmpmskpj_altn'] . $data['rs_rmpmskpj_altr'] . $data['rs_rmpmskpj_altkk'] . $data['rs_rmpmskpj_altkp'] . $data['rs_rmpmskpj_altth'];
        }
        return $data;
    }
}