<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\RmkMdl;
use App\Models\RmtrfrMdl;

class Rmtrfr extends BaseController
{
    use ResponseTrait;
    protected $MdlRmtrfr;
    protected $MdlRmk;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlRmtrfr = new RmtrfrMdl();
        $this->MdlRmk = new RmkMdl();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeng',
            'pAct' => 'pAPeng',
            'cAct' => 'cArmrtrf',
            'cmAct' => 'cmArmrtrf',
            'scAct' => 'scArmrtrfr',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA TARIF RUANGAN';
        $this->data['PageTitle'] = 'Data Tarif Ruangan';
        $this->data['BasePage'] = 'rmtrfr';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData';
        $this->data['IdForm'] = 'rmtrfrAddData';
        $this->data['UrlForm'] = 'rmtrfr';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);
        $this->data['Rmk'] = $this->MdlRmk->getAll();
        $this->data['Rmtrfr'] = $this->MdlRmtrfr->getAll();
        for ($i = 0; $i < count($this->data['Rmtrfr']); $i++) {
            $this->data['Rmtrfr'][$i]['rs_rmtrfr_trf'] = 0;
            $this->data['Rmtrfr'][$i]['rs_rmtrfr_trf'] = $this->data['Rmtrfr'][$i]['rs_rmtrfr_trf'] + $this->data['Rmtrfr'][$i]['rs_rmtrfr_srn'] + $this->data['Rmtrfr'][$i]['rs_rmtrfr_jp'] + $this->data['Rmtrfr'][$i]['rs_rmtrfr_jd'] + $this->data['Rmtrfr'][$i]['rs_rmtrfr_jpr'] + $this->data['Rmtrfr'][$i]['rs_rmtrfr_nm'] + $this->data['Rmtrfr'][$i]['rs_rmtrfr_kns'];
            $this->data['Rmtrfr'][$i]['rs_rmtrfr_trf'] = $this->Another_Include->rupiah($this->data['Rmtrfr'][$i]['rs_rmtrfr_trf']);

            $this->data['Rmtrfr'][$i]['rs_rmtrfr_srn'] = $this->Another_Include->rupiah($this->data['Rmtrfr'][$i]['rs_rmtrfr_srn']);
            $this->data['Rmtrfr'][$i]['rs_rmtrfr_jp'] = $this->Another_Include->rupiah($this->data['Rmtrfr'][$i]['rs_rmtrfr_jp']);
            $this->data['Rmtrfr'][$i]['rs_rmtrfr_jd'] = $this->Another_Include->rupiah($this->data['Rmtrfr'][$i]['rs_rmtrfr_jd']);
            $this->data['Rmtrfr'][$i]['rs_rmtrfr_jpr'] = $this->Another_Include->rupiah($this->data['Rmtrfr'][$i]['rs_rmtrfr_jpr']);
            $this->data['Rmtrfr'][$i]['rs_rmtrfr_nm'] = $this->Another_Include->rupiah($this->data['Rmtrfr'][$i]['rs_rmtrfr_nm']);
            $this->data['Rmtrfr'][$i]['rs_rmtrfr_kns'] = $this->Another_Include->rupiah($this->data['Rmtrfr'][$i]['rs_rmtrfr_kns']);

            $this->data['Rmtrfr'][$i]['rs_rmtrfr_tgl'] = $this->Another_Include->changeDateNF($this->data['Rmtrfr'][$i]['rs_rmtrfr_tgl']);
        }

        echo view('rmtrfr/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }

    public function editData($rs_rmtrfr_id_ex = '')
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA TARIF RUANGAN';
        $this->data['PageTitle'] = 'Data Tarif Ruangan';
        $this->data['BasePage'] = 'rmtrfr';
        $this->data['ButtonMethod'] = 'UBAH';
        $this->data['MethodForm'] = 'updateData/' . $rs_rmtrfr_id_ex;
        $this->data['IdForm'] = 'rmtrfrAddData';
        $this->data['UrlForm'] = 'rmtrfr';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);


        $this->data['Rmk'] = $this->MdlRmk->getAll();
        $this->data['Rmtrfr'] = $this->MdlRmtrfr->getAll();
        for ($i = 0; $i < count($this->data['Rmtrfr']); $i++) {
            $this->data['Rmtrfr'][$i]['rs_rmtrfr_trf'] = 0;
            $this->data['Rmtrfr'][$i]['rs_rmtrfr_trf'] = $this->data['Rmtrfr'][$i]['rs_rmtrfr_trf'] + $this->data['Rmtrfr'][$i]['rs_rmtrfr_srn'] + $this->data['Rmtrfr'][$i]['rs_rmtrfr_jp'] + $this->data['Rmtrfr'][$i]['rs_rmtrfr_jd'] + $this->data['Rmtrfr'][$i]['rs_rmtrfr_jpr'] + $this->data['Rmtrfr'][$i]['rs_rmtrfr_nm'] + $this->data['Rmtrfr'][$i]['rs_rmtrfr_kns'];
            $this->data['Rmtrfr'][$i]['rs_rmtrfr_trf'] = $this->Another_Include->rupiah($this->data['Rmtrfr'][$i]['rs_rmtrfr_trf']);

            $this->data['Rmtrfr'][$i]['rs_rmtrfr_srn'] = $this->Another_Include->rupiah($this->data['Rmtrfr'][$i]['rs_rmtrfr_srn']);
            $this->data['Rmtrfr'][$i]['rs_rmtrfr_jp'] = $this->Another_Include->rupiah($this->data['Rmtrfr'][$i]['rs_rmtrfr_jp']);
            $this->data['Rmtrfr'][$i]['rs_rmtrfr_jd'] = $this->Another_Include->rupiah($this->data['Rmtrfr'][$i]['rs_rmtrfr_jd']);
            $this->data['Rmtrfr'][$i]['rs_rmtrfr_jpr'] = $this->Another_Include->rupiah($this->data['Rmtrfr'][$i]['rs_rmtrfr_jpr']);
            $this->data['Rmtrfr'][$i]['rs_rmtrfr_nm'] = $this->Another_Include->rupiah($this->data['Rmtrfr'][$i]['rs_rmtrfr_nm']);
            $this->data['Rmtrfr'][$i]['rs_rmtrfr_kns'] = $this->Another_Include->rupiah($this->data['Rmtrfr'][$i]['rs_rmtrfr_kns']);

            $this->data['Rmtrfr'][$i]['rs_rmtrfr_tgl'] = $this->Another_Include->changeDateNF($this->data['Rmtrfr'][$i]['rs_rmtrfr_tgl']);
        }
        if ($rs_rmtrfr_id_ex === null || $rs_rmtrfr_id_ex == '') {
            return redirect()->to('/' . $this->data['BasePage']);
        } else {
            $this->data['fillUpdate'] = $this->MdlRmtrfr->getAll($rs_rmtrfr_id_ex);

            echo view('rmtrfr/index', $this->data);
            echo view('Templates/anotherScript');
            echo view('Templates/ajaxInsert', $this->data);
            echo view('Templates/loadData');
        }
    }

    public function insertData()
    {

        $rs_rmtrfr_id_ex = $this->MdlRmtrfr->getIdEx($this->Another_Include->getRandStr(3));
        $rs_rmtrfr_rmk = $this->request->getPost('rs_rmtrfr_rmk');
        $rs_rmtrfr_srn = $this->request->getPost('rs_rmtrfr_srn');
        $rs_rmtrfr_jp = $this->request->getPost('rs_rmtrfr_jp');
        $rs_rmtrfr_jd = $this->request->getPost('rs_rmtrfr_jd');
        $rs_rmtrfr_jpr = $this->request->getPost('rs_rmtrfr_jpr');
        $rs_rmtrfr_nm = $this->request->getPost('rs_rmtrfr_nm');
        $rs_rmtrfr_kns = $this->request->getPost('rs_rmtrfr_kns');
        $rs_rmtrfr_tgl = $this->request->getPost('rs_rmtrfr_tgl');
        $rs_rmtrfr_sk = $this->request->getPost('rs_rmtrfr_sk');

        $data = [
            'rs_rmtrfr_id_ex' => $rs_rmtrfr_id_ex,
            'rs_rmtrfr_rmk' => $rs_rmtrfr_rmk,
            'rs_rmtrfr_srn' => $rs_rmtrfr_srn,
            'rs_rmtrfr_jp' => $rs_rmtrfr_jp,
            'rs_rmtrfr_jd' => $rs_rmtrfr_jd,
            'rs_rmtrfr_jpr' => $rs_rmtrfr_jpr,
            'rs_rmtrfr_nm' => $rs_rmtrfr_nm,
            'rs_rmtrfr_kns' => $rs_rmtrfr_kns,
            'rs_rmtrfr_tgl' => $rs_rmtrfr_tgl,
            'rs_rmtrfr_sk' => $rs_rmtrfr_sk,
        ];

        $insertData = $this->MdlRmtrfr->insertData($data);
        if ($insertData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Tarif Ruangan Berhasil Disimpan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Tarif Ruangan Tidak Dapat Disimpan'];
        }

        return $this->respond($data, $data['status']);
    }

    public function updateData($rs_rmtrfr_id_ex = '')
    {
        $rs_rmtrfr_id_ex = $this->request->getPost('rs_rmtrfr_id_ex');
        $rs_rmtrfr_rmk = $this->request->getPost('rs_rmtrfr_rmk');
        $rs_rmtrfr_srn = $this->request->getPost('rs_rmtrfr_srn');
        $rs_rmtrfr_jp = $this->request->getPost('rs_rmtrfr_jp');
        $rs_rmtrfr_jd = $this->request->getPost('rs_rmtrfr_jd');
        $rs_rmtrfr_jpr = $this->request->getPost('rs_rmtrfr_jpr');
        $rs_rmtrfr_nm = $this->request->getPost('rs_rmtrfr_nm');
        $rs_rmtrfr_kns = $this->request->getPost('rs_rmtrfr_kns');
        $rs_rmtrfr_tgl = $this->request->getPost('rs_rmtrfr_tgl');
        $rs_rmtrfr_sk = $this->request->getPost('rs_rmtrfr_sk');
        $data = [
            'rs_rmtrfr_rmk' => $rs_rmtrfr_rmk,
            'rs_rmtrfr_srn' => $rs_rmtrfr_srn,
            'rs_rmtrfr_jp' => $rs_rmtrfr_jp,
            'rs_rmtrfr_jd' => $rs_rmtrfr_jd,
            'rs_rmtrfr_jpr' => $rs_rmtrfr_jpr,
            'rs_rmtrfr_nm' => $rs_rmtrfr_nm,
            'rs_rmtrfr_kns' => $rs_rmtrfr_kns,
            'rs_rmtrfr_tgl' => $rs_rmtrfr_tgl,
            'rs_rmtrfr_sk' => $rs_rmtrfr_sk,
        ];
        $updateData = $this->MdlRmtrfr->updateData($data, $rs_rmtrfr_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Tarif Ruangan Berhasil Diubah'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Tarif Ruangan Tidak Dapat Diubah'];
        }
        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmtrfr_id_ex = '')
    {
        if ($rs_rmtrfr_id_ex === null || $rs_rmtrfr_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlRmtrfr->deleteData($rs_rmtrfr_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Tarif Ruangan Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Tarif Ruangan Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function sumAll($data)
    {
        for ($i = 0; $i < count($data); $i++) {
            $data[$i]['rs_rmtrfr_h'] = $data[$i]['rs_rmtrfr_srn'] + $data[$i]['rs_rmtrfr_jp'] + $data[$i]['rs_rmtrfr_jd'] + $data[$i]['rs_rmtrfr_jpr'] + $data[$i]['rs_rmtrfr_nm'] + $data[$i]['rs_rmtrfr_kns'];
        }
        return $data;
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmtrfr_id_ex';
        $id = 'rs_rmtrfr_id';
        $length = 2;
        $typeGet = 'result';
        $field = 'rs_rmtrfr_id_ex, rs_rmtrfr_id, rs_rmtrfr_srn, rs_rmtrfr_jp, rs_rmtrfr_jd, rs_rmtrfr_jpr, rs_rmtrfr_nm, rs_rmtrfr_kns, rs_rmtrfr_tgl, rs_rmtrfr_sk';
        $fillUpdate = 'rs_rmtrfr_id_ex, rs_rmtrfr_srn, rs_rmtrfr_jp, rs_rmtrfr_jd, rs_rmtrfr_jpr, rs_rmtrfr_nm, rs_rmtrfr_kns, rs_rmtrfr_tgl, rs_rmtrfr_sk';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [],
                //order by
                [
                    0 => ['id' => 'rs_rmtrfr_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmtrfr_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}