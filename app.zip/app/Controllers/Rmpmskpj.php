<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\UmMdl;

class Rmpmskpj extends BaseController
{
    use ResponseTrait;
    protected $MdlU;
    protected $AI;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_rmpmskpj', 'rs_rmpmskpj_id_ex');
        $this->AI = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeng',
            'pAct' => 'pAPeng',
            'cAct' => 'cArmref',
            'cmAct' => 'cmArmref',
            'scAct' => '',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function getAll()
    {
        return $this->setDB('getAllByAct');
    }

    public function getByRmpmsk($data)
    {
        return $this->setDB('getByRmpmsk', $data);
    }

    public function insertData($data)
    {
        $insertData = $this->MdlU->insertData($data);

        return $insertData;
    }




    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmpmskpj_id_ex';
        $id = 'rs_rmpmskpj_id';
        $length = 3;
        $typeGet = 'result';

        $fillUpdate = '';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [],
                //order by
                [
                    0 => ['id' => 'rs_rmpmskpj_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'getByRmpmsk') {
            return $this->MdlU->getAll(
                //type result / row
                'row',
                // select *
                '*',
                //where
                [
                    0 => ['idEx' => 'rs_rmpmskpj_rmpmsk', 'idExV' => $data]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpmskpj_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmhub', 'string' => 'rs_rmhub.rs_rmhub_id_ex = rs_rmpmskpj.rs_rmpmskpj_rmhub', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_rmpdk', 'string' => 'rs_rmpdk.rs_rmpdk_id_ex = rs_rmpmskpj.rs_rmpmskpj_rmpdk', 'type' => 'LEFT'],
                    2 => ['tableName' => 'rs_rmkrj', 'string' => 'rs_rmkrj.rs_rmkrj_id_ex = rs_rmpmskpj.rs_rmpmskpj_rmkrj', 'type' => 'LEFT'],
                    3 => ['tableName' => 'rs_rmi', 'string' => 'rs_rmi.rs_rmi_id_ex = rs_rmpmskpj.rs_rmpmskpj_rmi', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpmskpj_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}