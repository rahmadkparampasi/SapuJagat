<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\RmphMdl;
use App\Models\RmpmskMdl;
use App\Models\RmpprktMdl;

class Rmpprkt extends BaseController
{
    use ResponseTrait;
    protected $MdlRmpmsk;
    protected $MdlRmpprkt;
    protected $MdlRmph;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlRmpmsk = new RmpmskMdl();
        $this->MdlRmpprkt = new RmpprktMdl();
        $this->MdlRmph = new RmphMdl();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOIgd',
            'pAct' => 'pAIgd',
            'cAct' => 'cArmpmsk',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {

        return redirect()->to('./rmpmsk');
    }

    public function insertData($rs_rmpprkt_rmpmsk)
    {
        $this->data['Rmpmsk'] = $this->MdlRmpmsk->getAllRmpmsk($rs_rmpprkt_rmpmsk);

        $rs_rmph_id_ex = $this->Another_Include->getRandStr(35);
        $rs_rmph_rmpp = $this->data['Rmpmsk']['rs_rmpmsk_rmpp'];
        $rs_rmph_ppeg = $this->data['rs_ppeg_id_ex'];
        $rs_rmph_jns = "CT";

        $rs_rmpprkt_id_ex = $this->MdlRmpprkt->getIdEx($this->Another_Include->getRandStr(25));
        $rs_rmpprkt_ku = $this->request->getPost('rs_rmpprkt_ku');
        $rs_rmpprkt_ks = $this->request->getPost('rs_rmpprkt_ks');
        $rs_rmpprkt_sis = $this->request->getPost('rs_rmpprkt_sis');
        $rs_rmpprkt_dias = $this->request->getPost('rs_rmpprkt_dias');
        $rs_rmpprkt_sh = $this->request->getPost('rs_rmpprkt_sh');
        $rs_rmpprkt_fnd = $this->request->getPost('rs_rmpprkt_fnd');
        $rs_rmpprkt_fnf = $this->request->getPost('rs_rmpprkt_fnf');
        $rs_rmpprkt_tgl = $this->request->getPost('rs_rmpprkt_tgl');
        $rs_rmpprkt_jam = $this->request->getPost('rs_rmpprkt_jam');

        $dataRmpprkt = [
            'rs_rmpprkt_id_ex' => $rs_rmpprkt_id_ex,
            'rs_rmpprkt_rmpmsk' => $rs_rmpprkt_rmpmsk,
            'rs_rmpprkt_rmph' => $rs_rmph_id_ex,
            'rs_rmpprkt_ku' => $rs_rmpprkt_ku,
            'rs_rmpprkt_ks' => $rs_rmpprkt_ks,
            'rs_rmpprkt_sis' => $rs_rmpprkt_sis,
            'rs_rmpprkt_dias' => $rs_rmpprkt_dias,
            'rs_rmpprkt_sh' => $rs_rmpprkt_sh,
            'rs_rmpprkt_fnd' => $rs_rmpprkt_fnd,
            'rs_rmpprkt_fnf' => $rs_rmpprkt_fnf,
            'rs_rmpprkt_tgl' => $rs_rmpprkt_tgl,
            'rs_rmpprkt_jam' => $rs_rmpprkt_jam,
        ];

        $dataRmph = [
            'rs_rmph_id_ex' => $rs_rmph_id_ex,
            'rs_rmph_rmpp' => $rs_rmph_rmpp,
            'rs_rmph_ppeg' => $rs_rmph_ppeg,
            'rs_rmph_jns' => $rs_rmph_jns
        ];

        $insertDataRmph = $this->MdlRmph->insertData($dataRmph);
        if ($insertDataRmph) {
            $insertDataRmpPrkt = $this->MdlRmpprkt->insertData($dataRmpprkt);
            if ($insertDataRmpPrkt) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Pemeriksaan Tanda Vital Pasien Berhasil Disimpan'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Pemeriksaan Tanda Vital Pasien Tidak Dapat Disimpan'];
            }
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Histori Pasien Tidak Dapat Disimpan'];
        }



        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmpprkt_id_ex = '')
    {
        if ($rs_rmpprkt_id_ex === null || $rs_rmpprkt_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlRmpprkt->deleteData($rs_rmpprkt_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Pemeriksaan Tanda Vital Pasien Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Pemeriksaan Tanda Vital Pasien Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }
}
