<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\RmfrrptlMdl;

class Rmfrrptl extends BaseController
{
    use ResponseTrait;
    protected $MdlRmfrrptl;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlRmfrrptl = new RmfrrptlMdl();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeng',
            'pAct' => 'pAPeng',
            'cAct' => 'cArmr',
            'cmAct' => 'cmArmref',
            'scAct' => 'scArmk',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA RIWAYAT PERJALANAN TRANSMISI LOKAL';
        $this->data['PageTitle'] = 'Data Riwayat Perjalanan Transmisi Lokal';
        $this->data['BasePage'] = 'rmfrrptl';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData';
        $this->data['IdForm'] = 'rmfrrptlAddData';
        $this->data['UrlForm'] = 'rmfrrptl';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);
        $this->data['Rmfrrptl'] = $this->MdlRmfrrptl->getAllRmfrrptl();

        echo view('Rmfrrptl/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }

    public function editData($rs_rmfrrptl_id_ex = '')
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA RIWAYAT PERJALANAN TRANSMISI LOKAL';
        $this->data['PageTitle'] = 'Data Riwayat Perjalanan Transmisi Lokal';
        $this->data['BasePage'] = 'rmfrrptl';
        $this->data['ButtonMethod'] = 'UBAH';
        $this->data['MethodForm'] = 'updateData/' . $rs_rmfrrptl_id_ex;
        $this->data['IdForm'] = 'rmfrrptlAddData';
        $this->data['UrlForm'] = 'rmfrrptl';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);


        $this->data['Rmfrrptl'] = $this->MdlRmfrrptl->getAllRmfrrptl();
        if ($rs_rmfrrptl_id_ex === null || $rs_rmfrrptl_id_ex == '') {
            return redirect()->to('/' . $this->data['BasePage']);
        } else {
            $this->data['fillUpdate'] = $this->MdlRmfrrptl->getAllRmfrrptl($rs_rmfrrptl_id_ex);

            echo view('Rmfrrptl/index', $this->data);
            echo view('Templates/anotherScript');
            echo view('Templates/ajaxInsert', $this->data);
            echo view('Templates/loadData');
        }
    }

    // public function getRmrByJson($rs_ppeg_id_ex, $BasePage)
    // {
    //     header('Content-Type: application/json');
    //     header("Access-Control-Allow-Origin: *");

    //     $this->data['data']['data'] = $this->MdlRmr->getAllRmr();
    //     $no = 0;
    //     for ($i = 0; $i < count($this->data['data']['data']); $i++) {
    //         $no++;
    //         $this->data['data']['data'][$i]['no'] = $no;

    //         $this->data['data']['data'][$i]['button'] = "<button class='btn bg-gradient-success' title='Tambahkan Data Ruangan Pegawai' onclick='callOther(\"Menambahkan Data Ruangan " . $this->data['data']['data'][$i]['rs_rmr_nm'] . " Dalam Data Pegawai\", \"/" . $BasePage . "/addRmrToPpeg/" . $this->data['data']['data'][$i]['rs_rmr_id_ex'] . "/" . $rs_ppeg_id_ex . "\")'><i class='fas fa-check'></i></button>";
    //     }
    //     return $this->respond($this->data['data'], 200);
    // }

    public function insertData()
    {

        $rs_rmfrrptl_id_ex = $this->Another_Include->getRandStr(7);
        $rs_rmfrrptl_nm = $this->request->getPost('rs_rmfrrptl_nm');
        $rs_rmfrrptl_ket = $this->request->getPost('rs_rmfrrptl_ket');

        $data = [
            'rs_rmfrrptl_id_ex' => $rs_rmfrrptl_id_ex,
            'rs_rmfrrptl_nm' => $rs_rmfrrptl_nm,
            'rs_rmfrrptl_ket' => $rs_rmfrrptl_ket,
        ];

        $insertData = $this->MdlRmfrrptl->insertData($data);
        if ($insertData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Riwayat Perjalanan Transmisi Lokal Berhasil Disimpan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Riwayat Perjalanan Transmisi Lokal Tidak Dapat Disimpan'];
        }

        return $this->respond($data, $data['status']);
    }

    public function updateData($rs_rmfrrptl_id_ex = '')
    {
        $rs_rmfrrptl_nm = $this->request->getPost('rs_rmfrrptl_nm');
        $rs_rmfrrptl_ket = $this->request->getPost('rs_rmfrrptl_ket');

        $rs_rmfrrptl_id_ex = $this->request->getPost('rs_rmfrrptl_id_ex');

        $data = [
            'rs_rmfrrptl_nm' => $rs_rmfrrptl_nm,
            'rs_rmfrrptl_ket' => $rs_rmfrrptl_ket,
        ];
        $updateData = $this->MdlRmfrrptl->updateData($data, $rs_rmfrrptl_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Riwayat Perjalanan Transmisi Lokal Berhasil Diubah'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Riwayat Perjalanan Transmisi Lokal Tidak Dapat Diubah'];
        }
        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmfrrptl_id_ex = '')
    {
        if ($rs_rmfrrptl_id_ex === null || $rs_rmfrrptl_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlRmfrrptl->deleteData($rs_rmfrrptl_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Riwayat Perjalanan Transmisi Lokal Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Riwayat Perjalanan Transmisi Lokal Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }
}
