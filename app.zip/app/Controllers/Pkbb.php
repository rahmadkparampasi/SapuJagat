<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\PkbbMdl;
use App\Models\PkpMdl;

class Pkbb extends BaseController
{
    use ResponseTrait;
    protected $MdlPkbb;
    protected $MdlPkp;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlPkbb = new PkbbMdl();
        $this->MdlPkp = new PkpMdl();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeg',
            'pAct' => 'pAPeg',
            'cAct' => 'cAPpeg',
            'cmAct' => '',
            'scAct' => '',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index($rs_pkbb_pkp = false)
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }

        if ($rs_pkbb_pkp === false) {
            return redirect()->to('/pkp');
        }
        $this->data['rs_pkbb_pkp'] = $rs_pkbb_pkp;
        $this->data['Pkp'] = $this->MdlPkp->getAllPkp($rs_pkbb_pkp);
        $this->data['WebTitle'] = 'DATA BERKAS BERKALA KATEGORI PEGAWAI ' . $this->data['Pkp']['rs_pkp_nm'];
        $this->data['PageTitle'] = 'Data Berkas Berkala Kategori Pegawai ' . ucwords(strtolower($this->data['Pkp']['rs_pkp_nm']));
        $this->data['BasePage'] = 'pkbb';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData/' . $rs_pkbb_pkp;
        $this->data['IdForm'] = 'pkbbAddData';
        $this->data['UrlForm'] = 'pkbb/' . $rs_pkbb_pkp;

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);


        $this->data['Pkbb'] = $this->MdlPkbb->getAllPkbb($rs_pkbb_pkp);

        for ($i = 0; $i < count($this->data['Pkbb']); $i++) {
            if ($this->data['Pkbb'][$i]['rs_pkbb_wjb'] == "0") {
                $this->data['Pkbb'][$i]['rs_pkbb_wjb'] = "TIDAK WAJIB";
            } else {
                $this->data['Pkbb'][$i]['rs_pkbb_wjb'] = "WAJIB";
            }
        }
        echo view('Pkbb/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }

    public function editData($rs_pkbb_pkp = '', $rs_pkbb_id_ex = '')
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }

        if ($rs_pkbb_pkp === '') {
            return redirect()->to('/pkbb');
        }

        if ($rs_pkbb_id_ex === '') {
            return redirect()->to('/pkbb/' . $rs_pkbb_pkp);
        }

        $this->data['rs_pkbb_pkp'] = $rs_pkbb_pkp;
        $this->data['Pkp'] = $this->MdlPkp->getAllPkp($rs_pkbb_pkp);
        if (empty($this->data['Pkp'])) {
            return redirect()->to('/pkp');
        }
        $this->data['WebTitle'] = 'DATA BERKAS BERKALA KATEGORI PEGAWAI ' . $this->data['Pkp']['rs_pkp_nm'];
        $this->data['PageTitle'] = 'Data Berkas Berkala Kategori Pegawai ' . ucwords(strtolower($this->data['Pkp']['rs_pkp_nm']));
        $this->data['BasePage'] = 'pkbb';
        $this->data['ButtonMethod'] = 'UBAH';
        $this->data['MethodForm'] = 'updateData/' . $rs_pkbb_pkp;
        $this->data['IdForm'] = 'pkbbAddData';
        $this->data['UrlForm'] = 'pkbb/' . $rs_pkbb_pkp;

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);

        $this->data['fillUpdate'] = $this->MdlPkbb->getAllPkbb($rs_pkbb_pkp, $rs_pkbb_id_ex);
        $this->data['Pkbb'] = $this->MdlPkbb->getAllPkbb($rs_pkbb_pkp);
        echo view('Pkbb/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
        echo view('Templates/loadData');
    }

    public function insertData($rs_pkbb_pkp)
    {
        $rs_pkbb_id_ex = $this->Another_Include->getRandStr(6);
        $rs_pkbb_nm = $this->request->getPost('rs_pkbb_nm');
        $rs_pkbb_jw = $this->request->getPost('rs_pkbb_jw');
        $rs_pkbb_jk = $this->request->getPost('rs_pkbb_jk');
        $rs_pkbb_wjb = $this->request->getPost('rs_pkbb_wjb');
        $data = [
            'rs_pkbb_id_ex' => $rs_pkbb_id_ex,
            'rs_pkbb_pkp' => $rs_pkbb_pkp,
            'rs_pkbb_nm' => $rs_pkbb_nm,
            'rs_pkbb_jw' => $rs_pkbb_jw,
            'rs_pkbb_jk' => $rs_pkbb_jk,
            'rs_pkbb_wjb' => $rs_pkbb_wjb,
        ];
        $insertData = $this->MdlPkbb->insertData($data);
        if ($insertData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Berkas Berkala Pegawai Berhasil Disimpan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Berkas Berkala Pegawai Tidak Dapat Disimpan'];
        }
        return $this->respond($data, $data['status']);
    }

    public function updateData()
    {
        $rs_pkbb_nm = $this->request->getPost('rs_pkbb_nm');
        $rs_pkbb_jw = $this->request->getPost('rs_pkbb_jw');
        $rs_pkbb_jk = $this->request->getPost('rs_pkbb_jk');
        $rs_pkbb_wjb = $this->request->getPost('rs_pkbb_wjb');
        $rs_pkbb_id_ex = $this->request->getPost('rs_pkbb_id_ex');
        $data = [
            'rs_pkbb_nm' => $rs_pkbb_nm,
            'rs_pkbb_jw' => $rs_pkbb_jw,
            'rs_pkbb_jk' => $rs_pkbb_jk,
            'rs_pkbb_wjb' => $rs_pkbb_wjb,
        ];
        $updateData = $this->MdlPkbb->updateData($data, $rs_pkbb_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Berkas Berkala Pegawai Berhasil Diubah'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Berkas Berkala Pegawai Tidak Dapat Diubah'];
        }
        return $this->respond($data, $data['status']);
    }



    public function deleteData($rs_pkbb_id_ex = '')
    {
        if ($rs_pkbb_id_ex === null || $rs_pkbb_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlPkbb->deleteData($rs_pkbb_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Berkas Berkala Pegawai Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Berkas Berkala Pegawai Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }
}
