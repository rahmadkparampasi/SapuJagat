<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\UmMdl;

class Setant extends BaseController
{
    use ResponseTrait;
    protected $MdlU;
    protected $Rmja;
    protected $AI;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_setant', 'rs_setant_id_ex');
        $this->Rmja = new Rmja();
        $this->AI = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeng',
            'pAct' => 'pAPeng',
            'cAct' => 'cArmref',
            'cmAct' => '',
            'scAct' => '',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA SETUP ANTRIAN';
        $this->data['PageTitle'] = 'Data Setup Antrian';
        $this->data['BasePage'] = 'setant';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData';
        $this->data['IdForm'] = 'setantAddData';
        $this->data['UrlForm'] = 'setant';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);


        $this->data['Setant'] = $this->setDB();
        for ($i=0; $i < count($this->data['Setant']); $i++) { 
            if($this->data['Setant'][$i]['rs_setant_plh'] == "1")
            {
                $this->data['Setant'][$i]['rs_setant_plh'] = "YA";
            }else{
                $this->data['Setant'][$i]['rs_setant_plh'] = "TIDAK";
            }
        }
        $this->data['Rmja'] = $this->Rmja->getAll();

        echo view('Setant/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }

    public function viewForm()
    {
    }
    public function tesCtk()
    {
        $this->data['WebTitle'] = 'DATA SETUP ANTRIAN';
        $this->data['PageTitle'] = 'Data Setup Antrian';
        $this->data['BasePage'] = 'setant';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'viewForm';
        $this->data['IdForm'] = 'setantAddData';
        $this->data['UrlForm'] = 'setant';
        echo view('Setant/indexCtk', $this->data);
        // echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }

    public function getAll()
    {
        return $this->setDB('getAllByActAndPlh');
    }

    public function getVByRmr($data)
    {
        $new =  $this->setDB('getVByRmr', $data);
        return $new['rs_setant_v'];
    }

    public function insertData()
    {
        $validated = $this->validate([
            'rs_setant_v' => 'uploaded[rs_setant_v]|mime_in[rs_setant_v,audio/mpeg,audio/mpg,audio/mpeg3,audio/mp3]|max_size[rs_setant_v,2048]'
        ]);
        if ($validated == FALSE) {
            // Kembali ke function index supaya membawa data uploads dan validasi
            $data = ['status' => 415, 'response' => "error", 'message' => 'Berkas Yang Diunggah Tidak Sesuai Spesifikasi'];
        }else{
            $rs_setant_id_ex = $this->setDB('idEx', $this->AI->getRandStr(3));
            $rs_setant_rmja = $this->request->getPost('rs_setant_rmja');
            $rs_setant_rmr = $this->request->getPost('rs_setant_rmr');
            $rs_setant_ket = $this->request->getPost('rs_setant_ket');
            $rs_setant_plh = $this->request->getPost('rs_setant_plh');
            $rs_setant_v = $this->request->getFile('rs_setant_v');

            $new_rs_setant_v = "Setsra-" . $rs_setant_id_ex . "-"  . date("YmdHis") . "." . $rs_setant_v->getClientExtension();
    
            $data = [
                'rs_setant_id_ex' => $rs_setant_id_ex,
                'rs_setant_rmja' => $rs_setant_rmja,
                'rs_setant_rmr' => $rs_setant_rmr,
                'rs_setant_ket' => $rs_setant_ket,
                'rs_setant_plh' => $rs_setant_plh,
                'rs_setant_v' => $new_rs_setant_v,

            ];
    
            $insertData = $this->MdlU->insertData($data);
            if ($insertData) {
                $rs_setant_v->move('uploads', $new_rs_setant_v);

                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Setup Antrian Berhasil Disimpan'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Setup Antrian Tidak Dapat Disimpan'];
            }
    
        }
        
        return $this->respond($data, $data['status']);
    }


    public function deleteData($rs_setant_id_ex = '')
    {
        if ($rs_setant_id_ex === null || $rs_setant_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlU->deleteData($rs_setant_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Setup Antrian Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Setup Antrian Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function block($rs_setant_id_ex = '')
    {
        $data = [
            'rs_setant_sts' => "0",
        ];
        $updateData = $this->MdlU->updateData($data, $rs_setant_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Status Setup Antrian Berhasil Di Dinonaktifkan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Status Setup Antrian Tidak Dapat Di Dinonaktifkan'];
        }
        return $this->respond($data, $data['status']);
    }

    public function unblock($rs_setant_id_ex = '')
    {
        $data = [
            'rs_setant_sts' => "1",
        ];
        $updateData = $this->MdlU->updateData($data, $rs_setant_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Status Setup Antrian Berhasil Aktifkan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Status Setup Antrian Tidak Dapat Aktifkan'];
        }
        return $this->respond($data, $data['status']);
    }


    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_setant_id_ex';
        $id = 'rs_setant_id';
        $length = 2;
        $typeGet = 'result';

        $fillUpdate = 'rs_setant_id_ex, rs_setant_rmja, rs_setant_rmr, rs_setant_ket';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [],
                //order by
                [
                    0 => ['id' => 'rs_setant_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmr', 'string' => 'rs_rmr.rs_rmr_id_ex = rs_setant.rs_setant_rmr', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_rmja', 'string' => 'rs_rmja.rs_rmja_id_ex = rs_setant.rs_setant_rmja', 'type' => 'LEFT'],
                ]
            );
        }elseif ($request == 'getVByRmr') {
            return $this->MdlU->getAll(
                //type result / row
                'row',
                // select *
                'rs_setant_v',
                //where
                [
                    0 => ['idEx' => 'rs_setant_rmr', 'idExV' => $data]
                ],
                //order by
                [
                    0 => ['id' => 'rs_setant_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        }elseif ($request == 'getAllByAct') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_setant_sts',
                        'idExV' => '1'
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_setant_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmr', 'string' => 'rs_rmr.rs_rmr_id_ex = rs_setant.rs_setant_rmr', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_rmja', 'string' => 'rs_rmja.rs_rmja_id_ex = rs_setant.rs_setant_rmja', 'type' => 'LEFT'],
                ]
            );
        }elseif ($request == 'getAllByActAndPlh') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_setant_sts',
                        'idExV' => '1'
                    ],
                    1 => [
                        'idEx' => 'rs_setant_plh',
                        'idExV' => '1'
                    ],
                ],
                //order by
                [
                    0 => ['id' => 'rs_setant_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmr', 'string' => 'rs_rmr.rs_rmr_id_ex = rs_setant.rs_setant_rmr', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_rmja', 'string' => 'rs_rmja.rs_rmja_id_ex = rs_setant.rs_setant_rmja', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_setant_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmr', 'string' => 'rs_rmr.rs_rmr_id_ex = rs_setant.rs_setant_rmr', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_rmja', 'string' => 'rs_rmja.rs_rmja_id_ex = rs_setant.rs_setant_rmja', 'type' => 'LEFT'],

                ]
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}
