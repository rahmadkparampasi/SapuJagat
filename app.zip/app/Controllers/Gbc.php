<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use Faker\Factory;

class Gbc extends BaseController
{
    use ResponseTrait;
    protected $data;

    public function __construct()
    {

        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeg',
            'pAct' => 'pAHome',
            'cAct' => '',
            'cmAct' => '',
            'scAct' => '',


            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }
    public function testing($v = '')
	{
		$tempdir="images";

		$target_path=$tempdir . $v . ".png";

		$fileImage= base_url("/bc?text=" . $v . "&codetype=code128&print=true&size=55&filepath=images");

		$content=file_get_contents($fileImage);

		file_put_contents($target_path, $content);

		
	}
}