<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\UmMdl;

class Rmtdkpk extends BaseController
{
    use ResponseTrait;
    protected $MdlU;
    protected $Rmtdkp;
    protected $Rmsl;
    protected $AI;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_rmtdkpk', 'rs_rmtdkpk_id_ex');
        $this->Rmtdkp = new Rmtdkp();
        $this->Rmsl = new Rmsl();
        $this->AI = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeng',
            'pAct' => 'pAPeng',
            'cAct' => 'cArmref',
            'cmAct' => 'cmArmref',
            'scAct' => '',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function viewData($rs_rmtdkpk_rmtdkp)
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['rs_rmtdkpk_rmtdkp'] = $rs_rmtdkpk_rmtdkp;
        $this->data['Rmtdkp'] = $this->Rmtdkp->getRmtdkp($rs_rmtdkpk_rmtdkp);
        $this->data['WebTitle'] = 'NILAI KRITIS PARAMETER ' . strtoupper($this->data['Rmtdkp']['rs_rmtdkp_p']);
        $this->data['PageTitle'] = 'Nilai Kritis Parameter ' . $this->data['Rmtdkp']['rs_rmtdkp_p'];
        $this->data['BasePage'] = 'rmtdkpk';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData';
        $this->data['IdForm'] = 'rmtdkpkAddData';
        $this->data['UrlForm'] = 'rmtdkpk';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);

        $this->data['Rmtdkpk'] = $this->setDB('getAll', $rs_rmtdkpk_rmtdkp);
        $this->data['Rmtdkpk'] = $this->AI->convertJKWF($this->data['Rmtdkpk'], 'rs_rmtdkpk_jk');
        // dd($this->data);

        echo view('Rmtdkpk/index', $this->data);
        // echo view('Templates/anotherScript');
        // echo view('Templates/ajaxInsert', $this->data);
    }

    public function insertData()
    {
        $rs_rmtdkpk_id_ex = $this->setDB('idEx', $this->AI->getRandStr(11));
        $rs_rmtdkpk_jk = $this->request->getPost('rs_rmtdkpk_jk');
        $rs_rmtdkpk_rmtdkp = $this->request->getPost('rs_rmtdkpk_rmtdkp');
        $rs_rmtdkpk_u = $this->request->getPost('rs_rmtdkpk_u');
        $rs_rmtdkpk_ba = $this->request->getPost('rs_rmtdkpk_ba');
        $rs_rmtdkpk_bb = $this->request->getPost('rs_rmtdkpk_bb');

        $data = [
            'rs_rmtdkpk_id_ex' => $rs_rmtdkpk_id_ex,
            'rs_rmtdkpk_jk' => $rs_rmtdkpk_jk,
            'rs_rmtdkpk_rmtdkp' => $rs_rmtdkpk_rmtdkp,
            'rs_rmtdkpk_u' => $rs_rmtdkpk_u,
            'rs_rmtdkpk_ba' => $rs_rmtdkpk_ba,
            'rs_rmtdkpk_bb' => $rs_rmtdkpk_bb,
        ];

        $insertData = $this->MdlU->insertData($data);
        if ($insertData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Nilai Kritis Parameter Tindakan Berhasil Disimpan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Nilai Kritis Parameter Tindakan Tidak Dapat Disimpan'];
        }

        return $this->respond($data, $data['status']);
    }


    public function deleteData($rs_rmtdkp_id_ex = '')
    {
        if ($rs_rmtdkp_id_ex === null || $rs_rmtdkp_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlU->deleteData($rs_rmtdkp_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Parameter Tindakan Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Parameter Tindakan Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function blockTdkPK($rs_rmtdkpk_id_ex = '')
    {
        $data = [
            'rs_rmtdkpk_sts' => "0",
        ];
        $updateData = $this->MdlU->updateData($data, $rs_rmtdkpk_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Nilai Kritis Parameter Tindakan Berhasil Di Dinonaktifkan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Nilai Kritis Parameter Tindakan Tidak Dapat Di Dinonaktifkan'];
        }
        return $this->respond($data, $data['status']);
    }

    public function unblockTdkPK($rs_rmtdkpk_id_ex = '')
    {
        $data = [
            'rs_rmtdkpk_sts' => "1",
        ];
        $updateData = $this->MdlU->updateData($data, $rs_rmtdkpk_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Nilai Kritis Parameter Tindakan Berhasil Aktifkan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Nilai Kritis Parameter Tindakan Tidak Dapat Aktifkan'];
        }
        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmtdkpk_id_ex';
        $id = 'rs_rmtdkpk_id';
        $length = 2;
        $typeGet = 'result';
        $fillUpdate = '';

        if ($request == 'getAll') {
            return $data = $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmtdkpk_rmtdkp',
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmtdkpk_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}
