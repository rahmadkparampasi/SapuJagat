<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\RmppMdl;
use App\Models\UmMdl;
use Picqer\Barcode\BarcodeGeneratorPNG as Barcode;
use PhpOffice\PhpSpreadsheet\Reader\Xls as Reader;

class Rmpp extends BaseController
{
    use ResponseTrait;
    protected $MdlRmpp;
    protected $MdlU;
    protected $Rmpmsk;
    protected $Rmi;
    protected $Rmag;
    protected $Rmgd;
    protected $AI;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlRmpp = new RmppMdl();
        $this->MdlU = new UmMdl('rs_rmpp', 'rs_rmpp_id_ex');
        $this->Rmpmsk = new Rmpmsk;
        $this->Rmi = new Rmi;
        $this->Rmag = new Rmag;
        $this->Rmgd = new Rmgd;
        $this->AI = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mORm',
            'pAct' => 'pARm',
            'cAct' => 'cArmpp',
            'cmAct' => '',
            'scAct' => '',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];

        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA PASIEN';
        $this->data['PageTitle'] = 'Data Pasien';
        $this->data['BasePage'] = 'rmpp';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData';
        $this->data['IdForm'] = 'rmppAddData';
        $this->data['UrlForm'] = 'rmpp';
        $this->data['Rmi'] = $this->Rmi->getAll();
        $this->data['Rmag'] = $this->Rmag->getAll();
        $this->data['Rmgd'] = $this->Rmgd->getAll();
        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);


        echo view('Rmpp/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }

    public function viewSearch($method = '', $id = '')
    {
        $this->data['Rmpp'] = $this->setDB('getAllSrc', [$method, $id]);
        $this->data['Rmpp'] = $this->AI->convertJKWF($this->data['Rmpp'], 'rs_rmpp_jk');
        $this->data['Rmpp'] = $this->AI->changeDateWF($this->data['Rmpp'], ['rs_rmpp_tgl_lhr']);
        for ($i = 0; $i < count($this->data['Rmpp']); $i++) {
            $this->data['Rmpp'][$i]['Rmpmsk'] = $this->Rmpmsk->setDB('getByRmpp', ['rs_rmpmsk_rmpp', $this->data['Rmpp'][$i]['rs_rmpp_id_ex']]);
            $this->data['Rmpp'][$i]['color'] = 'success';
            $this->data['Rmpp'][$i]['icon'] = 'child';
            if ($this->data['Rmpp'][$i]['Rmpmsk'] !== null) {
                if ($this->data['Rmpp'][$i]['Rmpmsk']['rs_rmpmsk_plg'] == '0') {
                    $this->data['Rmpp'][$i]['color'] = 'warning';
                    $this->data['Rmpp'][$i]['icon'] = 'procedures';
                }
            }
        }
        echo view('rmpp/indexSrc', $this->data);
    }

    public function editData($rs_rmpp_id_ex = '')
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA Pasien';
        $this->data['PageTitle'] = 'Data Pasien';
        $this->data['BasePage'] = 'rmpp';
        $this->data['ButtonMethod'] = 'UBAH';
        $this->data['MethodForm'] = 'updateData/' . $rs_rmpp_id_ex;
        $this->data['IdForm'] = 'rmppAddData';
        $this->data['UrlForm'] = 'rmpp';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);


        $this->data['Rmpp'] = $this->MdlRmpp->getAllRmpp();
        if ($rs_rmpp_id_ex === null || $rs_rmpp_id_ex == '') {
            return redirect()->to('/' . $this->data['BasePage']);
        } else {
            $this->data['fillUpdate'] = $this->MdlRmpp->getAllRmpp($rs_rmpp_id_ex);

            echo view('Rmpp/index', $this->data);
            echo view('Templates/anotherScript');
            echo view('Templates/ajaxInsert', $this->data);
            echo view('Templates/loadData');
        }
    }

    public function getRmppByJson()
    {
        header('Content-Type: application/json');
        header("Access-Control-Allow-Origin: *");

        $this->data['data']['data'] = $this->MdlRmpp->getAllRmpp();
        $no = 0;
        for ($i = 0; $i < count($this->data['data']['data']); $i++) {
            $no++;
            $this->data['data']['data'][$i]['no'] = $no;
            $this->data['data']['data'][$i]['button'] = "<button class='btn bg-gradient-success' title='Tambahkan Pasien Ke IGD' onclick='addFill(\"rs_rmpmsk_rmpp\", \"" . $this->data['data']['data'][$i]['rs_rmpp_id_ex'] . "\"); addFill(\"rs_rmpp_nm1\", \"" . $this->data['data']['data'][$i]['rs_rmpp_nm'] . "\"); addFill(\"rs_rmpp_ind1\", \"" . $this->data['data']['data'][$i]['rs_rmpp_ind'] . "\"); addFill(\"rs_rmpp_rm\", \"" . $this->data['data']['data'][$i]['rs_rmpp_rm'] . "\")' data-target='#modalChangeWktu' data-toggle='modal'><i class='fas fa-check'></i></button>";

            $this->data['d'] = (string)date('d', strtotime($this->data['data']['data'][$i]['rs_rmpp_tgl_lhr']));
            $this->data['F'] = (string)date('F', strtotime($this->data['data']['data'][$i]['rs_rmpp_tgl_lhr']));
            $this->data['F'] = $this->AI->monthConv($this->data['F']);
            $this->data['Y'] = (string)date('Y', strtotime($this->data['data']['data'][$i]['rs_rmpp_tgl_lhr']));
            $this->data['data']['data'][$i]['rs_rmpp_tgl_lhr'] = strtoupper($this->data['d'] . " " . $this->data['F'] . " " . $this->data['Y']);

            if ($this->data['data']['data'][$i]['rs_rmpp_jk'] == "L") {
                $this->data['data']['data'][$i]['rs_rmpp_jk'] = "LAKI-LAKI";
            } else {
                $this->data['data']['data'][$i]['rs_rmpp_jk'] = "PEREMPUAN";
            }

            $this->data['data']['data'][$i]['rs_rmpp_rm'] = $this->AI->cB("<h3>" . $this->data['data']['data'][$i]['rs_rmpp_rm'] . "</h3>");
        }
        return $this->respond($this->data['data'], 200);
    }



    public function insertData()
    {

        $redColor = [0, 0, 0];

        $generator = new Barcode();



        $rs_rmpp_ppeg = $this->data['rs_ppeg_id_ex'];

        $array = $this->request->getPost();
        unset($array['datatableKirana_length']);
        $arrayFlip = array_keys($array);
        $arrayFlipV = array_values($arrayFlip);
        $arrayV = array_values($array);

        $rs_rmpp_id_ex = $this->MdlRmpp->getIdExRmpp($this->AI->getRandStr(30));
        $rs_rmpp = [];
        $rs_rmpp['rs_rmpp_id_ex'] = $rs_rmpp_id_ex;
        $rs_rmpp['rs_rmpp_ppeg'] = $rs_rmpp_ppeg;
        $rs_rmpp['rs_rmpp_rm'] = $this->getNoRm();
        $bc = 'bc-'. $rs_rmpp_id_ex . "-"  . date("YmdHis") . ".png" ;
        $rs_rmpp['rs_rmpp_cd'] = $bc;
        for ($i = 0; $i < count($arrayV); $i++) {
            $rs_rmpp[$arrayFlipV[$i]] = $arrayV[$i];
        }

        $insertData = $this->MdlRmpp->insertData($rs_rmpp);
        if ($insertData) {
            file_put_contents('bc/'.$bc, $generator->getBarcode((string)$rs_rmpp['rs_rmpp_rm'], $generator::TYPE_CODE_128, 3, 50, $redColor));       

            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Pasien Berhasil Disimpan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Pasien Tidak Dapat Disimpan'];
        }

        return $this->respond($data, $data['status']);
    }

    public function insertDataFile()
    {
        date_default_timezone_set("Asia/Makassar");

        $ExcelReader = new Reader();

        $file = $this->request->getFile('file');
        $fileLocation = $file->getTempName();
        $objPhpExcel = $ExcelReader->load($fileLocation);
        $sheet = $objPhpExcel->getActiveSheet()->toArray(null, true, true, true);
        $success = 0;
        $error = 0;
        $count = count($sheet) + 1;
        $data = [];
        $redColor = [0, 0, 0];

        $generator = new Barcode();
        for ($i = 1; $i < $count; $i++) {
            if ($sheet[$i]['A']==""||$sheet[$i]['A']==null) {
                $error += 1;
                continue;
            }
            $sheet[$i]['B'] = str_replace('\'', '', $sheet[$i]['B']);
            $sheet[$i]['A'] = str_replace(' ', '', $sheet[$i]['A']);
            $this->data['Rmpp'] = $this->setDB('getAllByRm', $sheet[$i]['A']);
            if (count($this->data['Rmpp'])>0) {
                $error += 1;
                continue;
            }

            $sheet[$i]['C'] = str_replace('\'', '', $sheet[$i]['C']);
            if ($sheet[$i]['D']!=""||$sheet[$i]['D']!=null) {
                $sheet[$i]['F'] = "L";
            }elseif ($sheet[$i]['E']!=""||$sheet[$i]['E']!=null) {
                $sheet[$i]['F'] = "P";
            }else{
                $sheet[$i]['F'] = "P";
            }
            
            $rs_rmpp_id_ex = $this->setDB('idEx', $this->AI->getRandStr(30));
            $bc = 'bc-'. $rs_rmpp_id_ex . "-"  . date("YmdHis") . ".png" ;

            $data = [
                'rs_rmpp_id_ex' => $rs_rmpp_id_ex,
                'rs_rmpp_rm' => $sheet[$i]['A'],
                'rs_rmpp_nm' => $sheet[$i]['B'],
                'rs_rmpp_altktp' => $sheet[$i]['C'],
                'rs_rmpp_jk' => $sheet[$i]['F'],
                'rs_rmpp_cd' => $bc,
            ];
            // dd($data);
            

            $insertData = $this->MdlU->insertData($data);
            if ($insertData) {
                file_put_contents('bc/'.$bc, $generator->getBarcode((string)$data['rs_rmpp_rm'], $generator::TYPE_CODE_128, 3, 50, $redColor));       

                $success += 1;
            } else {
                $error += 1;

            }            
        }

        // dd($sheet, $data);
        $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Berhasil Diproses, Dengan Data Yang Berhasil Berjumlah ' . (string)$success . ' Data, Dan Yang Tidak Berhasil Berjumlah ' . (string)$error . ' Data'];
        return $this->respond($data, $data['status']);
    }

    public function getNoRm()
    {
        $rs_rmpp_rm_l = (int)$this->MdlRmpp->getLastNoRm();
        $rs_rmpp_rm_n = $rs_rmpp_rm_l + 1;
        return $rs_rmpp_rm_n;
    }

    public function updateData($rs_rmpp_id_ex = '')
    {
        $array = $this->request->getPost();
        unset($array['datatableKirana_length']);
        unset($array['rs_rmpp_id_ex']);
        $arrayFlip = array_keys($array);
        $arrayFlipV = array_values($arrayFlip);
        $arrayV = array_values($array);
        $data = [];
        for ($i = 0; $i < count($arrayV); $i++) {
            $data[$arrayFlipV[$i]] = $arrayV[$i];
        }
        $updateData = $this->MdlRmpp->updateData($data, $rs_rmpp_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Pasien Berhasil Diubah'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Pasien Tidak Dapat Diubah'];
        }
        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmpp_id_ex = '')
    {
        if ($rs_rmpp_id_ex === null || $rs_rmpp_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlRmpp->deleteData($rs_rmpp_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Pasien Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Pasien Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function countRmpp()
    {
        return $this->setDB('count');
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmpp_id_ex';
        $id = 'rs_rmpp_id';
        $length = 5;
        $typeGet = 'result';

        $fillUpdate = 'rs_rmpp_id_ex, rs_rmpp_rm';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [],
                //order by
                [
                    0 => ['id' => 'rs_rmpp_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmi', 'string' => 'rs_rmi.rs_rmi_id_ex = rs_rmpp.rs_rmpp_rmi', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'getAllSrc') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [],
                //order by
                [
                    0 => ['id' => 'rs_rmpp_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmi', 'string' => 'rs_rmi.rs_rmi_id_ex = rs_rmpp.rs_rmpp_rmi', 'type' => 'LEFT'],
                ],
                //like
                [
                    0 => ['idEx' => $data[0], 'idExV' => $data[1]],
                ]
            );
        }elseif ($request == 'getAllByRm') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmpp_rm',
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpp_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    
                ],
                //like
                [
                   
                ]
            );
        } elseif ($request == 'count') {
            return $this->MdlU->getAll(
                //type result / row
                'count',
                // select *
                '*',
                //where
                [],
                //order by
                [
                    0 => ['id' => 'rs_rmpp_id', 'orderType' => 'DESC'],
                ],
                //join
                []
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpp_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        } elseif ($request == 'getCode') {
            return $this->MdlU->getIdEx('rs_rmpres_kd', $data, $id, 4);
        }
    }
}