<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\PprMdl;
use App\Models\RmrMdl;

class Ppr extends BaseController
{
    use ResponseTrait;
    protected $MdlPpr;
    protected $MdlRmr;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlPpr = new PprMdl();
        $this->MdlRmr = new RmrMdl();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeng',
            'pAct' => 'pAPeng',
            'cAct' => 'cArmr',
            'cmAct' => '',
            'scAct' => '',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
    }

    public function getAllForSelectByRmr($rs_ppr_rmr)
    {
        header("Content-Type:application/json;charset=utf-8");
        header("Access-Control-Allow-Origin: *");


        $data = $this->MdlPpr->getAllPpegByRmr($rs_ppr_rmr);
        for ($i = 0; $i < count($data); $i++) {
            if ($data[$i]['rs_ppeg_nmd'] != "") {
                $data[$i]['rs_ppeg_nm'] = $data[$i]['rs_ppeg_nmd'] . ". " . $data[$i]['rs_ppeg_nm'];
            }

            if ($data[$i]['rs_ppeg_nmb'] != "") {
                $data[$i]['rs_ppeg_nm'] = $data[$i]['rs_ppeg_nm'] . ", " . $data[$i]['rs_ppeg_nmb'];
            }
            $data[$i]['optText'] = $data[$i]['rs_ppeg_nm'];
            $data[$i]['optValue'] = $data[$i]['rs_ppeg_id_ex'];
        }
        return $this->respond($data, 200);
    }

    public function getPprByJson($rs_ppr_rmr = '', $id = '', $v = '')
    {
        header('Content-Type: application/json');
        header("Access-Control-Allow-Origin: *");

        $this->data['data']['data'] =  $this->MdlPpr->getAllPpegByRmr($rs_ppr_rmr);
        $no = 0;
        for ($i = 0; $i < count($this->data['data']['data']); $i++) {
            $no++;
            $this->data['data']['data'][$i]['no'] = $no;

            if ($this->data['data']['data'][$i]['rs_ppeg_nmd'] != "") {
                $this->data['data']['data'][$i]['rs_ppeg_nm'] = $this->data['data']['data'][$i]['rs_ppeg_nmd'] . ". " . $this->data['data']['data'][$i]['rs_ppeg_nm'];
            }

            if ($this->data['data']['data'][$i]['rs_ppeg_nmb'] != "") {
                $this->data['data']['data'][$i]['rs_ppeg_nm'] = $this->data['data']['data'][$i]['rs_ppeg_nm'] . ", " . $this->data['data']['data'][$i]['rs_ppeg_nmb'];
            }
            $this->data['data']['data'][$i]['check'] = "<input type='checkbox' name='rs_rmplp_ppeg[]' id='rs_rmplp_ppeg" . $no . "' class='form-control' value='" . $this->data['data']['data'][$i]['rs_ppeg_id_ex'] . "'/>";
            $this->data['data']['data'][$i]['buttonFill'] = "<button type='button' data-dismiss='modal' class='btn btn-success' onclick='addFill(\"" . $id . "\", \"" . $this->data['data']['data'][$i]['rs_ppeg_id_ex'] . "\"); addFill(\"" . $v . "\", \"" . $this->data['data']['data'][$i]['rs_ppeg_nm'] . "\");'><i class='fa fa-check'></i></button>";
        }

        return $this->respond($this->data['data'], 200);
    }

    public function viewData($rs_ppr_rmr = '')
    {
        if ($rs_ppr_rmr == '') {
            echo "<span class='badge badge-danger'>Tidak Ada Daftar Pegawai Dalam Ruangan</span>";
        } else {
            $this->data['Rmr'] = $this->MdlRmr->getAllRmr($rs_ppr_rmr);
            $this->data['WebTitle'] = 'DATA PEGAWAI DALAM RUANGAN ' . strtoupper($this->data['Rmr']['rs_rmr_nm']);
            $this->data['PageTitle'] = 'Data Pegawai Dalam Ruangan ' . $this->data['Rmr']['rs_rmr_nm'];
            $this->data['BasePage'] = 'ppr';
            $this->data['ButtonMethod'] = 'UBAH';
            $this->data['MethodForm'] = 'insertView/' . $rs_ppr_rmr;
            $this->data['IdForm'] = 'pprAddData';
            $this->data['UrlForm'] = 'ppr';
            $this->data['Ppr'] = $this->MdlPpr->getAllPpegByRmr($rs_ppr_rmr);
            for ($i = 0; $i < count($this->data['Ppr']); $i++) {
                if ($this->data['Ppr'][$i]['rs_ppeg_nmd'] != "") {
                    $this->data['Ppr'][$i]['rs_ppeg_nm'] = ". " . $this->data['Ppr'][$i]['rs_ppeg_nm'];
                }

                if ($this->data['Ppr'][$i]['rs_ppeg_nmb'] != "") {
                    $this->data['Ppr'][$i]['rs_ppeg_nm'] = $this->data['Ppr'][$i]['rs_ppeg_nm'] . ", ";
                }

                $this->data['Ppr'][$i]['rs_ppeg_nm'] = $this->data['Ppr'][$i]['rs_ppeg_nmd'] . $this->data['Ppr'][$i]['rs_ppeg_nm'] . $this->data['Ppr'][$i]['rs_ppeg_nmb'];
            }
            echo view('Ppr/index', $this->data);
            echo view('Templates/ajaxInsert', $this->data);
        }
    }

    public function deleteData($rs_ppr_id = '')
    {
        if ($rs_ppr_id === null || $rs_ppr_id == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlPpr->deleteData($rs_ppr_id);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Pegawai Dalam Ruangan Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Pegawai Dalam Ruangan Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }
}