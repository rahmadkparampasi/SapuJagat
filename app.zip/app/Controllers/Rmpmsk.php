<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\RmaMdl;
use App\Controllers\Rmph;
use App\Models\RmphMdl;
use App\Models\RmpmskMdl;
use App\Models\RmppMdl;
use App\Models\RmprMdl;
use App\Models\UmMdl;

class Rmpmsk extends BaseController
{
    use ResponseTrait;
    protected $MdlRmpmsk;
    protected $MdlRmpp;
    protected $Rmph;
    protected $MdlRmph;
    protected $Rmkrj;
    protected $Rmhub;
    protected $Rmpdk;
    protected $Rmsts;
    protected $Rmtgl;
    protected $Rmab;
    protected $Rmi;
    protected $Rmag;
    protected $Rmgd;
    protected $Rmpmskpj;

    protected $MdlRmpr;
    protected $MdlRma;

    protected $MdlU;


    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlRmpmsk = new RmpmskMdl();
        $this->MdlRmpp = new RmppMdl();
        $this->Rmph = new Rmph();
        $this->MdlRmpr = new RmprMdl();
        $this->MdlRma = new RmaMdl();
        $this->MdlRmph = new RmphMdl();
        $this->Rmkrj = new Rmkrj();
        $this->Rmhub = new Rmhub();
        $this->Rmpdk = new Rmpdk();
        $this->Rmsts = new Rmsts();
        $this->Rmtgl = new Rmtgl();
        $this->Rmab = new Rmab();
        $this->Rmi = new Rmi();
        $this->Rmag = new Rmag();
        $this->Rmgd = new Rmgd();
        $this->Rmpmskpj = new Rmpmskpj();

        $this->MdlU = new UmMdl('rs_rmpmsk', 'rs_rmpmsk_id_ex');
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOIgd',
            'pAct' => 'pAIgd',
            'cAct' => 'cArmpmsk',
            'cmAct' => '',
            'scAct' => '',
            'rmr_id_ex' => 'mZuZm01',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA PASIEN INSTALASI GAWAT DARURAT';
        $this->data['PageTitle'] = 'Data Pasien Instalasi Gawat Darurat';
        $this->data['BasePage'] = 'rmpmsk';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData';
        $this->data['IdForm'] = 'rmpmskAddData';
        $this->data['UrlForm'] = 'rmpmsk';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);

        $this->data['Rmpmsk'] = $this->MdlRmpmsk->getAllRmpmsk();

        $this->data['Rma'] = $this->MdlRma->getAllRma();

        $this->data['Rmkrj'] = $this->Rmkrj->getAll();
        $this->data['Rmhub'] = $this->Rmhub->getAll();
        $this->data['Rmpdk'] = $this->Rmpdk->getAll();
        $this->data['Rmsts'] = $this->Rmsts->getAll();
        $this->data['Rmtgl'] = $this->Rmtgl->getAll();
        $this->data['Rmab'] = $this->Rmab->getAll();
        $this->data['Rmi'] = $this->Rmi->getAll();
        $this->data['Rmag'] = $this->Rmag->getAll();
        $this->data['Rmgd'] = $this->Rmgd->getAll();

        for ($i = 0; $i < count($this->data['Rmpmsk']); $i++) {
            $this->data['d'] = (string)date('d', strtotime($this->data['Rmpmsk'][$i]['rs_rmpmsk_tgl']));
            $this->data['F'] = (string)date('F', strtotime($this->data['Rmpmsk'][$i]['rs_rmpmsk_tgl']));
            $this->data['F'] = $this->Another_Include->monthConv($this->data['F']);
            $this->data['Y'] = (string)date('Y', strtotime($this->data['Rmpmsk'][$i]['rs_rmpmsk_tgl']));
            $this->data['Rmpmsk'][$i]['rs_rmpmsk_tgl'] = strtoupper($this->data['d'] . " " . $this->data['F'] . " " . $this->data['Y']);

            $this->data['d'] = (string)date('d', strtotime($this->data['Rmpmsk'][$i]['rs_rmpp_tgl_lhr']));
            $this->data['F'] = (string)date('F', strtotime($this->data['Rmpmsk'][$i]['rs_rmpp_tgl_lhr']));
            $this->data['F'] = $this->Another_Include->monthConv($this->data['F']);
            $this->data['Y'] = (string)date('Y', strtotime($this->data['Rmpmsk'][$i]['rs_rmpp_tgl_lhr']));
            $this->data['Rmpmsk'][$i]['rs_rmpp_tgl_lhr'] = strtoupper($this->data['d'] . " " . $this->data['F'] . " " . $this->data['Y']);

            if ($this->data['Rmpmsk'][$i]['rs_rmpp_jk'] == "L") {
                $this->data['Rmpmsk'][$i]['rs_rmpp_jk'] = "LAKI-LAKI";
            } else {
                $this->data['Rmpmsk'][$i]['rs_rmpp_jk'] = "PEREMPUAN";
            }
        }

        echo view('Rmpmsk/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }

    public function insertDataRmpp()
    {
        $rs_rmpmsk_rmpp = $this->request->getPost('rs_rmpmsk_rmpp');
        $insertDataRmph = $this->Rmph->iDH($rs_rmpmsk_rmpp, "PR");
        if ($insertDataRmph[0]) {


            $array = $this->request->getPost();
            unset($array['datatableKirana_length']);
            $arrayFlip = array_keys($array);
            $arrayFlipV = array_values($arrayFlip);
            $arrayV = array_values($array);

            $rs_rmpmsk_id_ex = $this->MdlRmpmsk->getIdExRmpmsk($this->Another_Include->getRandStr(7));

            $rs_rmpr_rmpmsk = $rs_rmpmsk_id_ex;
            $rs_rmpr_rmr = $this->data['rmr_id_ex'];
            $rs_rmpr_ppeg = $this->data['rs_ppeg_id_ex'];
            $rs_rmpr_rmph = $insertDataRmph[1];

            $dataRmpmsk = [];
            $dataRmpmsk = [
                'rs_rmpmsk_id_ex' => $rs_rmpmsk_id_ex,
                'rs_rmpmsk_rmpp' => $rs_rmpmsk_rmpp,
                'rs_rmpmsk_rmph' => $insertDataRmph[1]
            ];

            $dataRmpr = [
                'rs_rmpr_rmpmsk' => $rs_rmpr_rmpmsk,
                'rs_rmpr_rmr' => $rs_rmpr_rmr,
                'rs_rmpr_ppeg' => $rs_rmpr_ppeg,
                'rs_rmpr_rmph' => $rs_rmpr_rmph
            ];

            $dataRmpp = [];

            for ($i = 0; $i < count($arrayV); $i++) {
                if (substr($arrayFlipV[$i], 0, 7) == "rs_rmpp") {
                    $dataRmpp[$arrayFlipV[$i]] = $arrayV[$i];
                    # code...
                } else {
                    $dataRmpmsk[$arrayFlipV[$i]] = $arrayV[$i];
                }
            }

            if ($dataRmpmsk['rs_rmpmsk_rma'] == "") {
                $dataRmpmsk['rs_rmpmsk_rma'] = null;
            }


            $insertDataRmpmsk = $this->MdlRmpmsk->insertData($dataRmpmsk);
            if ($insertDataRmpmsk) {
                $insertDataRmpr = $this->MdlRmpr->insertData($dataRmpr);
                if ($insertDataRmpr) {
                    $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Pasien Masuk Berhasil Disimpan'];
                } else {
                    $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Ruangan Pasien Masuk Tidak Dapat Disimpan'];
                }
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Pasien Masuk Tidak Dapat Disimpan'];
            }
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Histori Pasien Tidak Dapat Disimpan'];
        }

        return $this->respond($data, $data['status']);
    }

    public function getRmpmskByJson()
    {
        header('Content-Type: application/json');
        header("Access-Control-Allow-Origin: *");
        $this->data['data']['data'] = $this->MdlRmpmsk->getAllRmpmsk();

        for ($i = 0; $i < count($this->data['data']['data']); $i++) {
            $this->data['d'] = (string)date('d', strtotime($this->data['data']['data'][$i]['rs_rmpmsk_tgl']));
            $this->data['F'] = (string)date('F', strtotime($this->data['data']['data'][$i]['rs_rmpmsk_tgl']));
            $this->data['F'] = $this->Another_Include->monthConv($this->data['F']);
            $this->data['Y'] = (string)date('Y', strtotime($this->data['data']['data'][$i]['rs_rmpmsk_tgl']));
            $this->data['data']['data'][$i]['rs_rmpmsk_tgl'] = strtoupper($this->data['d'] . " " . $this->data['F'] . " " . $this->data['Y']);

            $this->data['d'] = (string)date('d', strtotime($this->data['data']['data'][$i]['rs_rmpp_tgl_lhr']));
            $this->data['F'] = (string)date('F', strtotime($this->data['data']['data'][$i]['rs_rmpp_tgl_lhr']));
            $this->data['F'] = $this->Another_Include->monthConv($this->data['F']);
            $this->data['Y'] = (string)date('Y', strtotime($this->data['data']['data'][$i]['rs_rmpp_tgl_lhr']));
            $this->data['data']['data'][$i]['rs_rmpp_tgl_lhr'] = strtoupper($this->data['d'] . " " . $this->data['F'] . " " . $this->data['Y']);

            if ($this->data['data']['data'][$i]['rs_rmpp_jk'] == "L") {
                $this->data['data']['data'][$i]['rs_rmpp_jk'] = "LAKI-LAKI";
            } else {
                $this->data['data']['data'][$i]['rs_rmpp_jk'] = "PEREMPUAN";
            }
        }
        return $this->respond($this->data['data'], 200);
    }



    public function insertData()
    {
        $rs_rmpp_ppeg = $this->data['rs_ppeg_id_ex'];

        $array = $this->request->getPost();
        // dd($array);
        unset($array['datatableKirana_length']);
        $arrayFlip = array_keys($array);
        $arrayFlipV = array_values($arrayFlip);
        $arrayV = array_values($array);

        $rs_rmpp_id_ex = $this->MdlRmpp->getIdExRmpp($this->Another_Include->getRandStr(30));

        $dataRmpp = [];
        $dataRmpp['rs_rmpp_id_ex'] = $rs_rmpp_id_ex;
        $dataRmpp['rs_rmpp_ppeg'] = $rs_rmpp_ppeg;
        $dataRmpp['rs_rmpp_rm'] = $this->getNoRm();

        $rs_rmph_id_ex = $this->MdlRmph->getIdExRmph($this->Another_Include->getRandStr(10));
        $rs_rmph_rmpp = $rs_rmpp_id_ex;
        $rs_rmph_ppeg = $this->data['rs_ppeg_id_ex'];
        $rs_rmph_jns = "PR";

        $dataRmph = [
            'rs_rmph_id_ex' => $rs_rmph_id_ex,
            'rs_rmph_rmpp' => $rs_rmph_rmpp,
            'rs_rmph_ppeg' => $rs_rmph_ppeg,
            'rs_rmph_jns' => $rs_rmph_jns
        ];


        $rs_rmpmsk_id_ex = $this->MdlRmpmsk->getIdExRmpmsk($this->Another_Include->getRandStr(7));

        $rs_rmpr_rmpmsk = $rs_rmpmsk_id_ex;
        $rs_rmpr_rmr = $this->data['rmr_id_ex'];
        $rs_rmpr_ppeg = $this->data['rs_ppeg_id_ex'];
        $rs_rmpr_rmph = $rs_rmph_id_ex;

        $dataRmpmsk = [];

        $dataRmpmsk = [
            'rs_rmpmsk_id_ex' => $rs_rmpmsk_id_ex,
            'rs_rmpmsk_rmpp' => $rs_rmpp_id_ex,
            'rs_rmpmsk_rmph' => $rs_rmph_id_ex
        ];

        $dataRmpmskpj = [
            'rs_rmpmskpj_id_ex' => $this->Rmpmskpj->setDB('idEx', $this->Another_Include->getRandStr(7)),
            'rs_rmpmskpj_rmpmsk' => $rs_rmpmsk_id_ex
        ];

        $dataRmpr = [
            'rs_rmpr_rmpmsk' => $rs_rmpr_rmpmsk,
            'rs_rmpr_rmr' => $rs_rmpr_rmr,
            'rs_rmpr_ppeg' => $rs_rmpr_ppeg,
            'rs_rmpr_rmph' => $rs_rmpr_rmph
        ];


        for ($i = 0; $i < count($arrayV); $i++) {
            if (substr($arrayFlipV[$i], 0, 7) == "rs_rmpp") {
                $dataRmpp[$arrayFlipV[$i]] = $arrayV[$i];
                # code...
            } elseif (substr($arrayFlipV[$i], 0, 11) == "rs_rmpmskpj") {
                $dataRmpmskpj[$arrayFlipV[$i]] = $arrayV[$i];
            } else {
                $dataRmpmsk[$arrayFlipV[$i]] = $arrayV[$i];
            }
        }

        if ($dataRmpmsk['rs_rmpmsk_rma'] == "") {
            $dataRmpmsk['rs_rmpmsk_rma'] = null;
        }

        // dd($array, $arrayFlip, $arrayFlipV, $arrayV, $dataRmpp, $dataRmpmsk, $dataRmpmskpj);

        $insertDataRmpp = $this->MdlRmpp->insertData($dataRmpp);
        if ($insertDataRmpp) {
            $insertDataRmph = $this->MdlRmph->insertData($dataRmph);
            if ($insertDataRmph) {
                $insertDataRmpmsk = $this->MdlRmpmsk->insertData($dataRmpmsk);
                if ($insertDataRmpmsk) {
                    $insertDataRmpmskpj = $this->Rmpmskpj->insertData($dataRmpmskpj);
                    if ($insertDataRmpmskpj) {
                        $insertDataRmpr = $this->MdlRmpr->insertData($dataRmpr);
                        if ($insertDataRmpr) {
                            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Pasien Masuk Berhasil Disimpan'];
                        } else {
                            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Ruangan Pasien Masuk Tidak Dapat Disimpan'];
                        }
                    } else {
                        $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Penanggung Jawab Pasien Masuk Tidak Dapat Disimpan'];
                    }
                } else {
                    $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Pasien Masuk Tidak Dapat Disimpan'];
                }
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Histori Pasien Tidak Dapat Disimpan'];
            }
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Pasien Tidak Dapat Disimpan'];
        }


        return $this->respond($data, $data['status']);
    }

    function insertDataU($data)
    {

        $feedback = false;
        $insertData = $this->MdlU->insertData($data);
        if ($insertData) {
            $feedback = true;
        } else {
            $feedback = false;
        }
        $data = [$feedback];
        return $data;
    }

    public function getNoRm()
    {
        $rs_rmpp_rm_l = (int)$this->MdlRmpp->getLastNoRm();
        $rs_rmpp_rm_n = $rs_rmpp_rm_l + 1;
        return $rs_rmpp_rm_n;
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmpmsk_id_ex';
        $id = 'rs_rmpmsk_id';
        $length = 3;
        $typeGet = 'result';

        $fillUpdate = 'rs_rmpmsk_id_ex';

        if ($request == 'getByRmpp') {
            return $this->MdlU->getAll(
                //type result / row
                'row',
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => $data[0],
                        'idExV' => $data[1]
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpmsk_id', 'orderType' => 'DESC'],
                ],
                //join
                []
            );
        } elseif ($request == 'getAllByRmpp') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => $data[0],
                        'idExV' => $data[1]
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpmsk_id', 'orderType' => 'DESC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rma', 'string' => 'rs_rma.rs_rma_id_ex = rs_rmpmsk.rs_rmpmsk_rma', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_rmsts', 'string' => 'rs_rmsts.rs_rmsts_id_ex = rs_rmpmsk.rs_rmpmsk_rmsts', 'type' => 'LEFT'],
                    2 => ['tableName' => 'rs_rmpdk', 'string' => 'rs_rmpdk.rs_rmpdk_id_ex = rs_rmpmsk.rs_rmpmsk_rmpdk', 'type' => 'LEFT'],
                    3 => ['tableName' => 'rs_rmkrj', 'string' => 'rs_rmkrj.rs_rmkrj_id_ex = rs_rmpmsk.rs_rmpmsk_rmkrj', 'type' => 'LEFT'],
                    4 => ['tableName' => 'rs_rmtgl', 'string' => 'rs_rmtgl.rs_rmtgl_id_ex = rs_rmpmsk.rs_rmpmsk_rmtgl', 'type' => 'LEFT'],
                    5 => ['tableName' => 'rs_rmab', 'string' => 'rs_rmab.rs_rmab_id_ex = rs_rmpmsk.rs_rmpmsk_rmab', 'type' => 'LEFT'],
                    6 => ['tableName' => 'rs_rmpr', 'string' => 'rs_rmpr.rs_rmpr_rmpmsk = rs_rmpmsk.rs_rmpmsk_id_ex', 'type' => 'LEFT'],
                    7 => ['tableName' => 'rs_rmr', 'string' => 'rs_rmr.rs_rmr_id_ex = rs_rmpr.rs_rmpr_rmr', 'type' => 'LEFT'],
                    8 => ['tableName' => 'rs_rmpplg', 'string' => 'rs_rmpplg.rs_rmpplg_rmpmsk = rs_rmpmsk.rs_rmpmsk_id_ex', 'type' => 'LEFT'],
                    9 => ['tableName' => 'rs_rmprk', 'string' => 'rs_rmprk.rs_rmprk_rmpmsk = rs_rmpmsk.rs_rmpmsk_id_ex', 'type' => 'LEFT'],
                    10 => ['tableName' => 'rs_rmpsls', 'string' => 'rs_rmpsls.rs_rmpsls_rmpmsk = rs_rmpmsk.rs_rmpmsk_id_ex', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'getAllSrc') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [],
                //order by
                [
                    0 => ['id' => 'rs_rmpp_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmi', 'string' => 'rs_rmi.rs_rmi_id_ex = rs_rmpp.rs_rmpp_rmi', 'type' => 'LEFT'],
                ],
                //like
                [
                    0 => ['idEx' => $data[0], 'idExV' => $data[1]],
                ]
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpp_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        } elseif ($request == 'getCode') {
            return $this->MdlU->getIdEx('rs_rmpres_kd', $data, $id, 4);
        }
    }
}