<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\RmaMdl;
use App\Models\RmppMdl;
use App\Models\UmMdl;

class Rmppd extends BaseController
{
    use ResponseTrait;
    protected $MdlRmpp;
    protected $MdlU;
    protected $Rmpmsk;
    protected $Rmpmskpj;
    protected $Rmpr;
    protected $Rmpmskd;
    protected $Rmkrj;
    protected $Rmhub;
    protected $Rmpdk;
    protected $Rmsts;
    protected $Rmtgl;
    protected $Rmab;
    protected $Rmi;
    protected $Rmprtt;
    protected $Rmph;
    protected $Rmpl;
    protected $Rmag;
    protected $Rmgd;
    protected $Setkrt;
    protected $MdlRma;
    protected $Setrmr;
    protected $AI;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlRmpp = new RmppMdl();
        $this->MdlU = new UmMdl('rs_rmpp', 'rs_rmpp_id_ex');
        $this->Rmpmsk = new Rmpmsk;
        $this->Rmpmskpj = new Rmpmskpj;
        $this->Rmpr = new Rmpr;
        $this->Rmpmskd = new Rmpmskd;
        $this->Rmkrj = new Rmkrj;
        $this->Rmhub = new Rmhub;
        $this->Rmpdk = new Rmpdk;
        $this->Rmsts = new Rmsts;
        $this->Rmtgl = new Rmtgl;
        $this->Rmab = new Rmab;
        $this->Rmi = new Rmi;
        $this->Rmprtt = new Rmprtt;
        $this->Rmph = new Rmph;
        $this->Rmpl = new Rmpl;
        $this->Rmag = new Rmag;
        $this->Rmgd = new Rmgd;
        $this->Setkrt = new Setkrt;
        $this->MdlRma = new RmaMdl();
        $this->AI = new Another_Include();
        $this->Setrmr = new Setrmr();
        $this->data['setRmr'] = $this->Setrmr->getAll();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mORm',
            'pAct' => 'pARm',
            'cAct' => 'cArmpp',
            'cmAct' => '',
            'scAct' => '',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),

            'setRmr' => [
                'setPlhKmr' => $this->data['setRmr'][7]['rs_setrmr_rmr'],
            ]
        ];

        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function viewData($rs_rmpp_id_ex)
    {
        // dd($this->data);
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['rs_rmpp_id_ex'] = $rs_rmpp_id_ex;
        $this->data['WebTitle'] = 'DATA PASIEN';
        $this->data['PageTitle'] = 'Data Pasien';
        $this->data['BasePage'] = 'rmppd';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData/' . $rs_rmpp_id_ex;
        $this->data['IdForm'] = 'rmppdAddData';
        $this->data['UrlForm'] = 'rmppd/viewData/' . $rs_rmpp_id_ex;

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);
        $this->data['display'] = "";
        if ($this->data['MethodForm1'] == "updateData") {
            $this->data['display'] = 'display: block;';
        } else {
            $this->data['display'] = 'display: none;';
        }

        $this->data['Rmkrj'] = $this->Rmkrj->getAll();
        $this->data['Rmhub'] = $this->Rmhub->getAll();
        $this->data['Rmpdk'] = $this->Rmpdk->getAll();
        $this->data['Rmsts'] = $this->Rmsts->getAll();
        $this->data['Rmtgl'] = $this->Rmtgl->getAll();
        $this->data['Rmab'] = $this->Rmab->getAll();
        $this->data['Rmi'] = $this->Rmi->getAll();
        $this->data['Rma'] = $this->MdlRma->getAllRma();
        $this->data['Rmag'] = $this->Rmag->getAll();
        $this->data['Rmgd'] = $this->Rmgd->getAll();



        $this->data['Rmpp'] = $this->setDB('fillUpdate', $rs_rmpp_id_ex);
        $this->data['Rmpp'] = $this->AI->convertJKNF($this->data['Rmpp'], 'rs_rmpp_jk');
        if ($this->data['Rmpp']['rs_rmpp_tgl_lhr']=="0000-00-00") {
            $this->data['Rmpp']['rs_rmpp_tgl_lhr']="BELUM ADA TANGGAL LAHIR";
        }else{
            $this->data['Rmpp']['rs_rmpp_tgl_lhr'] = $this->AI->changeDateNF($this->data['Rmpp']['rs_rmpp_tgl_lhr']);
        }
        //dd($this->data['Rmpp']);
        $this->data['Rmpp'] = $this->changeTextRmpmsk($this->data['Rmpp']);
        $this->data['Rmpp']['Rmpmsk'] = $this->Rmpmsk->setDB('getAllByRmpp', ['rs_rmpmsk_rmpp', $this->data['Rmpp']['rs_rmpp_id_ex']]);
        $this->data['Rmpp']['Rmpmsk'] = $this->AI->changeDateWF($this->data['Rmpp']['Rmpmsk'], ['rs_rmpmsk_tgl']);
        for ($i = 0; $i < count($this->data['Rmpp']['Rmpmsk']); $i++) {
            $this->data['Rmpp']['Rmpmsk'][$i]['color'] = 'success';
            $this->data['Rmpp']['Rmpmsk'][$i]['colorSts'] = 'warning';
            $this->data['Rmpp']['Rmpmsk'][$i]['sts'] = 'Masih Dirawat';
            if ($this->data['Rmpp']['Rmpmsk'][$i]['rs_rmpmsk_plg'] == '0') {
                $this->data['Rmpp']['Rmpmsk'][$i]['color'] = 'warning';
            }

            if ($this->data['Rmpp']['Rmpmsk'][$i]['rs_rmpplg_tgl'] != null) {
                $this->data['Rmpp']['Rmpmsk'][$i]['colorSts'] = 'success';
                $this->data['Rmpp']['Rmpmsk'][$i]['sts'] = 'Sudah Pulang';
            } elseif ($this->data['Rmpp']['Rmpmsk'][$i]['rs_rmprk_tgl'] != null) {
                $this->data['Rmpp']['Rmpmsk'][$i]['colorSts'] = 'danger';
                $this->data['Rmpp']['Rmpmsk'][$i]['sts'] = 'Dirujuk Keluar';
            } elseif ($this->data['Rmpp']['Rmpmsk'][$i]['rs_rmpsls_tgl'] != null) {
                $this->data['Rmpp']['Rmpmsk'][$i]['colorSts'] = 'primary';
                $this->data['Rmpp']['Rmpmsk'][$i]['sts'] = 'Selesai';
            }

            if ($this->data['Rmpp']['Rmpmsk'][$i]['rs_rmpmsk_cp'] == "TN") {
                $this->data['Rmpp']['Rmpmsk'][$i]['rs_rmpmsk_cp'] = "Tunai";
            } else {
                $this->data['Rmpp']['Rmpmsk'][$i]['rs_rmpmsk_cp'] = "Asuransi : " . $this->data['Rmpp']['Rmpmsk'][$i]['rs_rma_nm'] . " - " . $this->data['Rmpp']['Rmpmsk'][$i]['rs_rmpmsk_anmr'];
            }
            $this->data['Rmpp']['Rmpmsk'][$i]['Rmpr'] = $this->Rmpr->gbRmpmsk($this->data['Rmpp']['Rmpmsk'][$i]['rs_rmpmsk_id_ex']);
            $this->data['Rmpp']['Rmpmsk'][$i]['Rmpr'] = $this->AI->changeDateWF($this->data['Rmpp']['Rmpmsk'][$i]['Rmpr'], ['rs_rmpr_tgl']);


            for ($j = 0; $j < count($this->data['Rmpp']['Rmpmsk'][$i]['Rmpr']); $j++) {
                if ($this->data['Rmpp']['Rmpmsk'][$i]['Rmpr'][$j]['rs_rmk_nm'] != "") {
                    $this->data['Rmpp']['Rmpmsk'][$i]['Rmpr'][$j]['rs_rmk_nm'] = "/" . $this->data['Rmpp']['Rmpmsk'][$i]['Rmpr'][$j]['rs_rmk_nm'];
                }
                if ($this->data['Rmpp']['Rmpmsk'][$i]['Rmpr'][$j]['rs_rmrkk_nm'] != "") {
                    $this->data['Rmpp']['Rmpmsk'][$i]['Rmpr'][$j]['rs_rmrkk_nm'] = "." . $this->data['Rmpp']['Rmpmsk'][$i]['Rmpr'][$j]['rs_rmrkk_nm'];
                }
                if ($this->data['Rmpp']['Rmpmsk'][$i]['Rmpr'][$j]['rs_rmrkkt_nm'] != "") {
                    $this->data['Rmpp']['Rmpmsk'][$i]['Rmpr'][$j]['rs_rmrkkt_nm'] = "-" . $this->data['Rmpp']['Rmpmsk'][$i]['Rmpr'][$j]['rs_rmrkkt_nm'];
                }
            }

            $this->data['Rmpp']['Rmpmsk'][$i]['Rmpl'] = $this->Rmpl->setDB('getAllWH', $this->data['Rmpp']['Rmpmsk'][$i]['rs_rmpmsk_id_ex']);

            $this->data['Rmpp']['Rmpmsk'][$i]['Rmprtt'] = $this->Rmprtt->setDB('getAllByRmpmsk', [$this->data['Rmpp']['Rmpmsk'][$i]['rs_rmpmsk_id_ex']]);
            $this->data['Rmpp']['Rmpmsk'][$i]['Rmprtt'] = $this->AI->changeDateWF($this->data['Rmpp']['Rmpmsk'][$i]['Rmprtt'], ['rs_rmprtt_tgl', 'rs_rmpr_tgl']);
            for ($j = 0; $j < count($this->data['Rmpp']['Rmpmsk'][$i]['Rmprtt']); $j++) {
                if ($this->data['Rmpp']['Rmpmsk'][$i]['Rmprtt'][$j]['rs_rmk_nm'] != "") {
                    $this->data['Rmpp']['Rmpmsk'][$i]['Rmprtt'][$j]['rs_rmk_nm'] = "/" . $this->data['Rmpp']['Rmpmsk'][$i]['Rmprtt'][$j]['rs_rmk_nm'];
                }
                if ($this->data['Rmpp']['Rmpmsk'][$i]['Rmprtt'][$j]['rs_rmrkk_nm'] != "") {
                    $this->data['Rmpp']['Rmpmsk'][$i]['Rmprtt'][$j]['rs_rmrkk_nm'] = "." . $this->data['Rmpp']['Rmpmsk'][$i]['Rmprtt'][$j]['rs_rmrkk_nm'];
                }
                if ($this->data['Rmpp']['Rmpmsk'][$i]['Rmprtt'][$j]['rs_rmrkkt_nm'] != "") {
                    $this->data['Rmpp']['Rmpmsk'][$i]['Rmprtt'][$j]['rs_rmrkkt_nm'] = "-" . $this->data['Rmpp']['Rmpmsk'][$i]['Rmprtt'][$j]['rs_rmrkkt_nm'];
                }
            }
        }

        $this->data['fillUpdate'] = $this->MdlRmpp->getAllRmpp($rs_rmpp_id_ex);
        if ($this->data['fillUpdate']['rs_rmpp_rmgd']==null) {
            $this->data['fillUpdate']['rs_rmpp_rmgd'] = "0";
        }
        if ($this->data['fillUpdate']['rs_rmpp_rmag']==null) {
            $this->data['fillUpdate']['rs_rmpp_rmag'] = "0";
        }
        if ($this->data['fillUpdate']['rs_rmpp_rmi']==null) {
            $this->data['fillUpdate']['rs_rmpp_rmi'] = "0";
        }
        echo view('Rmpp/indexD', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
        echo view('Templates/loadData');

    }


    public function ctkKrt($rs_rmpp_id_ex = '')
    {
        $this->data['rs_rmpp_id_ex'] = $rs_rmpp_id_ex;
        $this->data['WebTitle'] = 'DATA PASIEN';
        $this->data['PageTitle'] = 'Data Pasien';
        $this->data['BasePage'] = 'rmppd';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData/' . $rs_rmpp_id_ex;
        $this->data['IdForm'] = 'rmppdAddData';
        $this->data['UrlForm'] = 'rmppd/viewData/' . $rs_rmpp_id_ex;
        $this->data['Rmpp'] = $this->setDB('fillUpdate', $rs_rmpp_id_ex);
        $this->data['Rmpp']['rs_rmpp_tgl_lhr'] = $this->AI->changeDateNF($this->data['Rmpp']['rs_rmpp_tgl_lhr']);
        $this->data['Rmpp'] = $this->AI->convertJKNF($this->data['Rmpp'], 'rs_rmpp_jk');
        $this->data['Rmpp']['rs_rmpp_rm']  = substr_replace($this->data['Rmpp']['rs_rmpp_rm'], " ", 2, 0);
        $this->data['Rmpp']['rs_rmpp_rm']  = substr_replace($this->data['Rmpp']['rs_rmpp_rm'], " ", 5, 0);
        $this->data['Setkrt'] = $this->Setkrt->getDpn();


        // dd($this->data['Rmpp']);
        echo view('Rmpp/indexCtkKrt', $this->data);
        // echo view('Templates/anotherScript');
    }
    public function ctkGlg($rs_rmpp_id_ex = '')
    {
        $this->data['rs_rmpp_id_ex'] = $rs_rmpp_id_ex;
        $this->data['WebTitle'] = 'DATA PASIEN';
        $this->data['PageTitle'] = 'Data Pasien';
        $this->data['BasePage'] = 'rmppd';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData/' . $rs_rmpp_id_ex;
        $this->data['IdForm'] = 'rmppdAddData';
        $this->data['UrlForm'] = 'rmppd/viewData/' . $rs_rmpp_id_ex;
        $this->data['Rmpp'] = $this->setDB('fillUpdate', $rs_rmpp_id_ex);
        $this->data['Rmpp']['rs_rmpp_tgl_lhr'] = $this->AI->changeDateNF($this->data['Rmpp']['rs_rmpp_tgl_lhr']);
        $this->data['Rmpp'] = $this->AI->convertJKNF($this->data['Rmpp'], 'rs_rmpp_jk');
        $this->data['Rmpp']['rs_rmpp_rm']  = substr_replace($this->data['Rmpp']['rs_rmpp_rm'], " ", 2, 0);
        $this->data['Rmpp']['rs_rmpp_rm']  = substr_replace($this->data['Rmpp']['rs_rmpp_rm'], " ", 5, 0);
        $this->data['Setkrt'] = $this->Setkrt->getDpn();


        // dd($this->data['Rmpp']);
        echo view('Rmpp/indexCtkGlg', $this->data);
        // echo view('Templates/anotherScript');
    }

    public function updateData($rs_rmpp_id_ex = '')
    {
        $array = $this->request->getPost();
        unset($array['datatableKirana_length']);
        unset($array['rs_rmpp_id_ex']);
        $arrayFlip = array_keys($array);
        $arrayFlipV = array_values($arrayFlip);
        $arrayV = array_values($array);
        $data = [];
        for ($i = 0; $i < count($arrayV); $i++) {
            $data[$arrayFlipV[$i]] = $arrayV[$i];
        }
        if ($data['rs_rmpp_rmgd']=="0") {
            $data['rs_rmpp_rmgd'] = null;
        }
        if ($data['rs_rmpp_rmag']=="0") {
            $data['rs_rmpp_rmag'] = null;
        }
        $updateData = $this->MdlRmpp->updateData($data, $rs_rmpp_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Pasien Berhasil Diubah'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Pasien Tidak Dapat Diubah'];
        }
        return $this->respond($data, $data['status']);
    }

    public function insertData($rs_rmpp_id_ex = '')
    {
        $insertDataRmph = $this->Rmph->iDH($rs_rmpp_id_ex, "PR");
        if ($insertDataRmph[0]) {
            $rs_rmpmsk_id_ex = $this->Rmpmsk->setDB('idEx', $this->AI->getRandStr(7));
            $dataRmpmsk = [
                'rs_rmpmsk_id_ex' => $rs_rmpmsk_id_ex,
                'rs_rmpmsk_rmph' => $insertDataRmph[1],
                'rs_rmpmsk_rmpp' => $this->request->getPost('rs_rmpmsk_rmpp'),
                'rs_rmpmsk_tgl' => $this->request->getPost('rs_rmpmsk_tgl'),
                'rs_rmpmsk_jam' => $this->request->getPost('rs_rmpmsk_jam'),
                'rs_rmpmsk_pr' => $this->request->getPost('rs_rmpmsk_pr'),
                'rs_rmpmsk_rd' => $this->request->getPost('rs_rmpmsk_rd'),
                'rs_rmpmsk_rjkd' => $this->request->getPost('rs_rmpmsk_rjkd'),
                'rs_rmpmsk_alt' => $this->request->getPost('rs_rmpmsk_alt'),
                'rs_rmpmsk_rmsts' => $this->request->getPost('rs_rmpmsk_rmsts'),
                'rs_rmpmsk_rmpdk' => $this->request->getPost('rs_rmpmsk_rmpdk'),
                'rs_rmpmsk_rmpdk' => $this->request->getPost('rs_rmpmsk_rmpdk'),
                'rs_rmpmsk_rmkrj' => $this->request->getPost('rs_rmpmsk_rmkrj'),
                'rs_rmpmsk_pp' => $this->request->getPost('rs_rmpmsk_pp'),
                'rs_rmpmsk_cp' => $this->request->getPost('rs_rmpmsk_cp'),
                'rs_rmpmsk_rma' => $this->request->getPost('rs_rmpmsk_rma'),
                'rs_rmpmsk_anmr' => $this->request->getPost('rs_rmpmsk_anmr'),
                'rs_rmpmsk_rmtgl' => $this->request->getPost('rs_rmpmsk_rmtgl'),
                'rs_rmpmsk_rmab' => $this->request->getPost('rs_rmpmsk_rmab'),
                'rs_rmpmsk_rmsmf' => $this->request->getPost('rs_rmpmsk_rmsmf'),
                'rs_rmpmsk_ppeg' => $this->request->getPost('rs_rmpmsk_ppeg'),
                'rs_rmpmsk_pj' => $this->request->getPost('rs_rmpmsk_pj'),

            ];

            $dataRmpmskpj = [
                'rs_rmpmskpj_id_ex' => $this->Rmpmskpj->setDB('idEx', $this->AI->getRandStr(7)),
                'rs_rmpmskpj_rmpmsk' => $rs_rmpmsk_id_ex,
                'rs_rmpmskpj_n' => $this->request->getPost('rs_rmpmskpj_n'),
                'rs_rmpmskpj_rmi' => $this->request->getPost('rs_rmpmskpj_rmi'),
                'rs_rmpmskpj_ind' => $this->request->getPost('rs_rmpmskpj_ind'),
                'rs_rmpmskpj_rmhub' => $this->request->getPost('rs_rmpmskpj_rmhub'),
                'rs_rmpmskpj_alt' => $this->request->getPost('rs_rmpmskpj_alt'),
                'rs_rmpmskpj_altktp' => $this->request->getPost('rs_rmpmskpj_altktp'),
                'rs_rmpmskpj_altn' => $this->request->getPost('rs_rmpmskpj_altn'),
                'rs_rmpmskpj_altr' => $this->request->getPost('rs_rmpmskpj_altr'),
                'rs_rmpmskpj_altkk' => $this->request->getPost('rs_rmpmskpj_altkk'),
                'rs_rmpmskpj_altkp' => $this->request->getPost('rs_rmpmskpj_altkp'),
                'rs_rmpmskpj_altth' => $this->request->getPost('rs_rmpmskpj_altth'),
                'rs_rmpmskpj_rmpdk' => $this->request->getPost('rs_rmpmskpj_rmpdk'),
                'rs_rmpmskpj_rmkrj' => $this->request->getPost('rs_rmpmskpj_rmkrj'),
            ];

            $dataRmpr = [
                'rs_rmpr_rmpmsk' => $rs_rmpmsk_id_ex,
                'rs_rmpr_rmr' => $this->request->getPost('rs_rmpr_rmr'),
                'rs_rmpr_tgl' => $this->request->getPost('rs_rmpmsk_tgl'),
                'rs_rmpr_jam' => $this->request->getPost('rs_rmpmsk_jam'),
            ];



            if ($dataRmpmsk['rs_rmpmsk_rma'] == "") {
                $dataRmpmsk['rs_rmpmsk_rma'] = null;
            }

            $vldDataRmpmskpj = true;
            if ($dataRmpmsk['rs_rmpmsk_pj'] == "1") {
                $vldDataRmpmskpj = true;
            }else{
                $vldDataRmpmskpj = false;
            }

            $insertDataRmpmsk = $this->Rmpmsk->insertDataU($dataRmpmsk);
            if ($insertDataRmpmsk[0]) {

                if ($vldDataRmpmskpj) {
                    $insertDataRmpmskpj = $this->Rmpmskpj->insertData($dataRmpmskpj);
                    if ($insertDataRmpmskpj) {
                        $vldDataRmpmskpj = true;
                    }else{
                        $vldDataRmpmskpj = false;
                    }
                }else{
                    $vldDataRmpmskpj = true;
                }

                if ($vldDataRmpmskpj) {

                    $dataRmpr['rs_rmpr_ppeg'] = $this->data['rs_ppeg_id_ex'];
                    $dataRmpr['rs_rmpr_rmph'] = $insertDataRmph[1];
                    $insertDataRmpr = $this->Rmpr->i($dataRmpr);
                    if ($insertDataRmpr[0]) {
                        $dataRmprtt['rs_rmprtt_id_ex'] = $this->Rmprtt->setDB('idEx', $this->AI->getRandJStr(9));
                        $dataRmprtt['rs_rmprtt_rmpr'] = $insertDataRmpr[1];
                        $dataRmprtt['rs_rmprtt_rmrkkt'] = $this->request->getPost('rs_rmprtt_rmrkkt');
                        $dataRmprtt['rs_rmprtt_tgl'] = $this->request->getPost('rs_rmpmsk_tgl');
                        $insertDataRmprtt = $this->Rmprtt->i($dataRmprtt);
                        if ($insertDataRmprtt) {
                            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Pasien Masuk Berhasil Disimpan'];
                        } else {
                            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Tempat Tidur Pasien Masuk Tidak Dapat Disimpan'];
                        }
                    } else {
                        $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Ruangan Pasien Masuk Tidak Dapat Disimpan'];
                    }
                } else {
                    $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Penanggung Jawab Pasien Masuk Tidak Dapat Disimpan'];
                }
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Pasien Masuk Tidak Dapat Disimpan'];
            }
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Histori Pasien Tidak Dapat Disimpan'];
        }

        return $this->respond($data, $data['status']);
    }

    public function changeTextRmpmsk($data)
    {

        $data['rs_rmpp_altktp1'] = substr($data['rs_rmpp_altktp'], 0, 30) . "...";
        if ($data['rs_rmpp_altn'] != "") {
            $data['rs_rmpp_altn'] = ", No. " . $data['rs_rmpp_altn'];
        }
        if ($data['rs_rmpp_altr'] != "") {
            $data['rs_rmpp_altr'] = ", RT/RW. " . $data['rs_rmpp_altr'];
        } else {
            $data['rs_rmpp_altr'] = ", RT/RW. -";
        }
        if ($data['rs_rmpp_altkk'] != "") {
            $data['rs_rmpp_altkk'] = ", Kelurahan/Kecamatan: " . $data['rs_rmpp_altkk'];
        } else {
            $data['rs_rmpp_altkk'] = ", Kelurahan/Kecamatan: - ";
        }

        if ($data['rs_rmpp_altkp'] != "") {
            $data['rs_rmpp_altkp'] = ", Kota/Kode Pos: " . $data['rs_rmpp_altkp'];
        } else {
            $data['rs_rmpp_altkp'] = ", Kota/Kode Pos: - ";
        }

        if ($data['rs_rmpp_altth'] != "") {
            $data['rs_rmpp_altth'] = ", Telepon/HP: " . $data['rs_rmpp_altth'];
        } else {
            $data['rs_rmpp_altth'] = ", Telepon/HP: - ";
        }

        if ($data['rs_rmpp_altktp'] != "") {
            $data['rs_rmpp_altktp'] = $data['rs_rmpp_altktp'] . $data['rs_rmpp_altn'] . $data['rs_rmpp_altr'] . $data['rs_rmpp_altkk'] . $data['rs_rmpp_altkp'] . $data['rs_rmpp_altth'];
        }


        return $data;
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmpp_id_ex';
        $id = 'rs_rmpp_id';
        $length = 3;
        $typeGet = 'result';

        $fillUpdate = 'rs_rmpp_id_ex, rs_rmpp_nm, rs_rmpp_ind, rs_rmpp_rmi, rs_rmpp_tgl_lhr, rs_rmpp_tmpt_lhr, rs_rmpp_rm, rs_rmpp_jk, rs_rmpp_rmag, rs_rmpp_rmgd, rs_rmpp_altktp, rs_rmpp_altn, rs_rmpp_altr, rs_rmpp_altkk, rs_rmpp_altkp, rs_rmpp_altth, rs_rmpp_sb, rs_rmpp_bhs, rs_rmi_nm, rs_rmag_nm, rs_rmgd_nm, rs_rmpp_cd';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [],
                //order by
                [
                    0 => ['id' => 'rs_rmpp_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmi', 'string' => 'rs_rmi.rs_rmi_id_ex = rs_rmpp.rs_rmpp_rmi', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'getAllSrc') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [],
                //order by
                [
                    0 => ['id' => 'rs_rmpp_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmi', 'string' => 'rs_rmi.rs_rmi_id_ex = rs_rmpp.rs_rmpp_rmi', 'type' => 'LEFT'],
                ],
                //like
                [
                    0 => ['idEx' => $data[0], 'idExV' => $data[1]],
                ]
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpp_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmi', 'string' => 'rs_rmi.rs_rmi_id_ex = rs_rmpp.rs_rmpp_rmi', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_rmag', 'string' => 'rs_rmag.rs_rmag_id_ex = rs_rmpp.rs_rmpp_rmag', 'type' => 'LEFT'],
                    2 => ['tableName' => 'rs_rmgd', 'string' => 'rs_rmgd.rs_rmgd_id_ex = rs_rmpp.rs_rmpp_rmgd', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        } elseif ($request == 'getCode') {
            return $this->MdlU->getIdEx('rs_rmpres_kd', $data, $id, 4);
        }
    }
}
