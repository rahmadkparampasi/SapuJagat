<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\UmMdl;

class Rmst extends BaseController
{
    use ResponseTrait;
    protected $MdlU;
    protected $AI;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_rmst', 'rs_rmst_id_ex');
        $this->AI = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeng',
            'pAct' => 'pAPeng',
            'cAct' => 'cArmref',
            'cmAct' => 'cmArmref',
            'scAct' => 'scArmst',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA SATUAN';
        $this->data['PageTitle'] = 'Data Satuan';
        $this->data['BasePage'] = 'rmst';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData';
        $this->data['IdForm'] = 'rmstAddData';
        $this->data['UrlForm'] = 'rmst';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);


        $this->data['Rmst'] = $this->setDB();

        echo view('Rmst/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }

    public function editData($rs_rmst_id_ex = '')
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA SATUAN';
        $this->data['PageTitle'] = 'Data Satuan';
        $this->data['BasePage'] = 'rmst';
        $this->data['ButtonMethod'] = 'UBAH';
        $this->data['MethodForm'] = 'updateData/' . $rs_rmst_id_ex;
        $this->data['IdForm'] = 'rmstAddData';
        $this->data['UrlForm'] = 'rmst';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);

        $this->data['Rmst'] = $this->setDB();

        if ($rs_rmst_id_ex === null || $rs_rmst_id_ex == '') {
            return redirect()->to('/' . $this->data['BasePage']);
        } else {
            $this->data['fillUpdate'] = $this->setDB('fillUpdate', $rs_rmst_id_ex);

            echo view('Rmst/index', $this->data);
            echo view('Templates/anotherScript');
            echo view('Templates/ajaxInsert', $this->data);
            echo view('Templates/loadData');
        }
    }

    public function getAll()
    {
        return $this->setDB('getAllByAct');
    }

    public function insertData()
    {

        $rs_rmst_id_ex = $this->setDB('idEx', $this->AI->getRandStr(3));
        $rs_rmst_s = $this->request->getPost('rs_rmst_s');
        $rs_rmst_nm = $this->request->getPost('rs_rmst_nm');

        $data = [
            'rs_rmst_id_ex' => $rs_rmst_id_ex,
            'rs_rmst_s' => $rs_rmst_s,
            'rs_rmst_nm' => $rs_rmst_nm
        ];

        $insertData = $this->MdlU->insertData($data);
        if ($insertData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Jenis Satuan Berhasil Disimpan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Jenis Satuan Tidak Dapat Disimpan'];
        }

        return $this->respond($data, $data['status']);
    }


    public function updateData($rs_rmst_id_ex = '')
    {
        $rs_rmst_s = $this->request->getPost('rs_rmst_s');
        $rs_rmst_nm = $this->request->getPost('rs_rmst_nm');
        $rs_rmst_id_ex = $this->request->getPost('rs_rmst_id_ex');
        $data = [
            'rs_rmst_s' => $rs_rmst_s,
            'rs_rmst_nm' => $rs_rmst_nm,
        ];
        $updateData = $this->MdlU->updateData($data, $rs_rmst_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Jenis Satuan Berhasil Diubah'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Jenis Satuan Tidak Dapat Diubah'];
        }
        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmst_id_ex = '')
    {
        if ($rs_rmst_id_ex === null || $rs_rmst_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlU->deleteData($rs_rmst_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Jenis Satuan Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Jenis Satuan Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function block($rs_rmst_id_ex = '')
    {
        $data = [
            'rs_rmst_sts' => "0",
        ];
        $updateData = $this->MdlU->updateData($data, $rs_rmst_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Status Jenis Satuan Berhasil Di Dinonaktifkan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Status Jenis Satuan Tidak Dapat Di Dinonaktifkan'];
        }
        return $this->respond($data, $data['status']);
    }

    public function unblock($rs_rmst_id_ex = '')
    {
        $data = [
            'rs_rmst_sts' => "1",
        ];
        $updateData = $this->MdlU->updateData($data, $rs_rmst_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Status Jenis Satuan Berhasil Aktifkan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Status Jenis Satuan Tidak Dapat Aktifkan'];
        }
        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmst_id_ex';
        $id = 'rs_rmst_id';
        $length = 2;
        $typeGet = 'result';

        $fillUpdate = 'rs_rmst_id_ex, rs_rmst_s, rs_rmst_nm';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [],
                //order by
                [
                    0 => ['id' => 'rs_rmst_id', 'orderType' => 'DESC'],
                ],
                //join
                []
            );
        } elseif ($request == 'getAllByAct') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => ['idEx' => 'rs_rmst_sts', 'idExV' => '1']
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmst_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmst_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}