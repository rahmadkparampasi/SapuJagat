<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\UmMdl;

class Rmppk extends BaseController
{
    use ResponseTrait;
    protected $MdlU;
    protected $Rmjf;
    protected $Rmkf;
    protected $Rmtf;
    protected $Rmcf;
    protected $Rmw;
    protected $AI;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_rmppk', 'rs_rmppk_id_ex');
        $this->Rmjf = new Rmjf;
        $this->Rmkf = new Rmkf;
        $this->Rmtf = new Rmtf;
        $this->Rmcf = new Rmcf;
        $this->Rmw = new Rmw;
        $this->AI = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeng',
            'pAct' => 'pAPeng',
            'cAct' => 'cArmppk',
            'cmAct' => '',
            'scAct' => '',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA PEMBERI PELAYANAN KESEHATAN';
        $this->data['PageTitle'] = 'Data Pemberi Pelayanan Kesehatan';
        $this->data['BasePage'] = 'rmppk';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData';
        $this->data['IdForm'] = 'rmppkAddData';
        $this->data['UrlForm'] = 'rmppk';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);


        $this->data['Rmppk'] = $this->setDB();
        $this->data['Rmjf'] = $this->Rmjf->getAll();
        $this->data['Rmkf'] = $this->Rmkf->getAll();
        $this->data['Rmtf'] = $this->Rmtf->getAll();
        $this->data['Rmcf'] = $this->Rmcf->getAll();
        $this->data['Rmw'] = $this->Rmw->getAll();

        echo view('Rmppk/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }

    public function editData($rs_rmppk_id_ex = '')
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA PEMBERI PELAYANAN KESEHATAN';
        $this->data['PageTitle'] = 'Data Pemberi Pelayanan Kesehatan';
        $this->data['BasePage'] = 'rmppk';
        $this->data['ButtonMethod'] = 'UBAH';
        $this->data['MethodForm'] = 'updateData/' . $rs_rmppk_id_ex;
        $this->data['IdForm'] = 'rmppkAddData';
        $this->data['UrlForm'] = 'rmppk';
        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);

        $this->data['Rmppk'] = $this->setDB();
        $this->data['Rmjf'] = $this->Rmjf->getAll();
        $this->data['Rmkf'] = $this->Rmkf->getAll();
        $this->data['Rmtf'] = $this->Rmtf->getAll();
        $this->data['Rmcf'] = $this->Rmcf->getAll();
        $this->data['Rmw'] = $this->Rmw->getAll();

        if ($rs_rmppk_id_ex === null || $rs_rmppk_id_ex == '') {
            return redirect()->to('/' . $this->data['BasePage']);
        } else {
            $this->data['fillUpdate'] = $this->setDB('fillUpdate', $rs_rmppk_id_ex);

            echo view('Rmppk/index', $this->data);
            echo view('Templates/anotherScript');
            echo view('Templates/ajaxInsert', $this->data);
            echo view('Templates/loadData');
        }
    }

    public function getAll()
    {
        return $this->setDB('getAllByAct');
    }
    public function getAllForSelect()
    {
        header("Content-Type:application/json;charset=utf-8");
        header("Access-Control-Allow-Origin: *");


        $data = $this->setDB('getAllByAct');
        for ($i = 0; $i < count($data); $i++) {
            $data[$i]['optText'] = $data[$i]['rs_rmppk_nm'];
            $data[$i]['optValue'] = $data[$i]['rs_rmppk_id_ex'];
        }
        return $this->respond($data, 200);
    }

    public function insertData()
    {

        $rs_rmppk_id_ex = $this->setDB('idEx', $this->AI->getRandStr(5));
        $rs_rmppk_nm = $this->request->getPost('rs_rmppk_nm');
        $rs_rmppk_kf = $this->request->getPost('rs_rmppk_kf');
        $rs_rmppk_bpjs = $this->request->getPost('rs_rmppk_bpjs');
        $rs_rmppk_rmjf = $this->request->getPost('rs_rmppk_rmjf');
        $rs_rmppk_rmkf = $this->request->getPost('rs_rmppk_rmkf');
        $rs_rmppk_rmtf = $this->request->getPost('rs_rmppk_rmtf');
        $rs_rmppk_rmcf = $this->request->getPost('rs_rmppk_rmcf');
        $rs_rmppk_rmw = $this->request->getPost('rs_rmppk_rmw');
        $rs_rmppk_alt = $this->request->getPost('rs_rmppk_alt');
        $rs_rmppk_rt = $this->request->getPost('rs_rmppk_rt');
        $rs_rmppk_rw = $this->request->getPost('rs_rmppk_rw');
        $rs_rmppk_pos = $this->request->getPost('rs_rmppk_pos');
        $rs_rmppk_telp = $this->request->getPost('rs_rmppk_telp');
        $rs_rmppk_fax = $this->request->getPost('rs_rmppk_fax');

        $data = [
            'rs_rmppk_id_ex' => $rs_rmppk_id_ex,
            'rs_rmppk_nm' => $rs_rmppk_nm,
            'rs_rmppk_kf' => $rs_rmppk_kf,
            'rs_rmppk_bpjs' => $rs_rmppk_bpjs,
            'rs_rmppk_rmjf' => $rs_rmppk_rmjf,
            'rs_rmppk_rmkf' => $rs_rmppk_rmkf,
            'rs_rmppk_rmtf' => $rs_rmppk_rmtf,
            'rs_rmppk_rmcf' => $rs_rmppk_rmcf,
            'rs_rmppk_rmw' => $rs_rmppk_rmw,
            'rs_rmppk_alt' => $rs_rmppk_alt,
            'rs_rmppk_rt' => $rs_rmppk_rt,
            'rs_rmppk_rw' => $rs_rmppk_rw,
            'rs_rmppk_pos' => $rs_rmppk_pos,
            'rs_rmppk_telp' => $rs_rmppk_telp,
            'rs_rmppk_fax' => $rs_rmppk_fax,
        ];

        $insertData = $this->MdlU->insertData($data);
        if ($insertData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Pemberi Pelayanan Kesehatan Berhasil Disimpan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Pemberi Pelayanan Kesehatan Tidak Dapat Disimpan'];
        }

        return $this->respond($data, $data['status']);
    }


    public function updateData($rs_rmppk_id_ex = '')
    {
        $rs_rmppk_nm = $this->request->getPost('rs_rmppk_nm');
        $rs_rmppk_id_ex = $this->request->getPost('rs_rmppk_id_ex');
        $rs_rmppk_kf = $this->request->getPost('rs_rmppk_kf');
        $rs_rmppk_bpjs = $this->request->getPost('rs_rmppk_bpjs');
        $rs_rmppk_rmjf = $this->request->getPost('rs_rmppk_rmjf');
        $rs_rmppk_rmkf = $this->request->getPost('rs_rmppk_rmkf');
        $rs_rmppk_rmtf = $this->request->getPost('rs_rmppk_rmtf');
        $rs_rmppk_rmcf = $this->request->getPost('rs_rmppk_rmcf');
        $rs_rmppk_rmw = $this->request->getPost('rs_rmppk_rmw');
        $rs_rmppk_alt = $this->request->getPost('rs_rmppk_alt');
        $rs_rmppk_rt = $this->request->getPost('rs_rmppk_rt');
        $rs_rmppk_rw = $this->request->getPost('rs_rmppk_rw');
        $rs_rmppk_pos = $this->request->getPost('rs_rmppk_pos');
        $rs_rmppk_telp = $this->request->getPost('rs_rmppk_telp');
        $rs_rmppk_fax = $this->request->getPost('rs_rmppk_fax');
        $data = [
            'rs_rmppk_nm' => $rs_rmppk_nm,
            'rs_rmppk_kf' => $rs_rmppk_kf,
            'rs_rmppk_bpjs' => $rs_rmppk_bpjs,
            'rs_rmppk_rmjf' => $rs_rmppk_rmjf,
            'rs_rmppk_rmkf' => $rs_rmppk_rmkf,
            'rs_rmppk_rmtf' => $rs_rmppk_rmtf,
            'rs_rmppk_rmcf' => $rs_rmppk_rmcf,
            'rs_rmppk_rmw' => $rs_rmppk_rmw,
            'rs_rmppk_alt' => $rs_rmppk_alt,
            'rs_rmppk_rt' => $rs_rmppk_rt,
            'rs_rmppk_rw' => $rs_rmppk_rw,
            'rs_rmppk_pos' => $rs_rmppk_pos,
            'rs_rmppk_telp' => $rs_rmppk_telp,
            'rs_rmppk_fax' => $rs_rmppk_fax,
        ];
        $updateData = $this->MdlU->updateData($data, $rs_rmppk_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Pemberi Pelayanan Kesehatan Berhasil Diubah'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Pemberi Pelayanan Kesehatan Tidak Dapat Diubah'];
        }
        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmppk_id_ex = '')
    {
        if ($rs_rmppk_id_ex === null || $rs_rmppk_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlU->deleteData($rs_rmppk_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Pemberi Pelayanan Kesehatan Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Pemberi Pelayanan Kesehatan Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function block($rs_rmppk_id_ex = '')
    {
        $data = [
            'rs_rmppk_sts' => "0",
        ];
        $updateData = $this->MdlU->updateData($data, $rs_rmppk_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Status Pemberi Pelayanan Kesehatan Berhasil Di Dinonaktifkan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Status Pemberi Pelayanan Kesehatan Tidak Dapat Di Dinonaktifkan'];
        }
        return $this->respond($data, $data['status']);
    }

    public function unblock($rs_rmppk_id_ex = '')
    {
        $data = [
            'rs_rmppk_sts' => "1",
        ];
        $updateData = $this->MdlU->updateData($data, $rs_rmppk_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Status Pemberi Pelayanan Kesehatan Berhasil Aktifkan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Status Pemberi Pelayanan Kesehatan Tidak Dapat Aktifkan'];
        }
        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmppk_id_ex';
        $id = 'rs_rmppk_id';
        $length = 2;
        $typeGet = 'result';

        $fillUpdate = 'rs_rmppk_id_ex, rs_rmppk_nm, rs_rmppk_kf, rs_rmppk_bpjs, rs_rmppk_rmjf, rs_rmppk_rmkf, rs_rmppk_rmtf, rs_rmppk_rmcf, rs_rmppk_rmw, rs_rmppk_alt, rs_rmppk_rt, rs_rmppk_rw, rs_rmppk_pos, rs_rmppk_telp, rs_rmppk_fax';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [],
                //order by
                [
                    0 => ['id' => 'rs_rmppk_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmjf', 'string' => 'rs_rmjf.rs_rmjf_id_ex = rs_rmppk.rs_rmppk_rmjf', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_rmkf', 'string' => 'rs_rmkf.rs_rmkf_id_ex = rs_rmppk.rs_rmppk_rmkf', 'type' => 'LEFT'],
                    2 => ['tableName' => 'rs_rmtf', 'string' => 'rs_rmtf.rs_rmtf_id_ex = rs_rmppk.rs_rmppk_rmtf', 'type' => 'LEFT'],
                    3 => ['tableName' => 'rs_rmcf', 'string' => 'rs_rmcf.rs_rmcf_id_ex = rs_rmppk.rs_rmppk_rmcf', 'type' => 'LEFT'],
                    4 => ['tableName' => 'rs_rmw', 'string' => 'rs_rmw.rs_rmw_id_ex = rs_rmppk.rs_rmppk_rmw', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'getAllByAct') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => ['idEx' => 'rs_rmppk_sts', 'idExV' => '1']
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmppk_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmppk_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}