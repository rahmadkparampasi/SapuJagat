<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\UmMdl;

class Rmja extends BaseController
{
    use ResponseTrait;
    protected $MdlU;
    protected $AI;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_rmja', 'rs_rmja_id_ex');
        $this->AI = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeng',
            'pAct' => 'pAPeng',
            'cAct' => 'cArmref',
            'cmAct' => 'cmArmref',
            'scAct' => 'scArmja',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA JENIS ANTRIAN';
        $this->data['PageTitle'] = 'Data Jenis Antrian';
        $this->data['BasePage'] = 'rmja';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData';
        $this->data['IdForm'] = 'rmjaAddData';
        $this->data['UrlForm'] = 'rmja';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);


        $this->data['Rmja'] = $this->setDB();

        echo view('Rmja/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }

    public function getAll()
    {
        return $this->setDB('getAllByAct');
    }

    public function insertData()
    {
        $validated = $this->validate([
            'rs_rmja_v' => 'uploaded[rs_rmja_v]|mime_in[rs_rmja_v,audio/mpeg,audio/mpg,audio/mpeg3,audio/mp3]|max_size[rs_rmja_v,2048]'
        ]);
        if ($validated == FALSE) {
            // Kembali ke function index supaya membawa data uploads dan validasi
            $data = ['status' => 415, 'response' => "error", 'message' => 'Berkas Yang Diunggah Tidak Sesuai Spesifikasi'];
        } else {
            $rs_rmja_id_ex = $this->setDB('idEx', $this->AI->getRandStr(3));
            $rs_rmja_v = $this->request->getFile('rs_rmja_v');
            $rs_rmja_nm = $this->request->getPost('rs_rmja_nm');

            $new_rs_rmja_v = "Rmja-" . $rs_rmja_id_ex . "-"  . date("YmdHis") . "." . $rs_rmja_v->getClientExtension();
            $data = [
                'rs_rmja_id_ex' => $rs_rmja_id_ex,
                'rs_rmja_v' => $new_rs_rmja_v,
                'rs_rmja_nm' => $rs_rmja_nm
            ];

            $insertData = $this->MdlU->insertData($data);
            if ($insertData) {
                $rs_rmja_v->move('uploads', $new_rs_rmja_v);
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Jenis Antrian Berhasil Disimpan'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Jenis Antrian Tidak Dapat Disimpan'];
            }
        }


        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmja_id_ex = '')
    {
        if ($rs_rmja_id_ex === null || $rs_rmja_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlU->deleteData($rs_rmja_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Jenis Antrian Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Jenis Antrian Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function block($rs_rmja_id_ex = '')
    {
        $data = [
            'rs_rmja_sts' => "0",
        ];
        $updateData = $this->MdlU->updateData($data, $rs_rmja_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Status Jenis Antrian Berhasil Di Dinonaktifkan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Status Jenis Antrian Tidak Dapat Di Dinonaktifkan'];
        }
        return $this->respond($data, $data['status']);
    }

    public function unblock($rs_rmja_id_ex = '')
    {
        $data = [
            'rs_rmja_sts' => "1",
        ];
        $updateData = $this->MdlU->updateData($data, $rs_rmja_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Status Jenis Antrian Berhasil Aktifkan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Status Jenis Antrian Tidak Dapat Aktifkan'];
        }
        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmja_id_ex';
        $id = 'rs_rmja_id';
        $length = 2;
        $typeGet = 'result';

        $fillUpdate = 'rs_rmja_id_ex, rs_rmja_s, rs_rmja_nm, rs_rmja_v';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [],
                //order by
                [
                    0 => ['id' => 'rs_rmja_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'getAllByAct') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => ['idEx' => 'rs_rmja_sts', 'idExV' => '1']
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmja_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmja_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}
