<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\RmicdnMdl;

use DateTime;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Reader\Xls as Reader;

class Rmicdn extends BaseController
{
    use ResponseTrait;
    protected $MdlRmicdn;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlRmicdn = new RmicdnMdl();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeng',
            'pAct' => 'pAPeng',
            'cAct' => 'cArmicdn',
            'cmAct' => 'cmArmref',
            'scAct' => 'scArmk',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA ICD - 9';
        $this->data['PageTitle'] = 'Data ICD - 9';
        $this->data['BasePage'] = 'rmicdn';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData';
        $this->data['IdForm'] = 'rmicdnAddData';
        $this->data['UrlForm'] = 'rmicdn';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);


        $this->data['Rmicdn'] = $this->MdlRmicdn->getAll();
        echo view('Rmicdn/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }

    public function insertData()
    {
        date_default_timezone_set("Asia/Makassar");

        $ExcelReader = new Reader();
        $file = $this->request->getFile('excelFile');
        $fileLocation = $file->getTempName();
        $objPhpExcel = $ExcelReader->load($fileLocation);
        $sheet = $objPhpExcel->getActiveSheet()->toArray(null, true, true, true);

        $success = 0;
        $error = 0;
        $count = count($sheet) + 1;
        for ($i = 1; $i < $count; $i++) {
            $rs_rmicdn_kd = $sheet[$i]['A'];
            $rs_rmicdn_nm = ucwords(strtolower($sheet[$i]['B']));
            $rs_rmicdn_ur = ucwords(strtolower($sheet[$i]['C']));

            $rs_rmicdn_id_ex  = $this->MdlRmicdn->getIdEx($this->Another_Include->getRandStr(3));

            $data = [
                'rs_rmicdn_id_ex ' => $rs_rmicdn_id_ex,
                'rs_rmicdn_kd' => $rs_rmicdn_kd,
                'rs_rmicdn_nm' => $rs_rmicdn_nm,
                'rs_rmicdn_ur' => $rs_rmicdn_ur,
            ];
            $insertData = $this->MdlRmicdn->insertData($data);
            if ($insertData) {
                $success += 1;
            } else {
                $error += 1;
            }
        }
        $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Berhasil Diproses, Dengan Data Yang Berhasil Berjumlah ' . (string)$success . ' Data, Dan Yang Tidak Berhasil Berjumlah ' . (string)$error . ' Data'];
        return $this->respond($data, $data['status']);
    }
    public function getRmicdnByJson($name = '', $idEx = '')
    {
        header('Content-Type: application/json');
        header("Access-Control-Allow-Origin: *");

        if ($name == "" || $idEx == "") {
            $this->data['data']['data'] = [];
        } else {
            $this->data['data']['data'] = $this->MdlRmicdn->getAll();
            $no = 0;
            for ($i = 0; $i < count($this->data['data']['data']); $i++) {
                $no++;
                $this->data['data']['data'][$i]['no'] = $no;
                $this->data['data']['data'][$i]['button'] = "<button class='btn bg-gradient-success' title='Tambahkan ICD 9 Ke Diagnosa Pasien' onclick='addFill(\"" . $name . "\", \"" . $this->data['data']['data'][$i]['rs_rmicdn_kd'] . "-" . $this->data['data']['data'][$i]['rs_rmicdn_nm'] . "\"); addFill(\"" . $idEx . "\", \"" . $this->data['data']['data'][$i]['rs_rmicdn_id_ex'] . "\"); destroyIcdn(); closeModal(\"modalViewRmIcdn\")'><i class='fas fa-check'></i></button>";
            }
        }

        return $this->respond($this->data['data'], 200);
    }

    public function updateData($rs_psp_id_ex = '')
    {
        $rs_psp_nm = $this->request->getPost('rs_psp_nm');
        $rs_psp_id_ex = $this->request->getPost('rs_psp_id_ex');
        $data = [
            'rs_psp_nm' => $rs_psp_nm,
        ];
        $updateData = $this->MdlPsp->updateData($data, $rs_psp_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Status Pegawai Berhasil Diubah'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Status Pegawai Tidak Dapat Diubah'];
        }
        return $this->respond($data, $data['status']);
    }



    public function deleteData($rs_psp_id_ex = '')
    {
        if ($rs_psp_id_ex === null || $rs_psp_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlPsp->deleteData($rs_psp_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Status Pegawai Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Status Pegawai Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }
}
