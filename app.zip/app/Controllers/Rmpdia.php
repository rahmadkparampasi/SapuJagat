<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\RmpdiaMdl;
use App\Models\RmphMdl;
use App\Models\RmpmskMdl;

class Rmpdia extends BaseController
{
    use ResponseTrait;
    protected $MdlRmpmsk;
    protected $MdlRmdia;
    protected $MdlRmph;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlRmpmsk = new RmpmskMdl();
        $this->MdlRmdia = new RmpdiaMdl();
        $this->MdlRmph = new RmphMdl();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOIgd',
            'pAct' => 'pAIgd',
            'cAct' => 'cArmpmsk',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {

        return redirect()->to('./rmpmsk');
    }

    public function insertData($rs_rmpdia_rmpmsk)
    {
        $this->data['Rmpmsk'] = $this->MdlRmpmsk->getAllRmpmsk($rs_rmpdia_rmpmsk);

        $rs_rmph_id_ex = $this->Another_Include->getRandStr(35);
        $rs_rmph_rmpp = $this->data['Rmpmsk']['rs_rmpmsk_rmpp'];
        $rs_rmph_ppeg = $this->data['rs_ppeg_id_ex'];
        $rs_rmph_jns = "CT";

        $rs_rmpdia_id_ex = $this->MdlRmdia->getIdEx($this->Another_Include->getRandStr(25));
        $rs_rmpdia_rmicdt = $this->request->getPost('rs_rmpdia_rmicdt');
        $rs_rmpdia_pri = $this->request->getPost('rs_rmpdia_pri');
        $rs_rmpdia_dia = $this->request->getPost('rs_rmpdia_dia');

        $dataRmpdia = [
            'rs_rmpdia_id_ex' => $rs_rmpdia_id_ex,
            'rs_rmptdk_rmpmsk' => $rs_rmpdia_rmpmsk,
            'rs_rmpdia_rmph' => $rs_rmph_id_ex,
            'rs_rmpdia_rmicdt' => $rs_rmpdia_rmicdt,
            'rs_rmpdia_pri' => $rs_rmpdia_pri,
            'rs_rmpdia_dia' => $rs_rmpdia_dia
        ];

        $dataRmph = [
            'rs_rmph_id_ex' => $rs_rmph_id_ex,
            'rs_rmph_rmpp' => $rs_rmph_rmpp,
            'rs_rmph_ppeg' => $rs_rmph_ppeg,
            'rs_rmph_jns' => $rs_rmph_jns
        ];

        $insertDataRmph = $this->MdlRmph->insertData($dataRmph);
        if ($insertDataRmph) {
            $insertDataRmpDia = $this->MdlRmdia->insertData($dataRmpdia);
            if ($insertDataRmpDia) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Diagnosa (ICD 10) Pasien Berhasil Disimpan'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Diagnosa (ICD 10) Pasien Tidak Dapat Disimpan'];
            }
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Histori Pasien Tidak Dapat Disimpan'];
        }



        return $this->respond($data, $data['status']);
    }

    public function updateData()
    {
        $rs_rmpjk_tgl = $this->request->getPost('rs_rmpjk_tgl');
        $rs_rmpjk_jam = $this->request->getPost('rs_rmpjk_jam');
        $rs_rmpjk_knt = $this->request->getPost('rs_rmpjk_knt');
        $rs_rmpjk_ket = $this->request->getPost('rs_rmpjk_ket');
        $rs_rmpjk_id_ex = $this->request->getPost('rs_rmpjk_id_ex');
        $data = [
            'rs_rmpjk_tgl' => $rs_rmpjk_tgl,
            'rs_rmpjk_jam' => $rs_rmpjk_jam,
            'rs_rmpjk_knt' => $rs_rmpjk_knt,
            'rs_rmpjk_ket' => $rs_rmpjk_ket,
        ];
        $updateData = $this->MdlRmpjk->updateData($data, $rs_rmpjk_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Diagnosa (ICD 10) Pasien Berhasil Diubah'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Diagnosa (ICD 10) Pasien Tidak Dapat Diubah'];
        }
        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmpjk_id_ex = '')
    {
        if ($rs_rmpjk_id_ex === null || $rs_rmpjk_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlRmprtd->deleteData($rs_rmpjk_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Diagnosa (ICD 10) Pasien Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Diagnosa (ICD 10) Pasien Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }
}
