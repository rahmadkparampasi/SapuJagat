<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\UmMdl;

class Lorend extends BaseController
{
    use ResponseTrait;
    protected $MdlU;
    protected $Loren;
    protected $AI;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_lorend', 'rs_lorend_id_ex');
        $this->AI = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOLo',
            'pAct' => 'pALo',
            'cAct' => 'cAloren',
            'cmAct' => '',
            'scAct' => '',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function viewData($rs_lorend_loren = '')
    {
        $this->Loren = new Loren();

        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        if ($rs_lorend_loren === null || $rs_lorend_loren == "") {
            return redirect()->to('./loren');
        }
        $this->data['rs_lorend_loren'] = $rs_lorend_loren;
        $this->data['Loren'] = $this->Loren->setDB('fillUpdateD', $rs_lorend_loren);
        $this->data['Loren']['rs_loren_tgl'] = $this->AI->changeDateNF($this->data['Loren']['rs_loren_tgl']);
        $this->data['WebTitle'] = 'DATA RENCANA KEBUTUHAN BARANG, KODE : '.strtoupper($this->data['Loren']['rs_loren_kd'].", Tanggal : ".$this->data['Loren']['rs_loren_tgl']);
        $this->data['PageTitle'] = 'Data Rencana Kebutuhan Barang, Kode : '.$this->data['Loren']['rs_loren_kd'].", Tanggal : ".$this->data['Loren']['rs_loren_tgl'];
        $this->data['BasePage'] = 'lorend';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData';
        $this->data['IdForm'] = 'lorendAddData';
        $this->data['UrlForm'] = 'lorend/viewData/'.$rs_lorend_loren;

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);


        $this->data['Lorend'] = $this->setDB('getAll', $rs_lorend_loren);
        for ($i=0; $i < count($this->data['Lorend']); $i++) { 
            $this->data['Lorend'][$i]['ttlHrg'] = 0;
            $this->data['Lorend'][$i]['ttlHrg'] = $this->data['Lorend'][$i]['rs_lorend_j']*$this->data['Lorend'][$i]['rs_lorend_hrg'];

            $this->data['Lorend'][$i]['ttlHrg'] = $this->AI->rupiah($this->data['Lorend'][$i]['ttlHrg']);
            $this->data['Lorend'][$i]['rs_lorend_hrg_n'] = $this->AI->rupiah($this->data['Lorend'][$i]['rs_lorend_hrg']);
        }
        $this->data['ttl'] = $this->AI->rupiah($this->getCountByLoren($rs_lorend_loren));

        echo view('Lorend/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }

    public function viewDataSls($rs_lorend_loren = '')
    {
        $this->Loren = new Loren();

        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        if ($rs_lorend_loren === null || $rs_lorend_loren == "") {
            return redirect()->to('./loren');
        }
        $this->data['rs_lorend_loren'] = $rs_lorend_loren;
        $this->data['Loren'] = $this->Loren->setDB('fillUpdateD', $rs_lorend_loren);
        $this->data['Loren']['rs_loren_tgl'] = $this->AI->changeDateNF($this->data['Loren']['rs_loren_tgl']);
        $this->data['WebTitle'] = 'PENYELESAIAN DATA RENCANA KEBUTUHAN BARANG, KODE : '.strtoupper($this->data['Loren']['rs_loren_kd'].", Tanggal : ".$this->data['Loren']['rs_loren_tgl']);
        $this->data['PageTitle'] = 'Penyelesaian Data Rencana Kebutuhan Barang, Kode : '.$this->data['Loren']['rs_loren_kd'].", Tanggal : ".$this->data['Loren']['rs_loren_tgl'];
        $this->data['BasePage'] = 'lorend';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData';
        $this->data['IdForm'] = 'lorendAddData';
        $this->data['UrlForm'] = 'lorend/viewData/'.$rs_lorend_loren;

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);


        $this->data['Lorend'] = $this->setDB('getAll', $rs_lorend_loren);
        for ($i=0; $i < count($this->data['Lorend']); $i++) { 
            $this->data['Lorend'][$i]['ttlHrg'] = 0;
            $this->data['Lorend'][$i]['ttlHrg'] = $this->data['Lorend'][$i]['rs_lorend_j']*$this->data['Lorend'][$i]['rs_lorend_hrg'];

            $this->data['Lorend'][$i]['ttlHrg'] = $this->AI->rupiah($this->data['Lorend'][$i]['ttlHrg']);
            $this->data['Lorend'][$i]['rs_lorend_hrg_n'] = $this->AI->rupiah($this->data['Lorend'][$i]['rs_lorend_hrg']);
        }
        $this->data['ttl'] = $this->AI->rupiah($this->getCountByLoren($rs_lorend_loren));

        echo view('Lorend/indexSls', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }

    public function getAll($data)
    {
        return $this->setDB('getAll', $data);
    }

    public function getCountByLoren($rs_lorend_loren)
    {
        return $this->setDB('getCountByLoren', $rs_lorend_loren)['ttl'];
    }

    public function insertData()
    {

        $rs_lorend_id_ex = $this->setDB('idEx', $this->AI->getRandStr(7));
        $rs_lorend_loren = $this->request->getPost('rs_lorend_loren');
        $rs_lorend_rmb = $this->request->getPost('rs_lorend_rmb');
        $rs_lorend_j = $this->request->getPost('rs_lorend_j');
        $rs_lorend_hrg = $this->request->getPost('rs_lorend_hrg');

        $data = [
            'rs_lorend_id_ex' => $rs_lorend_id_ex,
            'rs_lorend_loren' => $rs_lorend_loren,
            'rs_lorend_rmb' => $rs_lorend_rmb,
            'rs_lorend_j' => $rs_lorend_j,
            'rs_lorend_hrg' => $rs_lorend_hrg,
        ];

        $insertData = $this->MdlU->insertData($data);
        if ($insertData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Rencana Kebutuhan Barang Detail Berhasil Disimpan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Rencana Kebutuhan Barang Detail Tidak Dapat Disimpan'];
        }

        return $this->respond($data, $data['status']);
    }    

    public function updateData()
    {
        $rs_lorend_id_ex = $this->request->getPost('rs_lorend_id_ex_n');
        $rs_lorend_j = $this->request->getPost('rs_lorend_j_n');
        $rs_lorend_hrg = $this->request->getPost('rs_lorend_hrg_n');
        $data = [
            'rs_lorend_j' => $rs_lorend_j,
            'rs_lorend_hrg' => $rs_lorend_hrg,
        ];
        $updateData = $this->MdlU->updateData($data, $rs_lorend_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Rencana Kebutuhan Barang Detail Berhasil Diubah'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Rencana Kebutuhan Barang Detail Tidak Dapat Diubah'];
        }
        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_lorend_id_ex = '')
    {
        if ($rs_lorend_id_ex === null || $rs_lorend_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlU->deleteData($rs_lorend_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Rencana Kebutuhan Barang Detail Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Rencana Kebutuhan Barang Detail Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_lorend_id_ex';
        $id = 'rs_lorend_id';
        $length = 2;
        $typeGet = 'result';

        $fillUpdate = '';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_lorend_loren',
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_lorend_id', 'orderType' => 'DESC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmb', 'string' => 'rs_rmb.rs_rmb_id_ex = rs_lorend.rs_lorend_rmb', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_rmgz', 'string' => 'rs_rmgz.rs_rmgz_id_ex = rs_rmb.rs_rmb_rmgz', 'type' => 'LEFT'],
                    2 => ['tableName' => 'rs_rmmrk', 'string' => 'rs_rmmrk.rs_rmmrk_id_ex = rs_rmb.rs_rmb_rmmrk', 'type' => 'LEFT'],
                    3 => ['tableName' => 'rs_rmjk', 'string' => 'rs_rmjk.rs_rmjk_id_ex = rs_rmb.rs_rmb_rmjk', 'type' => 'LEFT'],
                    4 => ['tableName' => 'rs_rmst', 'string' => 'rs_rmst.rs_rmst_id_ex = rs_rmb.rs_rmb_rmst', 'type' => 'LEFT'],
                    5 => ['tableName' => 'rs_rmpyd', 'string' => 'rs_rmpyd.rs_rmpyd_id_ex = rs_rmb.rs_rmb_rmpyd', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'getCountByLoren') {
            $typeGet = 'row';
            return $this->MdlU->getCostum(
                "SELECT SUM(rs_lorend.rs_lorend_hrg * rs_lorend.rs_lorend_j) AS ttl FROM rs_lorend WHERE rs_lorend_loren = ?", [$data], 'row'
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_lorend_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}