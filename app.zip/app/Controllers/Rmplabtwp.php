<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\UmMdl;

class Rmplabtwp extends BaseController
{
    use ResponseTrait;

    protected $MdlU;
    protected $Rmplabt;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_rmplabtwp', 'rs_rmplabtwp_id');
        $this->Rmplabt = new Rmplabt;
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOIgd',
            'pAct' => 'pAIgd',
            'cAct' => 'cArmpmsk',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {

        return redirect()->to('./rmpmsk');
    }

    public function getAll($rs_rmplabtwp_rmplabtw)
    {
        $this->data['Rmplabtwp'] = $this->setDB('getAll', $rs_rmplabtwp_rmplabtw);
        for ($i = 0; $i < count($this->data['Rmplabtwp']); $i++) {
            
            if ($this->data['Rmplabtwp'][$i]['rs_ppeg_nmd'] != "") {
                $this->data['Rmplabtwp'][$i]['rs_ppeg_nm'] = $this->data['Rmplabtwp'][$i]['rs_ppeg_nmd'] . ". " . $this->data['Rmplabtwp'][$i]['rs_ppeg_nm'];
            }

            if ($this->data['Rmplabtwp'][$i]['rs_ppeg_nmb'] != "") {
                $this->data['Rmplabtwp'][$i]['rs_ppeg_nm'] = $this->data['Rmplabtwp'][$i]['rs_ppeg_nm'] . ", " . $this->data['Rmplabtwp'][$i]['rs_ppeg_nmb'];
            }
        }
        return  $this->data['Rmplabtwp'];
    }
    

    public function insertData()
    {
        $rs_rmplabtwp_rmplabtw = $this->request->getPost('rs_rmplabtwp_rmplabtw');
        $rs_rmplp_ppeg = $this->request->getPost('rs_rmplp_ppeg');
        if ($rs_rmplp_ppeg == null || empty($rs_rmplp_ppeg)) {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Pilih Terlebih Dahulu Data Tenaga Medis'];
        } else {
            $success = 0;
            $error = 0;
            foreach ($this->request->getPost('rs_rmplp_ppeg') as $key) {
                $this->data['Rmplabtwp'] = $this->setDB('getAllByRmplabtwAndPpeg', [$rs_rmplabtwp_rmplabtw, $key]);
                if ($this->data['Rmplabtwp'] != null || count($this->data['Rmplabtwp']) > 0) {
                    $error = $error + 1;
                } else {
                    $data = [];

                    $data = [
                        'rs_rmplabtwp_rmplabtw' => $rs_rmplabtwp_rmplabtw,
                        'rs_rmplabtwp_ppeg' => $key,
                    ];
                    $insertData = $this->MdlU->insertData($data);
                    if ($insertData) {
                        $success = $success + 1;
                    } else {
                        $error = $error + 1;
                    }
                }
            }
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Tenaga Medis Dalam Tindakan Berhasil Diproses, Dengan Jumlah Data Yang Berhasil Disimpan Berjumlah ' . (string)$success . ' Data, Dan Yang Gagal Disimpan Berjumlah ' . (string)$error . ' Data'];
        }

        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmplabtwp_id = '')
    {
        if ($rs_rmplabtwp_id === null || $rs_rmplabtwp_id == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlU->deleteData($rs_rmplabtwp_id);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Tenaga Medis Dalam Tindakan Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Tenaga Medis Dalam Tindakan Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmplabtwp_id';
        $id = 'rs_rmplabtwp_id';
        $length = 3;
        $typeGet = 'result';

        $fillUpdate = '*';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmplabtwp_rmplabtw',
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmplabtwp_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_ppeg', 'string' => 'rs_ppeg.rs_ppeg_id_ex = rs_rmplabtwp.rs_rmplabtwp_ppeg', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'getAllByRmplabtwAndPpeg') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmplabtwp_rmplabtw',
                        'idExV' => $data[0]
                    ],
                    1 => [
                        'idEx' => 'rs_rmplabtwp_ppeg',
                        'idExV' => $data[1]
                    ]
                ],
                //order by
                [],
                //join
                []
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmplabt_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}