<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\UmMdl;

class Rmpresr extends BaseController
{
    use ResponseTrait;

    protected $MdlU;
    protected $Rmpresrb;
    protected $Rmap;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_rmpresr', 'rs_rmpresr_id_ex');
        $this->Rmpresrb = new Rmpresrb;
        $this->Rmap = new Rmap;
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOIgd',
            'pAct' => 'pAIgd',
            'cAct' => 'cArmpmsk',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {

        return redirect()->to('./rmpmsk');
    }

    public function viewData($rs_rmpresr_rmpres = '', $rs_rmpres_kd = '', $rs_rmpres_tgl = '', $rs_rmpres_jam = '', $rs_rmpres_rmr = '')
    {
        if ($rs_rmpresr_rmpres == '') {
            echo "<span class='badge badge-danger'>Tidak Ada Daftar Tindakan Dalam Ruangan</span>";
        } else {
            $this->data['rs_rmpresr_rmpres'] = $rs_rmpresr_rmpres;
            $this->data['rs_rmpres_kd'] = $rs_rmpres_kd;
            $this->data['rs_rmpres_tgl'] = $rs_rmpres_tgl;
            $this->data['rs_rmpres_jam'] = $rs_rmpres_jam;
            $this->data['rs_rmpres_rmr'] = $rs_rmpres_rmr;
            $this->data['WebTitle'] = 'DAFTAR ORDER OBAT RACIK, KODE ORDER : ' . strtoupper($rs_rmpres_kd . ', TANGGAL ORDER : ' . $rs_rmpres_tgl . ', JAM ORDER : ' . $rs_rmpres_jam);
            $this->data['PageTitle'] = 'Daftar Order Obat Racik, Kode Order : ' . $rs_rmpres_kd . ', Tanggal Order : ' . $rs_rmpres_tgl . ', Jam Order : ' . $rs_rmpres_jam;
            $this->data['BasePage'] = 'rmpresr';
            $this->data['ButtonMethod'] = 'SIMPAN';
            $this->data['MethodForm'] = 'insertView/' . $rs_rmpresr_rmpres;
            $this->data['IdForm'] = 'rmpresrAddData';
            $this->data['UrlForm'] = 'rmpresr';
            $this->data['Rmpresr'] = $this->setDB('getAll', $rs_rmpresr_rmpres);
            for ($i = 0; $i < count($this->data['Rmpresr']); $i++) {
                $this->data['Rmpresr'][$i]['Rmpresrb'] = $this->Rmpresrb->getAll($this->data['Rmpresr'][$i]['rs_rmpresr_id_ex']);
            }
            // dd($this->data['Rmpresr']);
            echo view('Rmpresr/index', $this->data);
            echo view('Templates/ajaxInsert', $this->data);
        }
    }

    public function getAll($rs_rmpresr_rmpres)
    {
        $this->data['Rmpresr'] = $this->setDB('getAll', $rs_rmpresr_rmpres);

        return  $this->data['Rmpresr'];
    }

    public function insertView($rs_rmpresr_rmpres)
    {
        $rs_rmpresr_id_ex = $this->setDB('idEx', $this->Another_Include->getRandStr(4));
        $rs_rmpresr_rmkr = $this->request->getPost('rs_rmpresr_rmkr');
        $rs_rmpresr_jmlh = $this->request->getPost('rs_rmpresr_jmlh');
        $rs_rmpresr_rmap = $this->request->getPost('rs_rmpresr_rmap');
        $rs_rmpresr_p = $this->request->getPost('rs_rmpresr_p');
        $rs_rmpresrb_rmb = $this->request->getPost('rs_rmpresrb_rmb');
        $rs_rmpresrb_jmlh = $this->request->getPost('rs_rmpresrb_jmlh');
        $data = [
            'rs_rmpresr_id_ex' => $rs_rmpresr_id_ex,
            'rs_rmpresr_rmkr' => $rs_rmpresr_rmkr,
            'rs_rmpresr_jmlh' => $rs_rmpresr_jmlh,
            'rs_rmpresr_rmpres' => $rs_rmpresr_rmpres,
            'rs_rmpresr_rmap' => $rs_rmpresr_rmap,
            'rs_rmpresr_p' => $rs_rmpresr_p
        ];

        $insertData = $this->MdlU->insertData($data);
        if ($insertData) {
            $insertDataRmpresrb = $this->Rmpresrb->insertData($rs_rmpresr_id_ex, $rs_rmpresrb_rmb, $rs_rmpresrb_jmlh);
            // if ($insertDataRmpresrb) {
            //     $data = ['status' => 200, 'response' => 'success', 'message' => 'Data E-Resep Racik Pasien Berhasil Disimpan'];
            // } else {
            //     $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Obat E-Resep Racik Pasien Tidak Dapat Disimpan'];
            // }

            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data E-Resep Racik Pasien Berhasil Disimpan, Dengan Data Obat Yang Berhasil Diproses Sejumlah ' . (string)$insertDataRmpresrb[0] . ' Data, Dan Data Obat Yang Gagal Diproses Sejumlah ' . (string)$insertDataRmpresrb[1] . ' Data'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data E-Resep Racik Pasien Tidak Dapat Disimpan'];
        }

        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmpresr_id = '')
    {
        if ($rs_rmpresr_id === null || $rs_rmpresr_id == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlU->deleteData($rs_rmpresr_id);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data E-Resep Racik Pasien Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data E-Resep Racik Pasien Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmpresr_id_ex';
        $id = 'rs_rmpresr_id';
        $length = 3;
        $typeGet = 'result';

        $fillUpdate = '*';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmpresr_rmpres',
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpresr_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmap', 'string' => 'rs_rmap.rs_rmap_id_ex = rs_rmpresr.rs_rmpresr_rmap', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_rmkr', 'string' => 'rs_rmkr.rs_rmkr_id_ex = rs_rmpresr.rs_rmpresr_rmkr', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpresr_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}