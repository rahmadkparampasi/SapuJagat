<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\RmkMdl;
use App\Models\RmrkMdl;
use App\Models\UmMdl;

class Rmk extends BaseController
{
    use ResponseTrait;
    protected $MdlU;
    protected $MdlRmk;
    protected $MdlRmrk;
    protected $AI;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_rmk', 'rs_rmk_id_ex');
        $this->MdlRmk = new RmkMdl();
        $this->MdlRmrk = new RmrkMdl();
        $this->AI = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeng',
            'pAct' => 'pAPeng',
            'cAct' => 'cArmref',
            'cmAct' => 'cmArmref',
            'scAct' => 'scArmk',


            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA KELAS';
        $this->data['PageTitle'] = 'Data Kelas';
        $this->data['BasePage'] = 'rmk';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData';
        $this->data['IdForm'] = 'rmkAddData';
        $this->data['UrlForm'] = 'rmk';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);
        $this->data['Rmk'] = $this->MdlRmk->getAll();

        echo view('Rmk/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }

    public function editData($rs_rmk_id_ex = '')
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA KELAS';
        $this->data['PageTitle'] = 'Data Kelas';
        $this->data['BasePage'] = 'rmk';
        $this->data['ButtonMethod'] = 'UBAH';
        $this->data['MethodForm'] = 'updateData/' . $rs_rmk_id_ex;
        $this->data['IdForm'] = 'rmkAddData';
        $this->data['UrlForm'] = 'rmk';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);

        $this->data['Rmk'] = $this->MdlRmk->getAll();
        for ($i = 0; $i < count($this->data['Rmk']); $i++) {
            if ($this->data['Rmk'][$i]['rs_rmk_sts'] == "1") {
                $this->data['Rmk'][$i]['rs_rmk_sts'] = $this->AI->cB('Aktif');
            } else {
                $this->data['Rmk'][$i]['rs_rmk_sts'] = $this->AI->cB('Tidak Aktif', 'danger');
            }
        }
        if ($rs_rmk_id_ex === null || $rs_rmk_id_ex == '') {
            return redirect()->to('/' . $this->data['BasePage']);
        } else {
            $this->data['fillUpdate'] = $this->MdlRmk->getAll($rs_rmk_id_ex);

            echo view('Rmk/index', $this->data);
            echo view('Templates/anotherScript');
            echo view('Templates/ajaxInsert', $this->data);
            echo view('Templates/loadData');
        }
    }

    public function getRmkByJson($rs_rmr_id_ex = '')
    {
        header('Content-Type: application/json');
        header("Access-Control-Allow-Origin: *");
        $this->data['data']['data'] = $this->MdlRmk->getAllAct();
        $no = 0;
        for ($i = 0; $i < count($this->data['data']['data']); $i++) {
            $no++;

            $this->data['data']['data'][$i]['button'] = "<button class='btn bg-gradient-success' title='Tambahkan Data Kelas Ke Dalam Ruangan' onclick='addWF(\"Menambahkan Kelas " . $this->data['data']['data'][$i]['rs_rmk_nm'] . " Dalam Data Ruangan\", \"/" . "rmrk/addRmkToRmrk/" . $rs_rmr_id_ex . "/" . $this->data['data']['data'][$i]['rs_rmk_id_ex'] . "\", loadTabKls)'><i class='fas fa-check'></i></button>";
            $this->data['data']['data'][$i]['no'] = $no;
        }
        return $this->respond($this->data['data'], 200);
    }

    public function insertData()
    {
        $rs_rmk_id_ex = $this->MdlRmk->getIdEx($this->AI->getRandStr(3));
        $rs_rmk_nm = $this->request->getPost('rs_rmk_nm');

        $data = [
            'rs_rmk_id_ex' => $rs_rmk_id_ex,
            'rs_rmk_nm' => $rs_rmk_nm
        ];

        $insertData = $this->MdlRmk->insertData($data);
        if ($insertData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Kelas Berhasil Disimpan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Kelas Tidak Dapat Disimpan'];
        }

        return $this->respond($data, $data['status']);
    }

    public function updateData($rs_rmk_id_ex = '')
    {
        $rs_rmk_nm = $this->request->getPost('rs_rmk_nm');
        $rs_rmk_id_ex = $this->request->getPost('rs_rmk_id_ex');

        $data = [
            'rs_rmk_nm' => $rs_rmk_nm,
        ];
        $updateData = $this->MdlRmk->updateData($data, $rs_rmk_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Kelas Berhasil Diubah'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Kelas Tidak Dapat Diubah'];
        }
        return $this->respond($data, $data['status']);
    }

    public function nonaktvRmk($rs_rmk_id_ex = '')
    {
        $data = [
            'rs_rmk_sts' => "0",
        ];
        $updateData = $this->MdlRmk->updateData($data, $rs_rmk_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Berhasil Menonaktifkan Kelas'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Tidak Dapat Menonaktifkan Kelas'];
        }
        return $this->respond($data, $data['status']);
    }

    public function aktvRmk($rs_rmk_id_ex = '')
    {
        $data = [
            'rs_rmk_sts' => "1",
        ];
        $updateData = $this->MdlRmk->updateData($data, $rs_rmk_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Berhasil Mengaktifkan Kelas'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Tidak Dapat Mengaktifkan Kelas'];
        }
        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmk_id_ex = '')
    {
        if ($rs_rmk_id_ex === null || $rs_rmk_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlRmk->deleteData($rs_rmk_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Kelas Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Kelas Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmk_id_ex';
        $id = 'rs_rmk_id';
        $length = 3;
        $typeGet = 'result';
        $fillUpdate = 'rs_rmk_id_ex';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [],
                //order by
                [
                    0 => ['id' => 'rs_rmk_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'getAllByRmtdk') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmttdk_rmtdk',
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmk_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmttdk', 'string' => 'rs_rmttdk.rs_rmttdk_rmk = rs_rmk.rs_rmk_id_ex', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_rmtdk', 'string' => 'rs_rmtdk.rs_rmtdk_id_ex = rs_rmttdk.rs_rmttdk_rmtdk', 'type' => 'LEFT'],
                ],
                //like
                []
            );
        } elseif ($request == 'getAllByRmtdkEmpty') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [],
                //order by
                [
                    0 => ['id' => 'rs_rmk_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmttdk', 'string' => 'rs_rmttdk.rs_rmttdk_rmk = rs_rmk.rs_rmk_id_ex', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_rmtdk', 'string' => 'rs_rmtdk.rs_rmtdk_id_ex = rs_rmttdk.rs_rmttdk_rmtdk', 'type' => 'LEFT'],
                ],
                //like
                [],
                //groupBy
                [
                    0 => ['id' => 'rs_rmk_id_ex'],
                ],
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmk_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}