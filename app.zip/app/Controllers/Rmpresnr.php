<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\UmMdl;

class Rmpresnr extends BaseController
{
    use ResponseTrait;

    protected $MdlU;
    protected $Rmap;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_rmpresnr', 'rs_rmpresnr_id');
        $this->Rmap = new Rmap;
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOIgd',
            'pAct' => 'pAIgd',
            'cAct' => 'cArmpmsk',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {

        return redirect()->to('./rmpmsk');
    }

    public function viewData($rs_rmpresnr_rmpres = '', $rs_rmpres_kd = '', $rs_rmpres_tgl = '', $rs_rmpres_jam = '', $rs_rmpres_rmr = '')
    {
        if ($rs_rmpresnr_rmpres == '') {
            echo "<span class='badge badge-danger'>Tidak Ada Daftar Tindakan Dalam Ruangan</span>";
        } else {
            $this->data['rs_rmpresnr_rmpres'] = $rs_rmpresnr_rmpres;
            $this->data['rs_rmpres_kd'] = $rs_rmpres_kd;
            $this->data['rs_rmpres_tgl'] = $rs_rmpres_tgl;
            $this->data['rs_rmpres_jam'] = $rs_rmpres_jam;
            $this->data['rs_rmpres_rmr'] = $rs_rmpres_rmr;
            $this->data['WebTitle'] = 'DAFTAR ORDER OBAT NON RACIK, KODE ORDER : ' . strtoupper($rs_rmpres_kd . ', TANGGAL ORDER : ' . $rs_rmpres_tgl . ', JAM ORDER : ' . $rs_rmpres_jam);
            $this->data['PageTitle'] = 'Daftar Order Obat Non Racik, Kode Order : ' . $rs_rmpres_kd . ', Tanggal Order : ' . $rs_rmpres_tgl . ', Jam Order : ' . $rs_rmpres_jam;
            $this->data['BasePage'] = 'rmpresnr';
            $this->data['ButtonMethod'] = 'SIMPAN';
            $this->data['MethodForm'] = 'insertView/' . $rs_rmpresnr_rmpres;
            $this->data['IdForm'] = 'rmpresnrAddData';
            $this->data['UrlForm'] = 'rmpresnr';
            $this->data['Rmpresnr'] = $this->setDB('getAll', $rs_rmpresnr_rmpres);
            $this->data['Rmap'] = $this->Rmap->getAll();
            echo view('Rmpresnr/index', $this->data);
            echo view('Templates/ajaxInsert', $this->data);
        }
    }

    public function getAll($rs_rmpresnr_rmpres)
    {
        $this->data['Rmpresnr'] = $this->setDB('getAll', $rs_rmpresnr_rmpres);

        return  $this->data['Rmpresnr'];
    }

    public function insertView($rs_rmpresnr_rmpres)
    {
        $rs_rmpresnr_rmb = $this->request->getPost('rs_rmpresnr_rmb');
        $rs_rmpresnr_jmlh = $this->request->getPost('rs_rmpresnr_jmlh');
        $rs_rmpresnr_rmap = $this->request->getPost('rs_rmpresnr_rmap');
        $rs_rmpresnr_ket = $this->request->getPost('rs_rmpresnr_ket');
        $data = [
            'rs_rmpresnr_rmb' => $rs_rmpresnr_rmb,
            'rs_rmpresnr_jmlh' => $rs_rmpresnr_jmlh,
            'rs_rmpresnr_rmpres' => $rs_rmpresnr_rmpres,
            'rs_rmpresnr_rmap' => $rs_rmpresnr_rmap,
            'rs_rmpresnr_ket' => $rs_rmpresnr_ket
        ];

        $insertData = $this->MdlU->insertData($data);
        if ($insertData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Obat E-Resep Non Racik Pasien Berhasil Disimpan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Obat E-Resep Non Racik Pasien Tidak Dapat Disimpan'];
        }

        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmpresnr_id = '')
    {
        if ($rs_rmpresnr_id === null || $rs_rmpresnr_id == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlU->deleteData($rs_rmpresnr_id);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Obat E-Resep Non Racik Pasien Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Obat E-Resep Non Racik Pasien Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmpresnr_id';
        $id = 'rs_rmpresnr_id';
        $length = 3;
        $typeGet = 'result';

        $fillUpdate = '*';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmpresnr_rmpres',
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpresnr_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmap', 'string' => 'rs_rmap.rs_rmap_id_ex = rs_rmpresnr.rs_rmpresnr_rmap', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_rmb', 'string' => 'rs_rmb.rs_rmb_id_ex = rs_rmpresnr.rs_rmpresnr_rmb', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'getAllByRmpradAndTdk') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmpresnr_rmpres',
                        'idExV' => $data[0]
                    ],
                    1 => [
                        'idEx' => 'rs_rmpresnr_rmb',
                        'idExV' => $data[1]
                    ]
                ],
                //order by
                [],
                //join
                []
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpresnr_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}