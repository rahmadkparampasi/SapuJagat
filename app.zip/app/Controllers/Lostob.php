<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\UmMdl;

class Lostob extends BaseController
{
    use ResponseTrait;
    protected $MdlU;
    protected $Lorend;
    protected $Loren;
    protected $Setrmr;
    protected $Rmrrmb;
    protected $AI;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_lostob', 'rs_lostob_id_ex');
        $this->Setrmr = new Setrmr();
        $this->Rmrrmb = new Rmrrmb();
        $this->AI = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data['setRmr'] = $this->Setrmr->getAll();
        $this->data = [
            'mOp' => 'mOLo',
            'pAct' => 'pALo',
            'cAct' => 'cAlostob',
            'cmAct' => '',
            'scAct' => '',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
            'setRmr' => [
                'setRmrApt' => $this->data['setRmr'][4]['rs_setrmr_rmr'],
            ]
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
        $this->Lorend = new Lorend();
        $this->Loren = new Loren();
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA STOK OBAT';
        $this->data['PageTitle'] = 'Data Stok Obat';
        $this->data['BasePage'] = 'lostob';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData';
        $this->data['IdForm'] = 'lostobAddData';
        $this->data['UrlForm'] = 'lostob';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);

        $this->data['Loren'] = $this->Loren->getAll();
        $this->data['Loren'] = $this->AI->changeDateWF($this->data['Loren'], ['rs_loren_tgl']);
        for ($i=0; $i < count($this->data['Loren']); $i++) { 
            $this->data['Loren'][$i]['ttlObat'] = 0;
            $this->data['Loren'][$i]['ttlObat'] = $this->setDB('geTtlObat', $this->data['Loren'][$i]['rs_loren_id_ex'])['ttlObat'];
            if ($this->data['Loren'][$i]['ttlObat']==0) {
                $this->data['Loren'][$i]['stsObat'] = $this->AI->cB('TELAH HABIS', 'danger');
            }else{
                $this->data['Loren'][$i]['stsObat'] = $this->AI->cB('MASIH ADA');
            }            
        }
        echo view('Lostob/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }

    public function viewDataD($rs_lostob_loren = '')
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        if ($rs_lostob_loren === null || $rs_lostob_loren == "") {
            return redirect()->to('./lostob');
        }

        $this->Lorend = new Lorend();
        $this->Loren = new Loren();
        $this->data['rs_lostob_loren'] = $rs_lostob_loren;
        $this->data['Loren'] = $this->Loren->setDB('fillUpdateD', $rs_lostob_loren);
        $this->data['Loren']['rs_loren_tgl'] = $this->AI->changeDateNF($this->data['Loren']['rs_loren_tgl']);

        $this->data['WebTitle'] = 'STOK OBAT Detail Kode : '.strtoupper($this->data['Loren']['rs_loren_kd']. ', Tanggal : '.$this->data['Loren']['rs_loren_tgl']);
        $this->data['PageTitle'] = 'Stok Obat Detail Kode : '.$this->data['Loren']['rs_loren_kd']. ', Tanggal : '.$this->data['Loren']['rs_loren_tgl'];
        $this->data['BasePage'] = 'lostob';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData';
        $this->data['IdForm'] = 'lostobAddData';
        $this->data['UrlForm'] = 'lostob/viewDataD/'.$rs_lostob_loren;
        $this->data['Lostob'] = $this->setDB('getAll', $rs_lostob_loren);     

        echo view('Lostob/indexD', $this->data);
        echo view('Templates/anotherScript');

    }

    public function sendObat()
    {
        $rs_lostob_id_ex = $this->request->getPost('rs_lostob_id_ex');
        $rs_rmrrmb_rmb = $this->request->getPost('rs_rmrrmb_rmb');
        $rs_rmrrmb_j = $this->request->getPost('rs_rmrrmb_j');
        $rs_rmrrmb_rmr = $this->request->getPost('rs_rmrrmb_rmr');
        $rs_lostob_j = $this->request->getPost('rs_lostob_j');
        // dd($rs_rmrrmb_j, $rs_lostob_j);
        if ((int)$rs_rmrrmb_j > (int)$rs_lostob_j) {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Jumlah Obat Yang Dipindahkan Lebih Besar Dari Yang Tersedia'];
        }else{
            $datalostob = ['rs_lostob_j' => (int)$rs_lostob_j-(int)$rs_rmrrmb_j];
            $updateDataLostOb = $this->MdlU->updateData($datalostob, $rs_lostob_id_ex);
            if ($updateDataLostOb) {
                $this->data['Rmrrmb'] = $this->Rmrrmb->getByRmrAndRmb($rs_rmrrmb_rmr, $rs_rmrrmb_rmb);
                if ($this->data['Rmrrmb']!=null) {
                    $dataRmrrmb = [
                        'rs_rmrrmb_j' => (int)$this->data['Rmrrmb']['rs_rmrrmb_j'] + $rs_rmrrmb_j,
                    ];
                    $updateDataRmrrmb = $this->Rmrrmb->updateData($dataRmrrmb, $this->data['Rmrrmb']['rs_rmrrmb_id']);
                    if ($updateDataRmrrmb) {
                        $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Obat Berhasil Dipindahkan'];
                    }else{
                        $datalostob = ['rs_lostob_j' => (int)$rs_lostob_j];
                        $updateDataLostOb = $this->TableGudangList->updateDataGudang($datalostob, $rs_lostob_id_ex);
                        $data = ['status' => 500, 'response' => 'error', 'message' => 'Terdapat Kesalahan Saat Memindahkan Data Produk'];
                    }
                }else{
                    $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Obat Ini Belum Terdaftar Diruangan'];
                }
            }else{
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Terdapat Kesalahan Saat Mengambil Data Gudang'];
            }
        }
        return $this->respond($data, $data['status']);

    }

    public function getAll()
    {
        return $this->setDB('getAllByAct');
    }

    public function insertData($data)
    {

        $rs_lostob_id_ex = $this->setDB('idEx', $this->AI->getRandStr(7));
        
        $data['rs_lostob_id_ex'] =  $rs_lostob_id_ex;

        return $this->MdlU->insertData($data);
        
    }

    public function deleteDataByLoren($rs_lostob_loren)
    {
        return $this->MdlU->deleteDataByV('rs_lostob_loren', $rs_lostob_loren);
        
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_lostob_id_ex';
        $id = 'rs_lostob_id';
        $length = 2;
        $typeGet = 'result';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_lostob_loren',
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_lostob_id', 'orderType' => 'DESC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmb', 'string' => 'rs_rmb.rs_rmb_id_ex = rs_lostob.rs_lostob_rmb', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_rmgz', 'string' => 'rs_rmgz.rs_rmgz_id_ex = rs_rmb.rs_rmb_rmgz', 'type' => 'LEFT'],
                    2 => ['tableName' => 'rs_rmmrk', 'string' => 'rs_rmmrk.rs_rmmrk_id_ex = rs_rmb.rs_rmb_rmmrk', 'type' => 'LEFT'],
                    3 => ['tableName' => 'rs_rmjk', 'string' => 'rs_rmjk.rs_rmjk_id_ex = rs_rmb.rs_rmb_rmjk', 'type' => 'LEFT'],
                    4 => ['tableName' => 'rs_rmst', 'string' => 'rs_rmst.rs_rmst_id_ex = rs_rmb.rs_rmb_rmst', 'type' => 'LEFT'],
                    5 => ['tableName' => 'rs_rmpyd', 'string' => 'rs_rmpyd.rs_rmpyd_id_ex = rs_rmb.rs_rmb_rmpyd', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'geTtlObat') {
            return $this->MdlU->getAll(
                //type result / row
                'row',
                // select *
                'SUM(rs_lostob_j) as ttlObat',
                //where
                [
                    0 => [
                        'idEx' => 'rs_lostob_loren',
                        'idExV' => $data
                    ]
                ],
                //order by
                [],
                //join
                []
            );
        }elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}