<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\RmphMdl;
use App\Models\RmpmskMdl;
use App\Models\UmMdl;

class Rmpjt extends BaseController
{
    use ResponseTrait;
    protected $MdlRmpmsk;
    protected $MdlU;
    protected $MdlRmph;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlRmpmsk = new RmpmskMdl();
        $this->MdlU = new UmMdl('rs_rmpjt', 'rs_rmpjt_id_ex');
        $this->MdlRmph = new RmphMdl();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOIgd',
            'pAct' => 'pAIgd',
            'cAct' => 'cArmpmsk',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {

        return redirect()->to('./rmpmsk');
    }

    public function getAll($rs_rmpjt_rmpmsk)
    {
        return $this->setDB('getAll', $rs_rmpjt_rmpmsk);
    }

    public function insertData($rs_rmpjt_rmpmsk)
    {
        $this->data['Rmpmsk'] = $this->MdlRmpmsk->getAllRmpmsk($rs_rmpjt_rmpmsk);

        $rs_rmph_id_ex = $this->Another_Include->getRandStr(35);
        $rs_rmph_rmpp = $this->data['Rmpmsk']['rs_rmpmsk_rmpp'];
        $rs_rmph_ppeg = $this->data['rs_ppeg_id_ex'];
        $rs_rmph_jns = "CT";

        $rs_rmpjt_id_ex = $this->setDB('idEx', $this->Another_Include->getRandStr(25));
        $rs_rmpjt_ppeg = $this->request->getPost('rs_rmpjt_ppeg');
        $rs_rmpjt_tgl = $this->request->getPost('rs_rmpjt_tgl');
        $rs_rmpjt_rmwk = $this->request->getPost('rs_rmpjt_rmwk');
        $rs_rmpjt_rmr = $this->request->getPost('rs_rmpjt_rmr');
        $rs_rmpjt_rmtdk = $this->request->getPost('rs_rmpjt_rmtdk');
        $rs_rmpjt_ket = $this->request->getPost('rs_rmpjt_ket');

        $dataRmpjt = [
            'rs_rmpjt_id_ex' => $rs_rmpjt_id_ex,
            'rs_rmpjt_rmpmsk' => $rs_rmpjt_rmpmsk,
            'rs_rmpjt_rmph' => $rs_rmph_id_ex,
            'rs_rmpjt_ppeg' => $rs_rmpjt_ppeg,
            'rs_rmpjt_tgl' => $rs_rmpjt_tgl,
            'rs_rmpjt_rmwk' => $rs_rmpjt_rmwk,
            'rs_rmpjt_rmr' => $rs_rmpjt_rmr,
            'rs_rmpjt_rmtdk' => $rs_rmpjt_rmtdk,
            'rs_rmpjt_ket' => $rs_rmpjt_ket,
        ];

        $dataRmph = [
            'rs_rmph_id_ex' => $rs_rmph_id_ex,
            'rs_rmph_rmpp' => $rs_rmph_rmpp,
            'rs_rmph_ppeg' => $rs_rmph_ppeg,
            'rs_rmph_jns' => $rs_rmph_jns
        ];

        $insertDataRmph = $this->MdlRmph->insertData($dataRmph);
        if ($insertDataRmph) {
            $insertDataRmpJt = $this->MdlU->insertData($dataRmpjt);
            if ($insertDataRmpJt) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Jadwal Tindakan Invasif Pasien Berhasil Disimpan'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Jadwal Tindakan Invasif Pasien Tidak Dapat Disimpan'];
            }
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Histori Pasien Tidak Dapat Disimpan'];
        }



        return $this->respond($data, $data['status']);
    }

    public function updateData()
    {
        $rs_rmpjk_tgl = $this->request->getPost('rs_rmpjk_tgl');
        $rs_rmpjk_jam = $this->request->getPost('rs_rmpjk_jam');
        $rs_rmpjk_knt = $this->request->getPost('rs_rmpjk_knt');
        $rs_rmpjk_ket = $this->request->getPost('rs_rmpjk_ket');
        $rs_rmpjk_id_ex = $this->request->getPost('rs_rmpjk_id_ex');
        $data = [
            'rs_rmpjk_tgl' => $rs_rmpjk_tgl,
            'rs_rmpjk_jam' => $rs_rmpjk_jam,
            'rs_rmpjk_knt' => $rs_rmpjk_knt,
            'rs_rmpjk_ket' => $rs_rmpjk_ket,
        ];
        $updateData = $this->MdlRmpjk->updateData($data, $rs_rmpjk_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Jadwal Tindakan Invasif Pasien Berhasil Diubah'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Jadwal Tindakan Invasif Pasien Tidak Dapat Diubah'];
        }
        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmpjk_id_ex = '')
    {
        if ($rs_rmpjk_id_ex === null || $rs_rmpjk_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlRmprtd->deleteData($rs_rmpjk_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Jadwal Tindakan Invasif Pasien Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Jadwal Tindakan Invasif Pasien Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmpjt_id_ex';
        $id = 'rs_rmpjt_id';
        $length = 5;
        $typeGet = 'result';

        $fillUpdate = '*';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmpjt_rmpmsk',
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpjt_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_ppeg', 'string' => 'rs_ppeg.rs_ppeg_id_ex = rs_rmpjt.rs_rmpjt_ppeg', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_rmwk', 'string' => 'rs_rmwk.rs_rmwk_id_ex = rs_rmpjt.rs_rmpjt_rmwk', 'type' => 'LEFT'],
                    2 => ['tableName' => 'rs_rmr', 'string' => 'rs_rmr.rs_rmr_id_ex = rs_rmpjt.rs_rmpjt_rmr', 'type' => 'LEFT'],
                    3 => ['tableName' => 'rs_rmtdk', 'string' => 'rs_rmtdk.rs_rmtdk_id_ex = rs_rmpjt.rs_rmpjt_rmtdk', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpjt_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}