<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\CheckDBMdl;
use App\Models\MkTableModel;
use App\Models\PaMdl;

class Msk extends BaseController
{
    use ResponseTrait;
    protected $TableMkTable;
    protected $TableCheckDB;
    protected $MdlPa;

    public function __construct()
    {
        $this->TableMkTable = new MkTableModel();
        $this->TableCheckDB = new CheckDBMdl();
        $this->MdlPa = new PaMdl();
        $this->session = \Config\Services::session();
        $this->data = [
            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
        ];
    }
    public function index()
    {
        $checkDB = $this->checkListDB();
        if ($checkDB[1] > 0) {
            // return redirect()->to('/mkTable');
        }
        $this->data['WebTitle'] = 'MASUK';
        $this->data['PageTitle'] = 'Masuk';
        $this->data['BasePage'] = 'msk';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'authMasuk';
        $this->data['IdForm'] = 'authForm';
        $this->data['UrlForm'] = '';
        echo view('Msk/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }

    public function authMasuk()
    {
        $rs_pa_un = $this->request->getPost('username');
        $rs_pa_pass = $this->request->getPost('password');
        $data = [
            'rs_pa_un' => $rs_pa_un,
            'rs_pa_pass' => $rs_pa_pass,
        ];
        $getUserData = $this->MdlPa->countUsername($data['rs_pa_un']);
        if ($getUserData != null || !empty($getUserData)) {
            if (password_verify($rs_pa_pass, $getUserData[0]['rs_pa_pass'])) {
                $this->session->set($getUserData[0]);
                $data = [
                    'status' => 200,
                    'response' => "success",
                    'message' => 'Berhasil Masuk'
                ];
            } else {
                $data = [
                    'status' => 500,
                    'response' => "error",
                    'message' => 'Kata Sandi Salah'
                ];
            }
        } else {
            $data = [
                'status' => 500,
                'response' => "error",
                'message' => 'Tidak Terdapat Pengguna Yang Dimaksud'
            ];
        }

        return $this->respond($data, $data['status']);
    }

    public function authkeluar()
    {
        header("Content-Type:application/json;charset=utf-8");
        header("Access-Control-Allow-Origin: *");

        $data = [
            'status' => 200,
            'response' => "success",
            'message' => 'Berhasil Keluar'
        ];

        $this->session->destroy();
        return $this->respond($data, 200);
    }

    public function checkListDB()
    {
        $table = $this->TableMkTable->checkDB();
        $success = 0;
        $error = 0;
        $errorEmpty = 0;
        $errorSameDB = 0;
        $errorCountDB = 0;
        $TableConfirm = $this->TableCheckDB->checkDB();
        $TableConfirm = $TableConfirm->getResultArray();
        $countTableOn = count($table);
        $countTableOff = count($TableConfirm);
        for ($i = 0; $i < count($table); $i++) {
            if (empty($TableConfirm)) {
                $errorEmpty += 1;
                $error += 1;
                echo "<script>console.log('Error empty(TableConfirm)')</script>";
                break;
            }
            if ($countTableOn != $countTableOff) {
                $errorCountDB += 1;
                $error += 1;
                echo "<script>console.log('Error i != j')</script>";
                break;
            }
        }
        if ($errorEmpty == 0 && $errorCountDB == 0) {
            for ($i = 0; $i < count($table); $i++) {
                if ($TableConfirm[$i]['Tables_in_rs'] != $table[$i]['TableName']) {
                    $errorSameDB += 1;
                    echo "<script>console.log('Isi Table_in_rs " . $TableConfirm[$i]['Tables_in_rs'] . "')</script>";
                    echo "<script>console.log('Error " . $TableConfirm[$i]['Tables_in_rs'] . " != " . $table[$i]['TableName'] . "')</script>";
                    break;
                } else {
                    continue;
                }
            }
            if ($errorSameDB > 0) {
                $error += 1;
                echo "<script>console.log('Error errorSameDB > 0')</script>";
            } else {
                for ($i = 0; $i < count($table); $i++) {

                    $TableConfirm = $this->TableCheckDB->checkDBWithField($table[$i]['TableName']);
                    for ($j = 0; $j < count($table[$i]['field']); $j++) {
                        if ($table[$i]['field'][$j] == $TableConfirm[$j]) {
                            $success += 1;
                        } else {
                            echo "<script>console.log('Error table[i][\'field\'][j] == TableConfirm[j] === " . $table[$i]['field'][$j] . "')</script>";
                            $error += 1;
                        }
                    }
                }
            }
        }
        return array($success, $error);
    }
}
