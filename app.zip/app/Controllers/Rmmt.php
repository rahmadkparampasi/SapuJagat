<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\RmmtMdl;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Reader\Xls as Reader;

class Rmmt extends BaseController
{
    use ResponseTrait;
    protected $MdlRmmt;
    protected $AI;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlRmmt = new RmmtMdl();
        $this->AI = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeng',
            'pAct' => 'pAPeng',
            'cAct' => 'cArmref',
            'cmAct' => 'cmArmref',
            'scAct' => 'scArmmt',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA JENIS MUTU';
        $this->data['PageTitle'] = 'Data Jenis Mutu';
        $this->data['BasePage'] = 'rmmt';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData';
        $this->data['IdForm'] = 'rmmtAddData';
        $this->data['UrlForm'] = 'rmmt';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);


        $this->data['Rmmt'] = $this->MdlRmmt->getAll();

        echo view('Rmmt/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }

    public function editData($rs_rmmt_id_ex = '')
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA JENIS MUTU';
        $this->data['PageTitle'] = 'Data Jenis Mutu';
        $this->data['BasePage'] = 'rmmt';
        $this->data['ButtonMethod'] = 'UBAH';
        $this->data['MethodForm'] = 'updateData/' . $rs_rmmt_id_ex;
        $this->data['IdForm'] = 'rmmtAddData';
        $this->data['UrlForm'] = 'rmmt';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);

        $this->data['Rmmt'] = $this->MdlRmmt->getAll();
        for ($i = 0; $i < count($this->data['Rmmt']); $i++) {
            if ($this->data['Rmmt'][$i]['rs_rmmt_sts'] == "1") {
                $this->data['Rmmt'][$i]['rs_rmmt_sts'] = $this->AI->cB('Aktif');
            } else {
                $this->data['Rmmt'][$i]['rs_rmmt_sts'] = $this->AI->cB('Tidak Aktif', 'danger');
            }
        }
        if ($rs_rmmt_id_ex === null || $rs_rmmt_id_ex == '') {
            return redirect()->to('/' . $this->data['BasePage']);
        } else {
            $this->data['fillUpdate'] = $this->MdlRmmt->getAll($rs_rmmt_id_ex);

            echo view('Rmmt/index', $this->data);
            echo view('Templates/anotherScript');
            echo view('Templates/ajaxInsert', $this->data);
            echo view('Templates/loadData');
        }
    }

    public function getRmmtByJson($rs_rmr_id_ex)
    {
        header('Content-Type: application/json');
        header("Access-Control-Allow-Origin: *");
        $this->data['data']['data'] = $this->MdlRmmt->getAll();
        $no = 0;
        for ($i = 0; $i < count($this->data['data']['data']); $i++) {
            $no++;

            $this->data['data']['data'][$i]['button'] = "<button class='btn bg-gradient-success' title='Tambahkan Mutu Ke Dalam RUangan' onclick='addWF(\"Menambahkan " . $this->data['data']['data'][$i]['rs_rmmt_nm'] . " Dalam Data Ruangan\", \"/" . "rmrmt/insertData/" . $rs_rmr_id_ex . "/" . $this->data['data']['data'][$i]['rs_rmmt_id_ex'] . "\", loadTabMt)'><i class='fas fa-check'></i></button>";
            $this->data['data']['data'][$i]['no'] = $no;
        }
        return $this->respond($this->data['data'], 200);
    }

    public function insertData()
    {

        $rs_rmmt_id_ex = $this->MdlRmmt->getIdEx($this->AI->getRandStr(3));
        $rs_rmmt_nm = $this->request->getPost('rs_rmmt_nm');

        $data = [
            'rs_rmmt_id_ex' => $rs_rmmt_id_ex,
            'rs_rmmt_nm' => $rs_rmmt_nm
        ];

        $insertData = $this->MdlRmmt->insertData($data);
        if ($insertData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Jenis Mutu Berhasil Disimpan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Jenis Mutu Tidak Dapat Disimpan'];
        }

        return $this->respond($data, $data['status']);
    }


    public function updateData($rs_rmmt_id_ex = '')
    {
        $rs_rmmt_nm = $this->request->getPost('rs_rmmt_nm');
        $rs_rmmt_id_ex = $this->request->getPost('rs_rmmt_id_ex');
        $data = [
            'rs_rmmt_nm' => $rs_rmmt_nm,
        ];
        $updateData = $this->MdlRmmt->updateData($data, $rs_rmmt_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Jenis Mutu Berhasil Diubah'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Jenis Mutu Tidak Dapat Diubah'];
        }
        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmmt_id_ex = '')
    {
        if ($rs_rmmt_id_ex === null || $rs_rmmt_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlRmmt->deleteData($rs_rmmt_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Jenis Mutu Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Jenis Mutu Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function blockRmmt($rs_rmmt_id_ex = '')
    {
        $data = [
            'rs_rmmt_sts' => "0",
        ];
        $updateData = $this->MdlRmmt->updateData($data, $rs_rmmt_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Status Jenis Mutu Berhasil Di Dinonaktifkan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Status Jenis Mutu Tidak Dapat Di Dinonaktifkan'];
        }
        return $this->respond($data, $data['status']);
    }

    public function unblockRmmt($rs_rmmt_id_ex = '')
    {
        $data = [
            'rs_rmmt_sts' => "1",
        ];
        $updateData = $this->MdlRmmt->updateData($data, $rs_rmmt_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Status Jenis Mutu Berhasil Aktifkan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Status Jenis Mutu Tidak Dapat Aktifkan'];
        }
        return $this->respond($data, $data['status']);
    }
}
