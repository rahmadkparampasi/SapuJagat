<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\UmMdl;

class Rmag extends BaseController
{
    use ResponseTrait;
    protected $MdlU;
    protected $AI;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_rmag', 'rs_rmag_id_ex');
        $this->AI = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeng',
            'pAct' => 'pAPeng',
            'cAct' => 'cArmref',
            'cmAct' => 'cmArmref',
            'scAct' => 'scArmag',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA AGAMA';
        $this->data['PageTitle'] = 'Data Agama';
        $this->data['BasePage'] = 'rmag';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData';
        $this->data['IdForm'] = 'rmagAddData';
        $this->data['UrlForm'] = 'rmag';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);


        $this->data['Rmag'] = $this->setDB();

        echo view('Rmag/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }

    public function editData($rs_rmag_id_ex = '')
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA AGAMA';
        $this->data['PageTitle'] = 'Data Agama';
        $this->data['BasePage'] = 'rmag';
        $this->data['ButtonMethod'] = 'UBAH';
        $this->data['MethodForm'] = 'updateData/' . $rs_rmag_id_ex;
        $this->data['IdForm'] = 'rmagAddData';
        $this->data['UrlForm'] = 'rmag';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);

        $this->data['Rmag'] = $this->setDB();

        if ($rs_rmag_id_ex === null || $rs_rmag_id_ex == '') {
            return redirect()->to('/' . $this->data['BasePage']);
        } else {
            $this->data['fillUpdate'] = $this->setDB('fillUpdate', $rs_rmag_id_ex);

            echo view('Rmag/index', $this->data);
            echo view('Templates/anotherScript');
            echo view('Templates/ajaxInsert', $this->data);
            echo view('Templates/loadData');
        }
    }

    public function getAll()
    {
        return $this->setDB('getAllByAct');
    }

    public function insertData()
    {

        $rs_rmag_id_ex = $this->setDB('idEx', $this->AI->getRandStr(3));
        $rs_rmag_nm = $this->request->getPost('rs_rmag_nm');

        $data = [
            'rs_rmag_id_ex' => $rs_rmag_id_ex,
            'rs_rmag_nm' => $rs_rmag_nm
        ];

        $insertData = $this->MdlU->insertData($data);
        if ($insertData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Agama Berhasil Disimpan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Agama Tidak Dapat Disimpan'];
        }

        return $this->respond($data, $data['status']);
    }


    public function updateData($rs_rmag_id_ex = '')
    {
        $rs_rmag_nm = $this->request->getPost('rs_rmag_nm');
        $rs_rmag_id_ex = $this->request->getPost('rs_rmag_id_ex');
        $data = [
            'rs_rmag_nm' => $rs_rmag_nm
        ];
        $updateData = $this->MdlU->updateData($data, $rs_rmag_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Agama Berhasil Diubah'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Agama Tidak Dapat Diubah'];
        }
        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmag_id_ex = '')
    {
        if ($rs_rmag_id_ex === null || $rs_rmag_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlU->deleteData($rs_rmag_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Agama Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Agama Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function block($rs_rmag_id_ex = '')
    {
        $data = [
            'rs_rmag_sts' => "0",
        ];
        $updateData = $this->MdlU->updateData($data, $rs_rmag_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Status Agama Berhasil Di Dinonaktifkan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Status Agama Tidak Dapat Di Dinonaktifkan'];
        }
        return $this->respond($data, $data['status']);
    }

    public function unblock($rs_rmag_id_ex = '')
    {
        $data = [
            'rs_rmag_sts' => "1",
        ];
        $updateData = $this->MdlU->updateData($data, $rs_rmag_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Status Agama Berhasil Aktifkan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Status Agama Tidak Dapat Aktifkan'];
        }
        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmag_id_ex';
        $id = 'rs_rmag_id';
        $length = 2;
        $typeGet = 'result';

        $fillUpdate = 'rs_rmag_id_ex, rs_rmag_nm';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [],
                //order by
                [
                    0 => ['id' => 'rs_rmag_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'getAllByAct') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => ['idEx' => 'rs_rmag_sts', 'idExV' => '1']
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmag_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmag_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}