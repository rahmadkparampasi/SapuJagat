<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\RmphMdl;
use App\Models\RmpmskMdl;
use App\Models\UmMdl;

class Rmpres extends BaseController
{
    use ResponseTrait;
    protected $MdlRmpmsk;
    protected $Rmpresnr;
    protected $MdlU;
    protected $MdlRmph;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlRmpmsk = new RmpmskMdl();
        $this->Rmpresnr = new Rmpresnr;
        $this->MdlU = new UmMdl('rs_rmpres', 'rs_rmpres_id_ex');
        $this->MdlRmph = new RmphMdl();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOIgd',
            'pAct' => 'pAIgd',
            'cAct' => 'cArmpmsk',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {

        return redirect()->to('./rmpmsk');
    }

    public function getAll($rs_rmpres_rmpmsk)
    {
        $data = $this->setDB('getAll', $rs_rmpres_rmpmsk);
        $data = $this->Another_Include->changeDateWF($data, ['rs_rmpres_tgl']);
        for ($i = 0; $i < count($data); $i++) {
            if ($data[$i]['rs_rmpres_fg'] == "1") {
                $data[$i]['rs_rmpres_fg'] = "Ya";
            } else {
                $data[$i]['rs_rmpres_fg'] = "Tidak";
            }
            if ($data[$i]['rs_rmpres_ms'] == "1") {
                $data[$i]['rs_rmpres_ms'] = "Ya";
            } else {
                $data[$i]['rs_rmpres_ms'] = "Tidak";
            }
            if ($data[$i]['rs_rmpres_hml'] == "1") {
                $data[$i]['rs_rmpres_hml'] = "Ya";
            } else {
                $data[$i]['rs_rmpres_hml'] = "Tidak";
            }
            if ($data[$i]['rs_rmpres_pp'] == "1") {
                $data[$i]['rs_rmpres_pp'] = "Ya";
            } else {
                $data[$i]['rs_rmpres_pp'] = "Tidak";
            }
            if ($data[$i]['rs_rmpres_ct'] == "1") {
                $data[$i]['rs_rmpres_ct'] = "Ya";
            } else {
                $data[$i]['rs_rmpres_ct'] = "Tidak";
            }
            $data[$i]['rmpresnr'] = $this->Rmpresnr->getAll($data[$i]['rs_rmpres_id_ex']);
            if ($data[$i]['rs_ppeg_nmd'] != "") {
                $data[$i]['rs_ppeg_nm'] = $data[$i]['rs_ppeg_nmd'] . ". " . $data[$i]['rs_ppeg_nm'];
            }

            if ($data[$i]['rs_ppeg_nmb'] != "") {
                $data[$i]['rs_ppeg_nm'] = $data[$i]['rs_ppeg_nm'] . ", " . $data[$i]['rs_ppeg_nmb'];
            }
        }
        return $data;
    }
    public function getByIdEx($rs_rmpres_id_ex)
    {
        $data = $this->setDB('fillUpdate', $rs_rmpres_id_ex);
        for ($i = 0; $i < count($data); $i++) {
            $data[$i]['rs_rmpres_tgl'] = $this->Another_Include->changeDateNF($data[$i]['rs_rmpres_tgl']);
        }
        return $data;
    }

    public function insertData($rs_rmpres_rmpmsk)
    {
        $this->data['Rmpmsk'] = $this->MdlRmpmsk->getAllRmpmsk($rs_rmpres_rmpmsk);

        $rs_rmph_id_ex = $this->Another_Include->getRandStr(35);
        $rs_rmph_rmpp = $this->data['Rmpmsk']['rs_rmpmsk_rmpp'];
        $rs_rmph_ppeg = $this->data['rs_ppeg_id_ex'];
        $rs_rmph_jns = "CT";

        $rs_rmpres_id_ex = $this->setDB('idEx', $this->Another_Include->getRandStr(7));
        $rs_rmpres_kd = $this->setDB('getCode', 'ER-' . $this->data['Rmpmsk']['rs_rmpp_rm'] . '-');
        $rs_rmpres_rmr = $this->request->getPost('rs_rmpres_rmr');
        $rs_rmpres_ppeg = $this->request->getPost('rs_rmpres_ppeg');
        $rs_rmpres_res = $this->request->getPost('rs_rmpres_res');
        $rs_rmpres_tgl = $this->request->getPost('rs_rmpres_tgl');
        $rs_rmpres_jam = $this->request->getPost('rs_rmpres_jam');
        $rs_rmpres_bb = $this->request->getPost('rs_rmpres_bb');
        $rs_rmpres_tb = $this->request->getPost('rs_rmpres_tb');
        $rs_rmpres_ao = $this->request->getPost('rs_rmpres_ao');
        $rs_rmpres_fg = $this->request->getPost('rs_rmpres_fg');
        $rs_rmpres_ms = $this->request->getPost('rs_rmpres_ms');
        $rs_rmpres_hml = $this->request->getPost('rs_rmpres_hml');
        $rs_rmpres_pp = $this->request->getPost('rs_rmpres_pp');
        $rs_rmpres_ct = $this->request->getPost('rs_rmpres_ct');

        $dataRmpres = [
            'rs_rmpres_id_ex' => $rs_rmpres_id_ex,
            'rs_rmpres_rmpmsk' => $rs_rmpres_rmpmsk,
            'rs_rmpres_kd' => $rs_rmpres_kd,
            'rs_rmpres_rmph' => $rs_rmph_id_ex,
            'rs_rmpres_rmr' => $rs_rmpres_rmr,
            'rs_rmpres_ppeg' => $rs_rmpres_ppeg,
            'rs_rmpres_res' => $rs_rmpres_res,
            'rs_rmpres_tgl' => $rs_rmpres_tgl,
            'rs_rmpres_jam' => $rs_rmpres_jam,
            'rs_rmpres_bb' => $rs_rmpres_bb,
            'rs_rmpres_tb' => $rs_rmpres_tb,
            'rs_rmpres_ao' => $rs_rmpres_ao,
            'rs_rmpres_fg' => $rs_rmpres_fg,
            'rs_rmpres_ms' => $rs_rmpres_ms,
            'rs_rmpres_hml' => $rs_rmpres_hml,
            'rs_rmpres_pp' => $rs_rmpres_pp,
            'rs_rmpres_ct' => $rs_rmpres_ct,
        ];

        $dataRmph = [
            'rs_rmph_id_ex' => $rs_rmph_id_ex,
            'rs_rmph_rmpp' => $rs_rmph_rmpp,
            'rs_rmph_ppeg' => $rs_rmph_ppeg,
            'rs_rmph_jns' => $rs_rmph_jns
        ];

        $insertDataRmph = $this->MdlRmph->insertData($dataRmph);
        if ($insertDataRmph) {
            $insertDataRmPres = $this->MdlU->insertData($dataRmpres);
            if ($insertDataRmPres) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data E-Resep Pasien Berhasil Disimpan'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data E-Resep Pasien Tidak Dapat Disimpan'];
            }
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Histori Pasien Tidak Dapat Disimpan'];
        }



        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmpres_id_ex = '')
    {
        if ($rs_rmpres_id_ex === null || $rs_rmpres_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlU->deleteData($rs_rmpres_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data E-Resep Pasien Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data E-Resep Pasien Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmpres_id_ex';
        $id = 'rs_rmpres_id';
        $length = 3;
        $typeGet = 'result';

        $fillUpdate = 'rs_rmpres_id_ex, rs_rmpres_kd, rs_rmpres_res, rs_rmpres_tgl, rs_rmpres_jam';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmpres_rmpmsk',
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpres_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmr', 'string' => 'rs_rmr.rs_rmr_id_ex = rs_rmpres.rs_rmpres_rmr', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_ppeg', 'string' => 'rs_ppeg.rs_ppeg_id_ex = rs_rmpres.rs_rmpres_ppeg', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpres_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        } elseif ($request == 'getCode') {
            return $this->MdlU->getIdEx('rs_rmpres_kd', $data, $id, 4);
        }
    }
}