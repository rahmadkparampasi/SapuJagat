<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\RmpddcddMdl;
use App\Models\RmphMdl;
use App\Models\RmpmskMdl;

class Rmpddcd extends BaseController
{
    use ResponseTrait;
    protected $MdlRmpmsk;
    protected $MdlRmpddcd;
    protected $MdlRmph;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlRmpmsk = new RmpmskMdl();
        $this->MdlRmpddcd = new RmpddcddMdl();
        $this->MdlRmph = new RmphMdl();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOIgd',
            'pAct' => 'pAIgd',
            'cAct' => 'cArmpmsk',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
        return redirect()->to('./rmpmsk');
    }

    public function viewData($rs_rmpddcd_rmpmsk = '')
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['Rmpmsk'] = $this->MdlRmpmsk->getAllRmpmsk($rs_rmpddcd_rmpmsk);

        $this->data['d'] = (string)date('d', strtotime($this->data['Rmpmsk']['rs_rmpmsk_tgl']));
        $this->data['F'] = (string)date('F', strtotime($this->data['Rmpmsk']['rs_rmpmsk_tgl']));
        $this->data['F'] = $this->Another_Include->monthConv($this->data['F']);
        $this->data['Y'] = (string)date('Y', strtotime($this->data['Rmpmsk']['rs_rmpmsk_tgl']));
        $this->data['Rmpmsk']['rs_rmpmsk_tgl'] = strtoupper($this->data['d'] . " " . $this->data['F'] . " " . $this->data['Y']);

        $this->data['d'] = (string)date('d', strtotime($this->data['Rmpmsk']['rs_rmpp_tgl_lhr']));
        $this->data['F'] = (string)date('F', strtotime($this->data['Rmpmsk']['rs_rmpp_tgl_lhr']));
        $this->data['F'] = $this->Another_Include->monthConv($this->data['F']);
        $this->data['Y'] = (string)date('Y', strtotime($this->data['Rmpmsk']['rs_rmpp_tgl_lhr']));
        $this->data['Rmpmsk']['rs_rmpp_tgl_lhr'] = strtoupper($this->data['d'] . " " . $this->data['F'] . " " . $this->data['Y']);

        $this->data['Rmpmsk']['rs_rmpp_alt'] = substr($this->data['Rmpmsk']['rs_rmpp_alt'], 0, 15) . '...';

        if ($this->data['Rmpmsk']['rs_rmpp_jk'] == "L") {
            $this->data['Rmpmsk']['rs_rmpp_jk'] = "LAKI-LAKI";
        } else {
            $this->data['Rmpmsk']['rs_rmpp_jk'] = "PEREMPUAN";
        }


        $this->data['WebTitle'] = 'DATA DETEKSI DINI CORONAVIRUS DISEASE (COVID-19)';
        $this->data['PageTitle'] = 'Data Deteksi Dini Coronavirus Disease (Covid-19)';
        $this->data['BasePage'] = 'rmpddcd';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData/' . $rs_rmpddcd_rmpmsk;
        $this->data['IdForm'] = 'rmpddcdAddData';
        $this->data['UrlForm'] = 'rmpddcd/viewData/' . $rs_rmpddcd_rmpmsk;

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);

        $this->data['Rmpddcd'] = $this->MdlRmpddcd->getAllRmpddcdd($rs_rmpddcd_rmpmsk);
        for ($i = 0; $i < count($this->data['Rmpddcd']); $i++) {
            $this->data['d'] = (string)date('d', strtotime($this->data['Rmpddcd'][$i]['rs_rmpddcd_tgl']));
            $this->data['F'] = (string)date('F', strtotime($this->data['Rmpddcd'][$i]['rs_rmpddcd_tgl']));
            $this->data['F'] = $this->Another_Include->monthConv($this->data['F']);
            $this->data['Y'] = (string)date('Y', strtotime($this->data['Rmpddcd'][$i]['rs_rmpddcd_tgl']));
            $this->data['Rmpddcd'][$i]['rs_rmpddcd_tgl'] = strtoupper($this->data['d'] . " " . $this->data['F'] . " " . $this->data['Y']);
        }


        if ($rs_rmpddcd_rmpmsk === null || $rs_rmpddcd_rmpmsk == '') {
            return redirect()->to('/' . $this->data['BasePage']);
        } else {
            echo view('Rmpddcd/index', $this->data);
            echo view('Templates/anotherScript');
            echo view('Templates/ajaxInsert', $this->data);
        }
    }

    // public function editData($rs_rmpadgd_id_ex = '')
    // {
    //     if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
    //         return redirect()->to('./msk');
    //     }
    //     $this->data['Rmpadgd'] = $this->MdlRmpadgd->getAllRmpadgd(false, $rs_rmpadgd_id_ex);
    //     $rs_rmpadgd_rmpmsk = $this->data['Rmpadgd']['rs_rmpadgd_rmpmsk'];
    //     $this->data['Rmpmsk'] = $this->MdlRmpmsk->getAllRmpmsk($rs_rmpadgd_rmpmsk);

    //     $this->data['d'] = (string)date('d', strtotime($this->data['Rmpmsk']['rs_rmpmsk_tgl']));
    //     $this->data['F'] = (string)date('F', strtotime($this->data['Rmpmsk']['rs_rmpmsk_tgl']));
    //     $this->data['F'] = $this->Another_Include->monthConv($this->data['F']);
    //     $this->data['Y'] = (string)date('Y', strtotime($this->data['Rmpmsk']['rs_rmpmsk_tgl']));
    //     $this->data['Rmpmsk']['rs_rmpmsk_tgl'] = strtoupper($this->data['d'] . " " . $this->data['F'] . " " . $this->data['Y']);

    //     $this->data['d'] = (string)date('d', strtotime($this->data['Rmpmsk']['rs_rmpp_tgl_lhr']));
    //     $this->data['F'] = (string)date('F', strtotime($this->data['Rmpmsk']['rs_rmpp_tgl_lhr']));
    //     $this->data['F'] = $this->Another_Include->monthConv($this->data['F']);
    //     $this->data['Y'] = (string)date('Y', strtotime($this->data['Rmpmsk']['rs_rmpp_tgl_lhr']));
    //     $this->data['Rmpmsk']['rs_rmpp_tgl_lhr'] = strtoupper($this->data['d'] . " " . $this->data['F'] . " " . $this->data['Y']);

    //     $this->data['Rmpmsk']['rs_rmpp_alt'] = substr($this->data['Rmpmsk']['rs_rmpp_alt'], 0, 15) . '...';

    //     if ($this->data['Rmpmsk']['rs_rmpp_jk'] == "L") {
    //         $this->data['Rmpmsk']['rs_rmpp_jk'] = "LAKI-LAKI";
    //     } else {
    //         $this->data['Rmpmsk']['rs_rmpp_jk'] = "PEREMPUAN";
    //     }


    //     $this->data['WebTitle'] = 'DATA ASESMEN AWAL DOKTER GAWAT DARURAT';
    //     $this->data['PageTitle'] = 'Data Asesmen Awal Dokter Gawat Darurat';
    //     $this->data['BasePage'] = 'rmpadgd';
    //     $this->data['ButtonMethod'] = 'UBAH';
    //     $this->data['MethodForm'] = 'updateData/' . $rs_rmpadgd_id_ex;
    //     $this->data['IdForm'] = 'rmpadgdAddData';
    //     $this->data['UrlForm'] = 'rmpadgd/viewData/' . $rs_rmpadgd_rmpmsk;

    //     $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);

    //     $this->data['Rmpadgd'] = $this->MdlRmpadgd->getAllRmpadgd($rs_rmpadgd_rmpmsk);
    //     for ($i = 0; $i < count($this->data['Rmpadgd']); $i++) {
    //         $this->data['d'] = (string)date('d', strtotime($this->data['Rmpadgd'][$i]['rs_rmpadgd_tgl']));
    //         $this->data['F'] = (string)date('F', strtotime($this->data['Rmpadgd'][$i]['rs_rmpadgd_tgl']));
    //         $this->data['F'] = $this->Another_Include->monthConv($this->data['F']);
    //         $this->data['Y'] = (string)date('Y', strtotime($this->data['Rmpadgd'][$i]['rs_rmpadgd_tgl']));
    //         $this->data['Rmpadgd'][$i]['rs_rmpadgd_tgl'] = strtoupper($this->data['d'] . " " . $this->data['F'] . " " . $this->data['Y']);
    //     }


    //     if ($rs_rmpadgd_rmpmsk === null || $rs_rmpadgd_rmpmsk == '') {
    //         return redirect()->to('/' . $this->data['BasePage']);
    //     } else {
    //         $this->data['fillUpdate'] = $this->MdlRmpadgd->getRmpadgdByIdEx($rs_rmpadgd_id_ex);
    //         // dd($this->data['fillUpdate']);
    //         echo view('Rmpadgd/index', $this->data);
    //         echo view('Templates/anotherScript');
    //         echo view('Templates/ajaxInsert', $this->data);
    //         echo view('Templates/loadData');
    //     }
    // }

    // public function insertData($rs_rmpadgd_rmpmsk)
    // {
    //     $this->data['Rmpmsk'] = $this->MdlRmpmsk->getAllRmpmsk($rs_rmpadgd_rmpmsk);

    //     $rs_rmph_id_ex = $this->MdlRmph->getIdExRmph($this->Another_Include->getRandStr(30));
    //     $rs_rmph_rmpp = $this->data['Rmpmsk']['rs_rmpmsk_rmpp'];
    //     $rs_rmph_ppeg = $this->data['rs_ppeg_id_ex'];
    //     $rs_rmph_jns = "CT";

    //     $dataRmpadgd = [];

    //     $array = $this->request->getPost();
    //     unset($array['datatableKirana_length']);
    //     $arrayFlip = array_keys($array);
    //     $arrayFlipV = array_values($arrayFlip);
    //     $arrayV = array_values($array);

    //     $rs_rmpadgd_id_ex = $this->MdlRmpadgd->getIdExRmpadgd($this->Another_Include->getRandStr(35));
    //     $dataRmpadgd['rs_rmpadgd_id_ex'] = $rs_rmpadgd_id_ex;
    //     $dataRmpadgd['rs_rmpadgd_rmpmsk'] = $rs_rmpadgd_rmpmsk;
    //     $dataRmpadgd['rs_rmpadgd_ppeg'] = $this->data['rs_ppeg_id_ex'];
    //     $dataRmpadgd['rs_rmpadgd_rmph'] = $rs_rmph_id_ex;
    //     for ($i = 0; $i < count($arrayV); $i++) {
    //         $dataRmpadgd[$arrayFlipV[$i]] = $arrayV[$i];
    //     }

    //     $dataRmph = [
    //         'rs_rmph_id_ex' => $rs_rmph_id_ex,
    //         'rs_rmph_rmpp' => $rs_rmph_rmpp,
    //         'rs_rmph_ppeg' => $rs_rmph_ppeg,
    //         'rs_rmph_jns' => $rs_rmph_jns
    //     ];

    //     $insertDataRmph = $this->MdlRmph->insertData($dataRmph);
    //     if ($insertDataRmph) {
    //         $insertDataRmpadgd = $this->MdlRmpadgd->insertData($dataRmpadgd);
    //         if ($insertDataRmpadgd) {
    //             $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Asesmen Awal Dokter Gawat Darurat Berhasil Disimpan'];
    //         } else {
    //             $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Asesmen Awal Dokter Gawat Darurat Tidak Dapat Disimpan'];
    //         }
    //     } else {
    //         $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Histori Pasien Tidak Dapat Disimpan'];
    //     }



    //     return $this->respond($data, $data['status']);
    // }

    // public function updateData($rs_rmpadgd_id_ex = '')
    // {

    //     $array = $this->request->getPost();
    //     // dd($array);
    //     unset($array['datatableKirana_length']);
    //     unset($array['rs_rmpadgd_id_ex']);
    //     $arrayFlip = array_keys($array);
    //     $arrayFlipV = array_values($arrayFlip);
    //     $arrayV = array_values($array);

    //     $dataRmpadgd = [];

    //     for ($i = 0; $i < count($arrayV); $i++) {
    //         $dataRmpadgd[$arrayFlipV[$i]] = $arrayV[$i];
    //     }
    //     // dd($dataRmpadgd);

    //     $updateDataRmpadgd = $this->MdlRmpadgd->updateData($dataRmpadgd, $rs_rmpadgd_id_ex);
    //     if ($updateDataRmpadgd) {
    //         $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Asesmen Awal Dokter Gawat Darurat Berhasil Diubah'];
    //     } else {
    //         $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Asesmen Awal Dokter Gawat Darurat Tidak Dapat Diubah'];
    //     }

    //     return $this->respond($data, $data['status']);
    // }

    // public function deleteData($rs_rmr_id_ex = '')
    // {
    //     if ($rs_rmr_id_ex === null || $rs_rmr_id_ex == '') {
    //         $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
    //     } else {
    //         $deleteData = $this->MdlRmr->deleteData($rs_rmr_id_ex);
    //         if ($deleteData) {
    //             $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Ruangan Berhasil Dihapus'];
    //         } else {
    //             $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Ruangan Tidak Dapat Dihapus'];
    //         }
    //     }
    //     return $this->respond($data, $data['status']);
    // }
}
