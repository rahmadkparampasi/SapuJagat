<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\UmMdl;

class Rmplabt extends BaseController
{
    use ResponseTrait;

    public $MdlU;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_rmplabt', 'rs_rmplabt_id_ex');
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOIgd',
            'pAct' => 'pAIgd',
            'cAct' => 'cArmpmsk',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {

        return redirect()->to('./rmpmsk');
    }

    public function getAll($rs_rmplabt_rmplab)
    {
        $this->data['Rmplabt'] = $this->setDB('getAll', $rs_rmplabt_rmplab);

        return  $this->data['Rmplabt'];
    }
    public function getAllByRmpmsk($rs_rmplab_rmpmsk)
    {
        $this->data['Rmplabt'] = $this->setDB('getAllByRmpmsk', $rs_rmplab_rmpmsk);
        for ($i = 0; $i < count($this->data['Rmplabt']); $i++) {
            
            if ($this->data['Rmplabt'][$i]['rs_ppeg_nmd'] != "") {
                $this->data['Rmplabt'][$i]['rs_ppeg_nm'] = $this->data['Rmplabt'][$i]['rs_ppeg_nmd'] . ". " . $this->data['Rmplabt'][$i]['rs_ppeg_nm'];
            }

            if ($this->data['Rmplabt'][$i]['rs_ppeg_nmb'] != "") {
                $this->data['Rmplabt'][$i]['rs_ppeg_nm'] = $this->data['Rmplabt'][$i]['rs_ppeg_nm'] . ", " . $this->data['Rmplabt'][$i]['rs_ppeg_nmb'];
            }
        }

        return  $this->data['Rmplabt'];
    }

    public function insertData()
    {
        $rs_rmplabt_rmplab = $this->request->getPost('rs_rmplabt_rmplab');
        $rs_rmplabt_rmtdk = $this->request->getPost('rs_rmplabt_rmtdk');
        if ($rs_rmplabt_rmtdk == null || empty($rs_rmplabt_rmtdk)) {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Pilih Terlebih Dahulu Data Tindakan'];
        } else {
            $success = 0;
            $error = 0;
            foreach ($this->request->getPost('rs_rmplabt_rmtdk') as $key) {
                $this->data['Rmplp'] = $this->setDB('getAllByRmplabAndTdk', [$rs_rmplabt_rmplab, $key]);
                if ($this->data['Rmplp'] != null || count($this->data['Rmplp']) > 0) {
                    $error = $error + 1;
                } else {
                    $data = [];

                    $data = [
                        'rs_rmplabt_id_ex' => $this->setDB('idEx', $this->Another_Include->getRandStr(8)),
                        'rs_rmplabt_rmplab' => $rs_rmplabt_rmplab,
                        'rs_rmplabt_rmtdk' => $key,
                    ];
                    $insertData = $this->MdlU->insertData($data);
                    if ($insertData) {
                        $success = + 1;
                    } else {
                        $error = + 1;
                    }
                }
            }
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Tindakan Laboratorium Pasien Berhasil Diproses, Dengan Jumlah Data Yang Berhasil Disimpan Berjumlah ' . (string)$success . ' Data, Dan Yang Gagal Disimpan Berjumlah ' . (string)$error . ' Data'];
        }

        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmplabt_id = '')
    {
        if ($rs_rmplabt_id === null || $rs_rmplabt_id == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlU->deleteData($rs_rmplabt_id);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Tindakan Laboratorium Pasien Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Tindakan Laboratorium Pasien Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmplabt_id_ex';
        $id = 'rs_rmplabt_id';
        $length = 3;
        $typeGet = 'result';

        $fillUpdate = '*';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmplabt_rmplab',
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmplabt_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmtdk', 'string' => 'rs_rmtdk.rs_rmtdk_id_ex = rs_rmplabt.rs_rmplabt_rmtdk', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_rmktdk', 'string' => 'rs_rmktdk.rs_rmktdk_id_ex = rs_rmtdk.rs_rmtdk_rmktdk', 'type' => 'LEFT'],
                ]
            );
        }elseif ($request == 'getAllByRmpmsk') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmplab_rmpmsk',
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmplabt_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmplab', 'string' => 'rs_rmplab.rs_rmplab_id_ex = rs_rmplabt.rs_rmplabt_rmplab', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_ppeg', 'string' => 'rs_ppeg.rs_ppeg_id_ex = rs_rmplab.rs_rmplab_ppeg', 'type' => 'LEFT'],
                    2 => ['tableName' => 'rs_rmtdk', 'string' => 'rs_rmtdk.rs_rmtdk_id_ex = rs_rmplabt.rs_rmplabt_rmtdk', 'type' => 'LEFT'],
                    3 => ['tableName' => 'rs_rmktdk', 'string' => 'rs_rmktdk.rs_rmktdk_id_ex = rs_rmtdk.rs_rmtdk_rmktdk', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'getAllByRmplabAndTdk') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmplabt_rmplab',
                        'idExV' => $data[0]
                    ],
                    1 => [
                        'idEx' => 'rs_rmplabt_rmtdk',
                        'idExV' => $data[1]
                    ]
                ],
                //order by
                [],
                //join
                []
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmplabt_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}