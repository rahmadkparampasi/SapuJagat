<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\RmicdtMdl;

use DateTime;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Reader\Xls as Reader;

class Rmicdt extends BaseController
{
    use ResponseTrait;
    protected $MdlRmicdt;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlRmicdt = new RmicdtMdl();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeng',
            'pAct' => 'pAPeng',
            'cAct' => 'cArmicdt',
            'cmAct' => 'cmArmref',
            'scAct' => 'scArmk',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA ICD - 10';
        $this->data['PageTitle'] = 'Data ICD - 10';
        $this->data['BasePage'] = 'rmicdt';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData';
        $this->data['IdForm'] = 'rmicdtAddData';
        $this->data['UrlForm'] = 'rmicdt';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);


        $this->data['Rmicdt'] = $this->MdlRmicdt->getAllRmicdt();
        echo view('Rmicdt/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }

    public function editData($rs_psp_id_ex = '')
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA STATUS PEGAWAI';
        $this->data['PageTitle'] = 'Data Status Pegawai';
        $this->data['BasePage'] = 'psp';
        $this->data['ButtonMethod'] = 'UBAH';
        $this->data['MethodForm'] = 'updateData/' . $rs_psp_id_ex;
        $this->data['IdForm'] = 'pspAddData';
        $this->data['UrlForm'] = 'psp';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);


        $this->data['Psp'] = $this->MdlPsp->getAllPsp();
        if ($rs_psp_id_ex === null || $rs_psp_id_ex == '') {
            return redirect()->to('/' . $this->data['BasePage']);
        } else {
            $this->data['fillUpdate'] = $this->MdlPsp->getAllPsp($rs_psp_id_ex);

            echo view('Psp/index', $this->data);
            echo view('Templates/anotherScript');
            echo view('Templates/ajaxInsert', $this->data);
            echo view('Templates/loadData');
        }
    }

    public function getRmicdtByJson($name = '', $idEx = '')
    {
        header('Content-Type: application/json');
        header("Access-Control-Allow-Origin: *");

        if ($name == "" || $idEx == "") {
            $this->data['data']['data'] = [];
        } else {
            $this->data['data']['data'] = $this->MdlRmicdt->getAllRmicdt();
            $no = 0;
            for ($i = 0; $i < count($this->data['data']['data']); $i++) {
                $no++;
                $this->data['data']['data'][$i]['no'] = $no;
                $this->data['data']['data'][$i]['button'] = "<button class='btn bg-gradient-success' title='Tambahkan ICD 10 Ke Diagnosa Pasien' data-dismiss='modal' onclick='addFill(\"" . $name . "\", \"" . $this->data['data']['data'][$i]['rs_rmicdt_kd'] . "-" . $this->data['data']['data'][$i]['rs_rmicdt_nm'] . "\"); addFill(\"" . $idEx . "\", \"" . $this->data['data']['data'][$i]['rs_rmicdt_id_ex'] . "\"); destroyIcdt(); closeModal(\"modalViewRmIcdt\")'><i class='fas fa-check'></i></button>";
            }
        }

        return $this->respond($this->data['data'], 200);
    }

    public function insertData()
    {
        date_default_timezone_set("Asia/Makassar");

        $ExcelReader = new Reader();
        $file = $this->request->getFile('excelFile');
        $fileLocation = $file->getTempName();
        $objPhpExcel = $ExcelReader->load($fileLocation);
        $sheet = $objPhpExcel->getActiveSheet()->toArray(null, true, true, true);

        $success = 0;
        $error = 0;
        $count = count($sheet) + 1;
        for ($i = 1; $i < $count; $i++) {
            if ((string)$sheet[$i]['B'] == "" || (string)$sheet[$i]['B'] == null) {
                $rs_rmicdt_kd = $sheet[$i]['A'];
            } else {
                $rs_rmicdt_kd = $sheet[$i]['A'] . "." . (string)$sheet[$i]['B'];
            }
            if ((string)$sheet[$i]['D'] == "" || (string)$sheet[$i]['D'] == null) {
                $rs_rmicdt_nm = $sheet[$i]['C'];
            } else {
                $rs_rmicdt_nm = $sheet[$i]['D'];
            }
            $rs_rmicdt_id_ex  = $this->MdlRmicdt->getIdEx($this->Another_Include->getRandStr(3));

            $data = [
                'rs_rmicdt_id_ex ' => $rs_rmicdt_id_ex,
                'rs_rmicdt_kd' => $rs_rmicdt_kd,
                'rs_rmicdt_nm' => $rs_rmicdt_nm,
            ];
            $insertData = $this->MdlRmicdt->insertData($data);
            if ($insertData) {
                $success += 1;
            } else {
                $error += 1;
            }
        }
        $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Berhasil Diproses, Dengan Data Yang Berhasil Berjumlah ' . (string)$success . ' Data, Dan Yang Tidak Berhasil Berjumlah ' . (string)$error . ' Data'];
        return $this->respond($data, $data['status']);
    }
    // public function insertData()
    // {
    //     $rs_rmicdt_id_ex  = $this->Another_Include->getRandStr(5);
    //     $rs_rmicdt_kd = strtoupper($this->request->getPost('rs_rmicdt_kd'));
    //     $rs_rmicdt_nm = strtoupper($this->request->getPost('rs_rmicdt_nm'));
    //     $data = [
    //         'rs_rmicdt_id_ex ' => $rs_rmicdt_id_ex,
    //         'rs_rmicdt_kd' => $rs_rmicdt_kd,
    //         'rs_rmicdt_nm' => $rs_rmicdt_nm,
    //     ];
    //     $insertData = $this->MdlRmicdt->insertData($data);
    //     if ($insertData) {
    //         $data = ['status' => 200, 'response' => 'success', 'message' => 'Data ICD - 10 Berhasil Disimpan'];
    //     } else {
    //         $data = ['status' => 500, 'response' => 'error', 'message' => 'Data ICD - 10 Tidak Dapat Disimpan'];
    //     }
    //     return $this->respond($data, $data['status']);
    // }

    public function updateData($rs_psp_id_ex = '')
    {
        $rs_psp_nm = $this->request->getPost('rs_psp_nm');
        $rs_psp_id_ex = $this->request->getPost('rs_psp_id_ex');
        $data = [
            'rs_psp_nm' => $rs_psp_nm,
        ];
        $updateData = $this->MdlPsp->updateData($data, $rs_psp_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Status Pegawai Berhasil Diubah'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Status Pegawai Tidak Dapat Diubah'];
        }
        return $this->respond($data, $data['status']);
    }



    public function deleteData($rs_psp_id_ex = '')
    {
        if ($rs_psp_id_ex === null || $rs_psp_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlPsp->deleteData($rs_psp_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Status Pegawai Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Status Pegawai Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }
}
