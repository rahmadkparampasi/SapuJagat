<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\RmphMdl;
use App\Models\RmpmskMdl;
use App\Models\UmMdl;

class Rmprk extends BaseController
{
    use ResponseTrait;
    protected $MdlRmpmsk;
    protected $MdlU;
    protected $MdlRmph;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlRmpmsk = new RmpmskMdl();
        $this->MdlU = new UmMdl('rs_rmprk', 'rs_rmprk_id_ex');
        $this->MdlRmph = new RmphMdl();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOIgd',
            'pAct' => 'pAIgd',
            'cAct' => 'cArmpmsk',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {

        return redirect()->to('./rmpmsk');
    }

    public function getAll($rs_rmprk_rmpmsk)
    {
        $data = $this->setDB('getAll', $rs_rmprk_rmpmsk);
        $data = $this->Another_Include->changeDateWF($data, ['rs_rmprk_tgl']);
        for ($i = 0; $i < count($data); $i++) {
            if ($data[$i]['rs_ppeg_nmd'] != "") {
                $data[$i]['rs_ppeg_nm'] = $data[$i]['rs_ppeg_nmd'] . ". " . $data[$i]['rs_ppeg_nm'];
            }

            if ($data[$i]['rs_ppeg_nmb'] != "") {
                $data[$i]['rs_ppeg_nm'] = $data[$i]['rs_ppeg_nm'] . ", " . $data[$i]['rs_ppeg_nmb'];
            }
        }
        return $data;
    }

    public function insertData($rs_rmprk_rmpmsk)
    {
        $this->data['Rmpmsk'] = $this->MdlRmpmsk->getAllRmpmsk($rs_rmprk_rmpmsk);

        $rs_rmph_id_ex = $this->Another_Include->getRandStr(35);
        $rs_rmph_rmpp = $this->data['Rmpmsk']['rs_rmpmsk_rmpp'];
        $rs_rmph_ppeg = $this->data['rs_ppeg_id_ex'];
        $rs_rmph_jns = "CT";

        $rs_rmprk_id_ex = $this->setDB('idEx', $this->Another_Include->getRandStr(11));
        $rs_rmprk_tgl = $this->request->getPost('rs_rmprk_tgl');
        $rs_rmprk_jam = $this->request->getPost('rs_rmprk_jam');
        $rs_rmprk_rmjr = $this->request->getPost('rs_rmprk_rmjr');
        $rs_rmprk_rmppk = $this->request->getPost('rs_rmprk_rmppk');
        $rs_rmprk_rmrr = $this->request->getPost('rs_rmprk_rmrr');
        $rs_rmprk_rmicdt = $this->request->getPost('rs_rmprk_rmicdt');
        $rs_rmprk_ppeg = $this->request->getPost('rs_rmprk_ppeg');
        $rs_rmprk_ket = $this->request->getPost('rs_rmprk_ket');

        $dataRmprk = [
            'rs_rmprk_id_ex' => $rs_rmprk_id_ex,
            'rs_rmprk_rmpmsk' => $rs_rmprk_rmpmsk,
            'rs_rmprk_rmph' => $rs_rmph_id_ex,
            'rs_rmprk_tgl' => $rs_rmprk_tgl,
            'rs_rmprk_jam' => $rs_rmprk_jam,
            'rs_rmprk_rmjr' => $rs_rmprk_rmjr,
            'rs_rmprk_rmppk' => $rs_rmprk_rmppk,
            'rs_rmprk_rmrr' => $rs_rmprk_rmrr,
            'rs_rmprk_rmicdt' => $rs_rmprk_rmicdt,
            'rs_rmprk_ppeg' => $rs_rmprk_ppeg,
            'rs_rmprk_ket' => $rs_rmprk_ket,
        ];
        $dataRmpmsk = [
            'rs_rmpmsk_plg' => '1'
        ];

        $dataRmph = [
            'rs_rmph_id_ex' => $rs_rmph_id_ex,
            'rs_rmph_rmpp' => $rs_rmph_rmpp,
            'rs_rmph_ppeg' => $rs_rmph_ppeg,
            'rs_rmph_jns' => $rs_rmph_jns
        ];
        $updateDataRmpmsk = $this->MdlRmpmsk->updateData($dataRmpmsk, $rs_rmprk_rmpmsk);
        if ($updateDataRmpmsk) {
            $insertDataRmph = $this->MdlRmph->insertData($dataRmph);
            if ($insertDataRmph) {
                $insertDataRmprk = $this->MdlU->insertData($dataRmprk);
                if ($insertDataRmprk) {
                    $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Rujukan Keluar Pasien Berhasil Disimpan'];
                } else {
                    $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Rujukan Keluar Pasien Tidak Dapat Disimpan'];
                }
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Histori Pasien Tidak Dapat Disimpan'];
            }
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Pasien Masuk Pasien Tidak Dapat Disimpan'];
        }



        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmprk_id_ex = '')
    {
        if ($rs_rmprk_id_ex === null || $rs_rmprk_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlU->deleteData($rs_rmprk_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Rujukan Keluar Pasien Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Rujukan Keluar Pasien Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmprk_id_ex';
        $id = 'rs_rmprk_id';
        $length = 4;
        $typeGet = 'result';

        $fillUpdate = '*';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmprk_rmpmsk',
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmprk_id', 'orderType' => 'ASC'],
                ],
                //join
                [

                    0 => ['tableName' => 'rs_rmjr', 'string' => 'rs_rmjr.rs_rmjr_id_ex = rs_rmprk.rs_rmprk_rmjr', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_ppeg', 'string' => 'rs_ppeg.rs_ppeg_id_ex = rs_rmprk.rs_rmprk_ppeg', 'type' => 'LEFT'],
                    2 => ['tableName' => 'rs_rmppk', 'string' => 'rs_rmppk.rs_rmppk_id_ex = rs_rmprk.rs_rmprk_rmppk', 'type' => 'LEFT'],
                    3 => ['tableName' => 'rs_rmrr', 'string' => 'rs_rmrr.rs_rmrr_id_ex = rs_rmprk.rs_rmprk_rmrr', 'type' => 'LEFT'],
                    4 => ['tableName' => 'rs_rmicdt', 'string' => 'rs_rmicdt.rs_rmicdt_id_ex = rs_rmprk.rs_rmprk_rmicdt', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmprk_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}