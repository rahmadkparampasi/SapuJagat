<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\UmMdl;

class Rmref extends BaseController
{
    use ResponseTrait;
    protected $MdlU;
    protected $AI;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_rmck', 'rs_rmck_id_ex');
        $this->AI = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeng',
            'pAct' => 'pAPeng',
            'cAct' => 'cArmref',
            'cmAct' => '',
            'scAct' => '',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA REFERENSI';
        $this->data['PageTitle'] = 'Data Referensi';
        $this->data['BasePage'] = 'rmref';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData';
        $this->data['IdForm'] = 'rmrefAddData';
        $this->data['UrlForm'] = 'rmref';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);

        echo view('Rmref/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }
}