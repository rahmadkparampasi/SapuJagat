<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\PsbbMdl;
use App\Models\PspMdl;

class Psbb extends BaseController
{
    use ResponseTrait;
    protected $MdlPsbb;
    protected $MdlPsp;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlPsbb = new PsbbMdl();
        $this->MdlPsp = new PspMdl();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeg',
            'pAct' => 'pAPeg',
            'cAct' => 'cAPpeg',
            'cmAct' => '',
            'scAct' => '',
            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index($rs_psbb_psp = false)
    {
        // if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
        //     return redirect()->to('./msk');
        // }

        if ($rs_psbb_psp === false) {
            return redirect()->to('/psp');
        }
        $this->data['rs_psbb_psp'] = $rs_psbb_psp;
        $this->data['Psp'] = $this->MdlPsp->getAllPsp($rs_psbb_psp);
        $this->data['WebTitle'] = 'DATA STATUS BERKAS BERKALA ' . $this->data['Psp']['rs_psp_nm'];
        $this->data['PageTitle'] = 'Data Status Berkas Berkala ' . $this->data['Psp']['rs_psp_nm'];
        $this->data['BasePage'] = 'psbb';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData/' . $rs_psbb_psp;
        $this->data['IdForm'] = 'psbbAddData';
        $this->data['UrlForm'] = 'psbb/' . $rs_psbb_psp;

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);


        $this->data['Psbb'] = $this->MdlPsbb->getAllPsbb($rs_psbb_psp);

        for ($i = 0; $i < count($this->data['Psbb']); $i++) {
            if ($this->data['Psbb'][$i]['rs_psbb_wjb'] == "0") {
                $this->data['Psbb'][$i]['rs_psbb_wjb'] = "TIDAK WAJIB";
            } else {
                $this->data['Psbb'][$i]['rs_psbb_wjb'] = "WAJIB";
            }
        }
        echo view('Psbb/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }

    public function editData($rs_psbb_psp = '', $rs_psbb_id_ex = '')
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }

        if ($rs_psbb_psp === '') {
            return redirect()->to('/psp');
        }

        if ($rs_psbb_id_ex === '') {
            return redirect()->to('/psbb/' . $rs_psbb_psp);
        }

        $this->data['rs_psbb_psp'] = $rs_psbb_psp;
        $this->data['Psp'] = $this->MdlPsp->getAllPsp($rs_psbb_psp);
        if (empty($this->data['Psp'])) {
            return redirect()->to('/psp');
        }
        $this->data['WebTitle'] = 'DATA STATUS BERKAS BERKALA KATEGORI ' . $this->data['Psp']['rs_psp_nm'];
        $this->data['PageTitle'] = 'Data Status Berkas Berkala Kategori ' . $this->data['Psp']['rs_psp_nm'];
        $this->data['BasePage'] = 'psbb';
        $this->data['ButtonMethod'] = 'UBAH';
        $this->data['MethodForm'] = 'updateData/' . $rs_psbb_psp;
        $this->data['IdForm'] = 'psbbAddData';
        $this->data['UrlForm'] = 'psbb/' . $rs_psbb_psp;

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);

        $this->data['fillUpdate'] = $this->MdlPsbb->getAllPsbb($rs_psbb_psp, $rs_psbb_id_ex);
        $this->data['Psbb'] = $this->MdlPsbb->getAllPsbb($rs_psbb_psp);
        echo view('Psbb/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
        echo view('Templates/loadData');
    }

    public function insertData($rs_psbb_psp)
    {
        $rs_psbb_id_ex = $this->Another_Include->getRandStr(6);
        $rs_psbb_nm = $this->request->getPost('rs_psbb_nm');
        $rs_psbb_jw = $this->request->getPost('rs_psbb_jw');
        $rs_psbb_jk = $this->request->getPost('rs_psbb_jk');
        $rs_psbb_wjb = $this->request->getPost('rs_psbb_wjb');
        $data = [
            'rs_psbb_id_ex' => $rs_psbb_id_ex,
            'rs_psbb_psp' => $rs_psbb_psp,
            'rs_psbb_nm' => $rs_psbb_nm,
            'rs_psbb_jw' => $rs_psbb_jw,
            'rs_psbb_jk' => $rs_psbb_jk,
            'rs_psbb_wjb' => $rs_psbb_wjb,
        ];
        $insertData = $this->MdlPsbb->insertData($data);
        if ($insertData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Status Berkas Berkala Pegawai Berhasil Disimpan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Status Berkas Berkala Pegawai Tidak Dapat Disimpan'];
        }
        return $this->respond($data, $data['status']);
    }

    public function updateData()
    {
        $rs_psbb_nm = $this->request->getPost('rs_psbb_nm');
        $rs_psbb_jw = $this->request->getPost('rs_psbb_jw');
        $rs_psbb_jk = $this->request->getPost('rs_psbb_jk');
        $rs_psbb_wjb = $this->request->getPost('rs_psbb_wjb');
        $rs_psbb_id_ex = $this->request->getPost('rs_psbb_id_ex');
        $data = [
            'rs_psbb_nm' => $rs_psbb_nm,
            'rs_psbb_jw' => $rs_psbb_jw,
            'rs_psbb_jk' => $rs_psbb_jk,
            'rs_psbb_wjb' => $rs_psbb_wjb,
        ];
        $updateData = $this->MdlPsbb->updateData($data, $rs_psbb_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Status Berkas Berkala Pegawai Berhasil Diubah'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Status Berkas Berkala Pegawai Tidak Dapat Diubah'];
        }
        return $this->respond($data, $data['status']);
    }



    public function deleteData($rs_psbb_id_ex = '')
    {
        if ($rs_psbb_id_ex === null || $rs_psbb_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlPsbb->deleteData($rs_psbb_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Status Berkas Berkala Pegawai Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Status Berkas Berkala Pegawai Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }
}
