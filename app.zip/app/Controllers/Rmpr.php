<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\UmMdl;

class Rmpr extends BaseController
{
    use ResponseTrait;
    protected $MdlU;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_rmpr', 'rs_rmpr_id_ex');
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mORm',
            'pAct' => 'pARm',
            'cAct' => 'cArmpp',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];

        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function gbRmpmsk($rs_rmpr_rmpmsk)
    {
        return $this->setDB('getAllByRmpmsk', $rs_rmpr_rmpmsk);
    }
    public function i($data)
    {

        $rs_rmpr_id_ex = $this->setDB('idEx', $this->Another_Include->getRandStr(7));
        $data['rs_rmpr_id_ex'] = $rs_rmpr_id_ex;

        $feedback = false;
        $insertData = $this->MdlU->insertData($data);
        if ($insertData) {
            $feedback = true;
        } else {
            $feedback = false;
        }
        $data = [$feedback, $rs_rmpr_id_ex];
        return $data;
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmpr_id_ex';
        $id = 'rs_rmpr_id';
        $length = 3;
        $typeGet = 'result';

        $fillUpdate = '';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [],
                //order by
                [
                    0 => ['id' => 'rs_rmpr_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'getAllByRmpmsk') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmpr_rmpmsk',
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpr_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmprtt', 'string' => 'rs_rmprtt.rs_rmprtt_rmpr = rs_rmpr.rs_rmpr_id_ex', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_rmrkkt', 'string' => 'rs_rmrkkt.rs_rmrkkt_id_ex = rs_rmprtt.rs_rmprtt_rmrkkt', 'type' => 'LEFT'],
                    2 => ['tableName' => 'rs_rmrkk', 'string' => 'rs_rmrkk.rs_rmrkk_id_ex = rs_rmrkkt.rs_rmrkkt_rmrkk', 'type' => 'LEFT'],
                    3 => ['tableName' => 'rs_rmrk', 'string' => 'rs_rmrk.rs_rmrk_id_ex = rs_rmrkk.rs_rmrkk_rmrk', 'type' => 'LEFT'],
                    4 => ['tableName' => 'rs_rmk', 'string' => 'rs_rmk.rs_rmk_id_ex = rs_rmrk.rs_rmrk_rmk', 'type' => 'LEFT'],
                    5 => ['tableName' => 'rs_rmr', 'string' => 'rs_rmr.rs_rmr_id_ex = rs_rmpr.rs_rmpr_rmr', 'type' => 'LEFT'],
                ],
                //like
                [],
                //group
                [
                    0 => ['id' => 'rs_rmr_id_ex']
                ]
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpr_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}