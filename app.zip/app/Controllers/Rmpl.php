<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\RmphMdl;
use App\Models\RmpmskMdl;
use App\Models\UmMdl;

class Rmpl extends BaseController
{
    use ResponseTrait;
    protected $MdlRmpmsk;
    protected $Rmplp;
    protected $MdlU;
    protected $MdlRmph;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlRmpmsk = new RmpmskMdl();
        $this->Rmplp = new Rmplp();
        $this->MdlU = new UmMdl('rs_rmpl', 'rs_rmpl_id_ex');
        $this->MdlRmph = new RmphMdl();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOIgd',
            'pAct' => 'pAIgd',
            'cAct' => 'cArmpmsk',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {

        return redirect()->to('./rmpmsk');
    }

    public function getAll($rs_rmpl_rmpmsk)
    {
        $data = $this->setDB('getAll', $rs_rmpl_rmpmsk);
        $data = $this->Another_Include->changeDateWF($data, ['rs_rmpl_tgl']);
        for ($i = 0; $i < count($data); $i++) {
            $data[$i]['rmplp'] = $this->Rmplp->getAll($data[$i]['rs_rmpl_id_ex']);
        }
        return $data;
    }

    public function insertData($rs_rmpl_rmpmsk)
    {
        $this->data['Rmpmsk'] = $this->MdlRmpmsk->getAllRmpmsk($rs_rmpl_rmpmsk);

        $rs_rmph_id_ex = $this->Another_Include->getRandStr(35);
        $rs_rmph_rmpp = $this->data['Rmpmsk']['rs_rmpmsk_rmpp'];
        $rs_rmph_ppeg = $this->data['rs_ppeg_id_ex'];
        $rs_rmph_jns = "CT";

        $rs_rmpl_id_ex = $this->setDB('idEx', $this->Another_Include->getRandStr(7));
        $rs_rmpl_tgl = $this->request->getPost('rs_rmpl_tgl');
        $rs_rmpl_jam = $this->request->getPost('rs_rmpl_jam');
        $rs_rmpl_rmtdk = $this->request->getPost('rs_rmpl_rmtdk');

        $dataRmpl = [
            'rs_rmpl_id_ex' => $rs_rmpl_id_ex,
            'rs_rmpl_rmpmsk' => $rs_rmpl_rmpmsk,
            'rs_rmpl_rmph' => $rs_rmph_id_ex,
            'rs_rmpl_tgl' => $rs_rmpl_tgl,
            'rs_rmpl_jam' => $rs_rmpl_jam,
            'rs_rmpl_rmtdk' => $rs_rmpl_rmtdk,
        ];

        $dataRmph = [
            'rs_rmph_id_ex' => $rs_rmph_id_ex,
            'rs_rmph_rmpp' => $rs_rmph_rmpp,
            'rs_rmph_ppeg' => $rs_rmph_ppeg,
            'rs_rmph_jns' => $rs_rmph_jns
        ];

        $insertDataRmph = $this->MdlRmph->insertData($dataRmph);
        if ($insertDataRmph) {
            $insertDataRmPl = $this->MdlU->insertData($dataRmpl);
            if ($insertDataRmPl) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Layanan Pasien Berhasil Disimpan'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Layanan Pasien Tidak Dapat Disimpan'];
            }
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Histori Pasien Tidak Dapat Disimpan'];
        }



        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmpl_id_ex = '')
    {
        if ($rs_rmpl_id_ex === null || $rs_rmpl_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlU->deleteData($rs_rmpl_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Layanan Pasien Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Layanan Pasien Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmpl_id_ex';
        $id = 'rs_rmpl_id';
        $length = 3;
        $typeGet = 'result';

        $fillUpdate = '*';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmpl_rmpmsk',
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpl_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmtdk', 'string' => 'rs_rmtdk.rs_rmtdk_id_ex = rs_rmpl.rs_rmpl_rmtdk', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'getAllWH') {
            $data = $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmpl_rmpmsk',
                        'idExV' => $data
                    ],
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpl_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmtdk', 'string' => 'rs_rmtdk.rs_rmtdk_id_ex = rs_rmpl.rs_rmpl_rmtdk', 'type' => 'LEFT'],
                ]
            );
            return $this->Another_Include->rupiahWF($data, ['rs_rmtdk_h']);
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpl_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}