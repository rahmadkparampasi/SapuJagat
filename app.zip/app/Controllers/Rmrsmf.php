<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\RmrMdl;
use App\Models\UmMdl;

class Rmrsmf extends BaseController
{
    use ResponseTrait;
    protected $MdlU;
    protected $MdlRmr;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_rmrsmf', 'rs_rmrsmf_id_ex');
        $this->MdlRmr = new RmrMdl();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeng',
            'pAct' => 'pAPeng',
            'cAct' => 'cArmr',
            'cmAct' => '',
            'scAct' => '',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
    }

    public function viewData($rs_rmrsmf_rmr = '')
    {
        if ($rs_rmrsmf_rmr == '') {
            echo "<span class='badge badge-danger'>Tidak Ada Daftar Tindakan Dalam Ruangan</span>";
        } else {
            $this->data['Rmr'] = $this->MdlRmr->getAllRmr($rs_rmrsmf_rmr);
            $this->data['WebTitle'] = 'DATA STAF MEDIS FUNGSIONAL DALAM RUANGAN ' . strtoupper($this->data['Rmr']['rs_rmr_nm']);
            $this->data['PageTitle'] = 'Data Staf Medis Fungsional Dalam Ruangan ' . $this->data['Rmr']['rs_rmr_nm'];
            $this->data['BasePage'] = 'rmrsmf';
            $this->data['ButtonMethod'] = 'SIMPAN';
            $this->data['MethodForm'] = 'insertView/' . $rs_rmrsmf_rmr;
            $this->data['IdForm'] = 'rmrsmfAddData';
            $this->data['UrlForm'] = 'rmrsmf';
            $this->data['Rmrsmf'] = $this->setDB('getAll', $rs_rmrsmf_rmr);
            echo view('Rmrsmf/index', $this->data);
            echo view('Templates/ajaxInsert', $this->data);
        }
    }

    public function getAllForSelect($rs_rmrsmf_rmr)
    {
        header("Content-Type:application/json;charset=utf-8");
        header("Access-Control-Allow-Origin: *");


        $data = $this->setDB('getAll', $rs_rmrsmf_rmr);
        for ($i = 0; $i < count($data); $i++) {
            $data[$i]['optText'] = $data[$i]['rs_rmsmf_nm'];
            $data[$i]['optValue'] = $data[$i]['rs_rmsmf_id_ex'];
        }
        return $this->respond($data, 200);
    }

    public function insertData($rs_rmrsmf_rmr, $rs_rmrsmf_rmsmf)
    {
        if ($rs_rmrsmf_rmr === null || $rs_rmrsmf_rmr == '' || $rs_rmrsmf_rmsmf === null || $rs_rmrsmf_rmsmf == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'TIdak Ada ID Rujukan'];
        } else {
            $data = [
                'rs_rmrsmf_id_ex' => $this->setDB('idEx', $this->Another_Include->getRandStr(5)),
                'rs_rmrsmf_rmr' => $rs_rmrsmf_rmr,
                'rs_rmrsmf_rmsmf' => $rs_rmrsmf_rmsmf,
            ];
            $this->data['Rmrsmf'] =  $this->setDB('getAllByRmrAndRmsmf', [$rs_rmrsmf_rmr, $rs_rmrsmf_rmsmf]);
            if (count($this->data['Rmrsmf']) > 0) {
                // $deleteData = $this->MdlPpr->deleteData($rs_ppr_ppeg);
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Staf Medis Fungsional Dalam Ruangan Ini Sudah Ada'];
            } else {
                $insertData = $this->MdlU->insertData($data);

                if ($insertData) {
                    $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Staf Medis Fungsional Dalam Ruangan Berhasil Disimpan'];
                } else {
                    $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Staf Medis Fungsional Dalam Ruangan Tidak Dapat Disimpan'];
                }
            }
        }

        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmrsmf_id_ex = '')
    {
        if ($rs_rmrsmf_id_ex === null || $rs_rmrsmf_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlRmrtdk->deleteData($rs_rmrsmf_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data TIndakan Dalam Ruangan Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data TIndakan Dalam Ruangan Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmrsmf_id_ex';
        $id = 'rs_rmrsmf_id';
        $length = 2;
        $typeGet = 'result';

        $fillUpdate = 'rs_rmrsmf_id_ex';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => ['idEx' => 'rs_rmrsmf_rmr', 'idExV' => $data]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmrsmf_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmsmf', 'string' => 'rs_rmsmf.rs_rmsmf_id_ex = rs_rmrsmf.rs_rmrsmf_rmsmf', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'getAllByAct') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => ['idEx' => 'rs_rmrsmf_sts', 'idExV' => '1']
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmrsmf_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'getAllByRmrAndRmsmf') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => ['idEx' => 'rs_rmrsmf_rmr', 'idExV' => $data[0]],
                    1 => ['idEx' => 'rs_rmrsmf_rmsmf', 'idExV' => $data[1]]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmrsmf_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmrsmf_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}