<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\UmMdl;

class Rmsmf extends BaseController
{
    use ResponseTrait;
    protected $MdlU;
    protected $AI;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_rmsmf', 'rs_rmsmf_id_ex');
        $this->AI = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeng',
            'pAct' => 'pAPeng',
            'cAct' => 'cArmref',
            'cmAct' => 'cmArmref',
            'scAct' => 'scArmsmf',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA JENIS STAF MEDIS FUNGSIONAL';
        $this->data['PageTitle'] = 'Data Jenis Staf Medis Fungsional';
        $this->data['BasePage'] = 'rmsmf';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData';
        $this->data['IdForm'] = 'rmsmfAddData';
        $this->data['UrlForm'] = 'rmsmf';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);


        $this->data['Rmsmf'] = $this->setDB();

        echo view('Rmsmf/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }

    public function editData($rs_rmsmf_id_ex = '')
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA JENIS STAF MEDIS FUNGSIONAL';
        $this->data['PageTitle'] = 'Data Jenis Staf Medis Fungsional';
        $this->data['BasePage'] = 'rmsmf';
        $this->data['ButtonMethod'] = 'UBAH';
        $this->data['MethodForm'] = 'updateData/' . $rs_rmsmf_id_ex;
        $this->data['IdForm'] = 'rmsmfAddData';
        $this->data['UrlForm'] = 'rmsmf';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);

        $this->data['Rmsmf'] = $this->setDB();

        if ($rs_rmsmf_id_ex === null || $rs_rmsmf_id_ex == '') {
            return redirect()->to('/' . $this->data['BasePage']);
        } else {
            $this->data['fillUpdate'] = $this->setDB('fillUpdate', $rs_rmsmf_id_ex);

            echo view('Rmsmf/index', $this->data);
            echo view('Templates/anotherScript');
            echo view('Templates/ajaxInsert', $this->data);
            echo view('Templates/loadData');
        }
    }

    public function getRmsmfByJson($rs_rmr_id_ex)
    {
        header('Content-Type: application/json');
        header("Access-Control-Allow-Origin: *");
        $this->data['data']['data'] = $this->setDB();
        $no = 0;
        for ($i = 0; $i < count($this->data['data']['data']); $i++) {
            $no++;

            $this->data['data']['data'][$i]['button'] = "<button class='btn bg-gradient-success' title='Tambahkan Staf Medis Fungsional Ke Dalam Ruangan' onclick='addWF(\"Menambahkan " . $this->data['data']['data'][$i]['rs_rmsmf_nm'] . " Dalam Data Ruangan\", \"/" . "rmrsmf/insertData/" . $rs_rmr_id_ex . "/" . $this->data['data']['data'][$i]['rs_rmsmf_id_ex'] . "\", loadTabSmf)'><i class='fas fa-check'></i></button>";
            $this->data['data']['data'][$i]['no'] = $no;
        }
        return $this->respond($this->data['data'], 200);
    }

    public function getAll()
    {
        return $this->setDB('getAllByAct');
    }

    public function insertData()
    {

        $rs_rmsmf_id_ex = $this->setDB('idEx', $this->AI->getRandStr(3));
        $rs_rmsmf_nm = $this->request->getPost('rs_rmsmf_nm');

        $data = [
            'rs_rmsmf_id_ex' => $rs_rmsmf_id_ex,
            'rs_rmsmf_nm' => $rs_rmsmf_nm
        ];

        $insertData = $this->MdlU->insertData($data);
        if ($insertData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Jenis Staf Medis Fungsional Berhasil Disimpan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Jenis Staf Medis Fungsional Tidak Dapat Disimpan'];
        }

        return $this->respond($data, $data['status']);
    }


    public function updateData($rs_rmsmf_id_ex = '')
    {
        $rs_rmsmf_nm = $this->request->getPost('rs_rmsmf_nm');
        $rs_rmsmf_id_ex = $this->request->getPost('rs_rmsmf_id_ex');
        $data = [
            'rs_rmsmf_nm' => $rs_rmsmf_nm
        ];
        $updateData = $this->MdlU->updateData($data, $rs_rmsmf_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Jenis Staf Medis Fungsional Berhasil Diubah'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Jenis Staf Medis Fungsional Tidak Dapat Diubah'];
        }
        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmsmf_id_ex = '')
    {
        if ($rs_rmsmf_id_ex === null || $rs_rmsmf_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlU->deleteData($rs_rmsmf_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Jenis Staf Medis Fungsional Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Jenis Staf Medis Fungsional Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function block($rs_rmsmf_id_ex = '')
    {
        $data = [
            'rs_rmsmf_sts' => "0",
        ];
        $updateData = $this->MdlU->updateData($data, $rs_rmsmf_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Status Jenis Staf Medis Fungsional Berhasil Di Dinonaktifkan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Status Jenis Staf Medis Fungsional Tidak Dapat Di Dinonaktifkan'];
        }
        return $this->respond($data, $data['status']);
    }

    public function unblock($rs_rmsmf_id_ex = '')
    {
        $data = [
            'rs_rmsmf_sts' => "1",
        ];
        $updateData = $this->MdlU->updateData($data, $rs_rmsmf_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Status Jenis Staf Medis Fungsional Berhasil Aktifkan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Status Jenis Staf Medis Fungsional Tidak Dapat Aktifkan'];
        }
        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmsmf_id_ex';
        $id = 'rs_rmsmf_id';
        $length = 2;
        $typeGet = 'result';

        $fillUpdate = 'rs_rmsmf_id_ex, rs_rmsmf_nm';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [],
                //order by
                [
                    0 => ['id' => 'rs_rmsmf_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'getAllByAct') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => ['idEx' => 'rs_rmsmf_sts', 'idExV' => '1']
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmsmf_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmsmf_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}