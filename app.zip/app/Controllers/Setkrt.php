<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\UmMdl;

class Setkrt extends BaseController
{
    use ResponseTrait;
    protected $MdlU;
    protected $AI;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_setkrt', 'rs_setkrt_id_ex');
        $this->AI = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeng',
            'pAct' => 'pAPeng',
            'cAct' => 'cArmref',
            'cmAct' => 'cmArmref',
            'scAct' => 'scAsetkrt',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA GAMBAR KARTU';
        $this->data['PageTitle'] = 'Data Gambar Kartu';
        $this->data['BasePage'] = 'setkrt';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData';
        $this->data['IdForm'] = 'setkrtAddData';
        $this->data['UrlForm'] = 'setkrt';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);


        $this->data['Setkrt'] = $this->setDB();

        echo view('Setkrt/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }

    public function ctkKrt($rs_setkrt_id_ex = '')
    {
        $this->data['rs_setkrt_id_ex'] = $rs_setkrt_id_ex;
        $this->data['WebTitle'] = 'CETAK GAMBAR KARTU';
        $this->data['PageTitle'] = 'Cetak Gambar Kartu';
        $this->data['BasePage'] = 'setkrt';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData/' . $rs_setkrt_id_ex;
        $this->data['IdForm'] = 'setkrtAddData';
        $this->data['UrlForm'] = 'setkrt/viewData/' . $rs_setkrt_id_ex;
        $this->data['Setkrt'] = $this->setDB('fillUpdate', $rs_setkrt_id_ex);

        echo view('Setkrt/indexCtkKrt', $this->data);
        // echo view('Templates/anotherScript');
    }

    public function getDpn()
    {
        return $this->setDB('getDpn');
    }


    public function insertData()
    {
        $validated = $this->validate([
            'rs_setkrt_fl' => 'uploaded[rs_setkrt_fl]|mime_in[rs_setkrt_fl,image/jpg,image/jpeg,image/gif,image/png]|max_size[rs_setkrt_fl,2048]'
        ]);
        if ($validated == FALSE) {
            // Kembali ke function index supaya membawa data uploads dan validasi
            $data = ['status' => 415, 'response' => "error", 'message' => 'Berkas Yang Diunggah Tidak Sesuai Spesifikasi'];
        } else {
            $rs_setkrt_id_ex = $this->setDB('idEx', $this->AI->getRandStr(3));
            $rs_setkrt_fl = $this->request->getFile('rs_setkrt_fl');
            $rs_setkrt_nm = $this->request->getPost('rs_setkrt_nm');

            $new_rs_setkrt_fl = "Setkrt-" . $rs_setkrt_id_ex . "-"  . date("YmdHis") . "." . $rs_setkrt_fl->getClientExtension();
            $data = [
                'rs_setkrt_id_ex' => $rs_setkrt_id_ex,
                'rs_setkrt_fl' => $new_rs_setkrt_fl,
                'rs_setkrt_nm' => $rs_setkrt_nm
            ];

            $insertData = $this->MdlU->insertData($data);
            if ($insertData) {
                $rs_setkrt_fl->move('uploads', $new_rs_setkrt_fl);
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Setup Gambar Kartu Berhasil Disimpan'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Setup Gambar Kartu Tidak Dapat Disimpan'];
            }
        }


        return $this->respond($data, $data['status']);
    }
    public function updateData()
    {
        $validated = $this->validate([
            'rs_setkrt_fl' => 'uploaded[rs_setkrt_fl]|mime_in[rs_setkrt_fl,image/jpg,image/jpeg,image/gif,image/png]|max_size[rs_setkrt_fl,2048]'
        ]);
        if ($validated == FALSE) {
            // Kembali ke function index supaya membawa data uploads dan validasi
            $data = ['status' => 415, 'response' => "error", 'message' => 'Berkas Yang Diunggah Tidak Sesuai Spesifikasi'];
        } else {
            $rs_setkrt_id_ex = $this->request->getPost('rs_setkrt_id_ex');
            $rs_setkrt_fl = $this->request->getFile('rs_setkrt_fl');

            $new_rs_setkrt_fl = "Setkrt-" . $rs_setkrt_id_ex . "-"  . date("YmdHis") . "." . $rs_setkrt_fl->getClientExtension();
            $data = [
                'rs_setkrt_fl' => $new_rs_setkrt_fl,
            ];

            $insertData = $this->MdlU->updateData($data, $rs_setkrt_id_ex);
            if ($insertData) {
                $rs_setkrt_fl->move('uploads', $new_rs_setkrt_fl);
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Setup Gambar Kartu Berhasil Diubah'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Setup Gambar Kartu Tidak Dapat Diubah'];
            }
        }


        return $this->respond($data, $data['status']);
    }



    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_setkrt_id_ex';
        $id = 'rs_setkrt_id';
        $length = 2;
        $typeGet = 'result';

        $fillUpdate = 'rs_setkrt_id_ex, rs_setkrt_nm, rs_setkrt_fl';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [],
                //order by
                [
                    0 => ['id' => 'rs_setkrt_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        }elseif ($request == 'getDpn') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                "rs_setkrt_fl",
                //where
                [
                    0 => [
                        'idEx' => "rs_setkrt_id",
                        'idExV' => 1
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_setkrt_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_setkrt_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}
