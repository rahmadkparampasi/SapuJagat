<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Controllers\Rmph;
use App\Models\RmpakspMdl;
use App\Models\RmpmskMdl;

class Rmpaksp extends BaseController
{
    use ResponseTrait;
    protected $MdlRmpmsk;
    protected $MdlRmpaksp;
    protected $Rmph;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlRmpmsk = new RmpmskMdl();
        $this->MdlRmpaksp = new RmpakspMdl();
        $this->Rmph = new Rmph();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOIgd',
            'pAct' => 'pAIgd',
            'cAct' => 'cArmpmsk',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {

        return redirect()->to('./rmpmsk');
    }

    public function insertData($rs_rmpaksp_rmpmsk)
    {
        $this->data['Rmpmsk'] = $this->MdlRmpmsk->getAllRmpmsk($rs_rmpaksp_rmpmsk);

        $insertDataRmph = $this->Rmph->iDH($this->data['Rmpmsk']['rs_rmpmsk_rmpp'], "CT");
        if ($insertDataRmph[0]) {
            $rs_rmpaksp_id_ex = $this->MdlRmpaksp->getIdEx($this->Another_Include->getRandStr(10));
            $rs_rmpaksp_ko = '';
            foreach ($this->request->getPost('rs_rmpaksp_ko') as $key) {
                $rs_rmpaksp_ko .= $key . ',';
            }
            $rs_rmpaksp_ln = $this->request->getPost('rs_rmpaksp_ln');
            $rs_rmpaksp_mp = $this->request->getPost('rs_rmpaksp_mp');

            $dataRmpAKSP = [
                'rs_rmpaksp_id_ex' => $rs_rmpaksp_id_ex,
                'rs_rmpaksp_rmpmsk' => $rs_rmpaksp_rmpmsk,
                'rs_rmpaksp_rmph' => $insertDataRmph[1],
                'rs_rmpaksp_ko' => $rs_rmpaksp_ko,
                'rs_rmpaksp_ln' => $rs_rmpaksp_ln,
                'rs_rmpaksp_mp' => $rs_rmpaksp_mp,
            ];
            $insertDataRmpAKSP = $this->MdlRmpaksp->insertData($dataRmpAKSP);
            if ($insertDataRmpAKSP) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Anamnesis Kondisi Sosial Dan Psikososial Pasien Berhasil Disimpan'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Anamnesis Kondisi Sosial Dan Psikososial Pasien Tidak Dapat Disimpan'];
            }
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Histori Pasien Tidak Dapat Disimpan'];
        }

        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmpaksp_id_ex = '')
    {
        if ($rs_rmpaksp_id_ex === null || $rs_rmpaksp_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlRmpaksp->deleteData($rs_rmpaksp_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Anamnesis Kondisi Sosial Dan Psikososial Pasien Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Anamnesis Kondisi Sosial Dan Psikososial Pasien Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }
}
