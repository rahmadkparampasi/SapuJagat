<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\UmMdl;

class Rmpradtw extends BaseController
{
    use ResponseTrait;

    protected $MdlU;
    protected $Rmpradt;
    protected $Rmpradtwp;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_rmpradtw', 'rs_rmpradtw_id_ex');
        $this->Rmpradt = new Rmpradt;
        $this->Rmpradtwp = new rmpradtwp;
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOIgd',
            'pAct' => 'pAIgd',
            'cAct' => 'cArmpmsk',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {

        return redirect()->to('./rmpmsk');
    }

    public function viewData($rs_rmpradtw_rmpradt = '', $rs_rmprad_tgl = '', $rs_rmprad_jam = '', $rs_rmtdk_nm = '')
    {
        if ($rs_rmpradtw_rmpradt == '') {
            echo "<span class='badge badge-danger'>Tidak Ada Daftar Tindakan Yang Dimaksud</span>";
        } else {
            $this->data['rs_rmpradtw_rmpradt'] = $rs_rmpradtw_rmpradt;
            $this->data['rs_rmprad_tgl'] = $rs_rmprad_tgl;
            $this->data['rs_rmprad_jam'] = $rs_rmprad_jam;
            $this->data['rs_rmtdk_nm'] = $rs_rmtdk_nm;
            $this->data['WebTitle'] = 'DAFTAR ORDER RADIOLOGI, TANGGAL ORDER : ' . strtoupper( $rs_rmprad_tgl . ', JAM ORDER : ' . $rs_rmprad_jam. ', DOKTER : ' . $rs_rmtdk_nm);
            $this->data['PageTitle'] = 'Daftar Order Radiologi, Tanggal Order : ' . $rs_rmprad_tgl . ', Jam Order : ' . $rs_rmprad_jam. ', Dokter : ' . $rs_rmtdk_nm;
            $this->data['BasePage'] = 'rmpradtw';
            $this->data['ButtonMethod'] = 'SIMPAN';
            $this->data['MethodForm'] = 'insertView/' . $rs_rmpradtw_rmpradt;
            $this->data['IdForm'] = 'rmpradtwAddData';
            $this->data['UrlForm'] = 'rmpradtw';
            $this->data['Rmpradtw'] = $this->setDB('getAll', $rs_rmpradtw_rmpradt);
            for ($i=0; $i < count($this->data['Rmpradtw']); $i++) { 
                $this->data['Rmpradtw'][$i]['Rmpradtwp'] = $this->Rmpradtwp->getAll($this->data['Rmpradtw'][$i]['rs_rmpradtw_id_ex']);
            }
            echo view('Rmpradtw/index', $this->data);
        }
    }

    public function getAll($rs_rmpradtw_rmpradt)
    {
        $this->data['Rmpradtw'] = $this->setDB('getAll', $rs_rmpradtw_rmpradt);

        return  $this->data['Rmpradtw'];
    }
    

    public function insertView($rs_rmpradtw_rmpradt)
    {
        $rs_rmpradtw_tgl = $this->request->getPost('rs_rmpradtw_tgl');
        $rs_rmpradtw_jam = $this->request->getPost('rs_rmpradtw_jam');
        

        $data = [
            'rs_rmpradtw_id_ex' => $this->setDB('idEx', $this->Another_Include->getRandStr(9)),
            'rs_rmpradtw_rmpradt' => $rs_rmpradtw_rmpradt,
            'rs_rmpradtw_tgl' => $rs_rmpradtw_tgl,
            'rs_rmpradtw_jam' => $rs_rmpradtw_jam,
        ];
        $dataRmpradt = [
            'rs_rmpradt_stj' => '1'
        ];

        
        $updateDataRmpradt = $this->Rmpradt->MdlU->updateData($dataRmpradt, $rs_rmpradtw_rmpradt);
        if ($updateDataRmpradt) {
            $insertDataupdateDataRmpradtw = $this->MdlU->insertData($data);
            if ($insertDataupdateDataRmpradtw) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Waktu Pemberian Tindakan Pasien Berhasil Disimpan'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Waktu Pemberian Tindakan Pasien Tidak Dapat Disimpan'];
            }
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Pasien Masuk Pasien Tidak Dapat Disimpan'];
        }

        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmpradtw_id_ex = '')
    {
        if ($rs_rmpradtw_id_ex === null || $rs_rmpradtw_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlU->deleteData($rs_rmpradtw_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Waktu Pemberian Tindakan Pasien Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Waktu Pemberian Tindakan Pasien Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmpradtw_id_ex';
        $id = 'rs_rmpradtw_id';
        $length = 3;
        $typeGet = 'result';

        $fillUpdate = '*';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmpradtw_rmpradt',
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpradtw_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmpradt', 'string' => 'rs_rmpradt.rs_rmpradt_id_ex = rs_rmpradtw.rs_rmpradtw_rmpradt', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_rmprad', 'string' => 'rs_rmprad.rs_rmprad_id_ex = rs_rmpradt.rs_rmpradt_rmprad', 'type' => 'LEFT'],
                ]
            );
        }elseif ($request == 'getAllByRmpmsk') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmprad_rmpmsk',
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpradt_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmprad', 'string' => 'rs_rmprad.rs_rmprad_id_ex = rs_rmpradt.rs_rmpradt_rmprad', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_ppeg', 'string' => 'rs_ppeg.rs_ppeg_id_ex = rs_rmprad.rs_rmprad_ppeg', 'type' => 'LEFT'],
                    2 => ['tableName' => 'rs_rmtdk', 'string' => 'rs_rmtdk.rs_rmtdk_id_ex = rs_rmpradt.rs_rmpradt_rmtdk', 'type' => 'LEFT'],
                    3 => ['tableName' => 'rs_rmktdk', 'string' => 'rs_rmktdk.rs_rmktdk_id_ex = rs_rmtdk.rs_rmtdk_rmktdk', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'getAllByRmplabAndTdk') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmpradt_rmplab',
                        'idExV' => $data[0]
                    ],
                    1 => [
                        'idEx' => 'rs_rmpradt_rmtdk',
                        'idExV' => $data[1]
                    ]
                ],
                //order by
                [],
                //join
                []
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpradt_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}