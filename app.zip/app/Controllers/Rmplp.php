<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\UmMdl;

class Rmplp extends BaseController
{
    use ResponseTrait;

    protected $MdlU;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_rmplp', 'rs_rmplp_id');
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOIgd',
            'pAct' => 'pAIgd',
            'cAct' => 'cArmpmsk',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {

        return redirect()->to('./rmpmsk');
    }

    public function getAll($rs_rmplp_rmpl)
    {
        $this->data['Rmplp'] = $this->setDB('getAll', $rs_rmplp_rmpl);
        for ($i = 0; $i < count($this->data['Rmplp']); $i++) {

            if ($this->data['Rmplp'][$i]['rs_ppeg_nmd'] != "") {
                $this->data['Rmplp'][$i]['rs_ppeg_nm'] = $this->data['Rmplp'][$i]['rs_ppeg_nmd'] . ". " . $this->data['Rmplp'][$i]['rs_ppeg_nm'];
            }

            if ($this->data['Rmplp'][$i]['rs_ppeg_nmb'] != "") {
                $this->data['Rmplp'][$i]['rs_ppeg_nm'] = $this->data['Rmplp'][$i]['rs_ppeg_nm'] . ", " . $this->data['Rmplp'][$i]['rs_ppeg_nmb'];
            }
        }
        return  $this->data['Rmplp'];
    }

    public function insertData()
    {
        $rs_rmplp_rmpl = $this->request->getPost('rs_rmplp_rmpl');
        $rs_rmplp_ppeg = $this->request->getPost('rs_rmplp_ppeg');
        if ($rs_rmplp_ppeg == null || empty($rs_rmplp_ppeg)) {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Pilih Terlebih Dahulu Data Pegawai'];
        } else {
            $success = 0;
            $error = 0;
            foreach ($this->request->getPost('rs_rmplp_ppeg') as $key) {
                $this->data['Rmplp'] = $this->setDB('getAllByRmplAndPpeg', [$rs_rmplp_rmpl, $key]);
                if ($this->data['Rmplp'] != null || count($this->data['Rmplp']) > 0) {
                    $error = $error + 1;
                } else {

                    $data = [
                        'rs_rmplp_rmpl' => $rs_rmplp_rmpl,
                        'rs_rmplp_ppeg' => $key,
                    ];
                    $insertData = $this->MdlU->insertData($data);
                    if ($insertData) {
                        $success = $success + 1;
                    } else {
                        $error = $error + 1;
                    }
                }
            }
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Tenaga Medis Layanan Pasien Berhasil Diproses, Dengan Jumlah Data Yang Berhasil Disimpan Berjumlah ' . (string)$success . ' Data, Dan Yang Gagal Disimpan Berjumlah ' . (string)$error . ' Data'];
        }

        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmplp_id = '')
    {
        if ($rs_rmplp_id === null || $rs_rmplp_id == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlU->deleteData($rs_rmplp_id);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Tenaga Medis Layanan Pasien Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Tenaga Medis Layanan Pasien Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmplp_id';
        $id = 'rs_rmplp_id';
        $length = 3;
        $typeGet = 'result';

        $fillUpdate = '*';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmplp_rmpl',
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmplp_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_ppeg', 'string' => 'rs_ppeg.rs_ppeg_id_ex = rs_rmplp.rs_rmplp_ppeg', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_pkp', 'string' => 'rs_pkp.rs_pkp_id_ex = rs_ppeg.rs_ppeg_pkp', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'getAllByRmplAndPpeg') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmplp_rmpl',
                        'idExV' => $data[0]
                    ],
                    1 => [
                        'idEx' => 'rs_rmplp_ppeg',
                        'idExV' => $data[1]
                    ]
                ],
                //order by
                [],
                //join
                []
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmplp_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}