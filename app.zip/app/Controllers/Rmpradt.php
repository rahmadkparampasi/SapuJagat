<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\UmMdl;

class Rmpradt extends BaseController
{
    use ResponseTrait;

    public $MdlU;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_rmpradt', 'rs_rmpradt_id');
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOIgd',
            'pAct' => 'pAIgd',
            'cAct' => 'cArmpmsk',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {

        return redirect()->to('./rmpmsk');
    }

    public function getAll($rs_rmpradt_rmprad)
    {
        $this->data['Rmplabt'] = $this->setDB('getAll', $rs_rmpradt_rmprad);

        return  $this->data['Rmplabt'];
    }

    public function getAllByRmpmsk($rs_rmplab_rmpmsk)
    {
        $this->data['Rmpradt'] = $this->setDB('getAllByRmpmsk', $rs_rmplab_rmpmsk);
        for ($i = 0; $i < count($this->data['Rmpradt']); $i++) {
            
            if ($this->data['Rmpradt'][$i]['rs_ppeg_nmd'] != "") {
                $this->data['Rmpradt'][$i]['rs_ppeg_nm'] = $this->data['Rmpradt'][$i]['rs_ppeg_nmd'] . ". " . $this->data['Rmpradt'][$i]['rs_ppeg_nm'];
            }

            if ($this->data['Rmpradt'][$i]['rs_ppeg_nmb'] != "") {
                $this->data['Rmpradt'][$i]['rs_ppeg_nm'] = $this->data['Rmpradt'][$i]['rs_ppeg_nm'] . ", " . $this->data['Rmpradt'][$i]['rs_ppeg_nmb'];
            }
        }

        return  $this->data['Rmpradt'];
    }

    public function insertData()
    {
        $rs_rmpradt_rmprad = $this->request->getPost('rs_rmplabt_rmplab');
        $rs_rmpradt_rmtdk = $this->request->getPost('rs_rmplabt_rmtdk');
        if ($rs_rmpradt_rmtdk == null || empty($rs_rmpradt_rmtdk)) {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Pilih Terlebih Dahulu Data Tindakan'];
        } else {
            $success = 0;
            $error = 0;
            foreach ($this->request->getPost('rs_rmplabt_rmtdk') as $key) {
                $this->data['Rmpradt'] = $this->setDB('getAllByRmpradAndTdk', [$rs_rmpradt_rmprad, $key]);
                if ($this->data['Rmpradt'] != null || count($this->data['Rmpradt']) > 0) {
                    $error = $error + 1;
                } else {

                    $data = [
                        'rs_rmpradt_id_ex' => $this->setDB('idEx', $this->Another_Include->getRandStr(8)),
                        'rs_rmpradt_rmprad' => $rs_rmpradt_rmprad,
                        'rs_rmpradt_rmtdk' => $key,
                    ];
                    $insertData = $this->MdlU->insertData($data);
                    if ($insertData) {
                        $success = $success + 1;
                    } else {
                        $error = $error + 1;
                    }
                }
            }
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Tindakan Radiologi Pasien Berhasil Diproses, Dengan Jumlah Data Yang Berhasil Disimpan Berjumlah ' . (string)$success . ' Data, Dan Yang Gagal Disimpan Berjumlah ' . (string)$error . ' Data'];
        }

        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmpradt_id = '')
    {
        if ($rs_rmpradt_id === null || $rs_rmpradt_id == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlU->deleteData($rs_rmpradt_id);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Tindakan Radiologi Pasien Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Tindakan Radiologi Pasien Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmpradt_id';
        $id = 'rs_rmpradt_id';
        $length = 3;
        $typeGet = 'result';

        $fillUpdate = '*';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmpradt_rmprad',
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpradt_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmtdk', 'string' => 'rs_rmtdk.rs_rmtdk_id_ex = rs_rmpradt.rs_rmpradt_rmtdk', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_rmktdk', 'string' => 'rs_rmktdk.rs_rmktdk_id_ex = rs_rmtdk.rs_rmtdk_rmktdk', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'getAllByRmpradAndTdk') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmpradt_rmprad',
                        'idExV' => $data[0]
                    ],
                    1 => [
                        'idEx' => 'rs_rmpradt_rmtdk',
                        'idExV' => $data[1]
                    ]
                ],
                //order by
                [],
                //join
                []
            );
        }elseif ($request == 'getAllByRmpmsk') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmprad_rmpmsk',
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpradt_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmprad', 'string' => 'rs_rmprad.rs_rmprad_id_ex = rs_rmpradt.rs_rmpradt_rmprad', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_ppeg', 'string' => 'rs_ppeg.rs_ppeg_id_ex = rs_rmprad.rs_rmprad_ppeg', 'type' => 'LEFT'],
                    2 => ['tableName' => 'rs_rmtdk', 'string' => 'rs_rmtdk.rs_rmtdk_id_ex = rs_rmpradt.rs_rmpradt_rmtdk', 'type' => 'LEFT'],
                    3 => ['tableName' => 'rs_rmktdk', 'string' => 'rs_rmktdk.rs_rmktdk_id_ex = rs_rmtdk.rs_rmtdk_rmktdk', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpradt_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}