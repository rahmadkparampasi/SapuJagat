<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\PkpMdl;

class Pkp extends BaseController
{
    use ResponseTrait;
    protected $MdlPkp;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlPkp = new PkpMdl();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeg',
            'pAct' => 'pAPeg',
            'cAct' => 'cAPkp',
            'cmAct' => '',
            'scAct' => '',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA KATEGORI PEGAWAI';
        $this->data['PageTitle'] = 'Data Kategori Pegawai';
        $this->data['BasePage'] = 'pkp';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData';
        $this->data['IdForm'] = 'pkpAddData';
        $this->data['UrlForm'] = 'pkp';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);


        $this->data['Pkp'] = $this->MdlPkp->getAllPkp();
        echo view('Pkp/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }

    public function editData($rs_pkp_id_ex = '')
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA JENIS PEGAWAI';
        $this->data['PageTitle'] = 'Data Jenis Pegawai';
        $this->data['BasePage'] = 'pkp';
        $this->data['ButtonMethod'] = 'UBAH';
        $this->data['MethodForm'] = 'updateData/' . $rs_pkp_id_ex;
        $this->data['IdForm'] = 'pkpAddData';
        $this->data['UrlForm'] = 'pkp';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);


        $this->data['Pkp'] = $this->MdlPkp->getAllPkp();
        if ($rs_pkp_id_ex === null || $rs_pkp_id_ex == '') {
            return redirect()->to('/' . $this->data['BasePage']);
        } else {
            $this->data['fillUpdate'] = $this->MdlPkp->getAllPkp($rs_pkp_id_ex);

            echo view('Pkp/index', $this->data);
            echo view('Templates/anotherScript');
            echo view('Templates/ajaxInsert', $this->data);
            echo view('Templates/loadData');
        }
    }

    public function insertData()
    {
        $rs_pkp_id_ex = $this->Another_Include->getRandStr(5);
        $rs_pkp_nm = strtoupper($this->request->getPost('rs_pkp_nm'));
        $data = [
            'rs_pkp_id_ex' => $rs_pkp_id_ex,
            'rs_pkp_nm' => $rs_pkp_nm,
        ];
        $insertData = $this->MdlPkp->insertData($data);
        if ($insertData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Jenis Pegawai Berhasil Disimpan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Jenis Pegawai Tidak Dapat Disimpan'];
        }
        return $this->respond($data, $data['status']);
    }

    public function updateData($rs_pkp_id_ex = '')
    {
        $rs_pkp_nm = $this->request->getPost('rs_pkp_nm');
        $rs_pkp_id_ex = $this->request->getPost('rs_pkp_id_ex');
        $data = [
            'rs_pkp_nm' => $rs_pkp_nm,
        ];
        $updateData = $this->MdlPkp->updateData($data, $rs_pkp_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Jenis Pegawai Berhasil Diubah'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Jenis Pegawai Tidak Dapat Diubah'];
        }
        return $this->respond($data, $data['status']);
    }



    public function deleteData($rs_pkp_id_ex = '')
    {
        if ($rs_pkp_id_ex === null || $rs_pkp_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlPkp->deleteData($rs_pkp_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Jenis Pegawai Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Jenis Pegawai Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }
}
