<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\RmrkMdl;
use App\Models\RmrMdl;

class Rmrk extends BaseController
{
    use ResponseTrait;
    protected $MdlRmrk;
    protected $MdlRmr;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlRmrk = new RmrkMdl();
        $this->MdlRmr = new RmrMdl();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeng',
            'pAct' => 'pAPeng',
            'cAct' => 'cArmr',
            'cmAct' => '',
            'scAct' => '',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
    }

    public function viewData($rs_rmrk_rmr = '')
    {
        if ($rs_rmrk_rmr == '') {
            echo "<span class='badge badge-danger'>Tidak Ada Daftar Kelas Ruangan</span>";
        } else {
            $this->data['Rmr'] = $this->MdlRmr->getAllRmr($rs_rmrk_rmr);
            $this->data['WebTitle'] = 'DATA KELAS DALAM RUANGAN ' . strtoupper($this->data['Rmr']['rs_rmr_nm']);
            $this->data['PageTitle'] = 'Data Kelas Dalam Ruangan ' . $this->data['Rmr']['rs_rmr_nm'];
            $this->data['BasePage'] = 'rmrk';
            $this->data['ButtonMethod'] = 'UBAH';
            $this->data['MethodForm'] = 'insertView/' . $rs_rmrk_rmr;
            $this->data['IdForm'] = 'rmrkAddData';
            $this->data['UrlForm'] = 'rmrk';
            $this->data['Rmrk'] = $this->MdlRmrk->getAllRmkByRmr($rs_rmrk_rmr);

            echo view('Rmrk/index', $this->data);
            echo view('Templates/ajaxInsert', $this->data);
        }
    }

    public function addRmkToRmrk($rs_rmr_id_ex, $rs_rmk_id_ex)
    {
        if ($rs_rmr_id_ex === null || $rs_rmr_id_ex == '' || $rs_rmk_id_ex === null || $rs_rmk_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'TIdak Ada ID Rujukan'];
        } else {
            $rs_rmrk_id_ex = $this->MdlRmrk->getIdEx($this->Another_Include->getRandStr(5));
            $data = [
                'rs_rmrk_id_ex' => $rs_rmrk_id_ex,
                'rs_rmrk_rmr' => $rs_rmr_id_ex,
                'rs_rmrk_rmk' => $rs_rmk_id_ex,
            ];
            $this->data['Rmrk'] = $this->MdlRmrk->getAllRmrkByRmkAndRmr($rs_rmr_id_ex, $rs_rmk_id_ex);
            if (count($this->data['Rmrk']) > 0) {
                // $deleteData = $this->MdlPpr->deleteData($rs_ppr_ppeg);
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Kelas Dalam Ruangan Ini Sudah Ada'];
            } else {
                $insertData = $this->MdlRmrk->insertData($data);

                if ($insertData) {
                    $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Kelas Dalam Ruangan Berhasil Disimpan'];
                } else {
                    $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Kelas Dalam Ruangan Tidak Dapat Disimpan'];
                }
            }
        }

        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmrk_id_ex = '')
    {
        if ($rs_rmrk_id_ex === null || $rs_rmrk_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlRmrk->deleteData($rs_rmrk_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Kelas Dalam Ruangan Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Kelas Dalam Ruangan Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function blockRmrk($rs_rmrk_id_ex = '')
    {
        $data = [
            'rs_rmrk_sts' => "0",
        ];
        $updateData = $this->MdlRmrk->updateData($data, $rs_rmrk_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Kelas Dalam Ruangan Berhasil Di Dinonaktifkan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Kelas Dalam Ruangan Tidak Dapat Di Dinonaktifkan'];
        }
        return $this->respond($data, $data['status']);
    }

    public function unblockRmrk($rs_rmrk_id_ex = '')
    {
        $data = [
            'rs_rmrk_sts' => "1",
        ];
        $updateData = $this->MdlRmrk->updateData($data, $rs_rmrk_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Kelas Dalam Ruangan Berhasil Aktifkan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Kelas Dalam Ruangan Tidak Dapat Aktifkan'];
        }
        return $this->respond($data, $data['status']);
    }
}
