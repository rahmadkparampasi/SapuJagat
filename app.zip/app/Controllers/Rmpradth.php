<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\UmMdl;

class Rmpradth extends BaseController
{
    use ResponseTrait;

    protected $MdlU;
    protected $Rmpradt;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_rmpradth', 'rs_rmpradth_id_ex');
        $this->Rmpradt = new Rmpradt;
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOIgd',
            'pAct' => 'pAIgd',
            'cAct' => 'cArmpmsk',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
            'rs_ppr_rmr' => $this->session->get('rs_ppr_rmr'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {

        return redirect()->to('./rmpmsk');
    }

    public function viewData($rs_rmpradth_rmpradt = '', $rs_rmprad_tgl = '', $rs_rmprad_jam = '', $rs_rmtdk_nm = '')
    {
        // dd($this->data);
        if ($rs_rmpradth_rmpradt == '') {
            echo "<span class='badge badge-danger'>Tidak Ada Daftar Tindakan Yang Dimaksud</span>";
        } else {
            $this->data['rs_rmpradth_rmpradt'] = $rs_rmpradth_rmpradt;
            $this->data['rs_rmprad_tgl'] = $rs_rmprad_tgl;
            $this->data['rs_rmprad_jam'] = $rs_rmprad_jam;
            $this->data['rs_rmtdk_nm'] = $rs_rmtdk_nm;
            $this->data['WebTitle'] = 'DAFTAR HASIL RADIOLOGI, TANGGAL ORDER : ' . strtoupper( $rs_rmprad_tgl . ', JAM ORDER : ' . $rs_rmprad_jam. ', DOKTER : ' . $rs_rmtdk_nm);
            $this->data['PageTitle'] = 'Daftar Hasil Radiologi, Tanggal Order : ' . $rs_rmprad_tgl . ', Jam Order : ' . $rs_rmprad_jam. ', Dokter : ' . $rs_rmtdk_nm;
            $this->data['BasePage'] = 'rmpradth';
            $this->data['ButtonMethod'] = 'SIMPAN';
            $this->data['MethodForm'] = 'insertView/' . $rs_rmpradth_rmpradt;
            $this->data['IdForm'] = 'rmpradthAddData';
            $this->data['UrlForm'] = 'rmpradth';
            $this->data['Rmpradth'] = $this->setDB('getAll', $rs_rmpradth_rmpradt);
            $this->data['Rmpradth'] = $this->Another_Include->changeDateWF($this->data['Rmpradth'], ['rs_rmpradth_tgl']);
            for ($i=0; $i < count($this->data['Rmpradth']); $i++) { 
                if ($this->data['Rmpradth'][$i]['rs_ppeg_nmd'] != "") {
                    $this->data['Rmpradth'][$i]['rs_ppeg_nm'] = $this->data['Rmpradth'][$i]['rs_ppeg_nmd'] . ". " . $this->data['Rmpradth'][$i]['rs_ppeg_nm'];
                }
    
                if ($this->data['Rmpradth'][$i]['rs_ppeg_nmb'] != "") {
                    $this->data['Rmpradth'][$i]['rs_ppeg_nm'] = $this->data['Rmpradth'][$i]['rs_ppeg_nm'] . ", " . $this->data['Rmpradth'][$i]['rs_ppeg_nmb'];
                }
            }
            echo view('Rmpradth/index', $this->data);
        }
    }

    public function getAll($rs_rmpradth_rmpradt)
    {
        $this->data['Rmpradth'] = $this->setDB('getAll', $rs_rmpradth_rmpradt);

        return  $this->data['Rmpradth'];
    }
    

    public function insertView($rs_rmpradth_rmpradt)
    {
        $rs_rmpradth_tgl = $this->request->getPost('rs_rmpradth_tgl');
        $rs_rmpradth_jam = $this->request->getPost('rs_rmpradth_jam');
        $rs_rmpradth_ppeg = $this->request->getPost('rs_rmpradth_ppeg');
        $rs_rmpradth_kls = $this->request->getPost('rs_rmpradth_kls');
        $rs_rmpradth_ksn = $this->request->getPost('rs_rmpradth_ksn');
        $rs_rmpradth_usul = $this->request->getPost('rs_rmpradth_usul');
        $rs_rmpradth_hp = $this->request->getPost('rs_rmpradth_hp');
        $rs_rmpradth_btk = $this->request->getPost('rs_rmpradth_btk');
        

        $data = [
            'rs_rmpradth_id_ex' => $this->setDB('idEx', $this->Another_Include->getRandStr(9)),
            'rs_rmpradth_rmpradt' => $rs_rmpradth_rmpradt,
            'rs_rmpradth_tgl' => $rs_rmpradth_tgl,
            'rs_rmpradth_jam' => $rs_rmpradth_jam,
            'rs_rmpradth_ppeg' => $rs_rmpradth_ppeg,
            'rs_rmpradth_kls' => $rs_rmpradth_kls,
            'rs_rmpradth_ksn' => $rs_rmpradth_ksn,
            'rs_rmpradth_usul' => $rs_rmpradth_usul,
            'rs_rmpradth_hp' => $rs_rmpradth_hp,
            'rs_rmpradth_btk' => $rs_rmpradth_btk,
        ];
        

        $insertDataupdateDataRmpradth = $this->MdlU->insertData($data);
        if ($insertDataupdateDataRmpradth) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Hasil Pemberian Tindakan Pasien Berhasil Disimpan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Hasil Pemberian Tindakan Pasien Tidak Dapat Disimpan'];
        }

        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmpradth_id_ex = '')
    {
        if ($rs_rmpradth_id_ex === null || $rs_rmpradth_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlU->deleteData($rs_rmpradth_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Hasil Pemberian Tindakan Pasien Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Hasil Pemberian Tindakan Pasien Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmpradth_id_ex';
        $id = 'rs_rmpradth_id';
        $length = 3;
        $typeGet = 'result';

        $fillUpdate = '*';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmpradth_rmpradt',
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpradth_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmpradt', 'string' => 'rs_rmpradt.rs_rmpradt_id_ex = rs_rmpradth.rs_rmpradth_rmpradt', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_rmprad', 'string' => 'rs_rmprad.rs_rmprad_id_ex = rs_rmpradt.rs_rmpradt_rmprad', 'type' => 'LEFT'],
                    2 => ['tableName' => 'rs_ppeg', 'string' => 'rs_ppeg.rs_ppeg_id_ex = rs_rmpradth.rs_rmpradth_ppeg', 'type' => 'LEFT'],
                ]
            );
        }elseif ($request == 'getAllByRmpmsk') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmprad_rmpmsk',
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpradt_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmprad', 'string' => 'rs_rmprad.rs_rmprad_id_ex = rs_rmpradt.rs_rmpradt_rmprad', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_ppeg', 'string' => 'rs_ppeg.rs_ppeg_id_ex = rs_rmprad.rs_rmprad_ppeg', 'type' => 'LEFT'],
                    2 => ['tableName' => 'rs_rmtdk', 'string' => 'rs_rmtdk.rs_rmtdk_id_ex = rs_rmpradt.rs_rmpradt_rmtdk', 'type' => 'LEFT'],
                    3 => ['tableName' => 'rs_rmktdk', 'string' => 'rs_rmktdk.rs_rmktdk_id_ex = rs_rmtdk.rs_rmtdk_rmktdk', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'getAllByRmplabAndTdk') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmpradt_rmplab',
                        'idExV' => $data[0]
                    ],
                    1 => [
                        'idEx' => 'rs_rmpradt_rmtdk',
                        'idExV' => $data[1]
                    ]
                ],
                //order by
                [],
                //join
                []
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmpradt_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}