<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\UmMdl;

class Loren extends BaseController
{
    use ResponseTrait;
    protected $MdlU;
    protected $Lorend;
    protected $Lostob;
    protected $Setrmr;
    protected $AI;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_loren', 'rs_loren_id_ex');
        $this->Lorend = new Lorend();
        $this->Lostob = new Lostob();
        $this->Setrmr = new Setrmr();
        $this->AI = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data['setRmr'] = $this->Setrmr->getAll();
        $this->data = [
            'mOp' => 'mOLo',
            'pAct' => 'pALo',
            'cAct' => 'cAloren',
            'cmAct' => '',
            'scAct' => '',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),

            'setRmr' => [
                'setRmrGud' => $this->data['setRmr'][6]['rs_setrmr_rmr'],
            ]
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA RENCANA KEBUTUHAN BARANG';
        $this->data['PageTitle'] = 'Data Rencana Kebutuhan Barang';
        $this->data['BasePage'] = 'loren';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData';
        $this->data['IdForm'] = 'lorenAddData';
        $this->data['UrlForm'] = 'loren';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);


        $this->data['Loren'] = $this->setDB();
        $this->data['Loren'] = $this->AI->changeDateWF($this->data['Loren'], ['rs_loren_tgl']);
        for ($i=0; $i < count($this->data['Loren']); $i++) { 
            $this->data['Loren'][$i]['ttl'] = $this->AI->rupiah($this->Lorend->getCountByLoren($this->data['Loren'][$i]['rs_loren_id_ex']));
            if($this->data['Loren'][$i]['rs_loren_fix']=="1")
            {
                $this->data['Loren'][$i]['rs_loren_fix'] = $this->AI->cB('TELAH SELESAI');
            }
        }
        // dd($this->data['Loren']);

        echo view('Loren/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/anotherScript');
    }

    public function editData($rs_loren_id_ex = '')
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA RENCANA KEBUTUHAN BARANG';
        $this->data['PageTitle'] = 'Data Rencana Kebutuhan Barang';
        $this->data['BasePage'] = 'loren';
        $this->data['ButtonMethod'] = 'UBAH';
        $this->data['MethodForm'] = 'updateData/' . $rs_loren_id_ex;
        $this->data['IdForm'] = 'lorenAddData';
        $this->data['UrlForm'] = 'loren';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);

        $this->data['Loren'] = $this->setDB();

        if ($rs_loren_id_ex === null || $rs_loren_id_ex == '') {
            return redirect()->to('/' . $this->data['BasePage']);
        } else {
            $this->data['fillUpdate'] = $this->setDB('fillUpdate', $rs_loren_id_ex);

            echo view('Loren/index', $this->data);
            echo view('Templates/anotherScript');
            echo view('Templates/ajaxInsert', $this->data);
            echo view('Templates/loadData');
        }
    }

    public function getAll()
    {
        return $this->setDB('getAll');
    }

    public function insertData()
    {

        $rs_loren_id_ex = $this->setDB('idEx', $this->AI->getRandStr(6));
        $rs_loren_tgl = $this->request->getPost('rs_loren_tgl');
        $rs_loren_thn = $this->request->getPost('rs_loren_thn');
        $rs_loren_kd = $this->request->getPost('rs_loren_kd');

        $data = [
            'rs_loren_id_ex' => $rs_loren_id_ex,
            'rs_loren_tgl' => $rs_loren_tgl,
            'rs_loren_thn' => $rs_loren_thn,
            'rs_loren_kd' => $rs_loren_kd,
            'rs_loren_ppeg' => $this->data['rs_ppeg_id_ex'],
        ];

        $insertData = $this->MdlU->insertData($data);
        if ($insertData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Rencana Kebutuhan Barang Berhasil Disimpan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Rencana Kebutuhan Barang Tidak Dapat Disimpan'];
        }

        return $this->respond($data, $data['status']);
    }


    public function updateData($rs_loren_id_ex = '')
    {
        $rs_loren_tgl = $this->request->getPost('rs_loren_tgl');
        $rs_loren_thn = $this->request->getPost('rs_loren_thn');
        $rs_loren_kd = $this->request->getPost('rs_loren_kd');
        $data = [
            'rs_loren_tgl' => $rs_loren_tgl,
            'rs_loren_thn' => $rs_loren_thn,
            'rs_loren_kd' => $rs_loren_kd,
        ];
        $updateData = $this->MdlU->updateData($data, $rs_loren_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Rencana Kebutuhan Barang Berhasil Diubah'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Rencana Kebutuhan Barang Tidak Dapat Diubah'];
        }
        return $this->respond($data, $data['status']);
    }
    public function sls($rs_loren_id_ex = '')
    {
        $this->data['Loren'] = $this->setDB('fillUpdateD', $rs_loren_id_ex);
        $success = 0;
        $error = 0;
        $total = 0;
        $this->data['Lorend'] = $this->Lorend->getAll($rs_loren_id_ex);

        for ($i = 0; $i < count($this->data['Lorend']); $i++) {
            
            $data['rs_lostob_loren'] = $this->data['Lorend'][$i]['rs_lorend_loren'];
            $data['rs_lostob_rmb'] = $this->data['Lorend'][$i]['rs_lorend_rmb'];
            $data['rs_lostob_j'] = $this->data['Lorend'][$i]['rs_lorend_j'];
            $data['rs_lostob_rmr'] = $this->data['setRmr']['setRmrGud'];
            $total += $this->data['Lorend'][$i]['rs_lorend_j']*$this->data['Lorend'][$i]['rs_lorend_hrg'];

            $insertDataLostob = $this->Lostob->insertData($data);
            if ($insertDataLostob) {
                $success += 1;
            } else {
                $error += 1;
            }
        }
        if ($error > 0) {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Terdapat Kesalahan Saat Menambahkan Data Ke Gudang, Harap Periksa Kembali Daftar Pembelian'];
            $deleteLostob = $this->Lostob->deleteDataByLoren($rs_loren_id_ex);
        }else{
            $data = [
                'rs_loren_fix' => '1',
            ];
            $updateData = $this->MdlU->updateData($data, $rs_loren_id_ex);
            if ($updateData) {
                // $insertDataJrnl = $this->insertJrnl($this->data['Pembelian']['stok_pembelian_akun'], 'C', $total, $this->data['stok_pengguna_id_ex'], 'Pembelian Produk', $stok_pembelian_id_ex, $this->data['Pembelian']['stok_pembelian_tgl']);
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Penyelesaian Rencana Kebutuhan Barang Berhasil Disimpan'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Penyelesaian Rencana Kebutuhan Barang Tidak Dapat Disimpan'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_loren_id_ex = '')
    {
        if ($rs_loren_id_ex === null || $rs_loren_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlU->deleteData($rs_loren_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Rencana Kebutuhan Barang Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Rencana Kebutuhan Barang Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function block($rs_loren_id_ex = '')
    {
        $data = [
            'rs_loren_sts' => "0",
        ];
        $updateData = $this->MdlU->updateData($data, $rs_loren_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Status Rencana Kebutuhan Barang Berhasil Di Dinonaktifkan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Status Rencana Kebutuhan Barang Tidak Dapat Di Dinonaktifkan'];
        }
        return $this->respond($data, $data['status']);
    }

    public function unblock($rs_loren_id_ex = '')
    {
        $data = [
            'rs_loren_sts' => "1",
        ];
        $updateData = $this->MdlU->updateData($data, $rs_loren_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Status Rencana Kebutuhan Barang Berhasil Aktifkan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Status Rencana Kebutuhan Barang Tidak Dapat Aktifkan'];
        }
        return $this->respond($data, $data['status']);
    }

    public function getKd($rs_loren_thn)
    {
        if ($rs_loren_thn === null || $rs_loren_thn == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada Tahun Pengadaan'];
        } else {
            if ((int)$rs_loren_thn == 0) {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Pilih Tahun Yang Benar'];
            } else {
                $data = ['status' => 200, 'response' => 'success', 'optValue' => $this->setDB('getKd', "B-".$rs_loren_thn)];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_loren_id_ex';
        $id = 'rs_loren_id';
        $length = 2;
        $typeGet = 'result';

        $fillUpdate = 'rs_loren_id_ex, rs_loren_tgl, rs_loren_thn, rs_loren_thn as rs_loren_thn_old, rs_loren_kd, rs_loren_kd as rs_loren_kd_old';
        $fillUpdateD = 'rs_loren_id_ex, rs_loren_tgl, rs_loren_thn, rs_loren_fix, rs_loren_sts, rs_loren_kd';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [],
                //order by
                [
                    0 => ['id' => 'rs_loren_id', 'orderType' => 'DESC'],
                ],
                //join
                []
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_loren_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'fillUpdateD') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdateD,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_loren_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'getKd') {
            return $this->MdlU->getIdEx('rs_loren_kd', $data, $id, 3, '-');
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}