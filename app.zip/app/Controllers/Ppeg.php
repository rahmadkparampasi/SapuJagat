<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\PpegMdl;
use App\Models\PaMdl;
use App\Models\PkpMdl;
use App\Models\PspMdl;
use App\Models\RmrMdl;
use App\Models\PprMdl;
use App\Models\UmMdl;
use PhpOffice\PhpSpreadsheet\Reader\Xls as Reader;

class Ppeg extends BaseController
{
    use ResponseTrait;
    protected $MdlU;
    protected $Pa;
    protected $MdlPpeg;
    protected $MdlPkp;
    protected $MdlPsp;
    protected $MdlPa;
    protected $MdlRmr;
    protected $MdlPpr;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        ini_set('memory_limit', '-1');
        $this->MdlU = new UmMdl('rs_ppeg', 'rs_ppeg_id_ex');
        $this->Pa = new Pa;
        $this->MdlPpeg = new PpegMdl();
        $this->MdlPkp = new PkpMdl();
        $this->MdlPsp = new PspMdl();
        $this->MdlPa = new PaMdl();
        $this->MdlRmr = new RmrMdl();
        $this->MdlPpr = new PprMdl();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeg',
            'pAct' => 'pAPeg',
            'cAct' => 'cAPpeg',
            'cmAct' => '',
            'scAct' => '',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA PEGAWAI';
        $this->data['PageTitle'] = 'Data Pegawai';
        $this->data['BasePage'] = 'ppeg';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData';
        $this->data['IdForm'] = 'ppegAddData';
        $this->data['UrlForm'] = 'ppeg';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);
        $this->data['Ppeg'] = $this->setDB();
        $this->data['Psp'] = $this->MdlPsp->getAllPsp();
        $this->data['Pkp'] = $this->MdlPkp->getAllPkp();
        $this->data['Rmr'] = $this->MdlRmr->getAllRmr();

        for ($i = 0; $i < count($this->data['Ppeg']); $i++) {
            $this->data['d'] = (string)date('d', strtotime($this->data['Ppeg'][$i]['rs_ppeg_tgl_lhr']));
            $this->data['F'] = (string)date('F', strtotime($this->data['Ppeg'][$i]['rs_ppeg_tgl_lhr']));
            $this->data['F'] = $this->Another_Include->monthConv($this->data['F']);
            $this->data['Y'] = (string)date('Y', strtotime($this->data['Ppeg'][$i]['rs_ppeg_tgl_lhr']));
            $this->data['Ppeg'][$i]['rs_ppeg_tgl_lhr'] = strtoupper($this->data['d'] . " " . $this->data['F'] . " " . $this->data['Y']);

            if ($this->data['Ppeg'][$i]['rs_ppeg_jk'] == "L") {
                $this->data['Ppeg'][$i]['rs_ppeg_jk'] = "LAKI-LAKI";
            } else {
                $this->data['Ppeg'][$i]['rs_ppeg_jk'] = "PEREMPUAN";
            }

            if ($this->data['Ppeg'][$i]['rs_ppeg_nmd'] != "") {
                $this->data['Ppeg'][$i]['rs_ppeg_nm'] = ". " . $this->data['Ppeg'][$i]['rs_ppeg_nm'];
            }

            if ($this->data['Ppeg'][$i]['rs_ppeg_nmb'] != "") {
                $this->data['Ppeg'][$i]['rs_ppeg_nm'] = $this->data['Ppeg'][$i]['rs_ppeg_nm'] . ", ";
            }

            

            $this->data['Ppeg'][$i]['rs_ppeg_nm'] = $this->data['Ppeg'][$i]['rs_ppeg_nmd'] . $this->data['Ppeg'][$i]['rs_ppeg_nm'] . $this->data['Ppeg'][$i]['rs_ppeg_nmb'];
        }
        echo view('Ppeg/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }

    public function getPpegByJson($rs_rmr_id_ex = '')
    {
        header('Content-Type: application/json');
        header("Access-Control-Allow-Origin: *");
        $this->data['data']['data'] = $this->MdlPpeg->getAllPpeg();
        $this->data['Psp'] = $this->MdlPsp->getAllPsp();
        $this->data['Pkp'] = $this->MdlPkp->getAllPkp();
        $no = 0;
        for ($i = 0; $i < count($this->data['data']['data']); $i++) {
            $no++;
            $this->data['d'] = (string)date('d', strtotime($this->data['data']['data'][$i]['rs_ppeg_tgl_lhr']));
            $this->data['F'] = (string)date('F', strtotime($this->data['data']['data'][$i]['rs_ppeg_tgl_lhr']));
            $this->data['F'] = $this->Another_Include->monthConv($this->data['F']);
            $this->data['Y'] = (string)date('Y', strtotime($this->data['data']['data'][$i]['rs_ppeg_tgl_lhr']));
            $this->data['data']['data'][$i]['rs_ppeg_tgl_lhr'] = strtoupper($this->data['d'] . " " . $this->data['F'] . " " . $this->data['Y']);
            $this->data['data']['data'][$i]['button'] = "<button class='btn bg-gradient-success' title='Tambahkan Pegawai Ke Dalam RUangan' onclick='addWF(\"Menambahkan " . $this->data['data']['data'][$i]['rs_rmr_nm'] . " Dalam Data Ruangan\", \"/" . "ppeg/addRmrToPpeg/" . $rs_rmr_id_ex . "/" . $this->data['data']['data'][$i]['rs_ppeg_id_ex'] . "\", loadTabPgw)'><i class='fas fa-check'></i></button>";
            $this->data['data']['data'][$i]['no'] = $no;

            if ($this->data['data']['data'][$i]['rs_ppeg_jk'] == "L") {
                $this->data['data']['data'][$i]['rs_ppeg_jk'] = "LAKI-LAKI";
            } else {
                $this->data['data']['data'][$i]['rs_ppeg_jk'] = "PEREMPUAN";
            }

            if ($this->data['data']['data'][$i]['rs_ppeg_nmd'] != "") {
                $this->data['data']['data'][$i]['rs_ppeg_nm'] = ". " . $this->data['data']['data'][$i]['rs_ppeg_nm'];
            }

            if ($this->data['data']['data'][$i]['rs_ppeg_nmb'] != "") {
                $this->data['data']['data'][$i]['rs_ppeg_nm'] = $this->data['data']['data'][$i]['rs_ppeg_nm'] . ", ";
            }

            if ($this->data['data']['data'][$i]['rs_ppeg_a'] == "0") {
                $this->data['data']['data'][$i]['rs_ppeg_a'] = "BELUM DIPILIH";
            } else {
                $this->data['data']['data'][$i]['rs_ppeg_a'] = strtoupper($this->data['data']['data'][$i]['rs_ppeg_a']);
            }

            if ($this->data['data']['data'][$i]['rs_ppeg_sts'] == "0") {
                $this->data['data']['data'][$i]['rs_ppeg_sts'] = "BELUM DIPILIH";
            } elseif ($this->data['data']['data'][$i]['rs_ppeg_sts'] == "M") {
                $this->data['data']['data'][$i]['rs_ppeg_sts'] = "MENIKAH";
            } else {
                $this->data['data']['data'][$i]['rs_ppeg_sts'] = "BELUM MENIKAH";
            }

            if ($this->data['data']['data'][$i]['rs_ppeg_gol'] == "0") {
                $this->data['data']['data'][$i]['rs_ppeg_gol'] = "BELUM DIPILIH";
            }

            $this->data['data']['data'][$i]['rs_ppeg_nm'] = $this->data['data']['data'][$i]['rs_ppeg_nmd'] . $this->data['data']['data'][$i]['rs_ppeg_nm'] . $this->data['data']['data'][$i]['rs_ppeg_nmb'];
        }
        return $this->respond($this->data['data'], 200);
    }

    public function insertData()
    {

        $options = [
            'cost' => 10,
        ];

        $rs_ppeg_id_ex = $this->Another_Include->getRandStr(15);
        $rs_ppeg_ab =  $this->setDB('getAb', $this->Another_Include->getRandJStr(3));
        $rs_ppeg_nmd = $this->request->getPost('rs_ppeg_nmd');
        $rs_ppeg_nm = $this->request->getPost('rs_ppeg_nm');
        $rs_ppeg_nmb = $this->request->getPost('rs_ppeg_nmb');
        $rs_ppeg_psp = $this->request->getPost('rs_ppeg_psp');
        $rs_ppeg_pkp = $this->request->getPost('rs_ppeg_pkp');
        $rs_ppeg_nip = $this->request->getPost('rs_ppeg_nip');
        $rs_ppeg_tmpt_lhr = $this->request->getPost('rs_ppeg_tmpt_lhr');
        $rs_ppeg_tgl_lhr = $this->request->getPost('rs_ppeg_tgl_lhr');
        $rs_ppeg_nik = $this->request->getPost('rs_ppeg_nik');
        $rs_ppeg_jk = $this->request->getPost('rs_ppeg_jk');


        $rs_pa_id_ex = $this->Another_Include->getRandStr(15);
        $rs_pa_ppeg = $rs_ppeg_id_ex;
        $rs_pa_act = "1";
        if ($rs_ppeg_nip != 0 || $rs_ppeg_nip != "") {
            $rs_pa_un = $rs_ppeg_nip;
            $rs_pa_pass = password_hash($rs_ppeg_nip, PASSWORD_BCRYPT, $options);
        } else {
            $rs_pa_un = $rs_ppeg_nik;
            $rs_pa_pass = password_hash($rs_ppeg_nik, PASSWORD_BCRYPT, $options);
        }
        $data = [
            'rs_ppeg_id_ex' => $rs_ppeg_id_ex,
            'rs_ppeg_ab' => $rs_ppeg_ab,
            'rs_ppeg_nmd' => $rs_ppeg_nmd,
            'rs_ppeg_nm' => $rs_ppeg_nm,
            'rs_ppeg_nmb' => $rs_ppeg_nmb,
            'rs_ppeg_psp' => $rs_ppeg_psp,
            'rs_ppeg_pkp' => $rs_ppeg_pkp,
            'rs_ppeg_nip' => $rs_ppeg_nip,
            'rs_ppeg_tmpt_lhr' => $rs_ppeg_tmpt_lhr,
            'rs_ppeg_tgl_lhr' => $rs_ppeg_tgl_lhr,
            'rs_ppeg_nik' => $rs_ppeg_nik,
            'rs_ppeg_jk' => $rs_ppeg_jk,
        ];

        $dataPeng = [
            'rs_pa_id_ex' => $rs_pa_id_ex,
            'rs_pa_ppeg' => $rs_pa_ppeg,
            'rs_pa_act' => $rs_pa_act,
            'rs_pa_un' => $rs_pa_un,
            'rs_pa_pass' => $rs_pa_pass
        ];

        $this->data['Ppeg'] = $this->MdlPpeg->getPpegByNip($rs_ppeg_nip);
        if (count($this->data['Ppeg']) > 0) {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Pegawai Sudah Ada'];
        } else {
            $insertData = $this->MdlPpeg->insertData($data);
            if ($insertData) {
                $insertDataPeng = $this->MdlPa->insertData($dataPeng);
                if ($insertDataPeng) {
                    $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Pegawai Berhasil Disimpan'];
                } else {
                    $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Akun Pegawai Tidak Dapat Disimpan'];
                }
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Pegawai Tidak Dapat Disimpan'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function insertFile()
    {
        $options = [
            'cost' => 10,
        ];
        date_default_timezone_set("Asia/Makassar");

        $ExcelReader = new Reader();

        $file = $this->request->getFile('file');
        $fileLocation = $file->getTempName();
        $objPhpExcel = $ExcelReader->load($fileLocation);
        $sheet = $objPhpExcel->getActiveSheet()->toArray(null, true, true, true);
        $success = 0;
        $error = 0;
        $count = count($sheet) + 1;
        $data = [];
        for ($i = 1; $i < $count; $i++) {
            $sheet[$i]['G'] = str_replace(' ', '', $sheet[$i]['G']);
            $sheet[$i]['H'] = str_replace(' ', '', $sheet[$i]['H']);
            $sheet[$i]['H'] = str_replace('\'', '', $sheet[$i]['H']);
            $sheet[$i]['D'] = str_replace(',', '', $sheet[$i]['D']);
            $sheet[$i]['K'] = substr($sheet[$i]['E'], 0, 2);
            $sheet[$i]['L'] = substr($sheet[$i]['E'], 3, 2);
            $sheet[$i]['M'] = substr($sheet[$i]['E'], 6, 4);
            $sheet[$i]['E'] = $sheet[$i]['M']."-".$sheet[$i]['L']."-".$sheet[$i]['K'];
            if ($sheet[$i]['I']=="REKAM MEDIS") {
                $sheet[$i]['I'] = "1msxe";
            }elseif ($sheet[$i]['I']=="ANALIS") {
                $sheet[$i]['I'] = "B9qFH";
            }elseif ($sheet[$i]['I']=="PERAWAT") {
                $sheet[$i]['I'] = "FCJ3e";
            }elseif ($sheet[$i]['I']=="BIDAN") {
                $sheet[$i]['I'] = "iRTpZ";
            }elseif ($sheet[$i]['I']=="MANAJEMEN") {
                $sheet[$i]['I'] = "KAkG9";
            }elseif ($sheet[$i]['I']=="FARMASI") {
                $sheet[$i]['I'] = "OCBdI";
            }elseif ($sheet[$i]['I']=="RADIOGRAFER") {
                $sheet[$i]['I'] = "QPIWU";
            }elseif ($sheet[$i]['I']=="GIZI") {
                $sheet[$i]['I'] = "XkhQb";
            }elseif ($sheet[$i]['I']=="FISIOTERAPI") {
                $sheet[$i]['I'] = "cjyAG";
            }elseif ($sheet[$i]['I']=="DOKTER") {
                if ($sheet[$i]['A']=="Drg"||$sheet[$i]['A']=="drg") {
                    $sheet[$i]['I'] = "PoF5o";
                }else{
                    if ($sheet[$i]['C']==null||$sheet[$i]['C']=="") {
                        $sheet[$i]['I'] = "ZOeJ9";
                    }else{
                        $sheet[$i]['I'] = "MaBj3";
                    }
                }
            }
             
            

            if ($sheet[$i]['F']=="ASN") {
                $sheet[$i]['F'] = "PybQC";
            }else{
                $sheet[$i]['F'] = "gQbGZ";
            }

            $sheet[$i]['C'] = str_replace(' ', '', $sheet[$i]['C']);
            $sheet[$i]['A'] = str_replace(' ', '', $sheet[$i]['A']);
            $sheet[$i]['C'] = str_replace(' ', '', $sheet[$i]['C']);

            $sheet[$i]['A'] = str_replace('\'', '', $sheet[$i]['A']);
            $sheet[$i]['A'] = str_replace('Drg', 'drg', $sheet[$i]['A']);
            $sheet[$i]['B'] = str_replace('\'', '', $sheet[$i]['B']);
            $sheet[$i]['C'] = str_replace('\'', '', $sheet[$i]['C']);
            $sheet[$i]['D'] = str_replace('\'', '', $sheet[$i]['D']);
            $sheet[$i]['G'] = str_replace('\'', '', $sheet[$i]['G']);
            $sheet[$i]['H'] = str_replace('\'', '', $sheet[$i]['H']);



            
            $rs_ppeg_id_ex  = $this->setDB('idEx', $this->Another_Include->getRandStr(12));

            $data = [
                'rs_ppeg_id_ex ' => $rs_ppeg_id_ex,
                'rs_ppeg_nmd' => $sheet[$i]['A'],
                'rs_ppeg_nm' => $sheet[$i]['B'],
                'rs_ppeg_nmb' => $sheet[$i]['C'],
                'rs_ppeg_psp' => $sheet[$i]['F'],
                'rs_ppeg_pkp' => $sheet[$i]['I'],
                'rs_ppeg_nip' => $sheet[$i]['G'],
                'rs_ppeg_tmpt_lhr' => $sheet[$i]['D'],
                'rs_ppeg_tgl_lhr' => $sheet[$i]['E'],
                'rs_ppeg_nik' => $sheet[$i]['H'],
                'rs_ppeg_jk' => $sheet[$i]['J'],
            ];
            

            if ($sheet[$i]['G'] != 0 || $sheet[$i]['G'] != "") {
                $un = $sheet[$i]['G'];
                $rs_pa_pass = password_hash($sheet[$i]['G'], PASSWORD_BCRYPT, $options);
            } else {
                $un = $sheet[$i]['H'];
                $rs_pa_pass = password_hash($sheet[$i]['H'], PASSWORD_BCRYPT, $options);
            }

            


            $dataPeng = [
                
                'rs_pa_ppeg' => $rs_ppeg_id_ex,
                'rs_pa_act' => '1',
                'rs_pa_un' => $un,
                'rs_pa_pass' => $rs_pa_pass
            ];
            $insertData = $this->MdlU->insertData($data);
            if ($insertData) {
                $insertDataPeng = $this->Pa->insertData($dataPeng);
                if ($insertDataPeng) {
                    $success += 1;

                } else {
                    $error += 1;

                }
            } else {
                $error += 1;

            }

            
        }

        // dd($sheet, $data);
        $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Berhasil Diproses, Dengan Data Yang Berhasil Berjumlah ' . (string)$success . ' Data, Dan Yang Tidak Berhasil Berjumlah ' . (string)$error . ' Data'];
        return $this->respond($data, $data['status']);
    }

    public function blockPa($rs_pa_id_ex = '')
    {
        $data = [
            'rs_pa_act' => "0",
        ];
        $updateData = $this->MdlPa->updateData($data, $rs_pa_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Pengguna Berhasil Di Blokir'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Pengguna Tidak Dapat Di Blokir'];
        }
        return $this->respond($data, $data['status']);
    }

    public function unblockPa($rs_pa_id_ex = '')
    {
        $data = [
            'rs_pa_act' => "1",
        ];
        $updateData = $this->MdlPa->updateData($data, $rs_pa_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Blokir Pengguna Berhasil Dibuka'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Blokir Pengguna Tidak Dapat Dibuka'];
        }
        return $this->respond($data, $data['status']);
    }



    public function deleteData($rs_ppeg_id_ex = '')
    {
        if ($rs_ppeg_id_ex === null || $rs_ppeg_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlPpeg->deleteData($rs_ppeg_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Pegawai Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Pegawai Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }


    public function addRmrToPpeg($rs_rmr_id_ex, $rs_ppr_ppeg)
    {
        if ($rs_rmr_id_ex === null || $rs_rmr_id_ex == '' || $rs_ppr_ppeg === null || $rs_ppr_ppeg == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'TIdak Ada ID Rujukan'];
        } else {
            $data = [
                'rs_ppr_rmr' => $rs_rmr_id_ex,
                'rs_ppr_ppeg' => $rs_ppr_ppeg,
            ];
            $this->data['Ppr'] = $this->MdlPpr->getAllPprByPpegAndRmr($rs_rmr_id_ex, $rs_ppr_ppeg);
            if (count($this->data['Ppr']) > 0) {
                // $deleteData = $this->MdlPpr->deleteData($rs_ppr_ppeg);
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Pegawai Dalam Ruangan Ini Sudah Ada'];
            } else {
                $insertData = $this->MdlPpr->insertData($data);

                if ($insertData) {
                    $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Ruagan Pegawai Berhasil Disimpan'];
                } else {
                    $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Ruagan Pegawai Tidak Dapat Disimpan'];
                }
            }
        }

        return $this->respond($data, $data['status']);
    }

    public function deleteRmrToPpeg($rs_ppr_id)
    {
        if ($rs_ppr_id === null || $rs_ppr_id == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'TIdak Ada ID Rujukan'];
        } else {

            $deleteData = $this->MdlPpr->deleteData($rs_ppr_id);

            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Ruagan Pegawai Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Ruangan Pegawai Tidak Dapat Dihapus'];
            }
        }

        return $this->respond($data, $data['status']);
    }

    public function countPpeg()
    {
        return $this->setDB('count');
    }
    public function getByIdEx($rs_ppeg_id_ex)
    {
        return $this->setDB('getByIdEx',$rs_ppeg_id_ex);
    }

    public function getAb()
    {
        $this->data['Ppeg'] = $this->setDB('getAll');
        for ($i=0; $i < count($this->data['Ppeg']); $i++) { 
            $data = [
                'rs_ppeg_ab' => $this->setDB('getAb', $this->Another_Include->getRandJStr(3))
            ];

            $this->MdlU->updateData($data, $this->data['Ppeg'][$i]['rs_ppeg_id_ex']);
        }
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_ppeg_id_ex';
        $id = 'rs_ppeg_id';
        $length = 3;
        $typeGet = 'result';

        $fillUpdate = 'rs_ppeg_id_ex, rs_ppeg_nm';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [],
                //order by
                [
                    0 => ['id' => 'rs_ppeg_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_pa', 'string' => 'rs_ppeg.rs_ppeg_id_ex = rs_pa.rs_pa_ppeg', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_pkp', 'string' => 'rs_pkp.rs_pkp_id_ex = rs_ppeg.rs_ppeg_pkp', 'type' => 'LEFT'],
                    2 => ['tableName' => 'rs_psp', 'string' => 'rs_psp.rs_psp_id_ex = rs_ppeg.rs_ppeg_psp', 'type' => 'LEFT'],
                    3 => ['tableName' => 'rs_ppsbb', 'string' => 'rs_ppeg.rs_ppeg_id_ex = rs_ppsbb.rs_ppsbb_ppeg', 'type' => 'LEFT'],
                    4 => ['tableName' => 'rs_ppr', 'string' => 'rs_ppr.rs_ppr_ppeg  = rs_ppeg.rs_ppeg_id_ex', 'type' => 'LEFT'],
                    5 => ['tableName' => 'rs_rmr', 'string' => 'rs_rmr.rs_rmr_id_ex = rs_ppr.rs_ppr_rmr', 'type' => 'LEFT'],
                    6 => ['tableName' => 'rs_rmag', 'string' => 'rs_rmag.rs_rmag_id_ex = rs_ppeg.rs_ppeg_rmag', 'type' => 'LEFT'],
                    7 => ['tableName' => 'rs_rmsts', 'string' => 'rs_rmsts.rs_rmsts_id_ex = rs_ppeg.rs_ppeg_rmsts', 'type' => 'LEFT'],
                    8 => ['tableName' => 'rs_rmgd', 'string' => 'rs_rmgd.rs_rmgd_id_ex = rs_ppeg.rs_ppeg_rmgd', 'type' => 'LEFT'],
                ]
            );
        }elseif ($request == 'getAllON') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [],
                //order by
                [
                    0 => ['id' => 'rs_ppeg_nm', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_pa', 'string' => 'rs_ppeg.rs_ppeg_id_ex = rs_pa.rs_pa_ppeg', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_pkp', 'string' => 'rs_pkp.rs_pkp_id_ex = rs_ppeg.rs_ppeg_pkp', 'type' => 'LEFT'],
                    2 => ['tableName' => 'rs_psp', 'string' => 'rs_psp.rs_psp_id_ex = rs_ppeg.rs_ppeg_psp', 'type' => 'LEFT'],
                    3 => ['tableName' => 'rs_ppsbb', 'string' => 'rs_ppeg.rs_ppeg_id_ex = rs_ppsbb.rs_ppsbb_ppeg', 'type' => 'LEFT'],
                    4 => ['tableName' => 'rs_ppr', 'string' => 'rs_ppr.rs_ppr_ppeg  = rs_ppeg.rs_ppeg_id_ex', 'type' => 'LEFT'],
                    5 => ['tableName' => 'rs_rmr', 'string' => 'rs_rmr.rs_rmr_id_ex = rs_ppr.rs_ppr_rmr', 'type' => 'LEFT'],
                    6 => ['tableName' => 'rs_rmag', 'string' => 'rs_rmag.rs_rmag_id_ex = rs_ppeg.rs_ppeg_rmag', 'type' => 'LEFT'],
                    7 => ['tableName' => 'rs_rmsts', 'string' => 'rs_rmsts.rs_rmsts_id_ex = rs_ppeg.rs_ppeg_rmsts', 'type' => 'LEFT'],
                    8 => ['tableName' => 'rs_rmgd', 'string' => 'rs_rmgd.rs_rmgd_id_ex = rs_ppeg.rs_ppeg_rmgd', 'type' => 'LEFT'],
                ]
            );
        }elseif ($request == 'getByIdEx') {
            return $this->MdlU->getAll(
                //type result / row
                'row',
                // select *
                '*',
                //where
                [
                    0 => ['idEx' => 'rs_ppeg_id_ex', 'idExV' => $data]
                ],
                //order by
                [
                    0 => ['id' => 'rs_ppeg_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_pa', 'string' => 'rs_ppeg.rs_ppeg_id_ex = rs_pa.rs_pa_ppeg', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_pkp', 'string' => 'rs_pkp.rs_pkp_id_ex = rs_ppeg.rs_ppeg_pkp', 'type' => 'LEFT'],
                    2 => ['tableName' => 'rs_psp', 'string' => 'rs_psp.rs_psp_id_ex = rs_ppeg.rs_ppeg_psp', 'type' => 'LEFT'],
                    3 => ['tableName' => 'rs_ppsbb', 'string' => 'rs_ppeg.rs_ppeg_id_ex = rs_ppsbb.rs_ppsbb_ppeg', 'type' => 'LEFT'],
                    4 => ['tableName' => 'rs_ppr', 'string' => 'rs_ppr.rs_ppr_ppeg  = rs_ppeg.rs_ppeg_id_ex', 'type' => 'LEFT'],
                    5 => ['tableName' => 'rs_rmr', 'string' => 'rs_rmr.rs_rmr_id_ex = rs_ppr.rs_ppr_rmr', 'type' => 'LEFT'],
                    6 => ['tableName' => 'rs_rmag', 'string' => 'rs_rmag.rs_rmag_id_ex = rs_ppeg.rs_ppeg_rmag', 'type' => 'LEFT'],
                    7 => ['tableName' => 'rs_rmsts', 'string' => 'rs_rmsts.rs_rmsts_id_ex = rs_ppeg.rs_ppeg_rmsts', 'type' => 'LEFT'],
                    8 => ['tableName' => 'rs_rmgd', 'string' => 'rs_rmgd.rs_rmgd_id_ex = rs_ppeg.rs_ppeg_rmgd', 'type' => 'LEFT'],
                ]
            );
        }elseif ($request == 'count') {
            return $this->MdlU->getAll(
                //type result / row
                'count',
                // select *
                '*',
                //where
                [],
                //order by
                [
                    0 => ['id' => 'rs_ppeg_id', 'orderType' => 'DESC'],
                ],
                //join
                []
            );
        } elseif ($request == 'getAllByIdEx') {
            return $this->MdlU->getAll(
                //type result / row
                'row',
                // select *
                '*',
                //where
                [
                    0 => ['idEx' => 'rs_ppeg_id_ex', 'idExV' => $data]
                ],
                //order by
                [
                    0 => ['id' => 'rs_ppeg_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    
                ]
            );
        } elseif ($request == 'getAllByStsASN') {
            return $this->MdlU->getAll(
                //type result / row
                'row',
                // select *
                '*',
                //where
                [
                    0 => ['idEx' => 'rs_ppeg_id_ex', 'idExV' => $data]
                ],
                //order by
                [
                    0 => ['id' => 'rs_ppeg_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_psp', 'string' => 'rs_psp.rs_psp_id_ex = rs_ppeg.rs_ppeg_psp', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'getAb') {
            return $this->MdlU->getIdEx('rs_ppeg_ab', $data, $id, 2);
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        } 
    }

    public function ctkPgwAll($rs_ppeg_id_ex = '')
    { 
        $this->data['Ppeg'] = $this->setDB();
        // if ($rs_ppeg_id_ex > 1 ) {
        //     $this->data['Ppeg'] = $this->setDB('getAll', [$rs_ppeg_id_ex]);
        // } else {
        //     echo "TIdak Ada Data";
        // }
         
        for ($i = 0; $i < count($this->data['Ppeg']); $i++) {
            $this->data['d'] = (string)date('d', strtotime($this->data['Ppeg'][$i]['rs_ppeg_tgl_lhr']));
            $this->data['F'] = (string)date('F', strtotime($this->data['Ppeg'][$i]['rs_ppeg_tgl_lhr']));
            $this->data['F'] = $this->Another_Include->monthConv($this->data['F']);
            $this->data['Y'] = (string)date('Y', strtotime($this->data['Ppeg'][$i]['rs_ppeg_tgl_lhr']));
            $this->data['Ppeg'][$i]['rs_ppeg_tgl_lhr'] = strtoupper($this->data['d'] . " " . $this->data['F'] . " " . $this->data['Y']);

            if ($this->data['Ppeg'][$i]['rs_ppeg_jk'] == "L") {
                $this->data['Ppeg'][$i]['rs_ppeg_jk'] = "LAKI-LAKI";
            } else {
                $this->data['Ppeg'][$i]['rs_ppeg_jk'] = "PEREMPUAN";
            }

            if ($this->data['Ppeg'][$i]['rs_ppeg_nmd'] != "") {
                $this->data['Ppeg'][$i]['rs_ppeg_nm'] = ". " . $this->data['Ppeg'][$i]['rs_ppeg_nm'];
            }

            if ($this->data['Ppeg'][$i]['rs_ppeg_nmb'] != "") {
                $this->data['Ppeg'][$i]['rs_ppeg_nm'] = $this->data['Ppeg'][$i]['rs_ppeg_nm'] . ", ";
            }

            if ($this->data['Ppeg'][$i]['rs_ppeg_a'] == "0") {
                $this->data['Ppeg'][$i]['rs_ppeg_a'] = "BELUM DIPILIH";
            } else {
                $this->data['Ppeg'][$i]['rs_ppeg_a'] = strtoupper($this->data['Ppeg'][$i]['rs_ppeg_a']);
            }

            if ($this->data['Ppeg'][$i]['rs_ppeg_sts'] == "0") {
                $this->data['Ppeg'][$i]['rs_ppeg_sts'] = "BELUM DIPILIH";
            } elseif ($this->data['Ppeg'][$i]['rs_ppeg_sts'] == "M") {
                $this->data['Ppeg'][$i]['rs_ppeg_sts'] = "MENIKAH";
            } else {
                $this->data['Ppeg'][$i]['rs_ppeg_sts'] = "BELUM MENIKAH";
            }

            if ($this->data['Ppeg'][$i]['rs_ppeg_gol'] == "0") {
                $this->data['Ppeg'][$i]['rs_ppeg_gol'] = "BELUM DIPILIH";
            }

            $this->data['Ppeg'][$i]['rs_ppeg_nm'] = $this->data['Ppeg'][$i]['rs_ppeg_nmd'] . $this->data['Ppeg'][$i]['rs_ppeg_nm'] . $this->data['Ppeg'][$i]['rs_ppeg_nmb'];
        }

        $this->data['WebTitle'] = 'DATA PEGAWAI';
        $this->data['PageTitle'] = 'Data Pegawai';
        $this->data['BasePage'] = 'ppeg';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData';
        $this->data['IdForm'] = 'ppegAddData';
        $this->data['UrlForm'] = 'ppeg';
        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);  

        echo view('Ppeg/indexCtkAllPgw', $this->data);
        echo view('Templates/anotherScript');
    }
    public function ctkPgwAllAb()
    { 
        $this->data['Ppeg'] = $this->setDB('getAllON');
        
         
        for ($i = 0; $i < count($this->data['Ppeg']); $i++) {
            $this->data['d'] = (string)date('d', strtotime($this->data['Ppeg'][$i]['rs_ppeg_tgl_lhr']));
            $this->data['F'] = (string)date('F', strtotime($this->data['Ppeg'][$i]['rs_ppeg_tgl_lhr']));
            $this->data['F'] = $this->Another_Include->monthConv($this->data['F']);
            $this->data['Y'] = (string)date('Y', strtotime($this->data['Ppeg'][$i]['rs_ppeg_tgl_lhr']));
            $this->data['Ppeg'][$i]['rs_ppeg_tgl_lhr'] = strtoupper($this->data['d'] . " " . $this->data['F'] . " " . $this->data['Y']);

            if ($this->data['Ppeg'][$i]['rs_ppeg_jk'] == "L") {
                $this->data['Ppeg'][$i]['rs_ppeg_jk'] = "LAKI-LAKI";
            } else {
                $this->data['Ppeg'][$i]['rs_ppeg_jk'] = "PEREMPUAN";
            }

            if ($this->data['Ppeg'][$i]['rs_ppeg_nmd'] != "") {
                $this->data['Ppeg'][$i]['rs_ppeg_nm'] = ". " . $this->data['Ppeg'][$i]['rs_ppeg_nm'];
            }

            if ($this->data['Ppeg'][$i]['rs_ppeg_nmb'] != "") {
                $this->data['Ppeg'][$i]['rs_ppeg_nm'] = $this->data['Ppeg'][$i]['rs_ppeg_nm'] . ", ";
            }

            

            $this->data['Ppeg'][$i]['rs_ppeg_nm'] = $this->data['Ppeg'][$i]['rs_ppeg_nmd'] . $this->data['Ppeg'][$i]['rs_ppeg_nm'] . $this->data['Ppeg'][$i]['rs_ppeg_nmb'];
        }

        $this->data['WebTitle'] = 'DATA PEGAWAI';
        $this->data['PageTitle'] = 'Data Pegawai';
        $this->data['BasePage'] = 'ppeg';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData';
        $this->data['IdForm'] = 'ppegAddData';
        $this->data['UrlForm'] = 'ppeg';
        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);  

        echo view('Ppeg/indexCtkAllPgwAb', $this->data);
        echo view('Templates/anotherScript');
    }


}