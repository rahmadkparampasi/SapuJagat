<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Controllers\Rmph;
use App\Models\RmpapgMdl;
use App\Models\RmpmskMdl;

class Rmpapg extends BaseController
{
    use ResponseTrait;
    protected $MdlRmpmsk;
    protected $MdlRmpapg;
    protected $Rmph;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlRmpmsk = new RmpmskMdl();
        $this->MdlRmpapg = new RmpapgMdl();
        $this->Rmph = new Rmph();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOIgd',
            'pAct' => 'pAIgd',
            'cAct' => 'cArmpmsk',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {

        return redirect()->to('./rmpmsk');
    }

    public function insertData($rs_rmpapg_rmpmsk)
    {
        $this->data['Rmpmsk'] = $this->MdlRmpmsk->getAllRmpmsk($rs_rmpapg_rmpmsk);

        $insertDataRmph = $this->Rmph->iDH($this->data['Rmpmsk']['rs_rmpmsk_rmpp'], "CT");
        if ($insertDataRmph[0]) {
            $rs_rmpapg_id_ex = $this->MdlRmpapg->getIdEx($this->Another_Include->getRandStr(10));
            $rs_rmpapg_pbb = $this->request->getPost('rs_rmpapg_pbb');
            $rs_rmpapg_imk = $this->request->getPost('rs_rmpapg_imk');
            $rs_rmpapg_kk = $this->request->getPost('rs_rmpapg_kk');
            $rs_rmpapg_skor = $this->request->getPost('rs_rmpapg_skor');
            $rs_rmpapg_skord = $this->request->getPost('rs_rmpapg_skord');

            $dataRmpASF = [
                'rs_rmpapg_id_ex' => $rs_rmpapg_id_ex,
                'rs_rmpapg_rmpmsk' => $rs_rmpapg_rmpmsk,
                'rs_rmpapg_rmph' => $insertDataRmph[1],
                'rs_rmpapg_pbb' => $rs_rmpapg_pbb,
                'rs_rmpapg_imk' => $rs_rmpapg_imk,
                'rs_rmpapg_kk' => $rs_rmpapg_kk,
                'rs_rmpapg_skor' => $rs_rmpapg_skor,
                'rs_rmpapg_skord' => $rs_rmpapg_skord,
            ];
            $insertDataRmpASF = $this->MdlRmpapg->insertData($dataRmpASF);
            if ($insertDataRmpASF) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Anamnesis Permasalahan Gizi Pasien Berhasil Disimpan'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Anamnesis Permasalahan Gizi Pasien Tidak Dapat Disimpan'];
            }
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Histori Pasien Tidak Dapat Disimpan'];
        }

        return $this->respond($data, $data['status']);
    }

    public function deleteData($rs_rmpapg_id_ex = '')
    {
        if ($rs_rmpapg_id_ex === null || $rs_rmpapg_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlRmpapg->deleteData($rs_rmpapg_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Anamnesis Permasalahan Gizi Pasien Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Anamnesis Permasalahan Gizi Pasien Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }
}
