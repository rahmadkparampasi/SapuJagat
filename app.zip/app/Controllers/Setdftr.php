<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\UmMdl;

class Setdftr extends BaseController
{
    use ResponseTrait;
    protected $MdlU;
    protected $AI;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_setdftr', 'rs_setdftr_id_ex');
        $this->AI = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeng',
            'pAct' => 'pAPeng',
            'cAct' => 'cArmref',
            'cmAct' => '',
            'scAct' => '',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA SETUP PENDAFTARAM';
        $this->data['PageTitle'] = 'Data Setup Pendaftaran';
        $this->data['BasePage'] = 'setdftr';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData';
        $this->data['IdForm'] = 'setdftrAddData';
        $this->data['UrlForm'] = 'setdftr';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);


        $this->data['Setdftr'] = $this->setDB();

        echo view('Setdftr/index', $this->data);
        echo view('Templates/anotherScript');
        // echo view('Templates/ajaxInsert', $this->data);
    }

    public function getParentByJson()
    {
        header('Access-Control-Allow-Origin: *');
        $parent_category_id = "";
        $dataByParent = $this->setDB('getAll');
        $data = [];
        foreach ($dataByParent as $val) {
            $data = $this->get_node_data($parent_category_id);
        }

        return $this->respond($data, 200);
    }

    public function get_node_data($str_prt = '')
    {
        $dataByParent = $this->setDB('getAllByIdEx', $str_prt);
        // dd($dataByParent);
        $output = array();
        foreach ($dataByParent as $row) {
            $sub_array = array();
            if ($row['rs_setdftr_sts'] == "0") {
                $sub_array['text'] = "<span class='badge badge-danger'>" . $row['rs_rmr_nm'] . "</span>";
            } else {
                $sub_array['text'] = $row['rs_rmr_nm'];
            }
            $sub_array['textAlt'] = $row['rs_rmr_nm'];
            $sub_array['sts'] = $row['rs_setdftr_sts'];
            $sub_array['idEx'] = $row['rs_setdftr_id_ex'];
            $sub_array['str'] = $row['rs_setdftr_str'];


            $sub_array['nodes'] = array_values($this->get_node_data($row['rs_setdftr_id_ex']));
            $sub_array['tags'] = [(string)count($sub_array['nodes'])];
            if (empty($sub_array['nodes'])) {
                unset($sub_array['nodes']);
            }
            $output[] = $sub_array;
        }
        return $output;
    }

    public function getAllForSelectNP()
    {

        header("Content-Type:application/json;charset=utf-8");
        header("Access-Control-Allow-Origin: *");


        $data = $this->setDB('getAllByIdEx', '');
        for ($i = 0; $i < count($data); $i++) {
            $data[$i]['optText'] = $data[$i]['rs_rmr_nm'];
            $data[$i]['optValue'] = $data[$i]['rs_setdftr_id_ex'];
        }
        return $this->respond($data, 200);
    }
    public function getAllForSelectWP($prt)
    {

        header("Content-Type:application/json;charset=utf-8");
        header("Access-Control-Allow-Origin: *");


        $data = $this->setDB('getAllByIdEx', $prt);
        for ($i = 0; $i < count($data); $i++) {
            $data[$i]['optText'] = $data[$i]['rs_rmr_nm'];
            $data[$i]['optValue'] = $data[$i]['rs_setdftr_id_ex'];
        }
        return $this->respond($data, 200);
    }
    public function getAllForSelectRmr($prt)
    {

        header("Content-Type:application/json;charset=utf-8");
        header("Access-Control-Allow-Origin: *");


        $data = $this->setDB('getAllByIdEx', $prt);
        for ($i = 0; $i < count($data); $i++) {
            $data[$i]['optText'] = $data[$i]['rs_rmr_nm'];
            $data[$i]['optValue'] = $data[$i]['rs_rmr_id_ex'];
        }
        return $this->respond($data, 200);
    }
    public function getAllForSelectRmrByRmr($prt)
    {

        header("Content-Type:application/json;charset=utf-8");
        header("Access-Control-Allow-Origin: *");


        $data = $this->setDB('getAllByRmr', $prt);
        // dd($data);
        $data = $this->setDB('getAllByIdEx', $data['rs_setdftr_id_ex']);
        for ($i = 0; $i < count($data); $i++) {
            $data[$i]['optText'] = $data[$i]['rs_rmr_nm'];
            $data[$i]['optValue'] = $data[$i]['rs_rmr_id_ex'];
        }
        return $this->respond($data, 200);
    }

    public function getAll()
    {
        return $this->setDB('getAll');
    }

    public function insertData()
    {

        $rs_setdftr_id_ex = $this->setDB('idEx', $this->AI->getRandStr(5));
        $rs_setdftr_rmr = $this->request->getPost('rs_setdftr_rmr');
        $rs_setdftr_prnt = $this->request->getPost('rs_setdftr_prnt');
        $rs_setdftr_str = $this->request->getPost('rs_setdftr_str');
        if ($rs_setdftr_str == "" || $rs_setdftr_str == "0") {
            $rs_setdftr_str = 1;
        } else {
            $rs_setdftr_str = $rs_setdftr_str + 1;
        }

        $data = [
            'rs_setdftr_id_ex' => $rs_setdftr_id_ex,
            'rs_setdftr_rmr' => $rs_setdftr_rmr,
            'rs_setdftr_prnt' => $rs_setdftr_prnt,
            'rs_setdftr_str' => $rs_setdftr_str,
        ];

        $insertData = $this->MdlU->insertData($data);
        if ($insertData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Setup Pendaftaran Berhasil Disimpan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Setup Pendaftaran Tidak Dapat Disimpan'];
        }

        return $this->respond($data, $data['status']);
    }


    public function updateData($rs_setdftr_id_ex = '')
    {
        $rs_setdftr_nm = $this->request->getPost('rs_setdftr_nm');
        $rs_setdftr_rmr = $this->request->getPost('rs_setdftr_rmr');
        $rs_setdftr_ket = $this->request->getPost('rs_setdftr_ket');
        $rs_setdftr_id_ex = $this->request->getPost('rs_setdftr_id_ex');
        $data = [
            'rs_setdftr_nm' => $rs_setdftr_nm,
            'rs_setdftr_rmr' => $rs_setdftr_rmr,
            'rs_setdftr_ket' => $rs_setdftr_ket,
        ];
        $updateData = $this->MdlU->updateData($data, $rs_setdftr_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Setup Ruangan Berhasil Diubah'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Setup Ruangan Tidak Dapat Diubah'];
        }
        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_setdftr_id_ex';
        $id = 'rs_setdftr_id';
        $length = 2;
        $typeGet = 'result';

        $fillUpdate = 'rs_setdftr_id_ex, rs_setdftr_nm, rs_setdftr_rmr, rs_rmr_nm, rs_setdftr_ket';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [],
                //order by
                [
                    0 => ['id' => 'rs_setdftr_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmr', 'string' => 'rs_rmr.rs_rmr_id_ex = rs_setdftr.rs_setdftr_rmr', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'getAllByIdEx') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_setdftr_prnt',
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_setdftr_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmr', 'string' => 'rs_rmr.rs_rmr_id_ex = rs_setdftr.rs_setdftr_rmr', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'getAllByRmr') {
            return $this->MdlU->getAll(
                //type result / row
                'row',
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_setdftr_rmr',
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_setdftr_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}