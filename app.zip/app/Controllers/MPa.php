<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\PaMdl;
use App\Models\PpiMdl;
use App\Models\PpsMdl;
use App\Models\PpegMdl;
use App\Models\PpsbbMdl;
use App\Models\PsbbMdl;
use App\Models\PspMdl;
use App\Models\PpsbMdl;
use App\Models\PsbMdl;
use App\Models\PkpMdl;
use App\Models\PkbbMdl;
use App\Models\PpkbbMdl;

class Mpa extends BaseController
{
    use ResponseTrait;
    protected $MdlPa;
    protected $MdlPpi;
    protected $MdlPps;
    protected $MdlPpeg;
    protected $MdlPpsbb;
    protected $MdlPsbb;
    protected $MdlPsp;
    protected $MdlPpsb;
    protected $MdlPsb;
    protected $MdlPkp;
    protected $MdlPkbb;
    protected $MdlPpkbb;

    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlPa = new PaMdl();
        $this->MdlPpi = new PpiMdl();
        $this->MdlPps = new PpsMdl();
        $this->MdlPpeg = new PpegMdl();
        $this->MdlPpsbb = new PpsbbMdl();
        $this->MdlPsbb = new PsbbMdl();
        $this->MdlPsp = new PspMdl();
        $this->MdlPpsb = new PpsbMdl();
        $this->MdlPsb = new PsbMdl();
        $this->MdlPkp = new PkpMdl();
        $this->MdlPkbb = new PkbbMdl();
        $this->MdlPpkbb = new PpkbbMdl();

        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPa',
            'pAct' => 'pAPa',
            'cAct' => '',
            'cmAct' => '',
            'scAct' => '',


            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }


    public function insertData()
    {
        header('Content-Type: application/json; charset=utf-8');
        header('Access-Control-Allow-Origin: *');

        $options = [
            'cost' => 10,
        ];
        $rs_pa_id_ex = $this->Another_Include->getRandStr(15);
        $rs_pa_un = $this->request->getPost('rs_pa_un');
        $rs_pa_pass = password_hash($rs_pa_un, PASSWORD_BCRYPT, $options);
        $rs_pa_act = "1";
        $rs_pa_ppeg = null;

        $dataPeng = [
            'rs_pa_id_ex' => $rs_pa_id_ex,
            'rs_pa_ppeg' => $rs_pa_ppeg,
            'rs_pa_act' => $rs_pa_act,
            'rs_pa_un' => $rs_pa_un,
            'rs_pa_pass' => $rs_pa_pass
        ];
        $insertDataPeng = $this->MdlPa->insertData($dataPeng);
        if ($insertDataPeng) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Pegawai Berhasil Disimpan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Akun Pegawai Tidak Dapat Disimpan'];
        }

        return $this->respond($data, $data['status']);
    }
}