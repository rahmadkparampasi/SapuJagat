<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\RmrkktMdl;
use App\Models\RmrkkMdl;
use App\Models\RmrkMdl;
use App\Models\RmrMdl;

class Rmrkk extends BaseController
{
    use ResponseTrait;
    protected $MdlRmrkk;
    protected $MdlRmrkkt;
    protected $MdlRmrk;
    protected $MdlRmr;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlRmrkk = new RmrkkMdl();
        $this->MdlRmrkkt = new RmrkktMdl();
        $this->MdlRmrk = new RmrkMdl();
        $this->MdlRmr = new RmrMdl();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeng',
            'pAct' => 'pAPeng',
            'cAct' => 'cArmr',
            'cmAct' => '',
            'scAct' => '',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
    }

    public function viewData($rs_rmrk_rmr = '')
    {
        if ($rs_rmrk_rmr == '') {
            echo "<span class='badge badge-danger'>Tidak Ada Daftar Kamar Dalam Ruangan</span>";
        } else {
            $this->data['Rmr'] = $this->MdlRmr->getAllRmr($rs_rmrk_rmr);
            $this->data['WebTitle'] = 'DATA KAMAR DALAM RUANGAN ' . strtoupper($this->data['Rmr']['rs_rmr_nm']);
            $this->data['PageTitle'] = 'Data Kamar Dalam Ruangan ' . $this->data['Rmr']['rs_rmr_nm'];
            $this->data['BasePage'] = 'rmrkk';
            $this->data['ButtonMethod'] = 'SIMPAN';
            $this->data['MethodForm'] = 'insertView/' . $rs_rmrk_rmr;
            $this->data['IdForm'] = 'rmrkkAddData';
            $this->data['UrlForm'] = 'rmrkk';
            $this->data['Rmrkk'] = $this->MdlRmrkk->getAll($rs_rmrk_rmr);
            for ($i=0; $i < count($this->data['Rmrkk']); $i++) { 
                $this->data['Rmrkk'][$i]['Rmrkkt'] = $this->MdlRmrkkt->getAll($this->data['Rmrkk'][$i]['rs_rmrkk_id_ex']);
            }
            
            $this->data['Rmrk'] = $this->MdlRmrk->getAllRmkByRmr($rs_rmrk_rmr);
            // dd($this->data);

            echo view('Rmrkk/index', $this->data);
        }
    }

    public function insertView()
    {
        $rs_rmrkk_id_ex = $this->MdlRmrkk->getIdEx($this->Another_Include->getRandStr(6));
        $rs_rmrkk_rmrk = $this->request->getPost('rs_rmrkk_rmrk');
        $rs_rmrkk_nm = $this->request->getPost('rs_rmrkk_nm');
        $data = [
            'rs_rmrkk_id_ex' => $rs_rmrkk_id_ex,
            'rs_rmrkk_rmrk' => $rs_rmrkk_rmrk,
            'rs_rmrkk_nm' => $rs_rmrkk_nm,
        ];
        $insertData = $this->MdlRmrkk->insertData($data);

        if ($insertData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Kamar Dalam Ruangan Berhasil Disimpan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Kamar Dalam Ruangan Tidak Dapat Disimpan'];
        }

        return $this->respond($data, $data['status']);
    }

    public function blockRmrkk($rs_rmrkk_id_ex = '')
    {
        $data = [
            'rs_rmrkk_sts' => "0",
        ];
        $updateData = $this->MdlRmrkk->updateData($data, $rs_rmrkk_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Kamar Dalam Ruangan Berhasil Di Dinonaktifkan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Kamar Dalam Ruangan Tidak Dapat Di Dinonaktifkan'];
        }
        return $this->respond($data, $data['status']);
    }

    public function unblockRmrkk($rs_rmrkk_id_ex = '')
    {
        $data = [
            'rs_rmrkk_sts' => "1",
        ];
        $updateData = $this->MdlRmrkk->updateData($data, $rs_rmrkk_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Kamar Dalam Ruangan Berhasil Aktifkan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Kamar Dalam Ruangan Tidak Dapat Aktifkan'];
        }
        return $this->respond($data, $data['status']);
    }
}
