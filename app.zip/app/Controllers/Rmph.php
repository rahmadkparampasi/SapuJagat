<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\RmphMdl;

class Rmph extends BaseController
{
    use ResponseTrait;
    protected $MdlRmph;
    protected $Another_Include;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlRmph = new RmphMdl();
        $this->Another_Include = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mORm',
            'pAct' => 'pARm',
            'cAct' => 'cArmpp',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];

        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
    }
    public function iDH($rs_rmph_rmpp = '', $rs_rmph_jns = '')
    {
        $feddBack = false;
        $rs_rmph_id_ex = $this->MdlRmph->getIdExRmph($this->Another_Include->getRandStr(10));
        $rs_rmph_rmpp = $rs_rmph_rmpp;
        $rs_rmph_ppeg = $this->data['rs_ppeg_id_ex'];
        $rs_rmph_jns = $rs_rmph_jns;

        $dataRmph = [
            'rs_rmph_id_ex' => $rs_rmph_id_ex,
            'rs_rmph_rmpp' => $rs_rmph_rmpp,
            'rs_rmph_ppeg' => $rs_rmph_ppeg,
            'rs_rmph_jns' => $rs_rmph_jns
        ];

        if ($rs_rmph_rmpp == '' || $rs_rmph_jns == '') {
            $feddBack = false;
        } else {
            $insertDataRmph = $this->MdlRmph->insertData($dataRmph);
            if ($insertDataRmph) {
                $feddBack = true;
            } else {
                $feddBack = false;
            }
        }
        $data = [$feddBack, $rs_rmph_id_ex];
        return $data;
    }
}
