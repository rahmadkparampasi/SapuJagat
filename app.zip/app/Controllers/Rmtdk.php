<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\UmMdl;
use PhpOffice\PhpSpreadsheet\Reader\Xls as Reader;

class Rmtdk extends BaseController
{
    use ResponseTrait;
    protected $MdlU;
    protected $Rmktdk;
    protected $AI;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_rmtdk', 'rs_rmtdk_id_ex');
        $this->Rmktdk = new Rmktdk();
        $this->AI = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeng',
            'pAct' => 'pAPeng',
            'cAct' => 'cArmref',
            'cmAct' => 'cmArmref',
            'scAct' => '',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA TINDAKAN';
        $this->data['PageTitle'] = 'Data Tindakan';
        $this->data['BasePage'] = 'rmtdk';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData';
        $this->data['IdForm'] = 'rmtdkAddData';
        $this->data['UrlForm'] = 'rmtdk';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);

        $this->data['Rmtdk'] = $this->setDB();
        $this->data['Rmktdk'] = $this->Rmktdk->getAll();

        echo view('Rmtdk/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }

    public function editData($rs_rmtdk_id_ex = '')
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['WebTitle'] = 'DATA TINDAKAN';
        $this->data['PageTitle'] = 'Data Tindakan';
        $this->data['BasePage'] = 'rmtdk';
        $this->data['ButtonMethod'] = 'UBAH';
        $this->data['MethodForm'] = 'updateData/' . $rs_rmtdk_id_ex;
        $this->data['IdForm'] = 'rmtdkAddData';
        $this->data['UrlForm'] = 'rmtdk';

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);

        $this->data['Rmtdk'] = $this->setDB();
        $this->data['Rmktdk'] = $this->Rmktdk->getAll();

        if ($rs_rmtdk_id_ex === null || $rs_rmtdk_id_ex == '') {
            return redirect()->to('/' . $this->data['BasePage']);
        } else {
            $this->data['fillUpdate'] = $this->setDB('fillUpdate', $rs_rmtdk_id_ex);

            echo view('Rmtdk/index', $this->data);
            echo view('Templates/anotherScript');
            echo view('Templates/ajaxInsert', $this->data);
            echo view('Templates/loadData');
        }
    }

    public function getRmtdkByJson($rs_rmr_id_ex)
    {
        header('Content-Type: application/json');
        header("Access-Control-Allow-Origin: *");
        $this->data['data']['data'] = $this->setDB('getAllByAct');
        $no = 0;
        for ($i = 0; $i < count($this->data['data']['data']); $i++) {
            $no++;

            $this->data['data']['data'][$i]['button'] = "<button class='btn bg-gradient-success' title='Tambahkan Tindakan Ke Dalam Ruangan' onclick='addWF(\"Menambahkan " . $this->data['data']['data'][$i]['rs_rmtdk_nm'] . " Dalam Data Ruangan\", \"/" . "rmrtdk/insertData/" . $rs_rmr_id_ex . "/" . $this->data['data']['data'][$i]['rs_rmtdk_id_ex'] . "\", loadTabTdk)'><i class='fas fa-check'></i></button>";
            $this->data['data']['data'][$i]['no'] = $no;
        }
        return $this->respond($this->data['data'], 200);
    }

    public function getRmtdk($rs_rmtdk_id_ex)
    {
        return $this->setDB('fillUpdate', $rs_rmtdk_id_ex);
    }

    public function insertData()
    {
        $rs_rmtdk_id_ex = $this->setDB('idEx', $this->AI->getRandStr(8));
        $rs_rmtdk_nm = $this->request->getPost('rs_rmtdk_nm');
        $rs_rmtdk_h = $this->request->getPost('rs_rmtdk_h');
        $rs_rmtdk_rmktdk = $this->request->getPost('rs_rmtdk_rmktdk');
        if ($rs_rmtdk_rmktdk == "") {
            $rs_rmtdk_rmktdk = null;
        }
        if ($rs_rmtdk_rmktdk == "TdkDipilih") {
            $rs_rmtdk_rmktdk = null;
        }
        $data = [
            'rs_rmtdk_id_ex' => $rs_rmtdk_id_ex,
            'rs_rmtdk_nm' => $rs_rmtdk_nm,
            'rs_rmtdk_h' => $rs_rmtdk_h,
            'rs_rmtdk_rmktdk' => $rs_rmtdk_rmktdk
        ];

        $insertData = $this->MdlU->insertData($data);
        if ($insertData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Tindakan Berhasil Disimpan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Tindakan Tidak Dapat Disimpan'];
        }

        return $this->respond($data, $data['status']);
    }

    public function insertFile()
    {
        
        date_default_timezone_set("Asia/Makassar");

        $ExcelReader = new Reader();

        $file = $this->request->getFile('file');
        $fileLocation = $file->getTempName();
        $objPhpExcel = $ExcelReader->load($fileLocation);
        $sheet = $objPhpExcel->getActiveSheet()->toArray(null, true, true, true);
        $success = 0;
        $error = 0;
        $count = count($sheet) + 1;
        $data = [];
        for ($i = 1; $i < $count; $i++) {
            
            $sheet[$i]['A'] = str_replace('\'', '', $sheet[$i]['A']);
            $sheet[$i]['D'] = str_replace(',', '', $sheet[$i]['D']);
            
            



            
            $rs_rmtdk_id_ex = $this->setDB('idEx', $this->AI->getRandStr(8));
            $rs_rmtdk_rmktdk = null;

            $data = [
                'rs_rmtdk_id_ex' => $rs_rmtdk_id_ex,
                'rs_rmtdk_nm' => $sheet[$i]['A'],
                'rs_rmtdk_h' => $sheet[$i]['D'],
                'rs_rmtdk_rmktdk' => $rs_rmtdk_rmktdk
            ];
            

            $insertData = $this->MdlU->insertData($data);
            if ($insertData) {
                $success += 1;
            } else {
                $error += 1;

            }            
        }
        // dd($sheet);

        // dd($sheet, $data);
        $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Berhasil Diproses, Dengan Data Yang Berhasil Berjumlah ' . (string)$success . ' Data, Dan Yang Tidak Berhasil Berjumlah ' . (string)$error . ' Data'];
        return $this->respond($data, $data['status']);
    }

    public function updateData($rs_rmtdk_id_ex = '')
    {
        $rs_rmtdk_nm = $this->request->getPost('rs_rmtdk_nm');
        $rs_rmtdk_h = $this->request->getPost('rs_rmtdk_h');
        $rs_rmtdk_rmktdk = $this->request->getPost('rs_rmtdk_rmktdk');
        $rs_rmtdk_id_ex = $this->request->getPost('rs_rmtdk_id_ex');
        if ($rs_rmtdk_rmktdk == "") {
            $rs_rmtdk_rmktdk = null;
        }
        if ($rs_rmtdk_rmktdk == "TdkDipilih") {
            $rs_rmtdk_rmktdk = null;
        }
        $data = [
            'rs_rmtdk_nm' => $rs_rmtdk_nm,
            'rs_rmtdk_h' => $rs_rmtdk_h,
            'rs_rmtdk_rmktdk' => $rs_rmtdk_rmktdk
        ];
        $updateData = $this->MdlU->updateData($data, $rs_rmtdk_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Tindakan Berhasil Diubah'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Tindakan Tidak Dapat Diubah'];
        }
        return $this->respond($data, $data['status']);
    }


    public function deleteData($rs_rmtdk_id_ex = '')
    {
        if ($rs_rmtdk_id_ex === null || $rs_rmtdk_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlU->deleteData($rs_rmtdk_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Tindakan Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Tindakan Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function blockTdk($rs_rmtdk_id_ex = '')
    {
        $data = [
            'rs_rmtdk_sts' => "0",
        ];
        $updateData = $this->MdlU->updateData($data, $rs_rmtdk_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Tindakan Berhasil Di Dinonaktifkan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Tindakan Tidak Dapat Di Dinonaktifkan'];
        }
        return $this->respond($data, $data['status']);
    }

    public function unblockTdk($rs_rmtdk_id_ex = '')
    {
        $data = [
            'rs_rmtdk_sts' => "1",
        ];
        $updateData = $this->MdlU->updateData($data, $rs_rmtdk_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Tindakan Berhasil Aktifkan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Tindakan Tidak Dapat Aktifkan'];
        }
        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmtdk_id_ex';
        $id = 'rs_rmtdk_id';
        $length = 2;
        $typeGet = 'result';
        $fillUpdate = 'rs_rmtdk_id_ex, rs_rmtdk_nm, rs_rmtdk_h';

        if ($request == 'getAll') {
            $data = $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [],
                //order by
                [
                    0 => ['id' => 'rs_rmtdk_id', 'orderType' => 'DESC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmktdk', 'string' => 'rs_rmktdk.rs_rmktdk_id_ex = rs_rmtdk.rs_rmtdk_rmktdk', 'type' => 'LEFT'],
                ]
            );
            return $this->AI->rupiahWF($data, ['rs_rmtdk_h']);
        } elseif ($request == 'getAllByAct') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => ['idEx' => 'rs_rmtdk_sts', 'idExV' => '1']
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmtdk_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmktdk', 'string' => 'rs_rmktdk.rs_rmktdk_id_ex = rs_rmtdk.rs_rmtdk_rmktdk', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmtdk_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}
