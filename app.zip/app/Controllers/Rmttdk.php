<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\UmMdl;

class Rmttdk extends BaseController
{
    use ResponseTrait;
    protected $MdlU;
    protected $Rmtdk;
    protected $Rmk;
    protected $AI;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_rmttdk', 'rs_rmttdk_id_ex');
        $this->Rmtdk = new Rmtdk();
        $this->Rmk = new Rmk();
        $this->AI = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mOPeng',
            'pAct' => 'pAPeng',
            'cAct' => 'cArmref',
            'cmAct' => 'cmArmref',
            'scAct' => '',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];
        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function viewData($rs_rmttdk_rmtdk = '')
    {
        if ($this->data['rs_ppeg_id_ex'] === null || $this->data['rs_ppeg_id_ex'] == "") {
            return redirect()->to('./msk');
        }
        $this->data['Rmtdk'] = $this->Rmtdk->setDB('fillUpdate', $rs_rmttdk_rmtdk);
        $this->data['WebTitle'] = 'DATA TINDAKAN ' . strtoupper($this->data['Rmtdk']['rs_rmtdk_nm']);
        $this->data['PageTitle'] = 'Data Tindakan ' . $this->data['Rmtdk']['rs_rmtdk_nm'];
        $this->data['BasePage'] = 'rmttdk';
        $this->data['ButtonMethod'] = 'SIMPAN';
        $this->data['MethodForm'] = 'insertData';
        $this->data['IdForm'] = 'rmttdkAddData';
        $this->data['UrlForm'] = 'rmttdk/viewData/' . $rs_rmttdk_rmtdk;

        $this->data['MethodForm1'] = substr($this->data['MethodForm'], 0, 10);

        $this->data['Rmttdk'] = $this->Rmk->setDB('getAllByRmtdk', $rs_rmttdk_rmtdk);


        if (count($this->data['Rmttdk']) == 0 || !isset($this->data['Rmttdk'])) {
            $this->data['Rmttdk'] = $this->Rmk->setDB('getAllByRmtdkEmpty', $rs_rmttdk_rmtdk);
            for ($i = 0; $i < count($this->data['Rmttdk']); $i++) {
                $this->data['Rmttdk'][$i]['rs_rmttdk_h'] = "";
            }
        }

        // dd($this->data['Rmttdk']);

        echo view('Rmttdk/index', $this->data);
        echo view('Templates/anotherScript');
        echo view('Templates/ajaxInsert', $this->data);
    }


    public function getRmtdkByJson($rs_rmr_id_ex)
    {
        header('Content-Type: application/json');
        header("Access-Control-Allow-Origin: *");
        $this->data['data']['data'] = $this->MdlRmtdk->getAll();
        $no = 0;
        for ($i = 0; $i < count($this->data['data']['data']); $i++) {
            $no++;

            $this->data['data']['data'][$i]['button'] = "<button class='btn bg-gradient-success' title='Tambahkan Tindakan Ke Dalam RUangan' onclick='addWF(\"Menambahkan " . $this->data['data']['data'][$i]['rs_rmtdk_nm'] . " Dalam Data Ruangan\", \"/" . "rmrtdk/insertData/" . $rs_rmr_id_ex . "/" . $this->data['data']['data'][$i]['rs_rmtdk_id_ex'] . "\", loadTabTdk)'><i class='fas fa-check'></i></button>";
            $this->data['data']['data'][$i]['no'] = $no;
        }
        return $this->respond($this->data['data'], 200);
    }



    public function insertData()
    {
        $rs_rmttdk_h = $this->request->getPost('rs_rmttdk_h');
        $rs_rmttdk_rmk = $this->request->getPost('rs_rmttdk_rmk');
        $rs_rmttdk_rmtdk = $this->request->getPost('rs_rmttdk_rmtdk');
        $deleteData = $this->MdlU->deleteDataByV('rs_rmttdk_rmtdk', $rs_rmttdk_rmtdk);
        if ($deleteData) {
            $success = 0;
            $error = 0;
            for ($i = 0; $i < count($rs_rmttdk_h); $i++) {
                $rs_rmttdk_id_ex = $this->setDB('idEx', $this->AI->getRandStr(7));
                $data = [
                    'rs_rmttdk_id_ex' => $rs_rmttdk_id_ex,
                    'rs_rmttdk_h' => $rs_rmttdk_h[$i],
                    'rs_rmttdk_rmk' => $rs_rmttdk_rmk[$i],
                    'rs_rmttdk_rmtdk' => $rs_rmttdk_rmtdk,
                ];
                $insertData = $this->MdlU->insertData($data);
                if ($insertData) {
                    $success = $success + 1;
                } else {
                    $error = $error + 1;
                }
            }
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Berhasil Diproses, Dengan Jumlah Data Yang Berhasil Diproses Berjumlah ' . (string)$success . ' Data, Dan Yang Gagal Diproses Berjumlah ' . (string)$error . ' Data'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Tarif Tindakan Tidak Dapat Dihapus'];
        }



        return $this->respond($data, $data['status']);
    }

    public function updateData($rs_rmtdk_id_ex = '')
    {
        $rs_rmtdk_nm = $this->request->getPost('rs_rmtdk_nm');
        $rs_rmtdk_rmktdk = $this->request->getPost('rs_rmtdk_rmktdk');
        $rs_rmtdk_id_ex = $this->request->getPost('rs_rmtdk_id_ex');
        if ($rs_rmtdk_rmktdk == "TdkDipilih") {
            $rs_rmtdk_rmktdk = null;
        }
        $data = [
            'rs_rmtdk_nm' => $rs_rmtdk_nm,
            'rs_rmtdk_rmktdk' => $rs_rmtdk_rmktdk
        ];
        $updateData = $this->MdlRmtdk->updateData($data, $rs_rmtdk_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Tindakan Berhasil Diubah'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Tindakan Tidak Dapat Diubah'];
        }
        return $this->respond($data, $data['status']);
    }


    public function deleteData($rs_rmtdk_id_ex = '')
    {
        if ($rs_rmtdk_id_ex === null || $rs_rmtdk_id_ex == '') {
            $data = ['status' => 404, 'response' => 'error', 'message' => 'Tidak Ada ID Rujukan Data'];
        } else {
            $deleteData = $this->MdlRmtdk->deleteData($rs_rmtdk_id_ex);
            if ($deleteData) {
                $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Tindakan Berhasil Dihapus'];
            } else {
                $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Tindakan Tidak Dapat Dihapus'];
            }
        }
        return $this->respond($data, $data['status']);
    }

    public function blockTdk($rs_rmtdk_id_ex = '')
    {
        $data = [
            'rs_rmtdk_sts' => "0",
        ];
        $updateData = $this->MdlRmtdk->updateData($data, $rs_rmtdk_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Tindakan Berhasil Di Dinonaktifkan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Tindakan Tidak Dapat Di Dinonaktifkan'];
        }
        return $this->respond($data, $data['status']);
    }

    public function unblockTdk($rs_rmtdk_id_ex = '')
    {
        $data = [
            'rs_rmtdk_sts' => "1",
        ];
        $updateData = $this->MdlRmtdk->updateData($data, $rs_rmtdk_id_ex);
        if ($updateData) {
            $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Tindakan Berhasil Aktifkan'];
        } else {
            $data = ['status' => 500, 'response' => 'error', 'message' => 'Data Tindakan Tidak Dapat Aktifkan'];
        }
        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmttdk_id_ex';
        $id = 'rs_rmttdk_id';
        $length = 3;
        $typeGet = 'result';
        $fillUpdate = 'rs_rmttdk_id_ex, rs_rmttdk_h';

        if ($request == 'getAll') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [],
                //order by
                [
                    0 => ['id' => 'rs_rmttdk_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'getAllByRmtdk') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmttdk_rmtdk',
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmrkkt_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmrkk', 'string' => 'rs_rmrkk.rs_rmrkk_id_ex = rs_rmrkkt.rs_rmrkkt_rmrkk', 'type' => 'LEFT'],
                    1 => ['tableName' => 'rs_rmrk', 'string' => 'rs_rmrk.rs_rmrk_id_ex = rs_rmrkk.rs_rmrkk_rmrk', 'type' => 'LEFT'],
                    2 => ['tableName' => 'rs_rmr', 'string' => 'rs_rmr.rs_rmr_id_ex = rs_rmrk.rs_rmrk_rmr', 'type' => 'LEFT'],
                    3 => ['tableName' => 'rs_rmk', 'string' => 'rs_rmk.rs_rmk_id_ex = rs_rmrk.rs_rmrk_rmk', 'type' => 'LEFT'],
                ],
                //like
                []
            );
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmttdk_id', 'orderType' => 'ASC'],
                ],
                //join
                []
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        }
    }
}