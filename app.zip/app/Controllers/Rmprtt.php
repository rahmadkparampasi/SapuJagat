<?php

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Models\Another_Include;
use App\Models\UmMdl;

class Rmprtt extends BaseController
{
    use ResponseTrait;
    protected $MdlU;
    protected $Rmtrfr;
    protected $AI;
    protected $data;
    protected $session;

    public function __construct()
    {
        $this->MdlU = new UmMdl('rs_rmprtt', 'rs_rmprtt_id_ex');
        $this->Rmtrfr = new Rmtrfr;
        $this->AI = new Another_Include();
        $this->session = \Config\Services::session();
        $this->data = [
            'mOp' => 'mORm',
            'pAct' => 'pARm',
            'cAct' => 'cArmpp',

            'layoutBody' => 'control-sidebar-slide-open accent-primary layout-footer-fixed layout-fixed',
            'rs_ppeg_id_ex' => $this->session->get('rs_ppeg_id_ex'),
            'rs_ppeg_nm' => $this->session->get('rs_ppeg_nm'),
            'rs_ppeg_pic' => $this->session->get('rs_ppeg_pic'),
        ];

        if ($this->data['rs_ppeg_pic'] == "") {
            $this->data['rs_ppeg_pic'] = "/images/user.png";
        } else {
            $this->data['rs_ppeg_pic'] = "/uploads/" . $this->data['rs_ppeg_pic'];
        }
    }

    public function index()
    {
    }
    public function i($data)
    {
        $feedback = false;

        $insertData = $this->MdlU->insertData($data);
        if ($insertData) {
            $feedback = true;
        } else {
            $feedback = false;
        }
        $data = [$feedback];
        return $data;
    }

    public function r()
    {
        $this->data['Rmprtt'] = $this->setDB('getAllByPlg');
        $error = 0;
        $success = 0;
        $date = strtotime("2021-09-24 23:29:00");
        //dd($date);
        for ($i = 0; $i < count($this->data['Rmprtt']); $i++) {
            $dataRmprtt['rs_rmprtt_id_ex'] = $this->setDB('idEx', $this->AI->getRandJStr(9));
            $dataRmprtt['rs_rmprtt_rmpr'] = $this->data['Rmprtt'][$i]['rs_rmprtt_rmpr'];
            $dataRmprtt['rs_rmprtt_rmrkkt'] = $this->data['Rmprtt'][$i]['rs_rmprtt_rmrkkt'];
            $dataRmprtt['rs_rmprtt_tgl'] = date("Y-m-d", strtotime("1 day", strtotime((string)$this->data['Rmprtt'][$i]['rs_rmprtt_tgl'])));
            $dataRmprtt['rs_rmprtt_jam'] = "00:01:00";
            $dataRmprtt['rs_rmprtt_plg'] = "0";


            $date2 = strtotime((string)$this->data['Rmprtt'][$i]['rs_rmprtt_tgl'] . " " . (string)$this->data['Rmprtt'][$i]['rs_rmprtt_jam']);

            $diff = abs($date2 - $date);

            $years = floor($diff / (365 * 60 * 60 * 24));
            $months = floor(($diff - $years * 365 * 60 * 60 * 24) / (30 * 60 * 60 * 24));
            $days = floor(($diff - $years * 365 * 60 * 60 * 24 - $months * 30 * 60 * 60 * 24) / (60 * 60 * 24));
            $hours = floor(($diff - $years * 365 * 60 * 60 * 24 - $months * 30 * 60 * 60 * 24 - $days * 60 * 60 * 24) / (60 * 60));

            $data['rs_rmprtt_byr'] = "0";

            if ((int)$hours >= 23) {
                $data['rs_rmprtt_byr'] = "1";
            }
            // dd((int)$hours, $data);

            $data['rs_rmprtt_plg'] = "1";



            $updateData = $this->MdlU->updateData($data, $this->data['Rmprtt'][$i]['rs_rmprtt_id_ex']);
            if ($updateData) {
                $insertData = $this->MdlU->insertData($dataRmprtt);
                if ($insertData) {
                    $success = $success + 1;
                } else {
                    $error = $error + 1;
                }
            } else {
                $error = $error + 1;
            }
        }
        $data = ['status' => 200, 'response' => 'success', 'message' => 'Data Tempat Tidur Pasien Masuk Berhasil Diproses, Dengan Jumlah Data Yang Berhasil Di Proses Berjumlah ' . (string)$success . ' Data, Dan Yang Gagal Di Proses Berjumlah ' . (string)$success . ' Data'];

        return $this->respond($data, $data['status']);
    }

    public function setDB($request = 'getAll', $data = false)
    {
        $idEx = 'rs_rmprtt_id_ex';
        $id = 'rs_rmprtt_id';
        $length = 3;
        $typeGet = 'result';

        $fillUpdate = '*';

        if ($request == 'getAllByPlg') {
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmprtt_plg',
                        'idExV' => '0'
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmprtt_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    // 0 => ['tableName' => 'rs_rmi', 'string' => 'rs_rmi.rs_rmi_id_ex = rs_rmpp.rs_rmpp_rmi', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'getAllByRmpmsk') {
            $val = $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                '*',
                //where
                [
                    0 => [
                        'idEx' => 'rs_rmpr_rmpmsk',
                        'idExV' => $data[0]
                    ],
                    1 => [
                        'idEx' => 'rs_rmprtt_plg',
                        'idExV' => '1'
                    ],
                    // 1 => [
                    //     'idEx' => 'rs_rmprtt_plg',
                    //     'idExV' => $data[1]
                    // ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmprtt_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    0 => ['tableName' => 'rs_rmpr', 'string' => 'rs_rmpr.rs_rmpr_id_ex = rs_rmprtt.rs_rmprtt_rmpr', 'type' => 'INNER'],
                    1 => ['tableName' => 'rs_rmrkkt', 'string' => 'rs_rmrkkt.rs_rmrkkt_id_ex = rs_rmprtt.rs_rmprtt_rmrkkt', 'type' => 'INNER'],
                    2 => ['tableName' => 'rs_rmrkk', 'string' => 'rs_rmrkk.rs_rmrkk_id_ex = rs_rmrkkt.rs_rmrkkt_rmrkk', 'type' => 'INNER'],
                    3 => ['tableName' => 'rs_rmrk', 'string' => 'rs_rmrk.rs_rmrk_id_ex = rs_rmrkk.rs_rmrkk_rmrk', 'type' => 'INNER'],
                    4 => ['tableName' => 'rs_rmk', 'string' => 'rs_rmk.rs_rmk_id_ex = rs_rmrk.rs_rmrk_rmk', 'type' => 'INNER'],
                    5 => ['tableName' => 'rs_rmtrfr', 'string' => 'rs_rmtrfr.rs_rmtrfr_rmk = rs_rmk.rs_rmk_id_ex', 'type' => 'INNER'],
                    6 => ['tableName' => 'rs_rmr', 'string' => 'rs_rmr.rs_rmr_id_ex = rs_rmpr.rs_rmpr_rmr', 'type' => 'INNER'],
                ],
                //like
                [
                    // 0 => ['idEx' => $data[0], 'idExV' => $data[1]],
                ]
            );
            $val = $this->Rmtrfr->sumAll($val);
            $val = $this->AI->rupiahWF($val, ['rs_rmtrfr_h']);
            return $this->AI->cBWFIF($val, 'rs_rmprtt_byr', 'rs_rmtrfr_h', ['danger', 'warning', 'success'], ['0', '1', '2']);
        } elseif ($request == 'fillUpdate') {
            $typeGet = 'row';
            return $this->MdlU->getAll(
                //type result / row
                $typeGet,
                // select *
                $fillUpdate,
                //where
                [
                    0 => [
                        'idEx' => $idEx,
                        'idExV' => $data
                    ]
                ],
                //order by
                [
                    0 => ['id' => 'rs_rmprtt_id', 'orderType' => 'ASC'],
                ],
                //join
                [
                    // 0 => ['tableName' => 'rs_rmi', 'string' => 'rs_rmi.rs_rmi_id_ex = rs_rmpp.rs_rmpp_rmi', 'type' => 'LEFT'],
                    // 1 => ['tableName' => 'rs_rmag', 'string' => 'rs_rmag.rs_rmag_id_ex = rs_rmpp.rs_rmpp_rmag', 'type' => 'LEFT'],
                    // 2 => ['tableName' => 'rs_rmgd', 'string' => 'rs_rmgd.rs_rmgd_id_ex = rs_rmpp.rs_rmpp_rmgd', 'type' => 'LEFT'],
                ]
            );
        } elseif ($request == 'idEx') {
            return $this->MdlU->getIdEx($idEx, $data, $id, $length);
        } elseif ($request == 'getCode') {
            return $this->MdlU->getIdEx('rs_rmpres_kd', $data, $id, 4);
        }
    }
}