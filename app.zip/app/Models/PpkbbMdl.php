<?php

namespace App\Models;

use CodeIgniter\Model;

class PpkbbMdl extends Model
{
    protected $table = 'rs_ppkbb';
    protected $tableName = 'rs_ppkbb';
    protected $primaryKey = 'rs_ppkbb_id';
    protected $useTimestamps = true;


    public function getAllPpkbb($rs_ppkbb_ppeg, $rs_ppkbb_id = false)
    {
        if ($rs_ppkbb_id === false) {
            $builder = $this->table($this->table);
            $builder->select('*');
            $builder->join('rs_pkbb', 'rs_pkbb.rs_pkbb_id_ex = rs_ppkbb.rs_ppkbb_pkbb', 'LEFT');
            $builder->orderBy('rs_ppkbb_id', 'DESC');
            $builder->where('rs_ppkbb_ppeg', $rs_ppkbb_ppeg);
            $query = $builder->get()->getResultArray();
            return $query;
        } else {
            $builder = $this->table($this->table);
            $builder->select('rs_ppkbb_id, rs_ppkbb_ppeg, rs_ppkbb_pkbb, rs_ppkbb_nmr, rs_ppkbb_tgl_s, rs_ppkbb_tgl_e, rs_ppkbb_fl, rs_ppkbb_ket');
            $builder->where('rs_ppkbb_id', $rs_ppkbb_id);
            $query = $builder->get()->getRowArray();
            return $query;
        }
    }


    public function insertData($data)
    {
        return $this->db->table($this->tableName)->insert($data);
    }

    public function updateData($data, $id_ex)
    {
        return $this->db->table($this->tableName)->update($data, ['rs_ppkbb_id' => $id_ex]);
    }

    public function deleteData($id_ex)
    {
        return $this->db->table($this->tableName)->delete(['rs_ppkbb_id' => $id_ex]);
    }
}
