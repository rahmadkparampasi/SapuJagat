<?php

namespace App\Models;

use CodeIgniter\Model;

class PaMdl extends Model
{
    protected $table = 'rs_pa';
    protected $tableName = 'rs_pa';
    protected $primaryKey = 'rs_pa_id_ex';
    protected $useTimestamps = true;
    protected $allowedFields = ['rs_pa_id_ex', 'rs_pa_un', 'rs_pa_ppeg', 'rs_pa_act'];

    public function getAllPaByIdEx($rs_pa_id_ex)
    {
        $builder = $this->table($this->table);
        $builder->select('*');
        $builder->where('rs_pa_id_ex', $rs_pa_id_ex);
        $query = $builder->get()->getRowArray();
        return $query;
    }

    public function countUsername($rs_pa_un)
    {
        $builder = $this->db->table($this->tableName);
        $builder->select('*');
        $builder->join('rs_ppeg', 'rs_ppeg.rs_ppeg_id_ex = rs_pa.rs_pa_ppeg', 'LEFT');
        $builder->join('rs_ppr', 'rs_ppr.rs_ppr_ppeg = rs_ppeg.rs_ppeg_id_ex', 'LEFT');
        $builder->where('rs_pa_un', $rs_pa_un);
        $builder->where('rs_pa_act', '1');
        $query = $builder->get()->getResultArray();
        return $query;
    }

    public function insertData($data)
    {
        return $this->db->table($this->tableName)->insert($data);
    }

    public function updateData($data, $id_ex)
    {
        return $this->db->table($this->tableName)->update($data, ['rs_pa_id_ex' => $id_ex]);
    }

    public function deleteData($id_ex)
    {
        return $this->db->table($this->tableName)->delete(['rs_pa_id_ex' => $id_ex]);
    }
}
