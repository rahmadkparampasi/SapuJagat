<?php

namespace App\Models;

use CodeIgniter\Model;

class RmrmtMdl extends Model
{
    protected $table = 'rs_rmrmt';
    protected $tableName = 'rs_rmrmt';
    protected $primaryKey = 'rs_rmrmt_id';
    protected $useTimestamps = true;
    protected $allowedFields = ['rs_rmrmt_rmr', 'rs_rmrmt_rmmt', 'rs_rmrmt_sts'];

    public function getAll($rs_rmrmt_rmr)
    {
        $builder = $this->table($this->table);
        $builder->select('*');
        $builder->join('rs_rmmt', 'rs_rmmt.rs_rmmt_id_ex = rs_rmrmt.rs_rmrmt_rmmt', 'LEFT');
        $builder->where('rs_rmrmt_rmr', $rs_rmrmt_rmr);
        $builder->orderBy('rs_rmrmt_id', 'ASC');
        $query = $builder->get()->getResultArray();
        return $query;
    }


    public function getAllByRmmtAndRmr($rs_rmrmt_rmr, $rs_rmrmt_rmmt)
    {
        $builder = $this->table($this->table);
        $builder->select('*');
        $builder->where('rs_rmrmt_rmr', $rs_rmrmt_rmr);
        $builder->where('rs_rmrmt_rmmt', $rs_rmrmt_rmmt);

        $query = $builder->get()->getResultArray();
        return $query;
    }

    public function insertData($data)
    {
        return $this->db->table($this->tableName)->insert($data);
    }

    public function updateData($data, $id)
    {
        return $this->db->table($this->tableName)->update($data, ['rs_rmrmt_id' => $id]);
    }

    public function deleteData($id)
    {
        return $this->db->table($this->tableName)->delete(['rs_rmrmt_id' => $id]);
    }
}
