<?php

namespace App\Models;

use CodeIgniter\Model;

class RmptrMdl extends Model
{
    protected $table = 'rs_rmptr';
    protected $tableName = 'rs_rmptr';
    protected $primaryKey = 'rs_rmptr_id_ex';
    protected $useTimestamps = true;
    protected $allowedFields = ['rs_rmptr_id_ex'];

    public function getAllRmptr($rs_rmptr_rmpmsk, $rs_rmptr_id_ex = false)
    {
        if ($rs_rmptr_id_ex === false) {
            $builder = $this->db->table($this->tableName);
            $builder->select('*');
            $builder->join('rs_rmsmf', 'rs_rmsmf.rs_rmsmf_id_ex = rs_rmptr.rs_rmptr_rmsmf', 'LEFT');
            $builder->join('rs_rmkt', 'rs_rmkt.rs_rmkt_id_ex = rs_rmptr.rs_rmptr_rmkt', 'LEFT');
            $builder->where('rs_rmptr_rmpmsk', $rs_rmptr_rmpmsk);
            $query = $builder->get()->getResultArray();
            return $query;
        } else {
            $builder = $this->db->table($this->tableName);
            $builder->select('*');
            $builder->where('rs_rmptr_id_ex', $rs_rmptr_id_ex);
            $query = $builder->get()->getRowArray();
            return $query;
        }
    }

    public function getRmptrByIdEx($rs_rmptr_id_ex)
    {
        $builder = $this->db->table($this->tableName);
        $builder->select('rs_rmptr_id_ex, rs_rmptr_ku, rs_rmptr_td, rs_rmptr_fnd, rs_rmptr_fnf, rs_rmptr_sh, rs_rmptr_ram, rs_rmptr_rao, rs_rmptr_jn, rs_rmptr_pfr, rs_rmptr_whz, rs_rmptr_sia, rs_rmptr_hn, rs_rmptr_pfn, rs_rmptr_sis, rs_rmptr_dia, rs_rmptr_hj, rs_rmptr_na, rs_rmptr_pc, rs_rmptr_ak, rs_rmptr_ks, rs_rmptr_doa, rs_rmptr_tgl, rs_rmptr_jam, rs_rmptr_ats');
        $builder->where('rs_rmptr_id_ex', $rs_rmptr_id_ex);
        $query = $builder->get()->getRowArray();
        return $query;
    }

    public function getIdExRmptr($rs_rmptr_id_ex)
    {
        $builder = $this->db->table($this->tableName);
        $builder->select('MAX(RIGHT(rs_rmptr_id_ex, 5)) as max_id ');
        $builder->like('rs_rmptr_id_ex', $rs_rmptr_id_ex);
        $builder->orderBy('rs_rmptr_id', 'DESC');
        $query = $builder->get()->getRowArray();
        $max_id = (int)$query['max_id'];
        $new_id_str = "";
        $new_id = $max_id + 1;
        $lengt_id = strlen((string)$new_id);
        $rolback = 5 - $lengt_id;
        for ($i = 0; $i < $rolback; $i++) {
            $new_id_str .= "0";
        }
        $new_id_str .= (string)$new_id;
        return $rs_rmptr_id_ex . $new_id_str;
    }

    public function insertData($data)
    {
        return $this->db->table($this->tableName)->insert($data);
    }

    public function updateData($data, $id_ex)
    {
        return $this->db->table($this->tableName)->update($data, ['rs_rmptr_id_ex' => $id_ex]);
    }

    public function deleteData($id_ex)
    {
        return $this->db->table($this->tableName)->delete(['rs_rmptr_id_ex' => $id_ex]);
    }
}