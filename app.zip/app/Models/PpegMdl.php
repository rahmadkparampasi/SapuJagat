<?php

namespace App\Models;

use CodeIgniter\Model;

class PpegMdl extends Model
{
    protected $table = 'rs_ppeg';
    protected $tableName = 'rs_ppeg';
    protected $primaryKey = 'rs_ppeg_id_ex';
    protected $useTimestamps = true;
    protected $allowedFields = ['rs_ppeg_id_ex', 'rs_ppeg_nmd', 'rs_pjp_nm', 'rs_ppeg_nmb', 'rs_ppeg_nm', 'rs_ppeg_stts', 'rs_ppeg_nip', 'rs_ppeg_tmpt_lhr', 'rs_ppeg_tgl_lhr', 'rs_ppeg_nik'];

    public function getAllPpeg($rs_ppeg_id_ex = false)
    {
        if ($rs_ppeg_id_ex === false) {
            $builder = $this->db->table($this->tableName);
            $builder->select('*');
            $builder->join('rs_pa', 'rs_ppeg.rs_ppeg_id_ex = rs_pa.rs_pa_ppeg', 'LEFT');
            $builder->join('rs_pkp', 'rs_pkp.rs_pkp_id_ex = rs_ppeg.rs_ppeg_pkp', 'LEFT');
            $builder->join('rs_psp', 'rs_psp.rs_psp_id_ex = rs_ppeg.rs_ppeg_psp', 'LEFT');
            $builder->join('rs_ppsbb', 'rs_ppeg.rs_ppeg_id_ex = rs_ppsbb.rs_ppsbb_ppeg', 'LEFT');
            $builder->join('rs_ppr', 'rs_ppr.rs_ppr_ppeg  = rs_ppeg.rs_ppeg_id_ex', 'LEFT');
            $builder->join('rs_rmr', 'rs_rmr.rs_rmr_id_ex = rs_ppr.rs_ppr_rmr', 'LEFT');
            $query = $builder->get()->getResultArray();
            return $query;
        } else {
            $builder = $this->db->table($this->tableName);
            $builder->select('rs_ppeg_id_ex, rs_ppeg_nmd, rs_pjp_nm, rs_ppeg_nmb, rs_ppeg_nm, rs_ppeg_stts, rs_ppeg_nip, rs_ppeg_tmpt_lhr, rs_ppeg_tgl_lhr, rs_ppeg_nik');
            $builder->where('rs_ppeg_id_ex', $rs_ppeg_id_ex);
            $query = $builder->get()->getRowArray();
            return $query;
        }
    }

    public function getPpegByIdEx($rs_ppeg_id_ex = false)
    {
        $builder = $this->db->table($this->tableName);
        $builder->select('*');
        $builder->join('rs_ppi', 'rs_ppeg.rs_ppeg_id_ex = rs_ppi.rs_ppi_ppeg', 'LEFT');
        $builder->join('rs_pa', 'rs_ppeg.rs_ppeg_id_ex = rs_pa.rs_pa_ppeg', 'LEFT');
        $builder->join('rs_pkp', 'rs_pkp.rs_pkp_id_ex = rs_ppeg.rs_ppeg_pkp', 'LEFT');
        $builder->join('rs_psp', 'rs_psp.rs_psp_id_ex = rs_ppeg.rs_ppeg_psp', 'LEFT');
        $builder->join('rs_ppsbb', 'rs_ppeg.rs_ppeg_id_ex = rs_ppsbb.rs_ppsbb_ppeg', 'LEFT');
        $builder->join('rs_psbb', 'rs_psbb.rs_psbb_psp = rs_psp.rs_psp_id_ex', 'LEFT');
        $builder->join('rs_psb', 'rs_psb.rs_psb_psp = rs_psp.rs_psp_id_ex', 'LEFT');
        $builder->join('rs_pkbb', 'rs_pkbb.rs_pkbb_pkp = rs_pkp.rs_pkp_id_ex', 'LEFT');
        $builder->where('rs_ppeg_id_ex', $rs_ppeg_id_ex);
        $query = $builder->get()->getRowArray();
        return $query;
    }

    public function getPpegByNip($rs_ppeg_nip = false)
    {
        $builder = $this->db->table($this->tableName);
        $builder->select('*');
        $builder->where('rs_ppeg_nip', $rs_ppeg_nip);
        $query = $builder->get()->getResultArray();
        return $query;
    }


    public function insertData($data)
    {
        return $this->db->table($this->tableName)->insert($data);
    }

    public function updateData($data, $id_ex)
    {
        return $this->db->table($this->tableName)->update($data, ['rs_ppeg_id_ex' => $id_ex]);
    }

    public function deleteData($id_ex)
    {
        return $this->db->table($this->tableName)->delete(['rs_ppeg_id_ex' => $id_ex]);
    }
}
