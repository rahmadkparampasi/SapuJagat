<?php

namespace App\Models;

use CodeIgniter\Model;

class PpsbbMdl extends Model
{
    protected $table = 'rs_ppsbb';
    protected $tableName = 'rs_ppsbb';
    protected $primaryKey = 'rs_ppsbb_id';
    protected $useTimestamps = true;


    public function getAllPpsbb($rs_ppsbb_ppeg, $rs_ppsbb_id = false)
    {
        if ($rs_ppsbb_id === false) {
            $builder = $this->table($this->table);
            $builder->select('*');
            $builder->join('rs_psbb', 'rs_psbb.rs_psbb_id_ex = rs_ppsbb.rs_ppsbb_pkbb', 'LEFT');
            $builder->orderBy('rs_ppsbb_id', 'DESC');
            $builder->where('rs_ppsbb_ppeg', $rs_ppsbb_ppeg);
            $query = $builder->get()->getResultArray();
            return $query;
        } else {
            $builder = $this->table($this->table);
            $builder->select('rs_ppsbb_id, rs_ppsbb_ppeg, rs_ppsbb_pkbb, rs_ppsbb_nmr, rs_ppsbb_tgl_s, rs_ppsbb_tgl_e, rs_ppsbb_fl, rs_ppsbb_ket');
            $builder->where('rs_ppsbb_id', $rs_ppsbb_id);
            $query = $builder->get()->getRowArray();
            return $query;
        }
    }

    public function getPpsbByIdEx($rs_ppsbb_ppeg = false)
    {
        $builder = $this->db->table($this->tableName);
        $builder->select('rs_ppsbb_ppeg, rs_ppsbb_nmr, rs_ppsbb_tgl_s, rs_ppsbb_tgl_e, rs_ppsbb_fl, rs_ppsbb_ket');
        $builder->where('rs_ppsbb_ppeg', $rs_ppsbb_ppeg);
        $query = $builder->get()->getRowArray();
        return $query;
    }

    public function insertData($data)
    {
        return $this->db->table($this->tableName)->insert($data);
    }

    public function updateData($data, $id_ex)
    {
        return $this->db->table($this->tableName)->update($data, ['rs_ppsbb_id' => $id_ex]);
    }

    public function deleteData($id_ex)
    {
        return $this->db->table($this->tableName)->delete(['rs_ppsbb_id' => $id_ex]);
    }
}
