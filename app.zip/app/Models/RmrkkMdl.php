<?php

namespace App\Models;

use CodeIgniter\Model;

class RmrkkMdl extends Model
{
    protected $table = 'rs_rmrkk';
    protected $tableName = 'rs_rmrkk';
    protected $primaryKey = 'rs_rmrk_id_ex';
    protected $useTimestamps = true;
    protected $allowedFields = ['rs_rmrk_rmr', 'rs_rmrk_rmk'];

    public function getAll($rs_rmrk_rmr = false)
    {
        $builder = $this->table($this->table);
        $builder->select('*');
        $builder->join('rs_rmrk', 'rs_rmrk.rs_rmrk_id_ex = rs_rmrkk.rs_rmrkk_rmrk', 'LEFT');
        $builder->join('rs_rmr', 'rs_rmr.rs_rmr_id_ex = rs_rmrk.rs_rmrk_rmr', 'LEFT');
        $builder->join('rs_rmk', 'rs_rmk.rs_rmk_id_ex = rs_rmrk.rs_rmrk_rmk', 'LEFT');
        $builder->where('rs_rmrk_rmr', $rs_rmrk_rmr);
        $builder->orderBy('rs_rmrkk_id', 'ASC');
        $query = $builder->get()->getResultArray();
        return $query;
    }

    public function getIdEx($rs_rmrkk_id_ex)
    {
        $builder = $this->db->table($this->tableName);
        $builder->select('MAX(RIGHT(rs_rmrkk_id_ex, 2)) as max_id ');
        $builder->like('rs_rmrkk_id_ex', $rs_rmrkk_id_ex);
        $builder->orderBy('rs_rmrkk_id', 'DESC');
        $query = $builder->get()->getRowArray();
        $max_id = (int)$query['max_id'];
        $new_id_str = "";
        $new_id = $max_id + 1;
        $lengt_id = strlen((string)$new_id);
        $rolback = 2 - $lengt_id;
        for ($i = 0; $i < $rolback; $i++) {
            $new_id_str .= "0";
        }
        $new_id_str .= (string)$new_id;
        return $rs_rmrkk_id_ex . $new_id_str;
    }


    public function getAllRmrkByRmkAndRmr($rs_rmrk_rmr, $rs_rmrk_rmk)
    {
        $builder = $this->table($this->table);
        $builder->select('*');
        $builder->where('rs_rmrk_rmr', $rs_rmrk_rmr);
        $builder->where('rs_rmrk_rmk', $rs_rmrk_rmk);

        $query = $builder->get()->getResultArray();
        return $query;
    }

    public function insertData($data)
    {
        return $this->db->table($this->tableName)->insert($data);
    }

    public function updateData($data, $id)
    {
        return $this->db->table($this->tableName)->update($data, ['rs_rmrkk_id_ex' => $id]);
    }

    public function deleteData($id)
    {
        return $this->db->table($this->tableName)->delete(['rs_rmrkk_id_ex' => $id]);
    }
}
