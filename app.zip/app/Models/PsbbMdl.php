<?php

namespace App\Models;

use CodeIgniter\Model;

class PsbbMdl extends Model
{
    protected $table = 'rs_psbb';
    protected $tableName = 'rs_psbb';
    protected $primaryKey = 'rs_psbb_id_ex';
    protected $useTimestamps = true;
    protected $allowedFields = ['rs_psbb_id_ex', 'rs_psbb_psp', 'rs_psbb_nm', 'rs_psbb_jw', 'rs_psbb_jk', 'rs_psbb_wjb'];

    public function getAllPsbb($rs_psbb_psp, $rs_psbb_id_ex = false)
    {
        if ($rs_psbb_id_ex === false) {
            $builder = $this->db->table($this->tableName);
            $builder->select('*');
            $builder->join('rs_psp', 'rs_psp.rs_psp_id_ex = rs_psbb.rs_psbb_psp', 'LEFT');
            $builder->where('rs_psbb_psp', $rs_psbb_psp);
            $query = $builder->get()->getResultArray();
            return $query;
        } else {
            $builder = $this->db->table($this->tableName);
            $builder->select('rs_psbb_id_ex, rs_psbb_nm, rs_psbb_jw, rs_psbb_jk, rs_psbb_wjb');
            $builder->where('rs_psbb_id_ex', $rs_psbb_id_ex);
            $query = $builder->get()->getRowArray();
            return $query;
        }
    }

    public function insertData($data)
    {
        return $this->db->table($this->tableName)->insert($data);
    }

    public function updateData($data, $id_ex)
    {
        return $this->db->table($this->tableName)->update($data, ['rs_psbb_id_ex' => $id_ex]);
    }

    public function deleteData($id_ex)
    {
        return $this->db->table($this->tableName)->delete(['rs_psbb_id_ex' => $id_ex]);
    }
}
