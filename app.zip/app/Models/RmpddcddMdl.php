<?php

namespace App\Models;

use CodeIgniter\Model;

class RmpddcddMdl extends Model
{
    protected $table = 'rs_rmpddcd';
    protected $tableName = 'rs_rmpddcd';
    protected $primaryKey = 'rs_rmpddcd_id_ex';
    protected $useTimestamps = true;


    public function getAllRmpddcdd($rs_rmpddcd_rmpmsk, $rs_rmpddcd_id_ex = false)
    {
        if ($rs_rmpddcd_id_ex === false) {
            $builder = $this->db->table($this->tableName);
            $builder->select('*');
            $builder->where('rs_rmpddcd_rmpmsk', $rs_rmpddcd_rmpmsk);
            $query = $builder->get()->getResultArray();
            return $query;
        } else {
            $builder = $this->db->table($this->tableName);
            $builder->select('*');
            $builder->where('rs_rmpddcd_id_ex', $rs_rmpddcd_id_ex);
            $query = $builder->get()->getRowArray();
            return $query;
        }
    }

    public function getRmpadgdByIdEx($rs_rmpadgd_id_ex)
    {
        $builder = $this->db->table($this->tableName);
        $builder->select('rs_rmpadgd_id_ex, rs_rmpadgd_tgl, rs_rmpadgd_jam, rs_rmpadgd_an, rs_rmpadgd_aln, rs_rmpadgd_fnf, rs_rmpadgd_fnd, rs_rmpadgd_td, rs_rmpadgd_sh, rs_rmpadgd_vas, rs_rmpadgd_gcse, rs_rmpadgd_gcsv, rs_rmpadgd_gcsm, rs_rmpadgd_kes, rs_rmpadgd_ku, rs_rmpadgd_pfk, rs_rmpadgd_pfd, rs_rmpadgd_pfp, rs_rmpadgd_pfe, rs_rmpadgd_pao, rs_rmpadgd_paok, rs_rmpadgd_osm, rs_rmpadgd_tin, rs_rmpadgd_obt, rs_rmpadgd_kon, rs_rmpadgd_per, rs_rmpadgd_paob, rs_rmpadgd_parjk, rs_rmpadgd_parjket, rs_rmpadgd_pari, rs_rmpadgd_park, rs_rmpadgd_parka, rs_rmpadgd_papa, rs_rmpadgd_kppk, rs_rmpadgd_pgcse, rs_rmpadgd_pgcsv, rs_rmpadgd_pgcsm, rs_rmpadgd_ptd, rs_rmpadgd_pfnd, rs_rmpadgd_pfnf, rs_rmpadgd_psh, rs_rmpadgd_pvas, rs_rmpadgd_pcat');
        $builder->where('rs_rmpadgd_id_ex', $rs_rmpadgd_id_ex);
        $query = $builder->get()->getRowArray();
        return $query;
    }

    public function getIdExRmpadgd($rs_rmpadgd_id_ex)
    {
        $builder = $this->db->table($this->tableName);
        $builder->select('MAX(RIGHT(rs_rmpadgd_id_ex, 5)) as max_id ');
        $builder->like('rs_rmpadgd_id_ex', $rs_rmpadgd_id_ex);
        $builder->orderBy('rs_rmpadgd_id', 'DESC');
        $query = $builder->get()->getRowArray();
        $max_id = (int)$query['max_id'];
        $new_id_str = "";
        $new_id = $max_id + 1;
        $lengt_id = strlen((string)$new_id);
        $rolback = 5 - $lengt_id;
        for ($i = 0; $i < $rolback; $i++) {
            $new_id_str .= "0";
        }
        $new_id_str .= (string)$new_id;
        return $rs_rmpadgd_id_ex . $new_id_str;
    }

    public function insertData($data)
    {
        return $this->db->table($this->tableName)->insert($data);
    }

    public function updateData($data, $id_ex)
    {
        return $this->db->table($this->tableName)->update($data, ['rs_rmpadgd_id_ex' => $id_ex]);
    }

    public function deleteData($id_ex)
    {
        return $this->db->table($this->tableName)->delete(['rs_rmpadgd_id_ex' => $id_ex]);
    }
}
