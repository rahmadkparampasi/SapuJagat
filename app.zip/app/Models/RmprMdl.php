<?php

namespace App\Models;

use CodeIgniter\Model;

class RmprMdl extends Model
{
    protected $table = 'rs_rmpr';
    protected $tableName = 'rs_rmpr';
    protected $primaryKey = 'rs_rmpr_id';
    protected $useTimestamps = true;
    protected $allowedFields = ['rs_rmpr_id', 'rs_rmpr_rmpmsk', 'rs_rmpr_rmr', 'rs_rmpr_ppeg', 'rs_rmpr_rmph'];

    public function getByRmpmsk($rs_rmpr_rmpmsk)
    {
        $builder = $this->table($this->table);
        $builder->select('*');
        $builder->where('rs_rmpr_rmpmsk', $rs_rmpr_rmpmsk);
        $builder->orderBy('rs_rmpr_id', 'ASC');
        $query = $builder->get()->getRowArray();
        return $query;
    }

    public function insertData($data)
    {
        return $this->db->table($this->tableName)->insert($data);
    }

    public function updateData($data, $id_ex)
    {
        return $this->db->table($this->tableName)->update($data, ['rs_rmpr_id' => $id_ex]);
    }

    public function deleteData($id_ex)
    {
        return $this->db->table($this->tableName)->delete(['rs_rmpr_id' => $id_ex]);
    }
}