<?php

namespace App\Models;

use CodeIgniter\Model;

class PpiMdl extends Model
{
    protected $table = 'rs_ppi';
    protected $tableName = 'rs_ppi';
    protected $primaryKey = 'rs_ppi_id_ex';
    protected $useTimestamps = true;


    public function getAllPpi($rs_ppi_ppeg, $rs_ppi_id_ex = false)
    {
        if ($rs_ppi_id_ex === false) {
            $builder = $this->db->table($this->tableName);
            $builder->select('*');
            $builder->where('rs_ppi_ppeg', $rs_ppi_ppeg);
            $query = $builder->get()->getResultArray();
            return $query;
        } else {
            $builder = $this->db->table($this->tableName);
            $builder->select('rs_ppi_id_ex, rs_ppi_t, rs_ppi_msk, rs_ppi_klr, rs_ppi_inst, rs_ppi_nmr, rs_ppi_ket, rs_ppi_fl');
            $builder->where('rs_ppi_id_ex', $rs_ppi_id_ex);
            $query = $builder->get()->getRowArray();
            return $query;
        }
    }

    public function getPpiByIdEx($rs_ppi_id_ex = false)
    {
        $builder = $this->db->table($this->tableName);
        $builder->select('rs_ppi_id_ex, rs_ppi_t, rs_ppi_msk, rs_ppi_klr, rs_ppi_inst, rs_ppi_nmr, rs_ppi_ket, rs_ppi_fl');
        $builder->where('rs_ppi_id_ex', $rs_ppi_id_ex);
        $query = $builder->get()->getRowArray();
        return $query;
    }

    public function insertData($data)
    {
        return $this->db->table($this->tableName)->insert($data);
    }

    public function updateData($data, $id_ex)
    {
        return $this->db->table($this->tableName)->update($data, ['rs_ppi_id_ex' => $id_ex]);
    }

    public function deleteData($id_ex)
    {
        return $this->db->table($this->tableName)->delete(['rs_ppi_id_ex' => $id_ex]);
    }
}