<?php

namespace App\Models;

use CodeIgniter\Model;

class RmphMdl extends Model
{
    protected $table = 'rs_rmph';
    protected $tableName = 'rs_rmph';
    protected $primaryKey = 'rs_rmph_id_ex';
    protected $useTimestamps = true;
    protected $allowedFields = ['rs_rmph_id_ex', 'rs_rmph_ppeg', 'rs_rmph_rmpp', 'rs_rmph_jns'];

    public function getIdExRmph($rs_rmph_id_ex)
    {
        $builder = $this->db->table($this->tableName);
        $builder->select('MAX(RIGHT(rs_rmph_id_ex, 5)) as max_id ');
        $builder->like('rs_rmph_id_ex', $rs_rmph_id_ex);
        $builder->orderBy('rs_rmph_id', 'DESC');
        $query = $builder->get()->getRowArray();
        $max_id = (int)$query['max_id'];
        $new_id_str = "";
        $new_id = $max_id + 1;
        $lengt_id = strlen((string)$new_id);
        $rolback = 5 - $lengt_id;
        for ($i = 0; $i < $rolback; $i++) {
            $new_id_str .= "0";
        }
        $new_id_str .= (string)$new_id;
        return $rs_rmph_id_ex . $new_id_str;
    }



    public function insertData($data)
    {
        return $this->db->table($this->tableName)->insert($data);
    }

    public function updateData($data, $id_ex)
    {
        return $this->db->table($this->tableName)->update($data, ['rs_rmph_id_ex' => $id_ex]);
    }

    public function deleteData($id_ex)
    {
        return $this->db->table($this->tableName)->delete(['rs_rmph_id_ex' => $id_ex]);
    }
}
