<?php

namespace App\Models;

use CodeIgniter\Model;

class RmppMdl extends Model
{
    protected $table = 'rs_rmpp';
    protected $tableName = 'rs_rmpp';
    protected $primaryKey = 'rs_rmpp_id_ex';
    protected $useTimestamps = true;


    public function getAllRmpp($rs_rmpp_id_ex = false)
    {
        if ($rs_rmpp_id_ex === false) {
            $builder = $this->db->table($this->tableName);
            $builder->select('*');
            $query = $builder->get()->getResultArray();
            return $query;
        } else {
            $builder = $this->db->table($this->tableName);
            $builder->select('rs_rmpp_nm, rs_rmpp_rmi, rs_rmpp_ind, rs_rmpp_tgl_lhr, rs_rmpp_tmpt_lhr, rs_rmpp_jk, rs_rmpp_rmag, rs_rmpp_altktp, rs_rmpp_altn, rs_rmpp_altr, rs_rmpp_altkk, rs_rmpp_altkp, rs_rmpp_altth, rs_rmpp_sb, rs_rmpp_bhs, rs_rmpp_rmgd');
            $builder->where('rs_rmpp_id_ex', $rs_rmpp_id_ex);
            $query = $builder->get()->getRowArray();
            return $query;
        }
    }

    public function getIdExRmpp($rs_rmpp_id_ex)
    {
        $builder = $this->db->table($this->tableName);
        $builder->select('MAX(RIGHT(rs_rmpp_id_ex, 5)) as max_id ');
        $builder->like('rs_rmpp_id_ex', $rs_rmpp_id_ex);
        $builder->orderBy('rs_rmpp_id', 'DESC');
        $query = $builder->get()->getRowArray();
        $max_id = (int)$query['max_id'];
        $new_id_str = "";
        $new_id = $max_id + 1;
        $lengt_id = strlen((string)$new_id);
        $rolback = 5 - $lengt_id;
        for ($i = 0; $i < $rolback; $i++) {
            $new_id_str .= "0";
        }
        $new_id_str .= (string)$new_id;
        return $rs_rmpp_id_ex . $new_id_str;
    }

    public function getLastNoRm()
    {
        $builder = $this->db->table($this->tableName);
        $builder->select('rs_rmpp_rm');
        $builder->orderBy('rs_rmpp_id', 'DESC');
        $builder->limit(1);
        $query = $builder->get()->getRowArray();
        if (empty($query)) {
            $query['rs_rmpp_rm'] = 0;
        }
        return $query['rs_rmpp_rm'];
    }

    public function insertData($data)
    {
        return $this->db->table($this->tableName)->insert($data);
    }

    public function updateData($data, $id_ex)
    {
        return $this->db->table($this->tableName)->update($data, ['rs_rmpp_id_ex' => $id_ex]);
    }

    public function deleteData($id_ex)
    {
        return $this->db->table($this->tableName)->delete(['rs_rmpp_id_ex' => $id_ex]);
    }
}
