<?php

namespace App\Models;

use CodeIgniter\Model;

class RmpmskMdl extends Model
{
    protected $table = 'rs_rmpmsk';
    protected $tableName = 'rs_rmpmsk';
    protected $primaryKey = 'rs_rmpmsk_id_ex';
    protected $useTimestamps = true;
    protected $allowedFields = ['rs_rmpmsk_id_ex', 'rs_rmpmsk_rmpp', 'rs_rmpmsk_tgl', 'rs_rmpmsk_jam'];

    public function getAllRmpmsk($rs_rmpmsk_id_ex = false)
    {
        if ($rs_rmpmsk_id_ex === false) {
            $builder = $this->db->table($this->tableName);
            $builder->select('*');
            $builder->join('rs_rmpp', 'rs_rmpp.rs_rmpp_id_ex = rs_rmpmsk.rs_rmpmsk_rmpp', 'LEFT');
            $builder->join('rs_rma', 'rs_rma.rs_rma_id_ex = rs_rmpmsk.rs_rmpmsk_rma', 'LEFT');
            $builder->where('rs_rmpmsk_plg', '0');
            $query = $builder->get()->getResultArray();
            return $query;
        } else {
            $builder = $this->db->table($this->tableName);
            $builder->select('*');
            $builder->join('rs_rmpp', 'rs_rmpp.rs_rmpp_id_ex = rs_rmpmsk.rs_rmpmsk_rmpp', 'LEFT');
            $builder->join('rs_rma', 'rs_rma.rs_rma_id_ex = rs_rmpmsk.rs_rmpmsk_rma', 'LEFT');
            $builder->where('rs_rmpmsk_id_ex', $rs_rmpmsk_id_ex);
            $query = $builder->get()->getRowArray();
            return $query;
        }
    }

    public function getAllRmpmskWJ($rs_rmpmsk_id_ex = false)
    {
        $builder = $this->db->table($this->tableName);
        $builder->select('*');
        // $builder->join('rs_rmpmskpj', 'rs_rmpmskpj.rs_rmpmskpj_rmpmsk = rs_rmpmsk.rs_rmpmsk_id_ex', 'LEFT');
        $builder->join('rs_rmpp', 'rs_rmpp.rs_rmpp_id_ex = rs_rmpmsk.rs_rmpmsk_rmpp', 'LEFT');
        $builder->join('rs_rmi', 'rs_rmi.rs_rmi_id_ex = rs_rmpp.rs_rmpp_rmi', 'LEFT');
        $builder->join('rs_rmag', 'rs_rmag.rs_rmag_id_ex = rs_rmpp.rs_rmpp_rmag', 'LEFT');
        $builder->join('rs_rma', 'rs_rma.rs_rma_id_ex = rs_rmpmsk.rs_rmpmsk_rma', 'LEFT');
        $builder->join('rs_rmsts', 'rs_rmsts.rs_rmsts_id_ex = rs_rmpmsk.rs_rmpmsk_rmsts', 'LEFT');
        $builder->join('rs_rmpdk', 'rs_rmpdk.rs_rmpdk_id_ex = rs_rmpmsk.rs_rmpmsk_rmpdk', 'LEFT');
        $builder->join('rs_rmkrj', 'rs_rmkrj.rs_rmkrj_id_ex = rs_rmpmsk.rs_rmpmsk_rmkrj', 'LEFT');
        $builder->join('rs_rmtgl', 'rs_rmtgl.rs_rmtgl_id_ex = rs_rmpmsk.rs_rmpmsk_rmtgl', 'LEFT');
        $builder->join('rs_rmab', 'rs_rmab.rs_rmab_id_ex = rs_rmpmsk.rs_rmpmsk_rmab', 'LEFT');
        $builder->where('rs_rmpmsk_id_ex', $rs_rmpmsk_id_ex);
        $query = $builder->get()->getRowArray();
        return $query;
    }

    public function getIdExRmpmsk($rs_rmpmsk_id_ex)
    {
        $builder = $this->db->table($this->tableName);
        $builder->select('MAX(RIGHT(rs_rmpmsk_id_ex, 3)) as max_id ');
        $builder->like('rs_rmpmsk_id_ex', $rs_rmpmsk_id_ex);
        $builder->orderBy('rs_rmpmsk_id', 'DESC');
        $query = $builder->get()->getRowArray();
        $max_id = (int)$query['max_id'];
        $new_id_str = "";
        $new_id = $max_id + 1;
        $lengt_id = strlen((string)$new_id);
        $rolback = 3 - $lengt_id;
        for ($i = 0; $i < $rolback; $i++) {
            $new_id_str .= "0";
        }
        $new_id_str .= (string)$new_id;
        return $rs_rmpmsk_id_ex . $new_id_str;
    }

    public function insertData($data)
    {
        return $this->db->table($this->tableName)->insert($data);
    }

    public function updateData($data, $id_ex)
    {
        return $this->db->table($this->tableName)->update($data, ['rs_rmpmsk_id_ex' => $id_ex]);
    }

    public function deleteData($id_ex)
    {
        return $this->db->table($this->tableName)->delete(['rs_rmpmsk_id_ex' => $id_ex]);
    }
}