<?php

namespace App\Models;

use CodeIgniter\Model;

class PpsbMdl extends Model
{
    protected $table = 'rs_ppsb';
    protected $tableName = 'rs_ppsb';
    protected $primaryKey = 'rs_ppsb_id';
    protected $useTimestamps = true;


    public function getAllPpsb($rs_ppsb_ppeg, $rs_ppsb_id = false)
    {
        if ($rs_ppsb_id === false) {
            $builder = $this->table($this->table);
            $builder->select('*');
            $builder->join('rs_psb', 'rs_psb.rs_psb_id_ex = rs_ppsb.rs_ppsb_pkb', 'LEFT');
            $builder->orderBy('rs_ppsb_id', 'DESC');
            $builder->where('rs_ppsb_ppeg', $rs_ppsb_ppeg);
            $query = $builder->get()->getResultArray();
            return $query;
        } else {
            $builder = $this->table($this->table);
            $builder->select('rs_ppsb_id, rs_ppsb_ppeg, rs_ppsb_pkb, rs_ppsb_nmr, rs_ppsb_fl, rs_ppsb_ket');
            $builder->where('rs_ppsb_id', $rs_ppsb_id);
            $query = $builder->get()->getRowArray();
            return $query;
        }
    }

    public function getPpsbByIdEx($rs_ppsb_ppeg = false)
    {
        $builder = $this->db->table($this->tableName);
        $builder->select('rs_ppsb_ppeg, rs_ppsbb_nmr, rs_ppsbb_tgl_s, rs_ppsbb_tgl_e, rs_ppsbb_fl, rs_ppsbb_ket');
        $builder->where('rs_ppsb_ppeg', $rs_ppsb_ppeg);
        $query = $builder->get()->getRowArray();
        return $query;
    }

    public function insertData($data)
    {
        return $this->db->table($this->tableName)->insert($data);
    }

    public function updateData($data, $id_ex)
    {
        return $this->db->table($this->tableName)->update($data, ['rs_ppsb_id' => $id_ex]);
    }

    public function deleteData($id_ex)
    {
        return $this->db->table($this->tableName)->delete(['rs_ppsb_id' => $id_ex]);
    }
}
