<?php

namespace App\Models;

use CodeIgniter\Model;

class PkbbMdl extends Model
{
    protected $table = 'rs_pkbb';
    protected $tableName = 'rs_pkbb';
    protected $primaryKey = 'rs_pkbb_id_ex';
    protected $useTimestamps = true;
    protected $allowedFields = ['rs_pkbb_id_ex', 'rs_pkbb_pkp', 'rs_pkbb_nm', 'rs_pkbb_jw', 'rs_pkbb_jk', 'rs_pkbb_wjb'];

    public function getAllPkbb($rs_pkbb_pkp, $rs_pkbb_id_ex = false)
    {
        if ($rs_pkbb_id_ex === false) {
            $builder = $this->db->table($this->tableName);
            $builder->select('*');
            $builder->join('rs_pkp', 'rs_pkp.rs_pkp_id_ex = rs_pkbb.rs_pkbb_pkp', 'INNER');
            $builder->where('rs_pkbb_pkp', $rs_pkbb_pkp);
            $query = $builder->get()->getResultArray();
            return $query;
        } else {
            $builder = $this->db->table($this->tableName);
            $builder->select('rs_pkbb_id_ex, rs_pkbb_nm, rs_pkbb_jw, rs_pkbb_jk, rs_pkbb_wjb');
            $builder->where('rs_pkbb_id_ex', $rs_pkbb_id_ex);
            $query = $builder->get()->getRowArray();
            return $query;
        }
    }

    public function insertData($data)
    {
        return $this->db->table($this->tableName)->insert($data);
    }

    public function updateData($data, $id_ex)
    {
        return $this->db->table($this->tableName)->update($data, ['rs_pkbb_id_ex' => $id_ex]);
    }

    public function deleteData($id_ex)
    {
        return $this->db->table($this->tableName)->delete(['rs_pkbb_id_ex' => $id_ex]);
    }
}
