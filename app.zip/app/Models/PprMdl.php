<?php

namespace App\Models;

use CodeIgniter\Model;

class PprMdl extends Model
{
    protected $table = 'rs_ppr';
    protected $tableName = 'rs_ppr';
    protected $primaryKey = 'rs_ppr_id';
    protected $useTimestamps = true;
    protected $allowedFields = ['rs_ppr_rmr', 'rs_ppr_ppeg'];

    public function getRmrByPpeg($rs_ppr_ppeg = false)
    {
        if ($rs_ppr_ppeg === false) {
            $builder = $this->table($this->table);
            $builder->select('*');
            $builder->join('rs_rmr', 'rs_rmr.rs_rmr_id_ex = rs_ppr.rs_ppr_rmr', 'LEFT');
            $builder->where('rs_ppr_ppeg', $rs_ppr_ppeg);
            $builder->orderBy('rs_ppr_id', 'ASC');
            $query = $builder->get()->getResultArray();
            return $query;
        } else {
            $builder = $this->db->table($this->tableName);
            $builder->select('rs_ppr_rmr, rs_ppr_ppeg');
            $builder->where('rs_ppr_ppeg', $rs_ppr_ppeg);
            $query = $builder->get()->getRowArray();
            return $query;
        }
    }

    public function getAllPpegByRmr($rs_ppr_rmr)
    {
        $builder = $this->table($this->table);
        $builder->select('*');
        $builder->join('rs_ppeg', 'rs_ppeg.rs_ppeg_id_ex = rs_ppr.rs_ppr_ppeg', 'LEFT');
        $builder->join('rs_pkp', 'rs_pkp.rs_pkp_id_ex = rs_ppeg.rs_ppeg_pkp', 'LEFT');
        $builder->join('rs_psp', 'rs_psp.rs_psp_id_ex = rs_ppeg.rs_ppeg_psp', 'LEFT');
        $builder->where('rs_ppr_rmr', $rs_ppr_rmr);
        $builder->orderBy('rs_ppr_id', 'ASC');
        $query = $builder->get()->getResultArray();
        return $query;
    }


    public function getAllPprByPpegAndRmr($rs_ppr_rmr, $rs_ppr_ppeg)
    {
        $builder = $this->table($this->table);
        $builder->select('*');
        $builder->where('rs_ppr_rmr', $rs_ppr_rmr);
        $builder->where('rs_ppr_ppeg', $rs_ppr_ppeg);

        $query = $builder->get()->getResultArray();
        return $query;
    }

    public function insertData($data)
    {
        return $this->db->table($this->tableName)->insert($data);
    }

    public function updateData($data, $id)
    {
        return $this->db->table($this->tableName)->update($data, ['rs_ppr_ppeg' => $id]);
    }

    public function deleteData($id)
    {
        return $this->db->table($this->tableName)->delete(['rs_ppr_id' => $id]);
    }
}
