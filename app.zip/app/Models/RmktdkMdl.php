<?php

namespace App\Models;

use CodeIgniter\Model;

class RmktdkMdl extends Model
{
    protected $table = 'rs_rmktdk';
    protected $tableName = 'rs_rmktdk';
    protected $primaryKey = 'rs_rmktdk_id_ex';
    protected $useTimestamps = true;
    protected $allowedFields = ['rs_rmktdk_id_ex', 'rs_rmktdk_nm', 'rs_rmktdk_sts'];

    public function getAll($rs_rmktdk_id_ex = false)
    {
        if ($rs_rmktdk_id_ex === false) {
            $builder = $this->db->table($this->tableName);
            $builder->select('*');
            $builder->orderBy('rs_rmktdk_id', 'ASC');
            $query = $builder->get()->getResultArray();
            return $query;
        } else {
            $builder = $this->db->table($this->tableName);
            $builder->select('rs_rmktdk_id_ex, rs_rmktdk_nm');
            $builder->where('rs_rmktdk_id_ex', $rs_rmktdk_id_ex);
            $query = $builder->get()->getRowArray();
            return $query;
        }
    }

    public function getIdEx($rs_rmktdk_id_ex)
    {
        $builder = $this->db->table($this->tableName);
        $builder->select('MAX(RIGHT(rs_rmktdk_id_ex, 2)) as max_id ');
        $builder->like('rs_rmktdk_id_ex', $rs_rmktdk_id_ex);
        $builder->orderBy('rs_rmktdk_id', 'DESC');
        $query = $builder->get()->getRowArray();
        $max_id = (int)$query['max_id'];
        $new_id_str = "";
        $new_id = $max_id + 1;
        $lengt_id = strlen((string)$new_id);
        $rolback = 2 - $lengt_id;
        for ($i = 0; $i < $rolback; $i++) {
            $new_id_str .= "0";
        }
        $new_id_str .= (string)$new_id;
        return $rs_rmktdk_id_ex . $new_id_str;
    }

    public function insertData($data)
    {
        return $this->db->table($this->tableName)->insert($data);
    }

    public function updateData($data, $id_ex)
    {
        return $this->db->table($this->tableName)->update($data, ['rs_rmktdk_id_ex' => $id_ex]);
    }

    public function deleteData($id_ex)
    {
        return $this->db->table($this->tableName)->delete(['rs_rmktdk_id_ex' => $id_ex]);
    }
}
