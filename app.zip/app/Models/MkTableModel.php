<?php

namespace App\Models;

use CodeIgniter\Model;

class MkTableModel extends Model
{
    protected $table = 'nl_inst';
    protected $tableName = 'nl_inst';
    protected $primaryKey = 'nl_inst_id_ex';
    protected $useTimestamps = true;
    protected $allowedFields = ['nl_inst_id_ex', 'nl_inst_nama', 'nl_inst_mail', 'nl_inst_alamat'];


    public function createTable($query)
    {
        $builder = $this->db->query($query);
        return $builder;
    }

    public function dropTable($TableName)
    {
        $builder = $this->db->query("SET FOREIGN_KEY_CHECKS = 0;");
        $builder = $this->db->query("DROP TABLE IF EXISTS " . $TableName . ";");
        $builder = $this->db->query("SET FOREIGN_KEY_CHECKS = 1;");
        return $builder;
    }

    public function checkDB()
    {
        $Table = [
            array(
                "TableName" => "rs_pa",
                "field" => array(
                    "rs_pa_id_ex",
                    "rs_pa_id",
                    "rs_pa_un",
                    "rs_pa_pass",
                    "rs_pa_ppeg",
                    "rs_pa_act"
                )
            ),
            array(
                "TableName" => "rs_pkbb",
                "field" => array(
                    "rs_pkbb_id_ex",
                    "rs_pkbb_id",
                    "rs_pkbb_pkp",
                    "rs_pkbb_nm",
                    "rs_pkbb_jw",
                    "rs_pkbb_jk",
                    "rs_pkbb_wjb"
                )
            ),
            array(
                "TableName" => "rs_pkp",
                "field" => array(
                    "rs_pkp_id_ex",
                    "rs_pkp_id",
                    "rs_pkp_nm"
                )
            ),
            array(
                "TableName" => "rs_ppeg",
                "field" => array(
                    "rs_ppeg_id_ex",
                    "rs_ppeg_id",
                    "rs_ppeg_pkp",
                    "rs_ppeg_nmd",
                    "rs_ppeg_nm",
                    "rs_ppeg_nmb",
                    "rs_ppeg_psp",
                    "rs_ppeg_nip",
                    "rs_ppeg_tmpt_lhr",
                    "rs_ppeg_tgl_lhr",
                    "rs_ppeg_nik",
                    "rs_ppeg_alt",
                    "rs_ppeg_jk",
                    "rs_ppeg_npwp",
                    "rs_ppeg_bpjs",
                    "rs_ppeg_hp",
                    "rs_ppeg_mail",
                    "rs_ppeg_a",
                    "rs_ppeg_sts",
                    "rs_ppeg_gol",
                    "rs_ppeg_pic"
                )
            ),
            array(
                "TableName" => "rs_ppi",
                "field" => array(
                    "rs_ppi_id_ex",
                    "rs_ppi_id",
                    "rs_ppi_ppeg",
                    "rs_ppi_t",
                    "rs_ppi_msk",
                    "rs_ppi_klr",
                    "rs_ppi_inst",
                    "rs_ppi_nmr",
                    "rs_ppi_ket",
                    "rs_ppi_fl"
                )
            ),
            array(
                "TableName" => "rs_ppkbb",
                "field" => array(
                    "rs_ppkbb_id",
                    "rs_ppkbb_ppeg",
                    "rs_ppkbb_pkbb",
                    "rs_ppkbb_nmr",
                    "rs_ppkbb_tgl_s",
                    "rs_ppkbb_tgl_e",
                    "rs_ppkbb_fl",
                    "rs_ppkbb_ket"
                )
            ),
            array(
                "TableName" => "rs_ppr",
                "field" => array(
                    "rs_ppr_id",
                    "rs_ppr_rmr",
                    "rs_ppr_ppeg"
                )
            ),
            array(
                "TableName" => "rs_pps",
                "field" => array(
                    "rs_pps_id_ex",
                    "rs_pps_id",
                    "rs_pps_ppeg",
                    "rs_pps_jns",
                    "rs_pps_thn",
                    "rs_pps_inst",
                    "rs_pps_nmr",
                    "rs_pps_ket",
                    "rs_pps_fl"
                )
            ),
            array(
                "TableName" => "rs_ppsb",
                "field" => array(
                    "rs_ppsb_id",
                    "rs_ppsb_ppeg",
                    "rs_ppsb_pkb",
                    "rs_ppsb_nmr",
                    "rs_ppsb_fl",
                    "rs_ppsb_ket",
                )
            ),
            array(
                "TableName" => "rs_ppsbb",
                "field" => array(
                    "rs_ppsbb_id",
                    "rs_ppsbb_ppeg",
                    "rs_ppsbb_pkbb",
                    "rs_ppsbb_nmr",
                    "rs_ppsbb_tgl_s",
                    "rs_ppsbb_tgl_e",
                    "rs_ppsbb_fl",
                    "rs_ppsbb_ket",
                )
            ),
            array(
                "TableName" => "rs_psb",
                "field" => array(
                    "rs_psb_id_ex",
                    "rs_psb_id",
                    "rs_psb_psp",
                    "rs_psb_nm"
                )
            ),
            array(
                "TableName" => "rs_psbb",
                "field" => array(
                    "rs_psbb_id_ex",
                    "rs_psbb_id",
                    "rs_psbb_psp",
                    "rs_psbb_nm",
                    "rs_psbb_jw",
                    "rs_psbb_jk",
                    "rs_psbb_wjb"
                )
            ),
            array(
                "TableName" => "rs_psp",
                "field" => array(
                    "rs_psp_id_ex",
                    "rs_psp_id",
                    "rs_psp_nm"
                )
            ),
            array(
                "TableName" => "rs_rma",
                "field" => array(
                    "rs_rma_id_ex",
                    "rs_rma_id",
                    "rs_rma_nm"
                )
            ),
            array(
                "TableName" => "rs_rmddtlcd",
                "field" => array(
                    "rs_rmddtlcd_id",
                    "rs_rmddtlcd_rmfrrptl",
                    "rs_rmddtlcd_rmpddcd"
                )
            ),
            array(
                "TableName" => "rs_rmfrrptl",
                "field" => array(
                    "rs_rmfrrptl_id_ex",
                    "rs_rmfrrptl_id",
                    "rs_rmfrrptl_nm",
                    "rs_rmfrrptl_ket"
                )
            ),
            array(
                "TableName" => "rs_rmicdn",
                "field" => array(
                    "rs_rmicdn_id_ex",
                    "rs_rmicdn_id",
                    "rs_rmicdn_kd",
                    "rs_rmicdn_nm"
                )
            ),
            array(
                "TableName" => "rs_rmicdt",
                "field" => array(
                    "rs_rmicdt_id_ex",
                    "rs_rmicdt_id",
                    "rs_rmicdt_kd",
                    "rs_rmicdt_nm"
                )
            ),
            array(
                "TableName" => "rs_rmk",
                "field" => array(
                    "rs_rmk_id_ex",
                    "rs_rmk_id",
                    "rs_rmk_nm",
                    "rs_rmk_sts"
                )
            ),
            array(
                "TableName" => "rs_rmktdk",
                "field" => array(
                    "rs_rmktdk_id_ex",
                    "rs_rmktdk_id",
                    "rs_rmktdk_nm",
                    "rs_rmktdk_sts"
                )
            ),
            array(
                "TableName" => "rs_rmmt",
                "field" => array(
                    "rs_rmmt_id_ex",
                    "rs_rmmt_id",
                    "rs_rmmt_nm",
                    "rs_rmmt_sts"
                )
            ),
            array(
                "TableName" => "rs_rmpaep",
                "field" => array(
                    "rs_rmpaep_id_ex",
                    "rs_rmpaep_id",
                    "rs_rmpaep_rmpmsk",
                    "rs_rmpaep_rmph",
                    "rs_rmpaep_kpi",
                    "rs_rmpaep_he",
                    "rs_rmpaep_dp",
                    "rs_rmpaep_dps",
                    "rs_rmpaep_ke"
                )
            ),
            array(
                "TableName" => "rs_rmpaksp",
                "field" => array(
                    "rs_rmpaksp_id_ex",
                    "rs_rmpaksp_id",
                    "rs_rmpaksp_rmpmsk",
                    "rs_rmpaksp_rmph",
                    "rs_rmpaksp_ko",
                    "rs_rmpaksp_ln",
                    "rs_rmpaksp_mp"
                )
            ),
            array(
                "TableName" => "rs_rmpaku",
                "field" => array(
                    "rs_rmpaku_id_ex",
                    "rs_rmpaku_id",
                    "rs_rmpaku_rmpmsk",
                    "rs_rmpaku_rmph",
                    "rs_rmpaku_ku"
                )
            ),
            array(
                "TableName" => "rs_rmpapg",
                "field" => array(
                    "rs_rmpapg_id_ex",
                    "rs_rmpapg_id",
                    "rs_rmpapg_rmpmsk",
                    "rs_rmpapg_rmph",
                    "rs_rmpapg_pbb",
                    "rs_rmpapg_imk",
                    "rs_rmpapg_kk",
                    "rs_rmpapg_skor",
                    "rs_rmpapg_skord",
                )
            ),
            array(
                "TableName" => "rs_rmpara",
                "field" => array(
                    "rs_rmpara_id_ex",
                    "rs_rmpara_id",
                    "rs_rmpara_rmpmsk",
                    "rs_rmpara_rmph",
                    "rs_rmpara_ra"
                )
            ),
            array(
                "TableName" => "rs_rmparo",
                "field" => array(
                    "rs_rmparo_id_ex",
                    "rs_rmparo_id",
                    "rs_rmparo_rmpmsk",
                    "rs_rmparo_rmph",
                    "rs_rmparo_nm",
                    "rs_rmparo_ds",
                    "rs_rmparo_lm"
                )
            ),
            array(
                "TableName" => "rs_rmparp",
                "field" => array(
                    "rs_rmparp_id_ex",
                    "rs_rmparp_id",
                    "rs_rmparp_rmpmsk",
                    "rs_rmparp_rmph",
                    "rs_rmparp_rp"
                )
            ),
            array(
                "TableName" => "rs_rmpasf",
                "field" => array(
                    "rs_rmpasf_id_ex",
                    "rs_rmpasf_id",
                    "rs_rmpasf_rmpmsk",
                    "rs_rmpasf_rmph",
                    "rs_rmpasf_ab",
                    "rs_rmpasf_absb",
                    "rs_rmpasf_ct",
                    "rs_rmpasf_ctsb"
                )
            ),
            array(
                "TableName" => "rs_rmpau",
                "field" => array(
                    "rs_rmpau_id_ex",
                    "rs_rmpau_id",
                    "rs_rmpau_rmpmsk",
                    "rs_rmpau_rmph",
                    "rs_rmpau_au"
                )
            ),
            array(
                "TableName" => "rs_rmpcok",
                "field" => array(
                    "rs_rmpcok_id_ex",
                    "rs_rmpcok_id",
                    "rs_rmpcok_rmpmsk",
                    "rs_rmpcok_rmph",
                    "rs_rmpcok_ppeg",
                    "rs_rmpcok_tgl"
                )
            ),
            array(
                "TableName" => "rs_rmpcppt",
                "field" => array(
                    "rs_rmpcppt_id_ex",
                    "rs_rmpcppt_id",
                    "rs_rmpcppt_rmpmsk",
                    "rs_rmpcppt_rmph",
                    "rs_rmpcppt_ppeg",
                    "rs_rmpcppt_tgl",
                    "rs_rmpcppt_jam",
                    "rs_rmpcppt_s",
                    "rs_rmpcppt_o",
                    "rs_rmpcppt_a",
                    "rs_rmpcppt_p"
                )
            ),
            array(
                "TableName" => "rs_rmpddcd",
                "field" => array(
                    "rs_rmpddcd_id_ex",
                    "rs_rmpddcd_id",
                    "rs_rmpddcd_rmpmsk",
                    "rs_rmpddcd_rmph",
                    "rs_rmpddcd_ppeg",
                    "rs_rmpddcd_tgl",
                    "rs_rmpddcd_jam",
                    "rs_rmpddcd_gdm",
                    "rs_rmpddcd_gth",
                    "rs_rmpddcd_gispp",
                    "rs_rmpddcd_grda",
                    "rs_rmpddcd_gprad",
                    "rs_rmpddcd_gpa",
                    "rs_rmpddcd_gatpb",
                    "rs_rmpddcd_gatldp",
                    "rs_rmpddcd_frrpln",
                    "rs_rmpddcd_frrpk",
                    "rs_rmpddcd_cpotg",
                    "rs_rmpddcd_cpodp",
                    "rs_rmpddcd_cppdp",
                    "rs_rmpddcd_cptl",
                    "rs_rmpddcd_cpgej"
                )
            ),
            array(
                "TableName" => "rs_rmpdia",
                "field" => array(
                    "rs_rmpdia_id_ex",
                    "rs_rmpdia_id",
                    "rs_rmpdia_rmpmsk",
                    "rs_rmpdia_rmph",
                    "rs_rmpdia_rmicdt",
                    "rs_rmpdia_pri",
                    "rs_rmpdia_dia"
                )
            ),
            array(
                "TableName" => "rs_rmped",
                "field" => array(
                    "rs_rmped_id_ex",
                    "rs_rmped_id",
                    "rs_rmped_rmpmsk",
                    "rs_rmped_rmph",
                    "rs_rmped_anm",
                    "rs_rmped_pp",
                    "rs_rmped_pf",
                    "rs_rmped_ed",
                    "rs_rmped_ug"
                )
            ),
            array(
                "TableName" => "rs_rmph",
                "field" => array(
                    "rs_rmph_id_ex",
                    "rs_rmph_id",
                    "rs_rmph_ppeg",
                    "rs_rmph_rmpp",
                    "rs_rmph_jns"
                )
            ),
            array(
                "TableName" => "rs_rmpjk",
                "field" => array(
                    "rs_rmpjk_id_ex",
                    "rs_rmpjk_id",
                    "rs_rmpjk_rmpmsk",
                    "rs_rmpjk_rmph",
                    "rs_rmpjk_tgl",
                    "rs_rmpjk_jam",
                    "rs_rmpjk_knt",
                    "rs_rmpjk_ket"
                )
            ),
            array(
                "TableName" => "rs_rmpl",
                "field" => array(
                    "rs_rmpl_id_ex",
                    "rs_rmpl_id",
                    "rs_rmpl_nm"
                )
            ),
            array(
                "TableName" => "rs_rmpmsk",
                "field" => array(
                    "rs_rmpmsk_id_ex",
                    "rs_rmpmsk_id",
                    "rs_rmpmsk_rmpp",
                    "rs_rmpmsk_rmph",
                    "rs_rmpmsk_pr",
                    "rs_rmpmsk_rd",
                    "rs_rmpmsk_rjkd",
                    "rs_rmpmsk_tgl",
                    "rs_rmpmsk_jam",
                    "rs_rmpmsk_alt",
                    "rs_rmpmsk_sts",
                    "rs_rmpmsk_pend",
                    "rs_rmpmsk_krj",
                    "rs_rmpmsk_pp",
                    "rs_rmpmsk_pj",
                    "rs_rmpmsk_pjn",
                    "rs_rmpmsk_pjjk",
                    "rs_rmpmsk_pjh",
                    "rs_rmpmsk_pjalt",
                    "rs_rmpmsk_pjaltktp",
                    "rs_rmpmsk_pjaltn",
                    "rs_rmpmsk_pjaltr",
                    "rs_rmpmsk_pjaltkk",
                    "rs_rmpmsk_pjaltkp",
                    "rs_rmpmsk_pjaltth",
                    "rs_rmpmsk_pjpend",
                    "rs_rmpmsk_pjkrj",
                    "rs_rmpmsk_pjind",
                    "rs_rmpmsk_cp",
                    "rs_rmpmsk_rma",
                    "rs_rmpmsk_anmr",
                    "rs_rmpmsk_ts",
                    "rs_rmpmsk_ab",
                    "rs_rmpmsk_plg"
                )
            ),
            array(
                "TableName" => "rs_rmpmt",
                "field" => array(
                    "rs_rmpmt_id_ex",
                    "rs_rmpmt_id",
                    "rs_rmpmt_rmpmsk",
                    "rs_rmpmt_rmph",
                    "rs_rmpmt_rmicdt",
                    "rs_rmpmt_pri",
                    "rs_rmpmt_dia"
                )
            ),
            array(
                "TableName" => "rs_rmpnld",
                "field" => array(
                    "rs_rmpnld_id_ex",
                    "rs_rmpnld_id",
                    "rs_rmpnld_rmpmsk",
                    "rs_rmpnld_rmph",
                    "rs_rmpnld_dia"
                )
            ),
            array(
                "TableName" => "rs_rmpnlf",
                "field" => array(
                    "rs_rmpnlf_id_ex",
                    "rs_rmpnlf_id",
                    "rs_rmpnlf_rmpmsk",
                    "rs_rmpnlf_rmph",
                    "rs_rmpnlf_fis"
                )
            ),
            array(
                "TableName" => "rs_rmpnln",
                "field" => array(
                    "rs_rmpnln_id_ex",
                    "rs_rmpnln_id",
                    "rs_rmpnln_rmpmsk",
                    "rs_rmpnln_rmph",
                    "rs_rmpnln_ny",
                    "rs_rmpnln_os",
                    "rs_rmpnln_sn",
                    "rs_rmpnln_mtd",
                    "rs_rmpnln_pnct",
                    "rs_rmpnln_gmbr",
                    "rs_rmpnln_drs",
                    "rs_rmpnln_lks"
                )
            ),
            array(
                "TableName" => "rs_rmpnls",
                "field" => array(
                    "rs_rmpnls_id_ex",
                    "rs_rmpnls_id",
                    "rs_rmpnls_rmpmsk",
                    "rs_rmpnls_rmph",
                    "rs_rmpnls_sts"
                )
            ),
            array(
                "TableName" => "rs_rmpp",
                "field" => array(
                    "rs_rmpp_id_ex",
                    "rs_rmpp_id",
                    "rs_rmpp_ppeg",
                    "rs_rmpp_nm",
                    "rs_rmpp_ind",
                    "rs_rmpp_tgl_lhr",
                    "rs_rmpp_tmpt_lhr",
                    "rs_rmpp_rm",
                    "rs_rmpp_jk",
                    "rs_rmpp_a",
                    "rs_rmpp_altktp",
                    "rs_rmpp_altn",
                    "rs_rmpp_altr",
                    "rs_rmpp_altkk",
                    "rs_rmpp_altkp",
                    "rs_rmpp_altth",
                    "rs_rmpp_sb",
                    "rs_rmpp_bhs"
                )
            ),
            array(
                "TableName" => "rs_rmpprkf",
                "field" => array(
                    "rs_rmpprkf_id_ex",
                    "rs_rmpprkf_id",
                    "rs_rmpprkf_rmpmsk",
                    "rs_rmpprkf_rmph",
                    "rs_rmpprkf_f"
                )
            ),
            array(
                "TableName" => "rs_rmpprkfu",
                "field" => array(
                    "rs_rmpprkfu_id_ex",
                    "rs_rmpprkfu_id",
                    "rs_rmpprkfu_rmpmsk",
                    "rs_rmpprkfu_rmph",
                    "rs_rmpprkfu_ab",
                    "rs_rmpprkfu_pro",
                    "rs_rmpprkfu_ct"
                )
            ),
            array(
                "TableName" => "rs_rmpprkn",
                "field" => array(
                    "rs_rmpprkn_id_ex",
                    "rs_rmpprkn_id",
                    "rs_rmpprkn_rmpmsk",
                    "rs_rmpprkn_rmph",
                    "rs_rmpprkn_bb",
                    "rs_rmpprkn_tb",
                    "rs_rmpprkn_imt",
                    "rs_rmpprkn_lk"
                )
            ),
            array(
                "TableName" => "rs_rmpprkt",
                "field" => array(
                    "rs_rmpprkt_id_ex",
                    "rs_rmpprkt_id",
                    "rs_rmpprkt_rmpmsk",
                    "rs_rmpprkt_rmph",
                    "rs_rmpprkt_ku",
                    "rs_rmpprkt_ks",
                    "rs_rmpprkt_sis",
                    "rs_rmpprkt_dias",
                    "rs_rmpprkt_sh",
                    "rs_rmpprkt_fnd",
                    "rs_rmpprkt_fnf",
                    "rs_rmpprkt_tgl",
                    "rs_rmpprkt_jam"
                )
            ),
            array(
                "TableName" => "rs_rmpr",
                "field" => array(
                    "rs_rmpr_id",
                    "rs_rmpr_rmpmsk",
                    "rs_rmpr_rmr",
                    "rs_rmpr_rmr_ppeg",
                    "rs_rmpr_rmph"
                )
            ),
            array(
                "TableName" => "rs_rmprt",
                "field" => array(
                    "rs_rmprt_id_ex",
                    "rs_rmprt_id",
                    "rs_rmprt_rmpmsk",
                    "rs_rmprt_rmph",
                    "rs_rmprt_t"
                )
            ),
            array(
                "TableName" => "rs_rmptdk",
                "field" => array(
                    "rs_rmptdk_id_ex",
                    "rs_rmptdk_id",
                    "rs_rmptdk_rmpmsk",
                    "rs_rmptdk_rmph",
                    "rs_rmptdk_rmicdn",
                    "rs_rmptdk_tdk"
                )
            ),
            array(
                "TableName" => "rs_rmptr",
                "field" => array(
                    "rs_rmptr_id_ex",
                    "rs_rmptr_id",
                    "rs_rmptr_rmpmsk",
                    "rs_rmptr_rmph",
                    "rs_rmptr_rmpl",
                    "rs_rmptr_kt",
                    "rs_rmptr_doa",
                    "rs_rmptr_tgl",
                    "rs_rmptr_jam"
                )
            ),
            array(
                "TableName" => "rs_rmr",
                "field" => array(
                    "rs_rmr_id_ex",
                    "rs_rmr_id",
                    "rs_rmr_nm",
                    "rs_rmr_prnt"
                )
            ),
        ];
        return $Table;
    }
}
