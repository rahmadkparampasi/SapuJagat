<?php

namespace App\Models;

use CodeIgniter\Model;

class RmpnldMdl extends Model
{
    protected $table = 'rs_rmpnld';
    protected $tableName = 'rs_rmpnld';
    protected $primaryKey = 'rs_rmpnld_id_ex';
    protected $useTimestamps = true;
    protected $allowedFields = ['rs_rmpnld_id_ex'];

    public function getAll($rs_rmpnld_rmpmsk, $rs_rmpnld_id_ex = false)
    {
        if ($rs_rmpnld_id_ex === false) {
            $builder = $this->db->table($this->tableName);
            $builder->select('*');
            $builder->where('rs_rmpnld_rmpmsk', $rs_rmpnld_rmpmsk);
            $query = $builder->get()->getResultArray();
            return $query;
        } else {
            $builder = $this->db->table($this->tableName);
            $builder->select('*');
            $builder->where('rs_rmpnld_id_ex', $rs_rmpnld_id_ex);
            $query = $builder->get()->getRowArray();
            return $query;
        }
    }

    public function getIdEx($rs_rmpnld_id_ex)
    {
        $builder = $this->db->table($this->tableName);
        $builder->select('MAX(RIGHT(rs_rmpnld_id_ex, 5)) as max_id ');
        $builder->like('rs_rmpnld_id_ex', $rs_rmpnld_id_ex);
        $builder->orderBy('rs_rmpnld_id', 'DESC');
        $query = $builder->get()->getRowArray();
        $max_id = (int)$query['max_id'];
        $new_id_str = "";
        $new_id = $max_id + 1;
        $lengt_id = strlen((string)$new_id);
        $rolback = 5 - $lengt_id;
        for ($i = 0; $i < $rolback; $i++) {
            $new_id_str .= "0";
        }
        $new_id_str .= (string)$new_id;
        return $rs_rmpnld_id_ex . $new_id_str;
    }

    public function insertData($data)
    {
        return $this->db->table($this->tableName)->insert($data);
    }

    public function updateData($data, $id_ex)
    {
        return $this->db->table($this->tableName)->update($data, ['rs_rmpnld_id_ex' => $id_ex]);
    }

    public function deleteData($id_ex)
    {
        return $this->db->table($this->tableName)->delete(['rs_rmpnld_id_ex' => $id_ex]);
    }
}
