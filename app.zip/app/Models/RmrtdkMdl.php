<?php

namespace App\Models;

use CodeIgniter\Model;

class RmrtdkMdl extends Model
{
    protected $table = 'rs_rmrtdk';
    protected $tableName = 'rs_rmrtdk';
    protected $primaryKey = 'rs_rmrtdk_id_ex';
    protected $useTimestamps = true;
    protected $allowedFields = ['rs_rmrtdk_rmr', 'rs_rmrtdk_rmtdk', 'rs_rmrmt_sts'];

    public function getAll($rs_rmrtdk_rmr)
    {
        $builder = $this->table($this->table);
        $builder->select('*');
        $builder->join('rs_rmtdk', 'rs_rmtdk.rs_rmtdk_id_ex = rs_rmrtdk.rs_rmrtdk_rmtdk', 'LEFT');
        $builder->join('rs_rmktdk', 'rs_rmktdk.rs_rmktdk_id_ex = rs_rmtdk.rs_rmtdk_rmktdk', 'LEFT');
        $builder->where('rs_rmrtdk_rmr', $rs_rmrtdk_rmr);
        $builder->orderBy('rs_rmrtdk_id', 'ASC');
        $query = $builder->get()->getResultArray();
        return $query;
    }


    public function getAllByRmtdkAndRmr($rs_rmrtdk_rmr, $rs_rmrtdk_rmtdk)
    {
        $builder = $this->table($this->table);
        $builder->select('*');
        $builder->where('rs_rmrtdk_rmr', $rs_rmrtdk_rmr);
        $builder->where('rs_rmrtdk_rmtdk', $rs_rmrtdk_rmtdk);

        $query = $builder->get()->getResultArray();
        return $query;
    }

    public function getIdEx($rs_rmrtdk_id_ex)
    {
        $builder = $this->db->table($this->tableName);
        $builder->select('MAX(RIGHT(rs_rmrtdk_id_ex, 3)) as max_id ');
        $builder->like('rs_rmrtdk_id_ex', $rs_rmrtdk_id_ex);
        $builder->orderBy('rs_rmrtdk_id', 'DESC');
        $query = $builder->get()->getRowArray();
        $max_id = (int)$query['max_id'];
        $new_id_str = "";
        $new_id = $max_id + 1;
        $lengt_id = strlen((string)$new_id);
        $rolback = 3 - $lengt_id;
        for ($i = 0; $i < $rolback; $i++) {
            $new_id_str .= "0";
        }
        $new_id_str .= (string)$new_id;
        return $rs_rmrtdk_id_ex . $new_id_str;
    }

    public function insertData($data)
    {
        return $this->db->table($this->tableName)->insert($data);
    }

    public function updateData($data, $id)
    {
        return $this->db->table($this->tableName)->update($data, ['rs_rmrtdk_id_ex' => $id]);
    }

    public function deleteData($id)
    {
        return $this->db->table($this->tableName)->delete(['rs_rmrtdk_id_ex' => $id]);
    }
}