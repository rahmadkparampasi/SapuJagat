<?php

namespace App\Models;

use CodeIgniter\Model;

class PpsMdl extends Model
{
    protected $table = 'rs_pps';
    protected $tableName = 'rs_pps';
    protected $primaryKey = 'rs_pps_id_ex';
    protected $useTimestamps = true;


    public function getAllPps($rs_pps_ppeg, $rs_pps_id_ex = false)
    {
        if ($rs_pps_id_ex === false) {
            $builder = $this->db->table($this->tableName);
            $builder->select('*');
            $builder->where('rs_pps_ppeg', $rs_pps_ppeg);
            $query = $builder->get()->getResultArray();
            return $query;
        } else {
            $builder = $this->db->table($this->tableName);
            $builder->select('rs_pps_id_ex, rs_pps_jns, rs_pps_thn, rs_pps_inst, rs_pps_nmr, rs_pps_ket, rs_pps_fl');
            $builder->where('rs_pps_id_ex', $rs_pps_id_ex);
            $query = $builder->get()->getRowArray();
            return $query;
        }
    }

    public function getPpsByIdEx($rs_pps_id_ex = false)
    {
        $builder = $this->db->table($this->tableName);
        $builder->select('rs_pps_id_ex, rs_pps_jns, rs_pps_thn, rs_pps_inst, rs_pps_nmr, rs_pps_ket, rs_pps_fl');
        $builder->where('rs_pps_id_ex', $rs_pps_id_ex);
        $query = $builder->get()->getRowArray();
        return $query;
    }

    public function insertData($data)
    {
        return $this->db->table($this->tableName)->insert($data);
    }

    public function updateData($data, $id_ex)
    {
        return $this->db->table($this->tableName)->update($data, ['rs_pps_id_ex' => $id_ex]);
    }

    public function deleteData($id_ex)
    {
        return $this->db->table($this->tableName)->delete(['rs_pps_id_ex' => $id_ex]);
    }
}