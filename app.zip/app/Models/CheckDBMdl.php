<?php

namespace App\Models;

use CodeIgniter\Model;

class CheckDBMdl extends Model
{
    protected $table = 'srt_isi';
    protected $tableName = 'srt_isi';
    protected $primaryKey = 'srt_isi_id_ex';
    protected $useTimestamps = true;

    public function checkDBWithField($NameTable)
    {
        $this->tableName = $NameTable;
        $builder = $this->db->table($this->tableName);
        $builder->select("*");
        $query = $builder->get()->getFieldNames();
        return $query;
    }

    public function checkDB()
    {
        $builder = $this->db->query("SHOW TABLES FROM `rs`");
        return $builder;
    }
}
