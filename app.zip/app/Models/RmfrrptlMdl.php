<?php

namespace App\Models;

use CodeIgniter\Model;

class RmfrrptlMdl extends Model
{
    protected $table = 'rs_rmfrrptl';
    protected $tableName = 'rs_rmfrrptl';
    protected $primaryKey = 'rs_rmfrrptl_id_ex';
    protected $useTimestamps = true;
    protected $allowedFields = ['rs_rmfrrptl_id_ex', 'rs_rmfrrptl_nm', 'rs_rmfrrptl_ket'];

    public function getAllRmfrrptl($rs_rmfrrptl_id_ex = false)
    {
        if ($rs_rmfrrptl_id_ex === false) {
            $builder = $this->db->table($this->tableName);
            $builder->select('*');
            $query = $builder->get()->getResultArray();
            return $query;
        } else {
            $builder = $this->db->table($this->tableName);
            $builder->select('rs_rmfrrptl_id_ex, rs_rmfrrptl_nm, rs_rmfrrptl_ket');
            $builder->where('rs_rmfrrptl_id_ex', $rs_rmfrrptl_id_ex);
            $query = $builder->get()->getRowArray();
            return $query;
        }
    }

    public function insertData($data)
    {
        return $this->db->table($this->tableName)->insert($data);
    }

    public function updateData($data, $id_ex)
    {
        return $this->db->table($this->tableName)->update($data, ['rs_rmfrrptl_id_ex' => $id_ex]);
    }

    public function deleteData($id_ex)
    {
        return $this->db->table($this->tableName)->delete(['rs_rmfrrptl_id_ex' => $id_ex]);
    }
}
