<?php

namespace App\Models;

use CodeIgniter\Model;

class RmrkktMdl extends Model
{
    protected $table = 'rs_rmrkkt';
    protected $tableName = 'rs_rmrkkt';
    protected $primaryKey = 'rs_rmrkkt_id';
    protected $useTimestamps = true;
    protected $allowedFields = ['rs_rmrkkt_id', 'rs_rmrkkt_nm', 'rs_rmrkkt_sts'];

    public function getAll($rs_rmrkkt_rmrkk = false)
    {
        $builder = $this->table($this->table);
        $builder->select('*');
        $builder->where('rs_rmrkkt_rmrkk', $rs_rmrkkt_rmrkk);
        $builder->orderBy('rs_rmrkkt_id', 'ASC');
        $query = $builder->get()->getResultArray();
        return $query;
    }

    public function getIdEx($rs_rmrkkt_id_ex)
    {
        $builder = $this->db->table($this->tableName);
        $builder->select('MAX(RIGHT(rs_rmrkkt_id_ex, 2)) as max_id ');
        $builder->like('rs_rmrkkt_id_ex', $rs_rmrkkt_id_ex);
        $builder->orderBy('rs_rmrkkt_id', 'DESC');
        $query = $builder->get()->getRowArray();
        $max_id = (int)$query['max_id'];
        $new_id_str = "";
        $new_id = $max_id + 1;
        $lengt_id = strlen((string)$new_id);
        $rolback = 2 - $lengt_id;
        for ($i = 0; $i < $rolback; $i++) {
            $new_id_str .= "0";
        }
        $new_id_str .= (string)$new_id;
        return $rs_rmrkkt_id_ex . $new_id_str;
    }

    public function insertData($data)
    {
        return $this->db->table($this->tableName)->insert($data);
    }

    public function updateData($data, $id)
    {
        return $this->db->table($this->tableName)->update($data, ['rs_rmrkkt_id_ex' => $id]);
    }

    public function deleteData($id)
    {
        return $this->db->table($this->tableName)->delete(['rs_rmrkkt_id_ex' => $id]);
    }
}
