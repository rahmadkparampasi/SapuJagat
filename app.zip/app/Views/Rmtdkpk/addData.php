<div class="card card-primary" style="
    <?php
    if ($MethodForm1 == "updateData") {
        echo 'display: flex;';
    } else {
        echo 'display: none;';
    } ?>" id="<?= $IdForm ?>card">
    <div class="card-header">
        <h3 class="card-title">Form Tambah <?= $PageTitle ?></h3>
    </div>
    <!-- /.card-header -->
    <!-- form start -->
    <form method="POST" class="form-valide" action="/<?= $BasePage ?>/<?= $MethodForm ?>" id="<?= $IdForm ?>" enctype="multipart/form-data">
        <?php
        if ($MethodForm1 == "updateData") {
            echo "<input type='hidden' name='rs_rmtdkpk_id_ex' id='rs_rmtdkpk_id_ex'>";
        }
        ?>
        <input type='hidden' name='rs_rmtdkpk_rmtdkp' id='rs_rmtdkpk_rmtdkp' value="<?= $rs_rmtdkpk_rmtdkp ?>">
        <div class="card-body">
            <div class="form-group">
                <label for="rs_rmtdkpk_jk">Jenis Kelamin</label>
                <select class="form-control" id="rs_rmtdkpk_jk" name="rs_rmtdkpk_jk" required>
                    <option value="" hidden>Pilih Salah Satu Pilihan</option>                    
                    <option value="L">Laki - Laki</option>                    
                    <option value="P">Perempuan</option>                    
                </select>
            </div>
            <div class="form-group">
                <label for="rs_rmtdkpk_u">Umur</label>
                <input type="number" class="form-control" id="rs_rmtdkpk_u" name="rs_rmtdkpk_u" required>
            </div>
            <div class="form-group">
                <label for="rs_rmtdkpk_ba">Nilai Batas Atas</label>
                <input type="number" class="form-control" id="rs_rmtdkpk_ba" name="rs_rmtdkpk_ba" required>
            </div>
            
            <div class="form-group">
                <label for="rs_rmtdkpk_bb">Nilai Batas Bawah</label>
                <input type="number" class="form-control" id="rs_rmtdkpk_bb" name="rs_rmtdkpk_bb" required>
            </div>
        </div>
        <!-- /.card-body -->

        <div class="card-footer">
            <button type="submit" class="btn bg-gradient-primary"><?= $ButtonMethod ?></button>
            <?php
            $MethodForm = substr($MethodForm, 0, 10);
            if ($MethodForm == "updateData") {
            ?>
                <a href="/<?= $BasePage ?>" class='btn bg-gradient-danger' aria-pressed="true">BATAL</a>
            <?php
            } else {
            ?>
                <button type="button" class="btn bg-gradient-danger" onclick="closeForm('<?= $IdForm ?>card', '<?= $IdForm ?>')">BATAL</button>

            <?php
            }
            ?>
        </div>
    </form>
</div>

<script>
    $(function() {
        $(document).ready(function() {
            var <?= $IdForm ?> = $('#<?= $IdForm ?>');
            <?= $IdForm ?>.submit(function(e) {
                showAnimated();
                $('#<?= $IdForm ?> :input').prop("disabled", false);
                $(this).attr('disabled', 'disabled');
                e.stopPropagation();
                e.preventDefault();
                $.ajax({
                    type: <?= $IdForm ?>.attr('method'),
                    url: <?= $IdForm ?>.attr('action'),
                    enctype: 'multipart/form-data',
                    data: new FormData(this),
                    contentType: false,
                    processData: false,
                    dataType: 'json',
                    success: function(data) {
                        hideAnimated();
                        if (data.response == "success") {
                            swal.fire({
                                title: "Terima Kasih",
                                text: data.message,
                                icon: data.response
                            }).then(function() {
                                showRmtdkpk('<?= $rs_rmtdkpk_rmtdkp ?>');
                            });
                        } else {
                            hideAnimated();
                            swal.fire({
                                title: "Tidak Dapat Melanjutkan Proses",
                                text: data.message,
                                icon: data.response
                            });
                        }
                    },
                    error: function(xhr) {
                        hideAnimated();
                        console.log(xhr);
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: xhr.responseJSON.message,
                            icon: "error"
                        });
                    }
                });
            });
        });
    });
</script>