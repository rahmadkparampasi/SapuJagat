<?= $this->include('Rmtdkpk/addData'); ?>
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Daftar <?= $PageTitle ?></h3>
        <div class="card-tools">
            <?php
            if ($MethodForm1 != "updateData") {
            ?>
                <button class='btn bg-gradient-success' role="button" aria-pressed="true" style="float: right;" onclick="showForm('<?= $IdForm ?>card')"><i class="fas fa-plus"></i>
                    TAMBAH</button>
            <?php
            }
            ?>
            <button class='btn bg-gradient-danger mx-1' role="button" aria-pressed="true" style="float: right;" onclick="closeRmtdkpk()"><i class="fas fa-ban"></i>
                TUTUP</button>
        </div>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
        <table class="dtKd table responsive table-bordered table-striped" id="datatableKirana<?= $IdForm ?>">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Jenis Kelamin</th>
                    <th>Umur</th>
                    <th>Batas Atas</th>
                    <th>Batas Bawah</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 0;
                foreach ($Rmtdkpk as $tk) : $no++ ?>
                    <tr>
                        <td><?= $no ?></td>
                        <td><?= $tk['rs_rmtdkpk_jk'] ?></td>
                        <td><?= $tk['rs_rmtdkpk_u'] ?></td>
                        <td><?= $tk['rs_rmtdkpk_ba'] ?></td>
                        <td><?= $tk['rs_rmtdkpk_bb'] ?></td>

                        <td>
                            <?php
                            if ($tk['rs_rmtdkpk_sts'] == "1") {
                            ?>
                                <button class="btn bg-gradient-success" title="Parameter Tindakan Aktif" onclick="addWF('Menonaktifkan Data Nilai Kritis Parameter Tindakan', '<?= $BasePage ?>/blockTdkPK/<?= $tk['rs_rmtdkpk_id_ex'] ?>', showRmtdkpk, '<?= $rs_rmtdkpk_rmtdkp ?>')">
                                    <i class='fas fa-check'></i>
                                </button>
                            <?php
                            } else {
                            ?>
                                <button class="btn bg-gradient-danger" title="Parameter Tindakan Tidak Aktif" onclick="addWF('Mengaktifkan Data Nilai Kritis Parameter Tindakan', '<?= $BasePage ?>/unblockTdkPK/<?= $tk['rs_rmtdkpk_id_ex'] ?>', showRmtdkpk, '<?= $rs_rmtdkpk_rmtdkp ?>')">
                                    <i class='fas fa-ban'></i>
                                </button>
                            <?php
                            }
                            ?>
                        </td>
                    </tr>
                <?php endforeach ?>
            </tbody>

        </table>
    </div>
    <!-- /.card-body -->
</div>

<script>
$(document).ready(function() {
    $('#datatableKirana<?= $IdForm ?>').DataTable({
        "order": [
            [0, "asc"]
        ],
        pageLength: 100,
        responsive: true,
        fixedHeader: true,
        keys: true,
        columnDefs: [{
                responsivePriority: 1,
                target: 0
            },
            {
                responsivePriority: 10001,
                target: 4
            },
            {
                responsivePriority: 2,
                target: -2
            }
        ]
    });
});
</script>