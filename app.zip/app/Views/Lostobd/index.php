<?= $this->extend('Templates/template'); ?>

<?= $this->section('content'); ?>
<!-- /.row -->

<div class="row">
    <!-- Area Chart -->
    <div class="col-xl-12 col-lg-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Daftar <?= $PageTitle ?></h3>
                <div class="card-tools row w-50">
                    <select class="form-control col mx-2" required id="rs_rmrrmb_rmr"
                        onfocus="ambilDataSelect('rs_rmrrmb_rmr', '/rmr/getAllForSelectByPrt/<?= $setRmr['setRmrApt'] ?>', 'Pilih Salah Satu Depo Layanan', toRemove=[], removeMessage=[], '')">
                        
                        <option hidden value="">Pilih Salah Satu Depo Layanan</option>
                        
                    </select>
                    
                    <button class='btn bg-gradient-primary col-2' role="button"
                        onclick="loadSrc(document.getElementById('rs_rmrrmb_rmr').value);"><i
                            class="fas fa-search"></i>
                        CARI</button>

                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <div class="row" id="listRmrrmb">
                </div>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
</div>
<script>
function loadSrc(v = '') {
    $.ajax({
        url: "/rmrrmb/viewJByRmr/" + v,
        success: function(data) {

            $('#listRmrrmb').html(data);
        }
    });
}
$(document).ready(function() {
    $("#value").on('keyup', function(event) {
        if (event.keyCode === 13) {
            loadSrc($("#rs_rmrrmb_rmr").val())
        }
    });
});
</script>

<?= $this->endSection(); ?>