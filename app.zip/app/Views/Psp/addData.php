<div class="card card-primary" style="
        <?php if ($MethodForm1 == "updateData") {
            echo 'display: flex;';
        } else {
            echo 'display: none;';
        } ?>" id="<?= $IdForm ?>card">
    <div class="card-header">
        <h3 class="card-title">Form Tambah <?= $PageTitle ?></h3>
    </div>
    <!-- /.card-header -->
    <!-- form start -->
    <form method="POST" class="form-valide" action="/<?= $BasePage ?>/<?= $MethodForm ?>" id="<?= $IdForm ?>"
        enctype="multipart/form-data">
        <?php
        if ($MethodForm1 == "updateData") {
            echo "<input type='hidden' name='rs_psp_id_ex' id='rs_psp_id_ex'>";
        }
        ?>
        <div class="card-body">
            <div class="form-group">
                <label for="rs_psp_nm">Nama Status Pegawai</label>
                <input type="text" class="form-control text-uppercase" id="rs_psp_nm" name="rs_psp_nm">
            </div>
        </div>
        <!-- /.card-body -->

        <div class="card-footer">
            <button type="submit" class="btn bg-gradient-primary"><?= $ButtonMethod ?></button>
            <?php
            if ($MethodForm1 == "updateData") {
            ?>
            <a href="/<?= $BasePage ?>" class='btn bg-gradient-danger' aria-pressed="true">BATAL</a>
            <?php
            } else {
            ?>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('<?= $IdForm ?>card', '<?= $IdForm ?>')">BATAL</button>

            <?php
            }
            ?>
        </div>
    </form>
</div>