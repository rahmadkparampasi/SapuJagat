<?= $this->extend('Templates/template'); ?>

<?= $this->section('content'); ?>
<!-- /.row -->

<div class="row">
    <!-- Area Chart -->
    <div class="col-xl-12 col-lg-12">
        <?= $this->include('Psp/addData'); ?>

        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Daftar <?= $PageTitle ?></h3>
                <div class="card-tools">
                    <?php
                    if ($MethodForm1 != "updateData") {
                    ?>
                    <button class='btn bg-gradient-success' role="button" aria-pressed="true" style="float: right;"
                        onclick="showForm('<?= $IdForm ?>card')"><i class="fas fa-plus"></i>
                        TAMBAH</button>
                    <?php
                    }
                    ?>
                    <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                            class="fas fa-minus"></i></button>
                    <button type="button" class="btn btn-tool" data-card-widget="remove"><i
                            class="fas fa-remove"></i></button>
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table id="datatableKirana" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Status Pegawai</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 0;
                        foreach ($Psp as $tk) : $no++ ?>
                        <tr>
                            <td><?= $no ?></td>
                            <td><?= $tk['rs_psp_nm'] ?></td>
                            <td>
                                <button class="btn bg-gradient-warning" title="Ubah Data Status Pegawai"
                                    onclick="callHref('<?= $BasePage ?>/editData/<?= $tk['rs_psp_id_ex'] ?>')">
                                    <i class='fas fa-pen'></i>
                                </button>

                                <button class="btn bg-gradient-danger" title="Hapus Data Status Pegawai"
                                    onclick="callOther('Menghapus <?= $tk['rs_psp_nm'] ?> Dalam Data Status Pegawai', '<?= $BasePage ?>/deleteData/<?= $tk['rs_psp_id_ex'] ?>')">
                                    <i class='fas fa-trash'></i>
                                </button>

                                <button class="btn bg-gradient-primary" title="Status Berkas Berkala Pegawai"
                                    onclick="callHref('/psbb/<?= $tk['rs_psp_id_ex'] ?>')">
                                    <i class='fas fa-book'></i>
                                </button>

                                <button class="btn bg-gradient-success" title="Status Berkas Pegawai"
                                    onclick="callHref('/psb/<?= $tk['rs_psp_id_ex'] ?>')">
                                    <i class='fas fa-address-book'></i>
                                </button>

                            </td>
                        </tr>
                        <?php endforeach ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th>No</th>
                            <th>Status Kategori</th>
                            <th>Aksi</th>
                        </tr>
                    </tfoot>
                </table>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
</div>

<script>
$(document).ready(function() {
    $('#datatableKirana').DataTable({
        "order": [
            [0, "asc"]
        ],
        pageLength: 10,
        responsive: true,
        fixedHeader: true,
        keys: true,
        columnDefs: [{
                responsivePriority: 1,
                target: 0
            },
            {
                responsivePriority: 10001,
                target: 4
            },
            {
                responsivePriority: 2,
                target: -2
            }
        ]
    });
});
</script>

<?= $this->endSection(); ?>