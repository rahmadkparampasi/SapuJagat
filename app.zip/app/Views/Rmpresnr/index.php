<hr>
<form style="display: none;" id="<?= $IdForm ?>resNr" class="form-valide" action="/<?= $BasePage ?>/<?= $MethodForm ?>"
    enctype="multipart/form-data" method="POST">
    <h4 class="text-center">Form <?= $PageTitle ?></h4>


    <div class="form-group row">
        <label for="rs_rmpresnr_rmb" class="col-sm-2 col-form-label">Obat</label>
        <div class="col-sm-8">
            <input type="hidden" id="rs_rmpresnr_rmb" name="rs_rmpresnr_rmb" required class="form-control">
            <input type="text" id="rs_rmpresnr_rmbnm" name="rs_rmpresnr_rmbnm" required class="form-control" disabled>
        </div>
        <div class="col-sm-2">
            <button type="button" class='btn bg-gradient-primary mx-1' data-target="#modalViewRmRmb" data-toggle="modal"
                style="float: right;"
                onclick="showRmRmb( 'rs_rmpresnr_rmbnm', 'rs_rmpresnr_rmb', '<?= $rs_rmpres_rmr ?>')"><i
                    class="fas fa-file-archive"></i>
                AMBIL OBAT</button>
        </div>
    </div>

    <div class="form-group row">
        <label for="rs_rmpresnr_jmlh" class="col-sm-2 col-form-label">Jumlah</label>
        <div class="col-sm-10">
            <input type="number" name="rs_rmpresnr_jmlh" id="rs_rmpresnr_jmlh" class="form-control" required>
        </div>
    </div>

    <div class="form-group row">
        <label for="rs_rmpresnr_rmap" class="col-sm-2 col-form-label">Aturan Pakai</label>
        <div class="col-sm-10">
            <select name="rs_rmpresnr_rmap" id="rs_rmpresnr_rmap" class="form-control"
                onfocus="ambilDataSelect('rs_rmpresnr_rmap', '/rmap/getAllForSelect/', 'Pilih Salah Satu Pilihan', toRemove=[], removeMessage=[], '')">
                <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
            </select>
        </div>
    </div>

    <div class="form-group row">
        <label for="rs_rmpresnr_ket" class="col-sm-2 col-form-label">Keterangan</label>
        <div class="col-sm-10">
            <textarea name="rs_rmpresnr_ket" id="rs_rmpresnr_ket" class="form-control" rows="10" cols="2"></textarea>
        </div>
    </div>

    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-primary"><?= $ButtonMethod ?></button>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('<?= $IdForm ?>resNr', '<?= $IdForm ?>'); ">BATAL</button>
        </div>
    </div>
    <hr>
</form>

<div>
    <h4 class="text-center">Daftar <?= $PageTitle ?></h4>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-success" style="float: right;"
                onclick="showForm('<?= $IdForm ?>resNr', 'block');"><i class="fas fa-plus"></i>
                Tambah</button>
        </div>
    </div>
    <table id="dtK<?= $IdForm ?>" class="table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Obat</th>
                <th>Jumlah</th>
                <th>Aturan Pakai</th>
                <th>Keterangan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Rmpresnr as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td>
                <td><?= $tk['rs_rmb_nm'] ?></td>
                <td><?= $tk['rs_rmpresnr_jmlh'] ?></td>
                <td><?= $tk['rs_rmap_nm'] ?></td>
                <td><?= $tk['rs_rmpresnr_ket'] ?></td>
                <td>
                    <button class="btn bg-gradient-danger"
                        title="Hapus <?= $tk['rs_rmb_nm'] ?> Dalam Data E-Resep Non Racik"
                        onclick="callOther('Menghapus <?= $tk['rs_rmb_nm'] ?> Dalam Data E-Resep Non Racik', '/rmpresnr/deleteData/<?= $tk['rs_rmpresnr_id'] ?>')">
                        <i class='fas fa-trash'></i></button>

                </td>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
    <br>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="button" class="btn bg-gradient-danger" style="float: right;" onclick="clearBox()"><i
                    class="fas fa-times"></i>
                Tutup</button>
        </div>
    </div>
</div>
<?= $this->include('Rmpmskd/modalViewRmb'); ?>
<script>
$(function() {
    $(document).ready(function() {
        var <?= $IdForm ?>resNr = $('#<?= $IdForm ?>resNr');
        <?= $IdForm ?>resNr.submit(function(e) {
            showAnimated();
            $('#<?= $IdForm ?>resNr :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');

            e.preventDefault();
            $.ajax({
                type: <?= $IdForm ?>resNr.attr('method'),
                url: <?= $IdForm ?>resNr.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            loadChildFormRes('rmpresnr',
                                '<?= $rs_rmpresnr_rmpres ?>',
                                '<?= $rs_rmpres_kd ?>',
                                '<?= $rs_rmpres_tgl ?>',
                                '<?= $rs_rmpres_jam ?>',
                                '<?= $rs_rmpres_rmr ?>');
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>

<script>
$(document).ready(function() {
    $('#dtK<?= $IdForm ?>').DataTable({
        "order": [
            [0, "asc"]
        ],
        pageLength: 10,
        responsive: true,
        fixedHeader: false,
        keys: true,
        columnDefs: [{
                responsivePriority: 1,
                target: 0
            },
            {
                responsivePriority: 10001,
                target: 4
            },
            {
                responsivePriority: 2,
                target: -2
            }
        ]
    });
});
</script>