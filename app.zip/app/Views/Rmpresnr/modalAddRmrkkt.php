<div class="modal fade" id="modalAddRmrkkt" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form id="addRmrkkt" method="POST" action="/rmrkkt/insertData" enctype="multipart/form-data">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">TAMBAH TEMPAT TIDUR</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <input type="hidden" name="rs_rmrkkt_rmrkk" id="rs_rmrkkt_rmrkk" value="">
                    <div class="form-group">
                        <label for="rs_rmrkkt_nma">RUANGAN, KELAS, KAMAR</label>
                        <input type="text" class="form-control" id="rs_rmrkkt_nma" name="rs_rmrkkt_nma" required disabled>
                    </div>
                    <div class="form-group">
                        <label for="rs_rmrkkt_nm">NAMA TEMPAT TIDUR</label>
                        <input type="text" class="form-control" id="rs_rmrkkt_nm" name="rs_rmrkkt_nm" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="item form-group">
                        <button type="submit" class="btn btn-success">SIMPAN</button>
                        <button type="button" class="btn btn-primary" data-dismiss="modal">BATAL</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
    $(function() {
        $(document).ready(function() {
            var addRmrkkt = $('#addRmrkkt');
            addRmrkkt.submit(function(e) {
                showAnimated();
                //$('#addChildRmr :input').prop("disabled", false);
                $(this).attr('disabled', 'disabled');

                e.preventDefault();
                $.ajax({
                    type: addRmrkkt.attr('method'),
                    url: addRmrkkt.attr('action'),
                    enctype: 'multipart/form-data',
                    data: new FormData(this),
                    contentType: false,
                    processData: false,
                    dataType: 'json',
                    success: function(data) {
                        hideAnimated();
                        if (data.response == "success") {
                            swal.fire({
                                title: "Terima Kasih",
                                text: data.message,
                                icon: data.response
                            }).then(function() {
                                loadTabKmr();
                                $('#modalAddRmrkkt').modal('hide');
                                document.getElementById("addRmrkkt").reset();

                            });
                        } else {
                            hideAnimated();
                            swal.fire({
                                title: "Tidak Dapat Melanjutkan Proses",
                                text: data.message,
                                icon: data.response
                            });
                        }
                    },
                    error: function(xhr) {
                        hideAnimated();
                        console.log(xhr);
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: xhr.responseJSON.message,
                            icon: "error"
                        });
                    }
                });
            });
        });
    });
</script>