<?= $this->extend('Templates/template'); ?>

<?= $this->section('content'); ?>
<!-- /.row -->
<!-- Ruangan -->
<h5 class="mb-2">Referensi Ruangan</h5>
<div class="row">

    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-info">
            <div class="inner">
                <h4>Tindakan</h4>

                <p>Berisikan Data Tindakan</p>
            </div>
            <div class="icon">
                <i class="fas fa-diagnoses"></i>
            </div>
            <a href="/rmtdk" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->
    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-info">
            <div class="inner">
                <h4>Kategori Tindakan</h4>

                <p>Berisikan Data Kategori Tindakan</p>
            </div>
            <div class="icon">
                <i class="fas fa-notes-medical"></i>
            </div>
            <a href="/rmktdk" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->
    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-info">
            <div class="inner">
                <h4>Kelas</h4>

                <p>Berisikan Data Kelas Yang Tersedia Di Rumah Sakit</p>
            </div>
            <div class="icon">
                <i class="fas fa-hospital-alt"></i>
            </div>
            <a href="/rmk" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->
    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-info">
            <div class="inner">
                <h4>Mutu</h4>

                <p>Berisikan Data Mutu Yang Tersedia Di Rumah Sakit</p>
            </div>
            <div class="icon">
                <i class="fas fa-star"></i>
            </div>
            <a href="/rmmt" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->
    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-info">
            <div class="inner">
                <h4>Staf Medis Fungsional</h4>

                <p>Berisikan Data Staf Medis Fungsional Yang Tersedia Di Rumah Sakit</p>
            </div>
            <div class="icon">
                <i class="fas fa-user-md"></i>
            </div>
            <a href="/rmsmf" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->
</div>
<!-- Ruangan -->
<!-- Pasien -->
<h5 class="mb-2">Referensi Pasien</h5>
<div class="row">

    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-success">
            <div class="inner">
                <h4>Kategori Triage</h4>

                <p>Berisikan Data Kategori Triage Yang Diberikan Ke Pasien</p>
            </div>
            <div class="icon">
                <i class="fas fa-file-medical-alt"></i>
            </div>
            <a href="/rmkt" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->
    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-success">
            <div class="inner">
                <h4>Keadaan Keluar</h4>

                <p>Berisikan Data Keadaan Keluar Yang Diberikan Ke Pasien</p>
            </div>
            <div class="icon">
                <i class="fas fa-door-open"></i>
            </div>
            <a href="/rmkk" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->
    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-success">
            <div class="inner">
                <h4>Cara Keluar</h4>

                <p>Berisikan Data Cara Keluar Yang Diberikan Ke Pasien</p>
            </div>
            <div class="icon">
                <i class="fas fa-stethoscope"></i>
            </div>
            <a href="/rmck" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->
    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-success">
            <div class="inner">
                <h4>Aturan Pakai</h4>

                <p>Berisikan Data Aturan Pakai Yang Diberikan Ke Pasien</p>
            </div>
            <div class="icon">
                <i class="fas fa-receipt"></i>
            </div>
            <a href="/rmap" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->
</div>
<!-- Pasien -->
<!-- Pilihan -->
<h5 class="mb-2">Referensi Pilihan</h5>
<div class="row">

    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-primary">
            <div class="inner">
                <h4>Jenis Kartu Identitas</h4>

                <p>Berisikan Data Jenis Kartu Identitas Yang Dijadikan Pilihan</p>
            </div>
            <div class="icon">
                <i class="fas fa-id-card"></i>
            </div>
            <a href="/rmi" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->
    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-primary">
            <div class="inner">
                <h4>Jenis Pekerjaan</h4>

                <p>Berisikan Data Jenis Pekerjaan Yang Dijadikan Pilihan</p>
            </div>
            <div class="icon">
                <i class="fas fa-briefcase"></i>
            </div>
            <a href="/rmkrj" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->
    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-primary">
            <div class="inner">
                <h4>Jenis Pendidikan</h4>

                <p>Berisikan Data Jenis Pendidikan Yang Dijadikan Pilihan</p>
            </div>
            <div class="icon">
                <i class="fas fa-user-graduate"></i>
            </div>
            <a href="/rmpdk" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->
    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-primary">
            <div class="inner">
                <h4>Jenis Waktu Kontrol</h4>

                <p>Berisikan Data Jenis Waktu Kontrol Yang Dijadikan Pilihan</p>
            </div>
            <div class="icon">
                <i class="fas fa-clock"></i>
            </div>
            <a href="/rmwk" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->
    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-primary">
            <div class="inner">
                <h4>Jenis Hubungan</h4>

                <p>Berisikan Data Jenis Hubungan Yang Dijadikan Pilihan</p>
            </div>
            <div class="icon">
                <i class="fas fa-handshake"></i>
            </div>
            <a href="/rmhub" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->
    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-primary">
            <div class="inner">
                <h4>Jenis Rujukan</h4>

                <p>Berisikan Data Jenis Rujukan Yang Dijadikan Pilihan</p>
            </div>
            <div class="icon">
                <i class="fas fa-ambulance"></i>
            </div>
            <a href="/rmjr" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->
    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-primary">
            <div class="inner">
                <h4>Jenis Ruangan Rujukan</h4>

                <p>Berisikan Data Jenis Ruangan Rujukan Yang Dijadikan Pilihan</p>
            </div>
            <div class="icon">
                <i class="fas fa-clinic-medical"></i>
            </div>
            <a href="/rmrr" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->
    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-primary">
            <div class="inner">
                <h4>Jenis Kemasan Racikan</h4>

                <p>Berisikan Data Jenis Kemasan Racikan Yang Dijadikan Pilihan</p>
            </div>
            <div class="icon">
                <i class="fas fa-prescription-bottle"></i>
            </div>
            <a href="/rmkr" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->
    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-primary">
            <div class="inner">
                <h4>Jenis Status Perkawinan</h4>

                <p>Berisikan Data Jenis Status Perkawinan Yang Dijadikan Pilihan</p>
            </div>
            <div class="icon">
                <i class="fas fa-ring"></i>
            </div>
            <a href="/rmsts" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->
    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-primary">
            <div class="inner">
                <h4>Jenis Alat Bantu</h4>

                <p>Berisikan Data Jenis Alat Bantu Yang Dijadikan Pilihan</p>
            </div>
            <div class="icon">
                <i class="fas fa-wheelchair"></i>
            </div>
            <a href="/rmab" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->
    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-primary">
            <div class="inner">
                <h4>Jenis Tinggal Sama Siapa</h4>

                <p>Berisikan Data Jenis Tinggal Sama Siapa Yang Dijadikan Pilihan</p>
            </div>
            <div class="icon">
                <i class="fas fa-home"></i>
            </div>
            <a href="/rmtgl" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->
    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-primary">
            <div class="inner">
                <h4>Jenis Agama</h4>

                <p>Berisikan Data Jenis Agama Yang Dijadikan Pilihan</p>
            </div>
            <div class="icon">
                <i class="fas fa-paper-plane"></i>
            </div>
            <a href="/rmag" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->
    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-primary">
            <div class="inner">
                <h4>Jenis Golongan Darah</h4>

                <p>Berisikan Data Jenis Golongan Darah Yang Dijadikan Pilihan</p>
            </div>
            <div class="icon">
                <i class="fas fa-tint"></i>
            </div>
            <a href="/rmgd" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->
    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-primary">
            <div class="inner">
                <h4>Jenis Generik / Zat Aktif</h4>

                <p>Berisikan Data Jenis Generik / Zat Aktif Yang Dijadikan Pilihan</p>
            </div>
            <div class="icon">
                <i class="fas fa-pills"></i>
            </div>
            <a href="/rmgz" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->
    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-primary">
            <div class="inner">
                <h4>Jenis Satuan</h4>

                <p>Berisikan Data Jenis Satuan Yang Dijadikan Pilihan</p>
            </div>
            <div class="icon">
                <i class="fas fa-balance-scale"></i>
            </div>
            <a href="/rmst" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->
    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-primary">
            <div class="inner">
                <h4>Jenis Antrian</h4>

                <p>Berisikan Data Jenis Antrian Yang Dijadikan Pilihan</p>
            </div>
            <div class="icon">
                <i class="fas fa-music"></i>
            </div>
            <a href="/rmja" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->
    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-primary">
            <div class="inner">
                <h4>Jenis Satuan Laboratorium</h4>

                <p>Berisikan Data Jenis Satuan Laboratorium Yang Dijadikan Pilihan</p>
            </div>
            <div class="icon">
                <i class="fas fa-flask"></i>
            </div>
            <a href="/rmsl" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->
    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-primary">
            <div class="inner">
                <h4>Jenis Merek / Produsen</h4>

                <p>Berisikan Data Jenis Merek / Produsen Yang Dijadikan Pilihan</p>
            </div>
            <div class="icon">
                <i class="fas fa-industry"></i>
            </div>
            <a href="/rmmrk" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->


</div>
<!-- Pilihan -->
<!-- Pilihan -->
<h5 class="mb-2">Referensi Fasilitas Kesehatan</h5>
<div class="row">
    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-danger">
            <div class="inner">
                <h4>Wilayah</h4>

                <p>Berisikan Data Wilayah Yang Dijadikan Pilihan</p>
            </div>
            <div class="icon">
                <i class="fas fa-map-marked-alt"></i>
            </div>
            <a href="/rmw" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->
    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-danger">
            <div class="inner">
                <h4>Jenis Fasilitas Kesehatan</h4>

                <p>Berisikan Data Jenis Fasilitas Kesehatan Yang Dijadikan Pilihan</p>
            </div>
            <div class="icon">
                <i class="fas fa-hospital"></i>
            </div>
            <a href="/rmjf" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->
    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-danger">
            <div class="inner">
                <h4>Kepemilikan Fasilitas Kesehatan</h4>

                <p>Berisikan Data Kepemilikan Fasilitas Kesehatan Yang Dijadikan Pilihan</p>
            </div>
            <div class="icon">
                <i class="fas fa-medal"></i>
            </div>
            <a href="/rmkf" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->
    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-danger">
            <div class="inner">
                <h4>Tipe Fasilitas Kesehatan</h4>

                <p>Berisikan Data Tipe Fasilitas Kesehatan Yang Dijadikan Pilihan</p>
            </div>
            <div class="icon">
                <i class="fas fa-layer-group"></i>
            </div>
            <a href="/rmtf" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->
    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-danger">
            <div class="inner">
                <h4>Kelas Fasilitas Kesehatan</h4>

                <p>Berisikan Data Kelas Fasilitas Kesehatan Yang Dijadikan Pilihan</p>
            </div>
            <div class="icon">
                <i class="fas fa-sort-alpha-down"></i>
            </div>
            <a href="/rmcf" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->
</div>
<!-- Pilihan -->
<!-- Setup -->
<h5 class="mb-2">Referensi Setup</h5>
<div class="row">
    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-warning">
            <div class="inner">
                <h4>Setup Ruangan</h4>

                <p>Berisikan Data Setup Ruangan Yang Dijadikan Pilihan</p>
            </div>
            <div class="icon">
                <i class="fas fa-cogs"></i>
            </div>
            <a href="/setrmr" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->
    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-warning">
            <div class="inner">
                <h4>Setup Pendaftaran</h4>

                <p>Berisikan Data Setup Pendaftaran Yang Dijadikan Pilihan</p>
            </div>
            <div class="icon">
                <i class="fas fa-file-signature"></i>
            </div>
            <a href="/setdftr" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->
    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-warning">
            <div class="inner">
                <h4>Setup Antrian</h4>

                <p>Berisikan Data Setup Antrian Yang Dijadikan Pilihan</p>
            </div>
            <div class="icon">
                <i class="fas fa-receipt"></i>
            </div>
            <a href="/setant" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->
    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-warning">
            <div class="inner">
                <h4>Setup Suara</h4>

                <p>Berisikan Data Setup Suara Antrian Yang Ditampilkan</p>
            </div>
            <div class="icon">
                <i class="fas fa-volume-up"></i>
            </div>
            <a href="/setsra" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->
    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-warning">
            <div class="inner">
                <h4>Setup Gambar Kartu</h4>

                <p>Berisikan Data Setup Gambar Kartu Yang Ditampilkan</p>
            </div>
            <div class="icon">
                <i class="fas fa-address-card"></i>
            </div>
            <a href="/setkrt" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->
    <div class="col-lg-3 col-6">
        <!-- small card -->
        <div class="small-box bg-warning">
            <div class="inner">
                <h4>Setup Permintaan</h4>

                <p>Berisikan Data Setup Permintaan Yang Akan Dituju Pasien</p>
            </div>
            <div class="icon">
                <i class="fas fa-shoe-prints"></i>
            </div>
            <a href="/setmnt" class="small-box-footer">
                Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
    <!-- /.col -->
</div>
<!-- Setup -->

<?= $this->endSection(); ?>