<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $WebTitle; ?></title>

    <meta name="subject" content="<?= $WebTitle; ?>" />
    <meta name="date" content="<?= date("Y-m-d") ?>" />
    <link rel="stylesheet" href="/vendors/include/bootstrap.min.css" media="all">
    <style>
        @page {
            size: 12.99in 8.27in;
            /* margin: 27mm 16mm 27mm 16mm; */
        }

        /* @page :left {
            margin-left: 3cm;
        }

        @page :right {
            margin-left: 4cm;
        } */

        @page :blank {
            @top-center {
                content: "This page is intentionally left blank.";
            }
        }

        @page: right {
            @bottom-left {
                margin: 10pt 0 30pt 0;
                border-top: 0.25pt solid #666;
                content: "My book";
                font-size: 9pt;
                color: #333;
            }
        }

        h1 {
            page-break-before: always;
        }

        h1,
        h2,
        h3,
        h4,
        h5 {
            page-break-after: avoid;
        }

        table,
        figure {
            page-break-inside: avoid;
        }

        @page: right {
            @bottom-right {
                content: counter(page);
            }
        }

        @page: left {
            @bottom-left {
                content: counter(page);
            }
        }

        @page: left {
            @bottom-left {
                content: "Page "counter(page) " of "counter(pages);
            }
        }

        body {
            counter-reset: chapternum;
        }

        h1.chapter:before {
            counter-increment: chapternum;
            content: counter(chapternum) ". ";
        }

        body {
            counter-reset: chapternum figurenum;
        }

        h1 {
            counter-reset: figurenum;
        }

        h1.title:before {
            counter-increment: chapternum;
            content: counter(chapternum) ". ";
        }

        figcaption:before {
            counter-increment: figurenum;
            content: counter(chapternum) "-"counter(figurenum) ". ";
        }

        h1 {
            string-set: doctitle content();
        }

        @page :right {
            @top-right {
                content: string(doctitle);
                margin: 30pt 0 10pt 0;
                font-size: 8pt;
            }
        }

        .fn {
            float: footnote;
        }

        .fn {
            counter-increment: footnote;
        }

        h1 {
            counter-reset: footnote;
        }

        .fn::footnote-call {
            content: counter(footnote);
            font-size: 9pt;
            vertical-align: super;
            line-height: none;
        }

        .fn::footnote-marker {
            font-weight: bold;
        }

        @page {
            /* @footnote {
                border-top: 1pt solid black;
            } */
        }

        @media print {
            @page {
                margin-top: 0;
                margin-bottom: 0;
            }

            body {
                padding-top: 72px;
                padding-bottom: 10px;
            }
        }

        .table-border,
        .table-border td,
        .table-border th {
            outline-color: #000;
            outline-style: solid;
            outline-width: thin;
        }

        .tH {
            background-color: rgba(155, 194, 230, 1) !important;
            text-align: center;
        }

        .tHn {

            text-align: center;
        }
    </style>
    <!-- Jquery -->
    <script src="/vendors/include/jquery-3.4.1.js"></script>
    <script src="/vendors/include/jquery-3.1.1.min.js"></script>
</head>

<body>
    <!-- <div class="frontcover">
        <h1><?= strtoupper($WebTitle); ?></h1>
    </div> -->
    <div class="contents" class="d-flex align-items-center">
        <table class="table-borderless" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th rowspan="3" class="px-3" style="width: 1% !important; white-space: nowrap !important;"><img src="/favicon.png" alt="" width="100"></th>
                    <th class="p-0 m-0" style="font-size: 26px;">Rumah Sakit Umum Daerah Kolonodale</th>
                </tr>
                <tr>
                    <th colspan="2" class="p-0 m-0" style="font-size: 26px;">Provinsi Sulawesi Tengah</th>
                </tr>
                <tr>
                    <th colspan="2" style="font-size: 20px; font-weight: 100;">Jl. dr. Azis Maralla No. 12, Kode Pos: 94971</th>
                </tr>
                <tr>
                    <th colspan="3"><img src="/images/line.png" alt="" width="100%"></th>
                    
                </tr>
            </thead>
            <tbody>

            </tbody>
        </table>
        <br><br>

        <p style="text-align: center; font-weight: bold; font-size: 2rem">LAPORAN DATA REKAP PEGAWAI</p>
        <br><br>
        <table id="datatableKirana" class="table table-border" cellspacing="0" width="95%" style="width: 95%; margin: 0 auto;">
            <thead>
                <tr>
                    <th class="tH">No.</th>
                    <th class="tH">Nama Pegawai</th>
                    <th class="tH">Status Kepegawaian</th>
                    <th class="tH">TTL</th>
                    <th class="tH">NIP</th>
                    <th class="tH">NIK</th>
                    <th class="tH">Ruangan</th>
                    <th class="tH">Kategori Kepegawaian</th>
                    <th class="tH">Jenis Kelamin</th>
                    <th class="tH">No. Handphone</th>
                </tr>
                <tr>
                    <th class="tHn">1</th>
                    <th class="tHn">2</th>
                    <th class="tHn">3</th>
                    <th class="tHn">4</th>
                    <th class="tHn">5</th>
                    <th class="tHn">6</th>
                    <th class="tHn">7</th>
                    <th class="tHn">8</th>
                    <th class="tHn">9</th>
                    <th class="tHn">10</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 0;
                foreach ($Ppeg as $tk) : $no++ ?>
                    <tr> 
                        <td><?= $no ?></td>
                        <td><?= $tk['rs_ppeg_nm'] ?></td>
                        <td><?= $tk['rs_psp_nm'] ?></td>
                        <td><?= $tk['rs_ppeg_tmpt_lhr'] ?>, <?= $tk['rs_ppeg_tgl_lhr'] ?></td>
                        <td><?= $tk['rs_ppeg_nip'] ?></td>
                        <td><?= $tk['rs_ppeg_nik'] ?></td>
                        <td><?= $tk['rs_rmr_nm'] ?></td>
                        <td><?= $tk['rs_pkp_nm'] ?></td>
                        <td><?= $tk['rs_ppeg_jk'] ?></td>
                        <td><?= $tk['rs_ppeg_hp'] ?></td>   
                    </tr>
                <?php endforeach ?>
 
            </tbody>

        </table>
        <br><br><br>
        <p style="font-size: 14px; text-align: right; text-decoration: underline; width: 100%;">Rumah Sakit Umum Daerah Kolonodale, Sulawesi Tengah</p>
        <!-- <p>Footnotes<span class="footnotes">Footnotes and notes placed in the footer of a document to reference the text. The footnote will be removed from the flow when the page is created.</span> are useful in books and printed documents.</p> -->
    </div>
</body>
<script>
    window.print();
</script>
<script>
    $(document).ready(function() {
        $('#datatableKirana').DataTable({
            "order": [
                [0, "asc"]
            ],
            pageLength: 10,
            responsive: false,
            fixedHeader: false,
            keys: false,
        });
    });
</script>

</html>