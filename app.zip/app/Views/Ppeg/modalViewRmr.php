<div class="modal fade bd-example-modal-lg" id="modalViewRmr" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabelPdf">DATA RUANGAN </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>



            <div class="modal-body">
                <table id="dt" class="table responsive table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Aksi</th>
                            <th class="text-nowrap">Nama Ruangan</th>
                        </tr>
                    </thead>
                </table>
                <script type="text/javascript">
                    function showRmr(rs_ppeg_id_ex = '', BasePage = '') {

                        var dt = $('#dt').DataTable({
                            destroy: true,
                            ajax: "<?= base_url('rmr/getRmrByJson') ?>" + "/" + rs_ppeg_id_ex + "/" + BasePage,
                            paging: false,
                            searching: false,
                            pageLength: 10,
                            responsive: true,
                            fixedHeader: true,
                            keys: true,
                            language: {
                                paginate: {
                                    previous: "Sebelumnya",
                                    next: "Selanjutnya"
                                },
                                "emptyTable": "Data Ruangan Belum Ada",
                            },
                            columns: [{
                                    "data": "no"
                                },
                                {
                                    "data": "button"
                                },
                                {
                                    "data": "rs_rmr_nm"
                                },
                            ],
                            columnDefs: [{
                                className: "text-nowrap",
                                "targets": [2]
                            }]
                        });
                    }
                </script>
            </div>

            <div class="modal-footer">
                <div class="item form-group">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">TUTUP</button>
                </div>
            </div>



        </div>
    </div>
</div>