<div class="card card-primary" style="
    <?php
    if ($MethodForm1 == "updateData") {
        echo 'display: flex;';
    } else {
        echo 'display: none;';
    } ?>" id="<?= $IdForm ?>card">
    <div class="card-header">
        <h3 class="card-title">Form Tambah <?= $PageTitle ?></h3>
    </div>
    <!-- /.card-header -->
    <!-- form start -->
    <form method="POST" class="form-valide" action="/<?= $BasePage ?>/<?= $MethodForm ?>" id="<?= $IdForm ?>"
        enctype="multipart/form-data">
        <?php
        if ($MethodForm1 == "updateData") {
            echo "<input type='hidden' name='rs_ppeg_id_ex' id='rs_ppeg_id_ex'>";
        }
        ?>
        <div class="card-body">
            <div class="form-group">
                <label for="rs_ppeg_nmd">Gelar Depan</label>
                <input type="text" class="form-control" id="rs_ppeg_nmd" name="rs_ppeg_nmd">
            </div>
            <div class="form-group">
                <label for="rs_ppeg_nm">Nama Pegawai</label>
                <input type="text" class="form-control" id="rs_ppeg_nm" name="rs_ppeg_nm" required>
            </div>
            <div class="form-group">
                <label for="rs_ppeg_nmb">Gelar Belakang</label>
                <input type="text" class="form-control" id="rs_ppeg_nmb" name="rs_ppeg_nmb">
            </div>
            <div class="form-group">
                <label for="rs_ppeg_psp">STATUS</label>
                <select name="rs_ppeg_psp" id="rs_ppeg_psp" class="form-control" required>
                    <option hidden>PILIH SALAH SATU PILIHAN</option>
                    <?php foreach ($Psp as $tk) : ?>
                    <option value="<?= $tk['rs_psp_id_ex'] ?>"><?= $tk['rs_psp_nm'] ?></option>
                    <?php endforeach ?>
                </select>
            </div>

            <div class="form-group">
                <label for="rs_ppeg_pkp">KATEGORI</label>
                <select name="rs_ppeg_pkp" id="rs_ppeg_pkp" class="form-control" required>
                    <option hidden>PILIH SALAH SATU PILIHAN</option>
                    <?php foreach ($Pkp as $tk) : ?>
                    <option value="<?= $tk['rs_pkp_id_ex'] ?>"><?= $tk['rs_pkp_nm'] ?></option>
                    <?php endforeach ?>
                </select>
            </div>


            <div class="form-group">
                <label for="rs_ppeg_nip">NIP</label>
                <input type="number" class="form-control" id="rs_ppeg_nip" name="rs_ppeg_nip">
            </div>
            <div class="form-group">
                <label for="rs_ppeg_nik">NIK</label>
                <input type="number" class="form-control" id="rs_ppeg_nik" name="rs_ppeg_nik" required>
            </div>
            <div class="form-group">
                <label for="rs_ppeg_tmpt_lhr">Tempat Lahir</label>
                <input type="text" class="form-control" id="rs_ppeg_tmpt_lhr" name="rs_ppeg_tmpt_lhr" required>
            </div>
            <div class="form-group">
                <label for="rs_ppeg_tgl_lhr">Tanggal Lahir</label>
                <input type="date" class="form-control" id="rs_ppeg_tgl_lhr" name="rs_ppeg_tgl_lhr" required>
            </div>
            <div class="form-group">
                <label for="rs_ppeg_jk">JENIS KELAMIN</label>
                <select name="rs_ppeg_jk" id="rs_ppeg_jk" class="form-control" required>
                    <option hidden>PILIH SALAH SATU PILIHAN</option>
                    <option value="L">LAKI-LAKI</option>
                    <option value="P">PEREMPUAN</option>
                </select>
            </div>
        </div>
        <!-- /.card-body -->

        <div class="card-footer">
            <button type="submit" class="btn bg-gradient-primary"><?= $ButtonMethod ?></button>
            <?php
            $MethodForm = substr($MethodForm, 0, 10);
            if ($MethodForm == "updateData") {
            ?>
            <a href="/<?= $BasePage ?>" class='btn bg-gradient-danger' aria-pressed="true">BATAL</a>
            <?php
            } else {
            ?>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('<?= $IdForm ?>card', '<?= $IdForm ?>')">BATAL</button>

            <?php
            }
            ?>
        </div>
    </form>
</div>