    <?= $this->extend('Templates/template'); ?>

    <?= $this->section('content'); ?>
    <!-- /.row -->

    <div class="row">
        <!-- Area Chart -->
        <div class="col-xl-12 col-lg-12">
            <?= $this->include('Ppeg/addData'); ?> 
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Daftar <?= $PageTitle ?></h3>
                    <div class="card-tools">

                        <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
                        <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>

                        <!-- <select class="form-control col mx-2" required id="method">
                        <option hidden value="">Pilih Cara Cetak Laporan</option>
                        <option value="rs_ppeg_id_ex">Rekap Data Seluruh Pegawai</option>
                        <option value="">Rekap Data ASN</option>
                        <option value="">Rekap Data Tenaga Kontrak</option> -->
                    </select>

                        <?php
                        if ($MethodForm1 != "updateData") {
                        ?>  
                            <!-- <button type="button" class="btn bg-gradient-info col-6.5"  onclick="callBlank('/ppeg/ctkPgwAll/')"><i class="fa fa-print"></i> CETAK REKAP PEGAWAI JK</button> -->
                            <button type="button" class="btn bg-gradient-primary col-6.5"  onclick="callBlank('/ppeg/ctkPgwAll/')"><i class="fa fa-print"></i> CETAK REKAP PEGAWAI</button>
                            <!-- <button type="button" class="btn bg-gradient-primary col-6.5"  onclick="callBlank('/ppeg/ctkPgwAllAb/')"><i class="fa fa-print"></i> CETAK ID ABSEN PEGAWAI</button> -->
                            <button class='btn bg-gradient-success mx-2' style="float: right;" onclick="showForm('<?= $IdForm ?>card')"><i class="fas fa-plus"></i>
                                    TAMBAH
                            </button>   
                        <?php
                        }
                        ?> 
                       
                    </div>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <table id="datatableKirana" class="table responsive table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Pegawai</th>
                                <th>ID Absen</th>
                                <th>Status Kepegawaian</th>
                                <th>TTL</th>
                                <th>NIP</th>
                                <th>NIK</th>
                                <th>Nama Pengguna</th>
                                <th>Ruangan</th>
                                <th>Kategori Kepegawaian</th>
                                <th>Jenis Kelamin</th>
                                <th>Alamat</th>
                                <th>NPWP</th>
                                <th>BPJS</th>
                                <th>No. HP</th>
                                <th>Email</th>
                                <th>Agama</th>
                                <th>Status Hubungan</th>
                                <th>Golongan Darah</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 0;
                            foreach ($Ppeg as $tk) : $no++ ?>
                                <tr>
                                    <td><?= $no ?></td>
                                    <td><?= $tk['rs_ppeg_nm'] ?></td>
                                    <td><?= $tk['rs_ppeg_ab'] ?></td>
                                    <td><?= $tk['rs_psp_nm'] ?></td>
                                    <td><?= $tk['rs_ppeg_tmpt_lhr'] ?>, <?= $tk['rs_ppeg_tgl_lhr'] ?></td>
                                    <td><?= $tk['rs_ppeg_nip'] ?></td>
                                    <td><?= $tk['rs_ppeg_nik'] ?></td>
                                    <td>
                                        <?= $tk['rs_pa_un'] ?><br />
                                        <?php
                                        if ($tk['rs_pa_act'] == "1") {
                                        ?>
                                            <span class="badge badge-success">Tidak Terblokir</span>
                                            <button class="btn bg-gradient-warning" title="Hapus Data Jenis Pegawai" onclick="callOther('Memblokir <?= $tk['rs_ppeg_nm'] ?> Dalam Data Akun', '<?= $BasePage ?>/blockPa/<?= $tk['rs_pa_id_ex'] ?>')">
                                                <i class='fas fa-lock'></i>
                                            </button>
                                        <?php
                                        } else {
                                        ?>
                                            <span class="badge badge-danger">Terblokir</span>
                                            <button class="btn bg-gradient-success" title="Hapus Data Jenis Pegawai" onclick="callOther('Membuka blokir <?= $tk['rs_ppeg_nm'] ?> Dalam Data Akun', '<?= $BasePage ?>/unblockPa/<?= $tk['rs_pa_id_ex'] ?>')">
                                                <i class='fas fa-unlock'></i>
                                            </button>
                                        <?php
                                        }
                                        ?>

                                    </td>
                                    <td>
                                        <?php
                                        if ($tk['rs_ppr_id'] == '') {
                                        ?>
                                            <!-- <button class="btn bg-gradient-primary " title="Tambahkan Data Ruangan" data-target="#modalViewRmr" data-toggle="modal" onclick="showRmr('<?= $tk['rs_ppeg_id_ex'] ?>', '<?= $BasePage ?>')">
                                                <i class='fas fa-clinic-medical'></i> Ruangan
                                            </button> -->
                                        <?php
                                        } else {
                                        ?>
                                            <h6><?= $tk['rs_rmr_nm'] ?></h6>
                                            <!-- <button class="btn bg-gradient-danger " title="Tambahkan Data Ruangan" onclick="callOther('Menghapus <?= $tk['rs_rmr_nm'] ?> Dalam Data Pegawai', '/<?= $BasePage ?>/deleteRmrToPpeg/<?= $tk['rs_ppr_id'] ?>')">
                                                <i class='fas fa-trash'></i> Hapus Data Ruagan
                                            </button> -->
                                        <?php
                                        }
                                        ?>

                                    </td>
                                    <td><?= $tk['rs_pkp_nm'] ?></td>
                                    <td><?= $tk['rs_ppeg_jk'] ?></td>
                                    <td><?= $tk['rs_ppeg_alt'] ?></td>
                                    <td><?= $tk['rs_ppeg_npwp'] ?></td>
                                    <td><?= $tk['rs_ppeg_bpjs'] ?></td>
                                    <td><?= $tk['rs_ppeg_hp'] ?></td>
                                    <td><?= $tk['rs_ppeg_mail'] ?></td>
                                    <td><?= $tk['rs_rmag_nm'] ?></td>
                                    <td><?= $tk['rs_rmsts_nm'] ?></td>
                                    <td><?= $tk['rs_rmgd_nm'] ?></td>
                                    <td>
                                        <button class="btn bg-gradient-danger" title="Hapus Data Pegawai" onclick="callOther('Menghapus <?= $tk['rs_ppeg_nm'] ?> Dalam Data Pegawai', '<?= $BasePage ?>/deleteData/<?= $tk['rs_ppeg_id_ex'] ?>')">
                                            <i class='fas fa-trash'></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.card-body -->
            </div> 
            <!-- /.card -->
        </div> 
    </div>
    <?= $this->include('Ppeg/modalViewRmr'); ?>
    <script>
        $(document).ready(function() {
            $('#datatableKirana').DataTable({
                "order": [
                    [0, "asc"]
                ],
                pageLength: 10,
                responsive: true,
                fixedHeader: true,
                keys: true,
                columnDefs: [{
                        responsivePriority: 1,
                        target: 0
                    },
                    {
                        responsivePriority: 10001,
                        target: 4
                    },
                    {
                        responsivePriority: 2,
                        target: -2
                    }
                ]
            });
        });
    </script>

    <?= $this->endSection(); ?>