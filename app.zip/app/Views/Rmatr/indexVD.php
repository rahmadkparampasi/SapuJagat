<?= $this->extend('Templates/template'); ?>

<?= $this->section('content'); ?>
<!-- /.row -->

<div class="row">
    <!-- Area Chart -->
    <div class="col-xl-12 col-lg-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Daftar <?= $PageTitle ?></h3>
                
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table id="datatableKirana" class="table responsive table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Kode Antrian</th>
                            <th>Tujuan</th>
                            <th>Tanggal Dan Jam</th>
                            <th>AKSI</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 0;
                        foreach ($Rmatr as $tk) : $no++ ?>
                        <tr>
                            <td><?= $no ?></td>
                            <td><?= $tk['rs_rmatr_kd'] ?></td>
                            <td><?= $tk['rs_rmr_nm'] ?></td>
                            <td><?= $tk['rs_rmatr_tgl']." ".$tk['rs_rmatr_jam'] ?></td>
                            <td>
                                <button class="btn bg-gradient-info" title="Berkas Suara Setup Antrian" onclick="kita(files<?= $no ?>)">
                                    <i class='fas fa-volume-up'></i> Panggil
                                </button>
                            </td>
                        </tr>
                        <script>
                            var files<?= $no ?> = [

                            ]
                        </script>
                        <?php endforeach ?>
                    </tbody>
                </table>
                <?php $no = 0;
                foreach ($Rmatr as $tk) : $no++ ?>
                    <script>
                        var files<?= $no ?> = [
                            '/uploads/<?= $Setsra[0]['rs_setsra_v'] ?>',
                            '/uploads/<?= $tk['rs_rmja_v'] ?>',
                            <?php foreach ($tk['m'] as $tkd) : ?>
                                '/uploads/<?= $tkd ?>',
                            <?php endforeach ?>
                            '/uploads/<?= $tk['me'] ?>',
                        ]
                    </script>
                
                <?php endforeach ?>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
</div>
<audio id="audioKita" autoplay tabindex="0">

<?= $this->include('Rmb/modalAddHrg'); ?>
<script>
    function kita(files) {
        // Playlist array
        

        // Current index of the files array
        var i = 0;

        // Get the audio element
        var music_player = document.querySelector("#audioKita");

        // function for moving to next audio file
        function next() {
            // Check for last audio file in the playlist
            if (i === files.length - 1) {
                i = 0;
                music_player.removeEventListener('ended');
            } else {
                i++;
            }

            // Change the audio element source
            music_player.src = files[i];

            
        }

        // Check if the player is selected
        if (music_player === null) {
            throw "Playlist Player does not exists ...";
        } else {
            // Start the player
            music_player.src = files[i];

            // Listen for the music ended event, to play the next audio file
            music_player.addEventListener('ended', next, false)
        }

    };
$(document).ready(function() {
    $('#datatableKirana').DataTable({
        "order": [
            [0, "asc"]
        ],
        pageLength: 100,
        responsive: true,
        fixedHeader: true,
        keys: true,
        columnDefs: [{
                responsivePriority: 1,
                target: 0
            },
            {
                responsivePriority: 10001,
                target: 4
            },
            {
                responsivePriority: 2,
                target: -2
            }
        ]
    });
});
</script>

<?= $this->endSection(); ?>