<div class="card card-primary" style="
    <?php
    if ($MethodForm1 == "updateData") {
        echo 'display: flex;';
    } else {
        echo 'display: none;';
    } ?>" id="<?= $IdForm ?>card">
    <div class="card-header">
        <h3 class="card-title">Form Tambah <?= $PageTitle ?></h3>
    </div>
    <!-- /.card-header -->
    <!-- form start -->
    <form method="POST" class="form-valide" action="/<?= $BasePage ?>/<?= $MethodForm ?>" id="<?= $IdForm ?>" enctype="multipart/form-data">
        <?php
        if ($MethodForm1 == "updateData") {
            echo "<input type='hidden' name='rs_setant_id_ex' id='rs_setant_id_ex'>";
        }
        ?>
        <div class="card-body">
            <div class="form-group">
                <label for="rs_setant_rmja">Jenis Antrian</label>
                <select class="form-control" id="rs_setant_rmja" name="rs_setant_rmja" required>
                    <option value="" hidden>Pilih Salah Satu Pilihan</option>
                    <?php foreach ($Rmja as $tkd) : ?>
                        <option value="<?= $tkd['rs_rmja_id_ex'] ?>"><?= $tkd['rs_rmja_nm'] ?></option>
                    <?php endforeach ?>

                </select>
            </div>
            <div class="form-group">
                <label for="rs_rmr_nm">Nama Bagian</label>
                <div class="row">
                    <div class="col-10">
                        <input type="text" class="form-control" id="rs_rmr_nm" name="rs_rmr_nm" disabled>
                        <input type="hidden" class="form-control" id="rs_setant_rmr" name="rs_setant_rmr" required>
                    </div>
                    <div class="col-2">
                        <button type="button" class='btn bg-gradient-primary mx-1 my-2 btn-block' data-target="#modalViewRmr" data-toggle="modal" onclick="showRmr();"><i class="fas fa-building"></i>
                            AMBIL RUANGAN</button>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label for="rs_setant_ket">Keterangan</label>
                <textarea class="form-control" id="rs_setant_ket" name="rs_setant_ket" cols="10" rows="2"></textarea>
            </div>
        </div>
        <!-- /.card-body -->

        <div class="card-footer">
            <button type="submit" class="btn bg-gradient-primary"><?= $ButtonMethod ?></button>
            <?php
            $MethodForm = substr($MethodForm, 0, 10);
            if ($MethodForm == "updateData") {
            ?>
                <a href="/<?= $BasePage ?>" class='btn bg-gradient-danger' aria-pressed="true">BATAL</a>
            <?php
            } else {
            ?>
                <button type="button" class="btn bg-gradient-danger" onclick="closeForm('<?= $IdForm ?>card', '<?= $IdForm ?>')">BATAL</button>

            <?php
            }
            ?>
        </div>
    </form>
</div>