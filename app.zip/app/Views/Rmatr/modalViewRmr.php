<div class="modal fade bd-example-modal-lg" id="modalViewRmr" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <form class="form-horizontal form-valide" method="POST" action="/rmplp/<?= $MethodForm ?>" id="formTabPlp">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabelPdf">LIHAT DATA BAGIAN DAN RUANGAN </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div id="cardDir"></div>

                    <script type="text/javascript">
                        function showRmr() {

                            $.ajax({
                                url: "<?= base_url('rmr/getParentByJson') ?>",
                                dataType: "json",
                                success: function(data) {
                                    $('#cardDir').treeview({
                                        data: data,
                                        levels: 2,
                                        showBorder: false,
                                        color: "#428bca",
                                        showIcon: true,
                                        expandIcon: "far fa-folder",
                                        collapseIcon: "far fa-folder-open",
                                        // // selectedIcon: "fas fa-folder-open",
                                        icon: "far fa-folder-open",
                                        emptyIcon: "far fa-file",
                                        // nodeIcon: "fas fa-folder-open",

                                        //showTags: true,
                                        highlightSelected: true,
                                        onNodeSelected: function(event, data) {
                                            var sels = $('#cardDir').treeview('getSelected');
                                            document.getElementById("rs_setant_rmr").value = sels[0]
                                                .idEx;
                                            document.getElementById("rs_rmr_nm").value = sels[0]
                                                .textAlt;
                                            $('#modalViewRmr').modal('hide');
                                        },
                                    });
                                }
                            });
                        }
                    </script>
                </div>
                <div class="modal-footer">
                    <div class="item form-group">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">TUTUP</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>