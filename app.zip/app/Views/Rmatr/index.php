<!DOCTYPE html>
<html lang="en">

<head>
    <!-- meta & tittle -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>RSUD Kolonodale | <?= $WebTitle; ?></title>
    <meta name="title" content="<?= $WebTitle; ?>">
    <meta name="description" content="<?= $PageTitle; ?>">
    <link rel="icon" href="/favicon.png" type="image/png">

    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="/vendors/script/fontawesome-free/css/all.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="/vendors/include/adminlte.min.css">
    <!-- animate -->
    <link rel="stylesheet" href="/vendors/script/animate/animate.min.css" media="all">
    <!-- loading -->
    <link rel="stylesheet" href="/vendors/include/loading.css" media="all">

    <!-- jquery -->
    <script src="/vendors/script/jquery/3.3.1/jquery.min.js"></script>
</head>

<body class="hold-transition lockscreen" style="background-image: url('/images/back.jpg'); background-repeat: no-repeat;
  background-size: cover;">
    <div id="indexAnt">
        <div id="selfLoading" class="hide">
            <div class="imagePos">
                <div class="row">
                    <div class="col-lg-12" style="text-align: center;">
                        <img style="width: 18rem;" src="/favicon.png" alt="" style="margin-left: auto; margin-right: auto;" class="imageTemp">
                    </div>
                    <div class="col-lg-12">
                        <p style="color: #fff; font-size: 40px; text-align: center;"><strong>LOADING</strong></p>
                    </div>
                </div>
            </div>

        </div>
        <!-- Automatic element centering -->
        <div class="lockscreen-wrapper my-5" style="max-width: 600px;">


            <!-- START LOCK SCREEN ITEM -->
            <div class="lockscreen-item w-100">
                <!-- lockscreen image -->
                <div class="lockscreen-image" style="top: -7px; left: -20px;">
                    <img src="/favicon.png" alt="User Image">
                </div>
                <!-- /.lockscreen-image -->

                <!-- lockscreen credentials (contains the form) -->
                <form class="lockscreen-credentials">
                    <div class="input-group">
                        <h4 class="text-center font-weight-bold">RUMAH SAKIT UMUM DAERAH KOLONODALE<br>KABUPATEN MOROWALI UTARA</h4>
                        <!-- <input type="password" class="form-control" placeholder="password">

                    <div class="input-group-append">
                        <button type="button" class="btn">
                            <i class="fas fa-arrow-right text-muted"></i>
                        </button>
                    </div> -->
                    </div>
                </form>
                <!-- /.lockscreen credentials -->

            </div>
            <!-- /.lockscreen-item -->

        </div>

        <div class="lockscreen-wrapper my-5 mw-100 row justify-content-center">

            <?php foreach ($Setant as $tk) : ?>
                <!-- START LOCK SCREEN ITEM -->
                <div class="lockscreen-item col-3 m-2" style="background-image: url('/images/assets-1.png'); background-repeat: no-repeat; background-size: 100% 100%; height: 5rem; background-color: rgba(255, 255, 255, 0) !important; cursor: pointer;" onclick="callOtherWP('/<?= $BasePage ?>/insertData/<?= $tk['rs_setant_rmr'] ?>/<?= $tk['rs_rmja_nm'] ?>/<?= $tk['rs_rmja_id_ex'] ?>')">
                    <!-- lockscreen credentials (contains the form) -->
                    <div class="lockscreen-credentials m-0 h-100 d-flex justify-content-center align-content-center">
                        <button class="btn text-white font-weight-bold h-auto" style="background-color: rgba(255, 255, 255, 0) !important; font-size: 17px;" onclick=""><?= strtoupper($tk['rs_rmr_nm']) ?></button>
                    </div>
                    <!-- /.lockscreen credentials -->
                </div>
                <!-- /.lockscreen-item -->
            <?php endforeach ?>
        </div>
        <div class="lockscreen-wrapper my-5 mw-100">
            <div class="lockscreen-footer text-center">
                <strong class="text-white">Copyright &copy; 2021 - <?= date("Y") ?> <a class="text-white" href="<?= base_url() ?>">RUMAH SAKIT UMUM DAERAH KOLONODALE, KABUPATEN MOROWALI UTARA</a>.</strong></b><br>
                <p class="text-white">All rights reserved</p>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            // element which needs to enter full-screen mode
            launchFullScreen(document.documentElement); //
        });

        function launchFullScreen(element) {
            if (element.requestFullScreen) {
                element.requestFullScreen();
            } else if (element.mozRequestFullScreen) {
                element.mozRequestFullScreen();
            } else if (element.webkitRequestFullScreen) {
                element.webkitRequestFullScreen();
            }
        }

        function callOtherWP(link, locationend = '') {
            showAnimated();
            var xhr = new XMLHttpRequest();
            xhr.open('GET', link, true);
            xhr.onload = function() {
                if (this.status == 200) {
                    let data = JSON.parse(xhr.responseText);
                    if (data.response == 'success') {
                        hideAnimated();
                        swal.fire({
                            title: 'Terima Kasih',
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            if (locationend == '') {
                                callBlank('/rmatr/ctk/'+data.idEx);
                                // location.reload();
                            }
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: 'Tidak Dapat Melanjutkan Proses',
                            text: data.message,
                            icon: data.response
                        });
                    }
                } else {
                    hideAnimated();
                    let data = JSON.parse(xhr.responseText);
                    swal.fire({
                        title: 'Tidak Dapat Melanjutkan Proses',
                        // text : 'Request failed.  Returned status of ' + xhr.status,
                        text: data.message,
                        icon: data.response
                    });
                }
            }
            xhr.send();
        }
    </script>
    <!-- /.center -->
    <!-- jquery -->
    <script src="/vendors/script/jquery/3.6.0/jquery.min.js"></script>


    <script src="/vendors/include/animation.js"></script>

    <!-- popper -->
    <script src="/vendors/script/popper/2.4.4/umd/popper.min.js"></script>
    <!-- bootstrap -->
    <script src="/vendors/script/bootstrap/4.3.1/dist/js/bootstrap.min.js"></script>
    <!-- bootstrap -->
    <script src="/vendors/script/bootstrap/4.1.3/bootstrap.bundle.min.js"></script>
    <!-- sweetAlert -->
<script src="/vendors/script/sweetalert2/sweetalert.min.js"></script>
</body>

</html>