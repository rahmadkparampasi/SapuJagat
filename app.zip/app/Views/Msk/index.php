<!DOCTYPE html>
<html lang="en">

<head>

    <!-- meta & tittle -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>RSUD Kolonodale | <?= $WebTitle; ?></title>
    <meta name="title" content="<?= $WebTitle; ?>">
    <meta name="description" content="<?= $PageTitle; ?>">
    <link rel="icon" href="/favicon.png" type="image/png">

    <!-- link style & javascript -->

    <!-- Bootstrap 4.1.3 -->
    <link rel="stylesheet" href="/vendors/script/bootstrap/4.3.1/dist/css/bootstrap.min.css" media="all">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="/vendors/script/fontawesome-free/css/all.min.css">

    <!-- iCheck -->
    <link rel="stylesheet" href="/vendors/script/icheck-bootstrap/icheck-bootstrap.min.css">

    <!-- Theme style -->
    <link rel="stylesheet" href="/vendors/include/adminlte.min.css">

    <!-- animate -->
    <link rel="stylesheet" href="/vendors/script/animate/animate.min.css" media="all">

    <!-- loading -->
    <link rel="stylesheet" href="/vendors/include/loading.css" media="all">

    <!-- jquery -->
    <script src="/vendors/script/jquery/3.3.1/jquery.min.js"></script>

    <!-- Jquery -->
    <!-- <script src="/vendors/include/jquery-3.4.1.js"></script>
    <script src="/vendors/include/jquery-3.1.1.min.js"></script> -->
</head>

<body class="hold-transition login-page">
    <div id="selfLoading" class="hide">
        <div class="imagePos">
            <div class="row">
                <div class="col-lg-12" style="text-align: center;">
                    <img style="width: 18rem;" src="/favicon.png" alt="" style="margin-left: auto; margin-right: auto;"
                        class="imageTemp">
                </div>
                <div class="col-lg-12">
                    <p style="color: #fff; font-size: 40px; text-align: center;"><strong>LOADING</strong></p>
                </div>
            </div>
        </div>

    </div>
    <div class="login-box">
        <div class="login-logo">
            <img src="/favicon.png" alt="" srcset="" width="150">
            <a href="./">
                <p>
                    <h4>RUMAH SAKIT UMUM DAERAH</h4>
                </p>
                <p>
                    <h3>KOLONODALE</h3>
                </p>
            </a>

        </div>
        <!-- /.login-logo -->
        <div class="card">
            <div class="card-body login-card-body">
                <p class="login-box-msg">SILAHKAN MASUK UNTUK MEMULAI</p>

                <form class="contactForm" role="form" action="/<?= $BasePage; ?>/<?= $MethodForm; ?>" method="POST"
                    id="<?= $IdForm ?>">
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" name="username" id="username" placeholder="NIK / NIP">
                        <div class="input-group-append">
                            <div class="input-group-text">
                                <span class="fas fa-id-card"></span>
                            </div>
                        </div>
                    </div>
                    <div class="input-group mb-3">
                        <input type="password" class="form-control" name="password" id="password"
                            placeholder="Kata Sandi">
                        <div class="input-group-append">
                            <div class="input-group-text">
                                <span class="fas fa-lock"></span>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <!-- /.col -->
                        <div class="col-12">
                            <button type="submit" class="btn btn-primary btn-block">MASUK</button>
                        </div>
                        <div class="col-12">
                            <a href="/mkTable">CEK DATABASE</a>
                        </div>
                        <!-- /.col -->
                    </div>
                </form>


            </div>
            <!-- /.login-card-body -->
        </div>
    </div>
    <!-- /.login-box -->

</body>
<!-- jquery -->
<script src="/vendors/script/jquery/3.6.0/jquery.min.js"></script>


<script src="/vendors/include/animation.js"></script>

<!-- popper -->
<script src="/vendors/script/popper/2.4.4/umd/popper.min.js"></script>
<!-- bootstrap -->
<script src="/vendors/script/bootstrap/4.3.1/dist/js/bootstrap.min.js"></script>
<!-- bootstrap -->
<script src="/vendors/script/bootstrap/4.1.3/bootstrap.bundle.min.js"></script>
<!-- fontawesome -->
<!-- <script src="/vendors/script/fontawesome/js/all.min.js"></script> -->
<!-- sweetAlert -->
<script src="/vendors/script/sweetalert2/sweetalert.min.js"></script>

<!-- Theme -->
<script src="/vendors/include/adminlte.js"></script>

</html>