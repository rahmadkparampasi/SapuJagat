<?= $this->extend('Templates/template'); ?>

<?= $this->section('content'); ?>
<!-- /.row -->

<div class="row">
    <!-- Area Chart -->
    <div class="col-xl-12 col-lg-12">
        <?= $this->include('Rmb/addData'); ?>
        <div class="callout callout-info">
            <h5><i class="fas fa-info"></i> Catatan:</h5>
            <ol>
                <li>Tombol : <button class="btn bg-gradient-success"><i class="fa fa-check"></i></button> Mengartikan
                    Bahwa Jenis Mutu Aktif, Untuk Menonaktifkan Tekan Tombol Tersebut</li>
                <br>
                <li>Tombol : <button class="btn bg-gradient-danger"><i class="fa fa-ban"></i></button> Mengartikan Bahwa
                    Jenis Mutu Tidak Aktif, Untuk Mengaktifkan Tekan Tombol Tersebut</li>
            </ol>
        </div>
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Daftar <?= $PageTitle ?></h3>
                <div class="card-tools">
                    <?php
                    if ($MethodForm1 != "updateData") {
                    ?>
                    <button class='btn bg-gradient-success' role="button" aria-pressed="true" style="float: right;"
                        onclick="showForm('<?= $IdForm ?>card')"><i class="fas fa-plus"></i>
                        TAMBAH</button>
                    <?php
                    }
                    ?>
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table id="datatableKirana" class="dtK table responsive table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Nama Generik</th>
                            <th>Kategori</th>
                            <th>Satuan</th>
                            <th>Merek</th>
                            <th>Penyedia</th>
                            <th>Harga</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 0;
                        foreach ($Rmb as $tk) : $no++ ?>
                        <tr>
                            <td><?= $no ?></td>
                            <td><?= $tk['rs_rmb_nm'] ?></td>
                            <td class="text-wrap"><?= $tk['rs_rmgz_nm'] ?></td>
                            <td><?= $tk['rs_rmjk_nm'] ?></td>
                            <td><?= $tk['rs_rmst_nm'] ?></td>
                            <td><?= $tk['rs_rmmrk_nm'] ?></td>
                            <td><?= $tk['rs_rmpyd_nm'] ?></td>
                            <td>
                                <button class="btn bg-gradient-info" title="Harga Barang" data-target="#modalAddHrg"
                                    data-toggle="modal"
                                    onclick="addFill('rs_rmb_id_ex1', '<?= $tk['rs_rmb_id_ex'] ?>'); addFill('rs_rmb_nmHrg', '<?= $tk['rs_rmb_nm'] ?>'); addFill('rs_rmb_hb', '<?= $tk['rs_rmb_hb'] ?>'); addFill('rs_rmb_hj', '<?= $tk['rs_rmb_hj'] ?>'); addFill('rs_rmb_ppn', '<?= $tk['rs_rmb_ppn'] ?>'); addFill('rs_rmb_mb', '<?= $tk['rs_rmb_mb'] ?>');">
                                    <i class='fas fa-money-bill-wave'></i>
                                </button>
                            </td>
                            <td>
                                <?php
                                    if ($tk['rs_rmb_sts'] == "1") {
                                    ?>
                                <button class="btn bg-gradient-success" title="Data Obat Aktif"
                                    onclick="callOther('Menonaktifkan <?= $tk['rs_rmb_nm'] ?> Dalam Data Data Obat', '<?= $BasePage ?>/block/<?= $tk['rs_rmb_id_ex'] ?>')">
                                    <i class='fas fa-check'></i>
                                </button>
                                <?php
                                    } else {
                                    ?>
                                <button class="btn bg-gradient-danger" title="Data Obat Tidak Aktif"
                                    onclick="callOther('Mengaktifkan <?= $tk['rs_rmb_nm'] ?> Dalam Data Data Obat', '<?= $BasePage ?>/unblock/<?= $tk['rs_rmb_id_ex'] ?>')">
                                    <i class='fas fa-ban'></i>
                                </button>
                                <?php
                                    }
                                    ?>
                            </td>
                            <td>
                                <button class="btn bg-gradient-warning m-1" title="Ubah Data Obat"
                                    onclick="callHref('<?= $BasePage ?>/editData/<?= $tk['rs_rmb_id_ex'] ?>')">
                                    <i class='fas fa-pen'></i>
                                </button>

                                <button class="btn bg-gradient-danger m-1" title="Hapus Data Obat"
                                    onclick="callOther('Menghapus <?= $tk['rs_rmb_nm'] ?> Dalam Data Obat', '<?= $BasePage ?>/deleteData/<?= $tk['rs_rmb_id_ex'] ?>')">
                                    <i class='fas fa-trash'></i>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach ?>
                    </tbody>
                </table>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
</div>
<?= $this->include('Rmb/modalAddHrg'); ?>

<?= $this->endSection(); ?>