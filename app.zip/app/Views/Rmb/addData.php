<div class="card card-primary" style="
    <?php
    if ($MethodForm1 == "updateData") {
        echo 'display: flex;';
    } else {
        echo 'display: none;';
    } ?>" id="<?= $IdForm ?>card">
    <div class="card-header">
        <h3 class="card-title">Form Tambah <?= $PageTitle ?></h3>
    </div>
    <!-- /.card-header -->
    <!-- form start -->
    <form method="POST" class="form-valide" action="/<?= $BasePage ?>/<?= $MethodForm ?>" id="<?= $IdForm ?>"
        enctype="multipart/form-data">
        <?php
        if ($MethodForm1 == "updateData") {
            echo "<input type='hidden' name='rs_rmb_id_ex' id='rs_rmb_id_ex'>";
        }
        ?>
        <div class="card-body">
            <div class="form-group">
                <label for="rs_rmb_nm">Nama</label>
                <input type="text" class="form-control" id="rs_rmb_nm" name="rs_rmb_nm" required>
            </div>
            <div class="form-group">
                <label for="rs_rmb_stk">Stok</label>
                <input type="number" class="form-control" id="rs_rmb_stk" name="rs_rmb_stk" required>
            </div>
            <div class="form-group">
                <label for="rs_rmb_rmgz">Nama Generik</label>
                <select name="rs_rmb_rmgz" id="rs_rmb_rmgz" class="form-control">
                    <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
                    <?php foreach ($Rmgz as $tk) : ?>
                    <option value="<?= $tk['rs_rmgz_id_ex'] ?>"><?= $tk['rs_rmgz_nm'] ?></option>
                    <?php endforeach ?>
                </select>
            </div>
            <div class="form-group">
                <label for="rs_rmb_rmmrk">Merek</label>
                <select name="rs_rmb_rmmrk" id="rs_rmb_rmmrk" class="form-control">
                    <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
                    <?php foreach ($Rmmrk as $tk) : ?>
                    <option value="<?= $tk['rs_rmmrk_id_ex'] ?>"><?= $tk['rs_rmmrk_nm'] ?></option>
                    <?php endforeach ?>
                </select>
            </div>
            <div class="form-group">
                <label for="rs_rmb_rmji">Jenis Inventaris</label>
                <select name="rs_rmb_rmji" id="rs_rmb_rmji" class="form-control"
                    onfocus="ambilDataSelect('rs_rmb_rmji', '/rmji/getAllForSelect/', 'Pilih Salah Satu Pilihan', toRemove=[], removeMessage=[], '')"
                    onchange="ambilDataSelect('rs_rmb_rmkb', '/rmkb/getAllForSelect/', 'Pilih Salah Satu Pilihan', toRemove=['rs_rmb_rmkb', 'rs_rmb_rmjk'], removeMessage=['Pilih Salah Satu Pilihan', 'Pilih Salah Satu Pilihan'], 'rs_rmb_rmji')">

                    <option hidden value="0">PILIH SALAH SATU PILIHAN</option>

                </select>
            </div>
            <div class="form-group">
                <label for="rs_rmb_rmkb">Jenis Kategori Barang</label>
                <select name="rs_rmb_rmkb" id="rs_rmb_rmkb" class="form-control"
                    onchange="ambilDataSelect('rs_rmb_rmjk', '/rmjk/getAllForSelect/', 'Pilih Salah Satu Pilihan', toRemove=['rs_rmb_rmjk'], removeMessage=['Pilih Salah Satu Pilihan'], 'rs_rmb_rmkb')">
                    <option hidden value="0">PILIH SALAH SATU PILIHAN</option>

                </select>
            </div>
            <div class="form-group">
                <label for="rs_rmb_rmjk">Kategori Barang</label>
                <select name="rs_rmb_rmjk" id="rs_rmb_rmjk" class="form-control">
                    <option hidden value="0">PILIH SALAH SATU PILIHAN</option>

                </select>
            </div>
            <div class="form-group">
                <label for="rs_rmb_po">Jenis Penggunaan Obat</label>
                <select name="rs_rmb_po" id="rs_rmb_po" class="form-control">
                    <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
                    <option value="OD">Obat Dalam</option>
                    <option value="OL">Obat Luar</option>
                </select>
            </div>
            <div class="form-group">
                <label for="rs_rmb_rmst">Satuan</label>
                <select name="rs_rmb_rmst" id="rs_rmb_rmst" class="form-control">
                    <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
                    <?php foreach ($Rmst as $tk) : ?>
                    <option value="<?= $tk['rs_rmst_id_ex'] ?>"><?= $tk['rs_rmst_nm'] ?></option>
                    <?php endforeach ?>
                </select>
            </div>
            <div class="form-group">
                <label for="rs_rmb_rmpyd">Penyedia Barang</label>
                <select name="rs_rmb_rmpyd" id="rs_rmb_rmpyd" class="form-control">
                    <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
                    <?php foreach ($Rmpyd as $tk) : ?>
                    <option value="<?= $tk['rs_rmpyd_id_ex'] ?>"><?= $tk['rs_rmpyd_nm'] ?></option>
                    <?php endforeach ?>
                </select>
            </div>
            <div class="form-group">
                <label for="rs_rmb_jg">Jenis Generik</label>
                <select name="rs_rmb_jg" id="rs_rmb_jg" class="form-control">
                    <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
                    <option value="G">Generik</option>
                    <option value="NG">Non Generik</option>
                </select>
            </div>
            <div class="form-group">
                <label for="rs_rmb_for">Formularium</label>
                <select name="rs_rmb_for" id="rs_rmb_for" class="form-control">
                    <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
                    <option value="F">Formularium</option>
                    <option value="NF">Non Formularium</option>
                </select>
            </div>
            <div class="form-group">
                <label for="rs_rmb_kt">Formularium</label>
                <select name="rs_rmb_kt" id="rs_rmb_kt" class="form-control">
                    <option value="0">BUKAN</option>
                    <option value="1">KLAIM TERPISAH</option>
                </select>
            </div>
        </div>

        <!-- /.card-body -->

        <div class="card-footer">
            <button type="submit" class="btn bg-gradient-primary"><?= $ButtonMethod ?></button>
            <?php
            $MethodForm = substr($MethodForm, 0, 10);
            if ($MethodForm == "updateData") {
            ?>
            <a href="/<?= $BasePage ?>" class='btn bg-gradient-danger' aria-pressed="true">BATAL</a>
            <?php
            } else {
            ?>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('<?= $IdForm ?>card', '<?= $IdForm ?>')">BATAL</button>

            <?php
            }
            ?>
        </div>
    </form>
</div>