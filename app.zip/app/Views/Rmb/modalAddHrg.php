<div class="modal fade" id="modalAddHrg" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form id="addHrg" method="POST" action="/rmb/updateDataHrg" enctype="multipart/form-data">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="">UBAH HARGA</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="rs_rmb_nmHrg">NAMA BARANG</label>
                        <input type="hidden" class="form-control" id="rs_rmb_id_ex1" name="rs_rmb_id_ex1" required>
                        <input type="text" class="form-control" id="rs_rmb_nmHrg" name="rs_rmb_nmHrg" required disabled>
                    </div>
                    <div class="form-group">
                        <label for="rs_rmb_hb">HARGA BELI</label>
                        <input type="number" class="form-control" id="rs_rmb_hb" name="rs_rmb_hb" step=".01" required>
                    </div>
                    <div class="form-group">
                        <label for="rs_rmb_hj">HARGA JUAL</label>
                        <input type="number" class="form-control" id="rs_rmb_hj" name="rs_rmb_hj" step=".01" required>
                    </div>
                    <div class="form-group">
                        <label for="rs_rmb_ppn">PPN</label>
                        <input type="number" class="form-control" id="rs_rmb_ppn" name="rs_rmb_ppn" step=".01" required>
                    </div>
                    <div class="form-group">
                        <label for="rs_rmb_mb">MASA BERLAKU</label>
                        <input type="date" class="form-control" id="rs_rmb_mb" name="rs_rmb_mb">
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="item form-group">
                        <button type="submit" class="btn btn-success">SIMPAN</button>
                        <button type="button" class="btn btn-primary" data-dismiss="modal">BATAL</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
$(function() {
    $(document).ready(function() {
        var addHrg = $('#addHrg');
        addHrg.submit(function(e) {
            showAnimated();
            //$('#addChildRmr :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');
            e.stopPropagation();
            e.preventDefault();
            $.ajax({
                type: addHrg.attr('method'),
                url: addHrg.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            window.location = '/<?= $UrlForm ?>';
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>