<?= $this->extend('Templates/template'); ?>

<?= $this->section('content'); ?>
<!-- /.row -->

<div class="row">
    <!-- Area Chart -->
    <div class="col-xl-12 col-lg-12">
        <?= $this->include('Loren/addData'); ?>
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Daftar <?= $PageTitle ?></h3>
                <div class="card-tools">
                    <?php
                    if ($MethodForm1 != "updateData") {
                    ?>
                    <button class='btn bg-gradient-success' role="button" aria-pressed="true" style="float: right;"
                        onclick="showForm('<?= $IdForm ?>card')"><i class="fas fa-plus"></i>
                        TAMBAH</button>
                    <?php
                    }
                    ?>
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table id="datatableKirana" class="dtK table responsive table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Kode Rencana</th>
                            <th>Tanggal Perencanaan</th>
                            <th>Tahun</th>
                            <th>Total</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 0;
                        foreach ($Loren as $tk) : $no++ ?>
                        <tr>
                            <td><?= $no ?></td>
                            <td><?= $tk['rs_loren_kd'] ?></td>
                            <td><?= $tk['rs_loren_tgl'] ?></td>
                            <td><?= $tk['rs_loren_thn'] ?></td>
                            <td><?= $tk['ttl'] ?></td>
                            <td>
                                <?php
                                    if ($tk['rs_loren_fix']=="0") {
                                ?>
                                <button class="btn bg-gradient-info" title="Selesaikan Rencana Kebutuhan Barang"
                                    onclick="callHref('/lorenD/viewDataSls/<?= $tk['rs_loren_id_ex'] ?>')">
                                    <i class='fas fa-thumbs-up'></i> SELESAIKAN
                                </button>
                                <?php
                                    }else{
                                ?>
                                    <?= $tk['rs_loren_fix'] ?>
                                <?php
                                    }
                                ?>
                            </td>
                            <td>
                                
                                <a href="/lorend/viewData/<?= $tk['rs_loren_id_ex'] ?>" class="btn bg-gradient-primary" title="Detail Rencana Kebutuhan Barang"><i class='fas fa-list'></i></a>
                                <?php
                                    if ($tk['rs_loren_fix']=="0") {
                                ?>
                                <button class="btn bg-gradient-warning" title="Ubah Rencana Kebutuhan Barang"
                                    onclick="callHref('<?= $BasePage ?>/editData/<?= $tk['rs_loren_id_ex'] ?>')">
                                    <i class='fas fa-pen'></i>
                                </button>

                                <button class="btn bg-gradient-danger" title="Hapus Rencana Kebutuhan Barang"
                                    onclick="callOther('Menghapus <?= $tk['rs_loren_kd'] ?> Dalam Rencana Kebutuhan Barang', '<?= $BasePage ?>/deleteData/<?= $tk['rs_loren_id_ex'] ?>')">
                                    <i class='fas fa-trash'></i>
                                </button>
                                <?php
                                    }
                                ?>
                                
                            </td>
                        </tr>
                        <?php endforeach ?>
                    </tbody>
                    
                </table>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
</div>


<?= $this->endSection(); ?>