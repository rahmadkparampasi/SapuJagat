<div class="card card-primary" style="
    <?php
    if ($MethodForm1 == "updateData") {
        echo 'display: flex;';
    } else {
        echo 'display: none;';
    } ?>" id="<?= $IdForm ?>card">
    <div class="card-header">
        <h3 class="card-title">Form Tambah <?= $PageTitle ?></h3>
    </div>
    <!-- /.card-header -->
    <!-- form start -->
    <form method="POST" class="form-valide" action="/<?= $BasePage ?>/<?= $MethodForm ?>" id="<?= $IdForm ?>"
        enctype="multipart/form-data">
        <?php
        if ($MethodForm1 == "updateData") {
            echo "<input type='hidden' name='rs_loren_id_ex' id='rs_loren_id_ex'>";
        }
        ?>
        <div class="card-body">
            <div class="form-group">
                <label for="rs_loren_tgl">Tanggal Perencanaan</label>
                <input type="date" class="form-control" id="rs_loren_tgl" name="rs_loren_tgl" required>
            </div>

            <div class="form-group">
                <label for="rs_loren_thn">Tahun Perencanaan</label>
                <input type="number" class="form-control" id="rs_loren_thn" name="rs_loren_thn" required oninput="getKode()">
            </div>

            <?php
            $MethodForm = substr($MethodForm, 0, 10);
            if ($MethodForm == "updateData") {
            ?>
                <input type="hidden" class="form-control" id="rs_loren_thn_old" name="rs_loren_thn_old" required>
            <?php
            }
            ?>

            <div class="form-group">
                <label for="rs_loren_kd">Kode Perencanaan</label>
                <input type="text" class="form-control" id="rs_loren_kd" name="rs_loren_kd" required disabled>
                <input type="hidden" class="form-control" id="rs_loren_kd_old" name="rs_loren_kd_old" required>
            </div>
        </div>
        
        <!-- /.card-body -->

        <div class="card-footer">
            <button type="submit" class="btn bg-gradient-primary"><?= $ButtonMethod ?></button>
            <?php
            $MethodForm = substr($MethodForm, 0, 10);
            if ($MethodForm == "updateData") {
            ?>
            <a href="/<?= $BasePage ?>" class='btn bg-gradient-danger' aria-pressed="true">BATAL</a>
            <?php
            } else {
            ?>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('<?= $IdForm ?>card', '<?= $IdForm ?>')">BATAL</button>

            <?php
            }
            ?>
        </div>
    </form>
</div>
<script>
    function getKode() {
        <?php
        $MethodForm = substr($MethodForm, 0, 10);
        if ($MethodForm != "updateData") {
        ?>
            ambilDataText('rs_loren_kd', '/loren/getKd/', ['rs_loren_kd'], 'rs_loren_thn');
        
        <?php
        } else {
        ?>
        var rs_loren_thn = document.getElementById('rs_loren_thn').value;
        var rs_loren_thn_old = document.getElementById('rs_loren_thn_old').value;

        if (rs_loren_thn!=rs_loren_thn_old) {
            ambilDataText('rs_loren_kd', '/loren/getKd/', ['rs_loren_kd'], 'rs_loren_thn');
        }else{
            document.getElementById('rs_loren_kd').value = document.getElementById('rs_loren_kd_old').value;
        }
        
        <?php
        }
        ?>
        
    }
</script>