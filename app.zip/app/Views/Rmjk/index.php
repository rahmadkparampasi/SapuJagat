<div class="card">
    <div class="card-header">
        <h3 class="card-title">Daftar Jenis Kategori <?= $Rmkb['rs_rmkb_nm'] ?></h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
        <table id="datatableKirana<?= $IdForm ?>" class="table responsive table-bordered table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Deskripsi</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 0;
                foreach ($Rmjk as $tk) : $no++ ?>
                <tr>
                    <td><?= $no ?></td>
                    <td><?= $tk['rs_rmjk_nm'] ?></td>
                    <td>
                        <?php
                            if ($tk['rs_rmjk_sts'] == "1") {
                            ?>
                        <button class="btn bg-gradient-success" title="Jenis Kategori Aktif"
                            onclick="addWF('Menonaktifkan <?= $tk['rs_rmjk_nm'] ?> Dalam Data Jenis Kategori', '<?= $BasePage ?>/block/<?= $tk['rs_rmjk_id_ex'] ?>', loadTabRmjk, '<?= $rs_rmjk_rmkb ?>')">
                            <i class='fas fa-check'></i>
                        </button>
                        <?php
                            } else {
                            ?>
                        <button class="btn bg-gradient-danger" title="Jenis Kategori Tidak Aktif"
                            onclick="addWF('Mengaktifkan <?= $tk['rs_rmjk_nm'] ?> Dalam Data Jenis Kategori', '<?= $BasePage ?>/unblock/<?= $tk['rs_rmjk_id_ex'] ?>', loadTabRmjk, '<?= $rs_rmjk_rmkb ?>')">
                            <i class='fas fa-ban'></i>
                        </button>
                        <?php
                            }
                            ?>
                    </td>
                </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    </div>
    <div class="card-footer">
        <button class='btn bg-gradient-info' role="button" aria-pressed="true" style="float: right;"
            data-target="#modalAddChildRmjk" data-toggle="modal"
            onclick="addFill('rs_rmjk_rmkb', '<?= $Rmkb['rs_rmkb_id_ex'] ?>')"><i class="fas fa-plus"></i>
            TAMBAH</button>

    </div>
    <!-- /.card-body -->
</div>
<!-- /.card -->

<?= $this->include('Rmjk/modalAddChild'); ?>
<script>
$(document).ready(function() {
    $('#datatableKirana<?= $IdForm ?>').DataTable({
        "order": [
            [0, "asc"]
        ],
        pageLength: 10,
        responsive: true,
        fixedHeader: true,
        keys: true,
        columnDefs: [{
                responsivePriority: 1,
                target: 0
            },
            {
                responsivePriority: 10001,
                target: 4
            },
            {
                responsivePriority: 2,
                target: -2
            }
        ]
    });
});
</script>