<div class="modal fade" id="modalSendOb" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form id="sendOb" method="POST" action="/lostob/sendObat" enctype="multipart/form-data">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="">FORM MEMASUKAN OBAT KE DEPO LAYANAN</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="rs_rmrrmb_rmbnm">NAMA OBAT</label>
                        <input type="hidden" class="form-control" id="rs_lostob_id_ex" name="rs_lostob_id_ex" required>
                        <input type="hidden" class="form-control" id="rs_rmrrmb_rmb" name="rs_rmrrmb_rmb" required>
                        <input type="text" class="form-control" id="rs_rmrrmb_rmbnm" name="rs_rmrrmb_rmbnm" required disabled>
                    </div>
                    <div class="form-group">
                        <label for="rs_lostob_j">JUMLAH OBAT YANG TERSEDIA</label>
                        <input type="hidden" class="form-control" id="rs_lostob_j" name="rs_lostob_j" required>
                        <input type="number" class="form-control" id="rs_lostob_j_n" name="rs_lostob_j_n" required disabled>
                    </div>
                    <div class="form-group">
                        <label for="rs_rmrrmb_j">JUMLAH OBAT YANG DIPINDAHKAN</label>
                        <input type="number" class="form-control" id="rs_rmrrmb_j" name="rs_rmrrmb_j" required>
                    </div>
                    
                    <div class="form-group row">
                        <label for="rs_rmrrmb_rmr">Tujuan Depo Layanan</label>
                        <select name="rs_rmrrmb_rmr" id="rs_rmrrmb_rmr" class="form-control"
                            onfocus="ambilDataSelect('rs_rmrrmb_rmr', '/rmr/getAllForSelectByPrt/<?= $setRmr['setRmrApt'] ?>', 'Pilih Salah Satu Depo Layanan', toRemove=[], removeMessage=[], '')">
                            <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
                        </select>
                        
                    </div>
                    
                </div>
                <div class="modal-footer">
                    <div class="item form-group">
                        <button type="submit" class="btn btn-success">SIMPAN</button>
                        <button type="button" class="btn btn-primary" data-dismiss="modal">BATAL</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
$(function() {
    $(document).ready(function() {
        var sendOb = $('#sendOb');
        sendOb.submit(function(e) {
            showAnimated();
            //$('#addChildRmr :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');
            e.stopPropagation();
            e.preventDefault();
            $.ajax({
                type: sendOb.attr('method'),
                url: sendOb.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            window.location = '/<?= $UrlForm ?>';
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>