<?= $this->extend('Templates/template'); ?>

<?= $this->section('content'); ?>
<!-- /.row -->

<div class="row">
    <!-- Area Chart -->
    <div class="col-xl-12 col-lg-12">
        
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Daftar <?= $PageTitle ?></h3>
                
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table id="datatableKirana" class="dtK table responsive table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Kode Rencana</th>
                            <th>Tanggal Perencanaan</th>
                            <th>Tahun</th>
                            <th>Total Obat</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 0;
                        foreach ($Loren as $tk) : $no++ ?>
                        <tr>
                            <td><?= $no ?></td>
                            <td><?= $tk['rs_loren_kd'] ?></td>
                            <td><?= $tk['rs_loren_tgl'] ?></td>
                            <td><?= $tk['rs_loren_thn'] ?></td>
                            <td><?= $tk['ttlObat'] ?></td>
                            <td><?= $tk['stsObat'] ?></td>
                            <td>
                                
                                <a href="/lostob/viewDataD/<?= $tk['rs_loren_id_ex'] ?>" class="btn bg-gradient-primary" title="Stok Produk Detail"><i class='fas fa-list'></i></a>
                                
                                
                            </td>
                        </tr>
                        <?php endforeach ?>
                    </tbody>
                    
                </table>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
</div>


<?= $this->endSection(); ?>