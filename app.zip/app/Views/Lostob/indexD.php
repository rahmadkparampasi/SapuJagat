<?= $this->extend('Templates/template'); ?>

<?= $this->section('content'); ?>
<!-- /.row -->

<div class="row">
    <!-- Area Chart -->
    <div class="col-xl-12 col-lg-12">
        
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Daftar <?= $PageTitle ?></h3>
                <div class="card-tools">
                    <a href="/lostob" class='btn bg-gradient-danger mx-1' role="button" aria-pressed="true" style="float: right;"><i class="fas fa-reply"></i> KEMBALI</a>
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table id="datatableKirana" class="dtK table responsive table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Nama Generik</th>
                            <th>Kategori</th>
                            <th>Merek</th>
                            <th>Penyedia</th>
                            <th>Jumlah Stok</th>
                            <th>Satuan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 0;
                        foreach ($Lostob as $tk) : $no++ ?>
                        <tr>
                        <td><?= $no ?></td>
                            <td><?= $tk['rs_rmb_nm'] ?></td>
                            <td class="text-wrap"><?= $tk['rs_rmgz_nm'] ?></td>
                            <td><?= $tk['rs_rmjk_nm'] ?></td>
                            <td><?= $tk['rs_rmmrk_nm'] ?></td>
                            <td><?= $tk['rs_rmpyd_nm'] ?></td>
                            <td><?= $tk['rs_lostob_j'] ?></td>
                            <td><?= $tk['rs_rmst_nm'] ?></td>
                            <td>
                                <?php
                                    if ((int)$tk['rs_lostob_j'] != 0) {
                                ?>
                                <button class="btn bg-gradient-primary" title="Masukan Obat Ke Apotik" data-toggle="modal" data-target="#modalSendOb" onclick="addFill('rs_rmrrmb_rmb', '<?= $tk['rs_rmb_id_ex'] ?>'); addFill('rs_rmrrmb_rmbnm', '<?= $tk['rs_rmb_nm'] ?>'); addFill('rs_lostob_id_ex', '<?= $tk['rs_lostob_id_ex'] ?>'); addFill('rs_lostob_j', '<?= $tk['rs_lostob_j'] ?>'); addFill('rs_lostob_j_n', '<?= $tk['rs_lostob_j'] ?>');">
                                    <i class="fa fa-share-square"></i> MASUKAN KE DEPO LAYANAN
                                </button>
                                <?php
                                    }
                                ?>
                            </td>
                        </tr>
                        <?php endforeach ?>
                    </tbody>
                    
                </table>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
</div>
<?= $this->include('Lostob/modalSendOb'); ?>


<?= $this->endSection(); ?>