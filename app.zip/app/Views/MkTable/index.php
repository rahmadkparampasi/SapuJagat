<!DOCTYPE html>
<html lang="en">

<head>

    <!-- meta & tittle -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>RSUD Kolonodale | <?= $WebTitle; ?></title>
    <meta name="title" content="<?= $WebTitle; ?>">
    <meta name="description" content="<?= $PageTitle; ?>">
    <link rel="icon" href="/favicon.png" type="image/png">

    <!-- link style & javascript -->

    <!-- Bootstrap 4.1.3 -->
    <link rel="stylesheet" href="/vendors/script/bootstrap/4.3.1/dist/css/bootstrap.min.css" media="all">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="/vendors/script/fontawesome-free/css/all.min.css">

    <!-- Tempusdominus Bbootstrap 4 -->
    <link rel="stylesheet" href="/vendors/script/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">

    <!-- iCheck -->
    <link rel="stylesheet" href="/vendors/script/icheck-bootstrap/icheck-bootstrap.min.css">

    <!-- select2 -->
    <link rel="stylesheet" href="/vendors/script/select2/4.1.0/select2.min.css">

    <!-- Theme style -->
    <link rel="stylesheet" href="/vendors/include/adminlte.min.css">

    <!-- OverlayScrollbars-master -->
    <link rel="stylesheet" href="/vendors/script/OverlayScrollbars-master/css/OverlayScrollbars.min.css">

    <!-- blueimp -->
    <link rel="stylesheet" href="/vendors/script/blueimp/3.3.0/css/blueimp-gallery.min.css" media="all">

    <!-- jasny -->
    <link rel="stylesheet" href="/vendors/script/jasny/jasny-bootstrap.min.css" media="all">

    <!-- animate -->
    <link rel="stylesheet" href="/vendors/script/animate/animate.min.css" media="all">

    <!-- summernote -->
    <link rel="stylesheet" href="/vendors/script/summernote/summernote-bs4.min.css">

    <!-- DataTables -->
    <link rel="stylesheet" href="/vendors/script/DataTables/datatables.min.css">
    <link rel="stylesheet" href="/vendors/script/DataTables/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="/vendors/script/DataTables/AutoFill-2.3.5/css/autoFill.bootstrap4.min.css">
    <link rel="stylesheet" href="/vendors/script/DataTables/Buttons-1.6.3/css/buttons.bootstrap4.min.css">
    <link rel="stylesheet" href="/vendors/script/DataTables/ColReorder-1.5.2/css/colReorder.bootstrap4.min.css">
    <link rel="stylesheet" href="/vendors/script/DataTables/DataTables-1.10.21/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="/vendors/script/DataTables/FixedColumns-3.3.1/css/fixedColumns.bootstrap4.min.css">
    <link rel="stylesheet" href="/vendors/script/DataTables/FixedHeader-3.1.7/css/fixedHeader.bootstrap4.min.css">
    <link rel="stylesheet" href="/vendors/script/DataTables/KeyTable-2.5.2/css/keyTable.bootstrap4.min.css">
    <link rel="stylesheet" href="/vendors/script/DataTables/Responsive-2.2.5/css/responsive.bootstrap4.min.css">
    <link rel="stylesheet" href="/vendors/script/DataTables/RowGroup-1.1.2/css/rowGroup.bootstrap4.min.css">
    <link rel="stylesheet" href="/vendors/script/DataTables/RowReorder-1.2.7/css/rowReorder.bootstrap4.min.css">
    <link rel="stylesheet" href="/vendors/script/DataTables/Scroller-2.0.2/css/scroller.bootstrap4.min.css">
    <link rel="stylesheet" href="/vendors/script/DataTables/SearchPanes-1.1.1/css/searchPanes.bootstrap4.min.css">

    <!-- awesome-bootstrap-checkbox-master -->
    <link rel="stylesheet" href="/vendors/script/awesome-bootstrap-checkbox-master/awesome-bootstrap-checkbox.css" media="all">

    <!-- jquery-ui -->
    <link rel="stylesheet" href="/vendors/script/jquery-ui/1.12.1/jquery-ui.min.css" media="all">

    <!-- Chart.js -->
    <link rel="stylesheet" href="/vendors/script/Chart.js/2.9.3/Chart.min.css" media="all">

    <!-- pdfjs-2.6.347-dist -->
    <script src="/vendors/script/pdfjs-2.6.347-dist/build/pdf.js"></script>
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.0.943/pdf.min.js"></script> -->

    <!-- loading -->
    <link rel="stylesheet" href="/vendors/include/loading.css" media="all">

    <!-- jquery -->
    <script src="/vendors/script/jquery/3.3.1/jquery.min.js"></script>

    <!-- Jquery -->
    <!-- <script src="/vendors/include/jquery-3.4.1.js"></script>
    <script src="/vendors/include/jquery-3.1.1.min.js"></script> -->
</head>

<body class="hold-transition login-page">
    <div id="selfLoading" class="hide">
        <div class="imagePos">
            <div class="row">
                <div class="col-lg-12" style="text-align: center;">
                    <img style="width: 18rem;" src="/favicon.png" alt="" style="margin-left: auto; margin-right: auto;" class="imageTemp">
                </div>
                <div class="col-lg-12">
                    <p style="color: #fff; font-size: 40px; text-align: center;"><strong>LOADING</strong></p>
                </div>
            </div>
        </div>

    </div>
    <div class="login-box">
        <div class="login-logo">
            <img src="/favicon.png" alt="" srcset="" width="150">
            <a href="./">
                <p>
                    <h4>RUMAH SAKIT UMUM DAERAH</h4>
                </p>
                <p>
                    <h3>KOLONODALE</h3>
                </p>
            </a>

        </div>
        <!-- /.login-logo -->
        <div class="card">
            <div class="card-body login-card-body">
                <p class="login-box-msg">SILAHKAN UPDATE DATABASE UNTUK MEMULAI</p>

                <form method="POST" class="form-valide" action="/<?= $BasePage ?>/<?= $MethodForm ?>" id="<?= $IdForm ?>" enctype="multipart/form-data">

                    <div class="input-group mb-3">
                        <input type="file" class="form-control" name="file" id="file" required accept=".sql" placeholder="Pilih Database">
                        <div class="input-group-append">
                            <div class="input-group-text">
                                <span class="fas fa-database"></span>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <!-- /.col -->
                        <div class="col-12">
                            <button class="btn btn-primary btn-lg" type="submit"><?= $ButtonMethod ?></button>
                            <button class="btn btn-danger btn-lg" type="button" id="cekSalahBtn">Cek Kesalahan</button>
                        </div>
                        <div class="col-12">
                            <a href="/msk">KEMBALI</a>
                        </div>
                        <!-- /.col -->
                    </div>
                </form>


            </div>
            <div id="cekSalah" class="overflow-auto" style="height: 100px;"></div>
            <!-- /.login-card-body -->
        </div>
    </div>
    <!-- /.login-box -->

</body>
<script>
    $(function() {
        $(document).ready(function() {
            var cekSalahBtn = $('#cekSalahBtn');
            cekSalahBtn.click(function() {
                $.ajax({
                    type: "POST",
                    url: "/mkTable/cekDB",
                    enctype: 'multipart/form-data',
                    contentType: false,
                    processData: false,
                    dataType: 'json',
                    success: function(data) {
                        hideAnimated();
                        $('#cekSalah').html(data.message);
                    }
                });
            });
        });
    });
</script>
<!-- jquery -->
<script src="/vendors/script/jquery/3.6.0/jquery.min.js"></script>


<script src="/vendors/include/animation.js"></script>

<!-- popper -->
<script src="/vendors/script/popper/2.4.4/umd/popper.min.js"></script>
<!-- bootstrap -->
<script src="/vendors/script/bootstrap/4.3.1/dist/js/bootstrap.min.js"></script>
<!-- bootstrap -->
<script src="/vendors/script/bootstrap/4.1.3/bootstrap.bundle.min.js"></script>
<!-- fontawesome -->
<!-- <script src="/vendors/script/fontawesome/js/all.min.js"></script> -->
<!-- sweetAlert -->
<script src="/vendors/script/sweetalert2/sweetalert.min.js"></script>
<!-- select2 -->
<script src="/vendors/script/select2/4.1.0/select2.min.js"></script>

<!-- Chart.js -->
<script src="/vendors/script/Chart.js/2.9.3/Chart.min.js"></script>

<!-- moment -->
<script src="/vendors/script/moment/2.27.0/moment.js"></script>

<!-- tempusdominus-bootstrap-4 -->
<script src="/vendors/script/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>

<!-- summernote -->
<script src="/vendors/script/summernote/summernote-bs4.min.js"></script>

<!-- OverlayScrollbars-master -->
<script src="/vendors/script/OverlayScrollbars-master/js/OverlayScrollbars.min.js"></script>

<!-- slimscroll -->
<script src="/vendors/script/slimscroll/1.3.8/jquery.slimscroll.min.js"></script>

<!-- FastClick -->
<script src="/vendors/script/fastclick/fastclick.js"></script>

<!-- icheck -->
<script src="/vendors/script/icheck/1.0.2/icheck.min.js"></script>

<!-- moment -->
<script src="/vendors/script/moment/2.27.0/moment.js"></script>
<!-- DataTables -->
<script src="/vendors/script/DataTables/datatables.min.js"></script>
<script src="/vendors/script/DataTables/dataTables.bootstrap4.min.js"></script>
<script src="/vendors/script/DataTables/AutoFill-2.3.5/js/autoFill.bootstrap4.min.js"></script>
<script src="/vendors/script/DataTables/Buttons-1.6.3/js/buttons.bootstrap4.min.js"></script>
<script src="/vendors/script/DataTables/ColReorder-1.5.2/js/colReorder.bootstrap4.min.js"></script>
<script src="/vendors/script/DataTables/DataTables-1.10.21/js/dataTables.bootstrap4.min.js"></script>
<script src="/vendors/script/DataTables/FixedColumns-3.3.1/js/fixedColumns.bootstrap4.min.js"></script>
<script src="/vendors/script/DataTables/FixedHeader-3.1.7/js/fixedHeader.bootstrap4.min.js"></script>
<script src="/vendors/script/DataTables/JSZip-2.5.0/jszip.min.js"></script>
<script src="/vendors/script/DataTables/KeyTable-2.5.2/js/keyTable.bootstrap4.min.js"></script>
<script src="/vendors/script/DataTables/pdfmake-0.1.36/pdfmake.min.js"></script>
<script src="/vendors/script/DataTables/Responsive-2.2.5/js/responsive.bootstrap4.min.js"></script>
<script src="/vendors/script/DataTables/RowGroup-1.1.2/js/rowGroup.bootstrap4.min.js"></script>
<script src="/vendors/script/DataTables/RowReorder-1.2.7/js/rowReorder.bootstrap4.min.js"></script>
<script src="/vendors/script/DataTables/Scroller-2.0.2/js/scroller.bootstrap4.min.js"></script>
<script src="/vendors/script/DataTables/SearchPanes-1.1.1/js/searchPanes.bootstrap4.min.js"></script>

<!-- jquery-mousewheel -->
<script src="/vendors/script/jquery-mousewheel/jquery.mousewheel.js"></script>

<!-- raphael -->
<script src="/vendors/script/raphael/raphael.min.js"></script>

<!-- <script src="/vendors/include/time.js"></script> -->
<!-- pace -->
<script src="/vendors/script/pace/0.7.8/pace.min.js"></script>
<!-- icheck -->
<script src="/vendors/script/icheck/1.0.2/icheck.min.js"></script>
<!-- jquery-ui -->
<script src="/vendors/script/jquery-ui/1.12.1/jquery-ui.min.js"></script>


<!-- blueimp -->
<script src="/vendors/script/blueimp/3.3.0/js/jquery.blueimp-gallery.min.js"></script>
<!-- bootstrap-3-typeahead -->
<script src="/vendors/script/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.js"></script>

<!-- Theme -->
<script src="/vendors/include/adminlte.js"></script>
<!-- <script src="/vendors/include/demo.js"></script> -->
<!-- <script src="/vendors/include/pages/dashboard2.js"></script> -->

</html>