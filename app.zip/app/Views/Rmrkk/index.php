<form style="display: none;" id="<?= $IdForm ?>" class="form-valide" action="/<?= $BasePage ?>/<?= $MethodForm ?>"
    enctype="multipart/form-data" method="POST">
    <h4 class="text-center">Form <?= $PageTitle ?></h4>


    <div class="form-group">
        <label for="rs_rmrkk_rmrk">Pilih Kelas</label>
        <select name="rs_rmrkk_rmrk" id="rs_rmrkk_rmrk" class="form-control" required>
            <option hidden value="">PILIH SALAH SATU PILIHAN</option>
            <?php foreach ($Rmrk as $tk) : ?>
            <option value="<?= $tk['rs_rmrk_id_ex'] ?>"><?= $tk['rs_rmk_nm'] ?></option>
            <?php endforeach ?>
        </select>
    </div>

    <div class="form-group">
        <label for="rs_rmrkk_nm">Nama Ruangan</label>
        <input type="text" name="rs_rmrkk_nm" id="rs_rmrkk_nm" class="form-control" required>
    </div>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-primary"><?= $ButtonMethod ?></button>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('<?= $IdForm ?>', '<?= $IdForm ?>'); ">BATAL</button>
        </div>
    </div>
    <hr>
</form>

<div>
    <h4 class="text-center">Daftar <?= $PageTitle ?></h4>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-success" style="float: right;"
                onclick="showForm('<?= $IdForm ?>', 'block');"><i class="fas fa-plus"></i>
                Tambah</button>
        </div>
    </div>
    <table id="dtK<?= $IdForm ?>" class="table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Ruangan</th>
                <th>Kelas Ruangan</th>
                <th>Status Kelas Dalam Ruangan</th>
                <th>Tempat Tidur</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Rmrkk as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td>
                <td><?= $tk['rs_rmrkk_nm'] ?></td>
                <td><?= $tk['rs_rmk_nm'] ?></td>
                <td>
                    <?php
                        if ($tk['rs_rmrkk_sts'] == "1") {
                        ?>
                    <button class="btn bg-gradient-success" title="Kamar Dalam Ruangan Aktif"
                        onclick="addWF('Menonaktifkan <?= $tk['rs_rmrkk_nm'] ?> Dalam Kamar Ruangan', '/<?= $BasePage ?>/blockRmrkk/<?= $tk['rs_rmrkk_id_ex'] ?>', loadTabKmr)">
                        <i class='fas fa-check'></i>
                    </button>
                    <?php
                        } else {
                        ?>
                    <button class="btn bg-gradient-danger" title="Kamar Dalam Ruangan Tidak Aktif"
                        onclick="addWF('Mengaktifkan <?= $tk['rs_rmrkk_nm'] ?> Dalam Kamar Ruangan', '/<?= $BasePage ?>/unblockRmrkk/<?= $tk['rs_rmrkk_id_ex'] ?>', loadTabKmr)">
                        <i class='fas fa-ban'></i>
                    </button>
                    <?php
                        }
                        ?>
                </td>
                <td>


                    <?php foreach ($tk['Rmrkkt'] as $tkd) : ?>
                    <div class='col-12'>
                        <?php
                                if ($tkd['rs_rmrkkt_sts'] == "1") {
                                ?>
                        <button class='btn bg-gradient-success'
                            title="<?= $tkd['rs_rmrkkt_nm'] ?> Di <?= $tk['rs_rmrkk_nm'] ?> Aktif"
                            onclick="addWF('Menonaktifkan <?= $tkd['rs_rmrkkt_nm'] ?> Di <?= $tk['rs_rmrkk_nm'] ?>', '/rmrkkt/blockRmrkkt/<?= $tkd['rs_rmrkkt_id_ex'] ?>', loadTabKmr)"><?= $tkd['rs_rmrkkt_nm'] ?></button>
                        <?php
                                } else {
                                ?>
                        <button class='btn bg-gradient-danger'
                            title="<?= $tkd['rs_rmrkkt_nm'] ?> Di <?= $tk['rs_rmrkk_nm'] ?> Tidak Aktif"
                            onclick="addWF('Mengaktifkan <?= $tkd['rs_rmrkkt_nm'] ?> Di <?= $tk['rs_rmrkk_nm'] ?>', '/rmrkkt/unblockRmrkkt/<?= $tkd['rs_rmrkkt_id_ex'] ?>', loadTabKmr)"><?= $tkd['rs_rmrkkt_nm'] ?></button>
                        <?php
                                }
                                ?>
                    </div>
                    <br>
                    <?php endforeach ?>

                    <button class='btn bg-gradient-info' role="button" aria-pressed="true" data-target="#modalAddRmrkkt"
                        data-toggle="modal"
                        onclick="addFill('rs_rmrkkt_rmrkk', '<?= $tk['rs_rmrkk_id_ex'] ?>'); addFill('rs_rmrkkt_nma', getSS().nameSRmr+', <?= $tk['rs_rmk_nm'] ?>, <?= $tk['rs_rmrkk_nm'] ?>')"><i
                            class="fas fa-plus"></i></button>

                </td>
            </tr>
            <?php endforeach ?>
        </tbody>
        <tfoot>
            <tr>
                <th>No</th>
                <th>Nama Ruangan</th>
                <th>Kelas Ruangan</th>
                <th>Status Kelas Dalam Ruangan</th>
                <th>Tempat Tidur</th>

            </tr>
        </tfoot>
    </table>
</div>
<?= $this->include('Rmrkk/modalAddRmrkkt'); ?>
<script>
$(function() {
    $(document).ready(function() {
        var <?= $IdForm ?> = $('#<?= $IdForm ?>');
        <?= $IdForm ?>.submit(function(e) {
            showAnimated();
            $('#<?= $IdForm ?> :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');

            e.preventDefault();
            $.ajax({
                type: <?= $IdForm ?>.attr('method'),
                url: <?= $IdForm ?>.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            loadTabKmr();
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>

<script>
$(document).ready(function() {
    $('#dtK<?= $IdForm ?>').DataTable({
        "order": [
            [0, "asc"]
        ],
        pageLength: 10,
        responsive: true,
        fixedHeader: false,
        keys: true,
        columnDefs: [{
                responsivePriority: 1,
                target: 0
            },
            {
                responsivePriority: 10001,
                target: 4
            },
            {
                responsivePriority: 2,
                target: -2
            }
        ]
    });
});
</script>