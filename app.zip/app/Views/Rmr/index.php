<?= $this->extend('Templates/template'); ?>

<?= $this->section('content'); ?>
<!-- /.row -->

<div class="row">
    <!-- Area Chart -->
    <div class="col-12">
        <div class="callout callout-info">
            <h5><i class="fas fa-info"></i> Catatan:</h5>
            <ol>
                <li>Tanda : <span class="badge badge-light" style="color: #428bca;"><i class="far fa-folder"></i></span>
                    Mengartikan Bahwa Jabatan / Ruangan Tersebut Masih Mempunyai Sub / Cabang Belum Terbuka Dan Dapat
                    Dibuka</li>
                <li>Tanda : <span class="badge badge-light" style="color: #428bca;"><i
                            class="far fa-folder-open"></i></span> Mengartikan Bahwa Jabatan / Ruangan Tersebut Masih
                    Mempunyai Sub / Cabang Telah Terbuka Dan Dapat Ditutup</li>
                <li>Tanda : <span class="badge badge-light" style="color: #428bca;"><i class="far fa-file"></i></span>
                    Mengartikan Bahwa Jabatan / Ruangan Tersebut Tidak Mempunyai Sub / Cabang</li>
                <br>
                <li>Tombol : <button class="btn bg-gradient-success"><i class="fa fa-check"></i></button> Mengartikan
                    Bahwa Status Aktif, Untuk Menonaktifkan Tekan Tombol Tersebut</li>
                <br>
                <li>Tombol : <button class="btn bg-gradient-danger"><i class="fa fa-ban"></i></button> Mengartikan Bahwa
                    Status Tidak Aktif, Untuk Mengaktifkan Tekan Tombol Tersebut</li>
                <br>
                <li>Warna : <span class="btn bg-gradient-success"></i></span> Pada Tempat Tidur Mengartikan Bahwa Status
                    Aktif, Untuk Menonaktifkan Tekan Tombol Tersebut</li>
                <li>Warna : <span class="btn bg-gradient-danger"></i></span> Pada Tempat Tidur Mengartikan Bahwa Status
                    Tidak Aktif, Untuk Mengaktifkan Tekan Tombol Tersebut</li>
            </ol>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Struktur Jabatan Dan Ruangan</h3>
                <div class="card-tools">
                    <button class='btn bg-gradient-info' role="button" aria-pressed="true" style="float: right;"
                        data-target="#modalAddChildRmr" data-toggle="modal"><i class="fas fa-plus"></i> TAMBAH</button>
                    <div id="btnStsRmr" class="d-flex">

                    </div>
                    <!-- <button class='btn bg-gradient-danger mx-1' role="button" aria-pressed="true" style="float: right;" onclick="dCRmr()"><i class="fas fa-ban"></i>NONAKTIFKAN</button> -->

                </div>
            </div>
            <div class="card-body">
                <div class="treeview-animated" style="font-size: 13px;" id="cardDir"></div>
            </div>
        </div>
    </div>
    <div class="col-xl-8 col-lg-8 col-md-8">

        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-12">
                        <h3 class="card-title w-100 row">
                            <div class="col-auto">Daftar Komponen Ruangan</div>
                            <div id="rs_rmr_nm_title" class="col-auto"></div>
                        </h3>
                        <hr>
                        <br>
                    </div>
                    <div class="col-12">
                        <ul class="nav nav-pills">
                            <li class="nav-item"><a class="nav-link" href="#TabItemPgw" id="TabParPgw" data-toggle="tab"
                                    onclick="addSess('tabParent', 'TabParPgw'); addSess('tabItem', 'TabItemPgw');"><i
                                        class="fa fa-users"></i> Pegawai</a>
                            </li>
                            <li class="nav-item"><a class="nav-link" href="#TabItemSMF" id="TabParSMF" data-toggle="tab"
                                    onclick="addSess('tabParent', 'TabParSMF'); addSess('tabItem', 'TabItemSMF');"><i
                                        class="fa fa-user-md"></i> SMF</a>
                            </li>
                            </li>

                            <li class="nav-item"><a class="nav-link" href="#TabItemKmr" id="TabParKmr" data-toggle="tab"
                                    onclick="addSess('tabParent', 'TabParKmr'); addSess('tabItem', 'TabItemKmr');"><i
                                        class="fa fa-building"></i> Kamar</a>
                            </li>

                            <li class="nav-item"><a class="nav-link" href="#TabItemTdk" id="TabParTdk" data-toggle="tab"
                                    onclick="addSess('tabParent', 'TabParTdk'); addSess('tabItem', 'TabItemTdk');"><i
                                        class="fa fa-first-aid"></i> Tindakan</a>
                            </li>

                            <li class="nav-item"><a class="nav-link" href="#TabItemBrg" id="TabParBrg" data-toggle="tab"
                                    onclick="addSess('tabParent', 'TabParBrg'); addSess('tabItem', 'TabItemBrg');"><i
                                        class="fa fa-box-open"></i> Obat</a>
                            </li>

                            <li class="nav-item"><a class="nav-link" href="#TabItemKls" id="TabParKls" data-toggle="tab"
                                    onclick="addSess('tabParent', 'TabParKls'); addSess('tabItem', 'TabItemKls');"><i
                                        class="fa fa-star"></i> Kelas</a>
                            </li>
                            <li class="nav-item"><a class="nav-link" href="#TabItemMt" id="TabParMt" data-toggle="tab"
                                    onclick="addSess('tabParent', 'TabParMt'); addSess('tabItem', 'TabItemMt');"><i
                                        class="fa fa-thumbs-up"></i> Mutu</a>
                            </li>


                        </ul>
                    </div>
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <div class="tab-content">
                    <div class="tab-pane" id="TabItemPgw">
                        Tab Dokter
                    </div>
                    <div class="tab-pane" id="TabItemSMF">
                        Tab SMF
                    </div>
                    <div class="tab-pane" id="TabItemBrg">
                        Tab Barang
                    </div>
                    <div class="tab-pane" id="TabItemTdk">
                        Tab Tindakan
                    </div>
                    <div class="tab-pane" id="TabItemKmr">
                        Tab Kamar
                    </div>

                    <div class="tab-pane" id="TabItemKls">
                        Tab Kelas
                    </div>
                    <div class="tab-pane" id="TabItemMt">
                        Tab Mutu
                    </div>
                    <!-- /.tab-pane -->


                </div>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
</div>
<?= $this->include('Rmr/modalAddChild'); ?>
<script>
var nSRmr = sessionStorage.getItem("nSRmr");
if (nSRmr == null || nSRmr == "") {
    nSRmr = 0;
} else {
    nSRmr = parseInt(nSRmr);
}

function dCRmr() {
    var nameSRmr = sessionStorage.getItem("nameSRmr");
    var idExSRmr = sessionStorage.getItem("idExSRmr");
    // console.log(idExSRmr);
    callOtherWF('Menonaktifkan ' + nameSRmr + ' Dalam Data Ruangan', '/<?= $BasePage ?>/blockRmr/' + idExSRmr,
        fill_treeview)
}

function aCRmr() {
    var nameSRmr = sessionStorage.getItem("nameSRmr");
    var idExSRmr = sessionStorage.getItem("idExSRmr");
    // console.log(idExSRmr);
    callOtherWF('Mengaktifkan ' + nameSRmr + ' Dalam Data Ruangan', '/<?= $BasePage ?>/ublockRmr/' + idExSRmr,
        fill_treeview)
}

function btnStsRmr(sts) {
    if (sts == "1") {
        $('#btnStsRmr').html(
            "<button class='btn bg-gradient-success mx-1' role='button' aria-pressed='true' style='float: right;' title='Nontaktifkan Status Ruangan' onclick='dCRmr()'><i class='fas fa-check'></i> AKTIF</button>"
        )
    } else {
        $('#btnStsRmr').html(
            "<button class='btn bg-gradient-danger mx-1' role='button' aria-pressed='true' style='float: right;' title='Aktifkan Status Ruangan' onclick='aCRmr()'><i class='fas fa-ban'></i> NONAKTIF</button>"
        )
    }
}

function addWF(m, l, f) {
    callOtherWF(m, l, f);
}


function getSS() {
    return {
        "idExSRmr": sessionStorage.getItem("idExSRmr"),
        "nameSRmr": sessionStorage.getItem("nameSRmr")
    };
}

function fill_treeview() {
    $.ajax({
        url: "<?= base_url('rmr/getParentByJson') ?>",
        dataType: "json",
        success: function(data) {
            $('#cardDir').treeview({
                data: data,
                levels: 5,
                showBorder: false,
                color: "#428bca",
                showIcon: true,
                expandIcon: "far fa-folder",
                collapseIcon: "far fa-folder-open",
                // // selectedIcon: "fas fa-folder-open",
                icon: "far fa-folder-open",
                emptyIcon: "far fa-file",
                // nodeIcon: "fas fa-folder-open",

                //showTags: true,
                highlightSelected: true,
                onNodeSelected: function(event, data) {
                    var sels = $('#cardDir').treeview('getSelected');
                    // console.log(sels);
                    // console.log(sels[0].idEx);
                    addSess('nSRmr', sels[0].nodeId);
                    addSess('nameSRmr', sels[0].textAlt);
                    addSess('nameStr', sels[0].str);
                    addSess('idExSRmr', sels[0].idEx);
                    document.getElementById("rs_rmr_prnt").value = sels[0].idEx;
                    document.getElementById("rs_rmr_nmAts").value = sels[0].textAlt;
                    document.getElementById("rs_rmr_str").value = sels[0].str;
                    if (sels[0].sts == "1") {
                        $('#rs_rmr_nm_title').html("<span class='badge badge-success'><h6>" +
                            sels[0].textAlt + "</h6></span>");
                    } else {
                        $('#rs_rmr_nm_title').html("<span class='badge badge-danger'><h6>" +
                            sels[0].textAlt + "</h6></span>");
                    }
                    loadTabPgw();
                    loadTabKls();
                    loadTabKmr();
                    loadTabMt();
                    loadTabTdk();
                    loadTabSmf();
                    loadTabBrg();
                    btnStsRmr(sels[0].sts);
                },
            });
            $('#cardDir').treeview('selectNode', [nSRmr]);
            $('#cardDir').treeview('expandNode', [nSRmr, {
                levels: 1,
                silent: true
            }]);
        }
    });
}

function setTabAct() {
    // console.log(sessionStorage.getItem("tabParent"));
    if (sessionStorage.getItem("tabParent") === null || sessionStorage.getItem("tabParent") === "") {
        tabPar = document.getElementById("TabParDok");
        tabPar.classList.add("active");
    } else {
        tabPar = document.getElementById(sessionStorage.getItem("tabParent"));
        tabPar.classList.add("active");
    }

    if (sessionStorage.getItem("tabItem") === null || sessionStorage.getItem("tabItem") === "") {
        tabItem = document.getElementById("TabItemDok");
        tabItem.classList.add("active");
    } else {
        tabItem = document.getElementById(sessionStorage.getItem("tabItem"));
        tabItem.classList.add("active");
    }
}

function loadTabPgw() {
    var sS = getSS();
    $.ajax({
        url: "/Ppr/viewData/" + sS.idExSRmr,
        success: function(data) {

            $('#TabItemPgw').html(data);
        }
    });
}

function loadTabKls() {
    var sS = getSS();
    $.ajax({
        url: "/Rmrk/viewData/" + sS.idExSRmr,
        success: function(data) {

            $('#TabItemKls').html(data);
        }
    });
}

function loadTabKmr() {
    var sS = getSS();
    $.ajax({
        url: "/Rmrkk/viewData/" + sS.idExSRmr,
        success: function(data) {

            $('#TabItemKmr').html(data);
        }
    });
}

function loadTabMt() {
    var sS = getSS();
    $.ajax({
        url: "/rmrmt/viewData/" + sS.idExSRmr,
        success: function(data) {

            $('#TabItemMt').html(data);
        }
    });
}

function loadTabTdk() {
    var sS = getSS();
    $.ajax({
        url: "/rmrtdk/viewData/" + sS.idExSRmr,
        success: function(data) {

            $('#TabItemTdk').html(data);
        }
    });
}

function loadTabSmf() {
    var sS = getSS();
    $.ajax({
        url: "/rmrsmf/viewData/" + sS.idExSRmr,
        success: function(data) {

            $('#TabItemSMF').html(data);
        }
    });
}

function loadTabBrg() {
    var sS = getSS();
    $.ajax({
        url: "/rmrrmb/viewData/" + sS.idExSRmr,
        success: function(data) {

            $('#TabItemBrg').html(data);
        }
    });
}

$(document).ready(function() {
    fill_treeview();
    setTabAct();


    $('#datatableKirana').DataTable({
        "order": [
            [0, "asc"]
        ],
        pageLength: 10,
        responsive: true,
        fixedHeader: true,
        keys: true,
        columnDefs: [{
                responsivePriority: 1,
                target: 0
            },
            {
                responsivePriority: 10001,
                target: 4
            },
            {
                responsivePriority: 2,
                target: -2
            }
        ]
    });
});
</script>

<?= $this->endSection(); ?>