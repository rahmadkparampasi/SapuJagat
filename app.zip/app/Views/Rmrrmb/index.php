<div style="display: none;" id="<?= $IdForm ?>">
    <h4 class="text-center">Form <?= $PageTitle ?></h4>

    <table id="dtK<?= $IdForm ?>Rmb" class="table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>Aksi</th>
                <th>No</th>
                <th>Nama Barang</th>
            </tr>
        </thead>
    </table>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="button" class="btn bg-gradient-success" onclick="addWF('Menambahkan Semua Obat Dalam Data Ruangan', '/rmrrmb/insertDataAll/<?= $rs_rmrtdk_rmr ?>', loadTabBrg)">PILIH SEMUA</button>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('<?= $IdForm ?>', '<?= $IdForm ?>'); destroyRmb()">BATAL</button>
        </div>
    </div>
    <hr>
</div>

<script>
function loadRmb() {
    var sS = getSS();
    $('#dtK<?= $IdForm ?>Rmb').DataTable({
        destroy: true,
        ajax: "<?= base_url('rmb/getRmbByJson') ?>" + "/" + sS.idExSRmr,
        paging: true,
        searching: true,
        pageLength: 10,
        responsive: true,
        fixedHeader: true,
        keys: true,
        language: {
            paginate: {
                previous: "Sebelumnya",
                next: "Selanjutnya"
            },
            "emptyTable": "Data Ruangan Belum Ada",
        },
        columns: [{
                "data": "button"
            },
            {
                "data": "no"
            },
            {
                "data": "rs_rmb_nm"
            },
        ],
        columnDefs: [{
            className: "text-nowrap",
            "targets": [2]
        }]
    });
}

function destroyRmb() {
    $('#dtK<?= $IdForm ?>Rmb').DataTable({
        destroy: true,
    });
}
</script>

<div>
    <h4 class="text-center"><?= $PageTitle ?></h4>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-success" style="float: right;"
                onclick="showForm('<?= $IdForm ?>', 'block'); loadRmb()"><i class="fas fa-plus"></i>
                Tambah</button>
        </div>
    </div>
    <table id="dtK<?= $IdForm ?>" class="table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Obat</th>
                <th>Nama Generik</th>
                <th>Kategori</th>
                <th>Satuan</th>
                <th>Merek</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Rmrrmb as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td>
                <td><?= $tk['rs_rmb_nm'] ?></td>
                <td class="text-wrap"><?= $tk['rs_rmgz_nm'] ?></td>
                <td><?= $tk['rs_rmjk_nm'] ?></td>
                <td><?= $tk['rs_rmst_nm'] ?></td>
                <td><?= $tk['rs_rmmrk_nm'] ?></td>
                <td>

                </td>
            </tr>
            <?php endforeach ?>
        </tbody>
        
    </table>
</div>

<script>
$(function() {
    $(document).ready(function() {
        var <?= $IdForm ?> = $('#<?= $IdForm ?>');
        <?= $IdForm ?>.submit(function(e) {
            showAnimated();
            $('#<?= $IdForm ?> :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');

            e.preventDefault();
            $.ajax({
                type: <?= $IdForm ?>.attr('method'),
                url: <?= $IdForm ?>.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            window.location = '/<?= $UrlForm ?>';
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>

<script>
$(document).ready(function() {
    $('#dtK<?= $IdForm ?>').DataTable({
        "order": [
            [0, "asc"]
        ],
        pageLength: 10,
        responsive: true,
        fixedHeader: false,
        keys: true,
        columnDefs: [{
                responsivePriority: 1,
                target: 0
            },
            {
                responsivePriority: 10001,
                target: 4
            },
            {
                responsivePriority: 2,
                target: -2
            }
        ]
    });
});
</script>