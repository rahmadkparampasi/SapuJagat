<div>
    <h4 class="text-center"><?= $PageTitle ?></h4>
    
    <table id="dtK<?= $IdForm ?>" class="table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Obat</th>
                <th>Nama Generik</th>
                <th>Kategori</th>
                <th>Merek</th>
                <th>Jumlah</th>
                <th>Satuan</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Rmrrmb as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td>
                <td><?= $tk['rs_rmb_nm'] ?></td>
                <td class="text-wrap"><?= $tk['rs_rmgz_nm'] ?></td>
                <td><?= $tk['rs_rmjk_nm'] ?></td>
                <td><?= $tk['rs_rmmrk_nm'] ?></td>
                <td><?= $tk['rs_rmrrmb_j'] ?></td>
                
                <td><?= $tk['rs_rmst_nm'] ?></td>
            </tr>
            <?php endforeach ?>
        </tbody>
        
    </table>
</div>


<script>
$(document).ready(function() {
    $('#dtK<?= $IdForm ?>').DataTable({
        "order": [
            [0, "asc"]
        ],
        pageLength: 10,
        responsive: true,
        fixedHeader: false,
        keys: true,
        columnDefs: [{
                responsivePriority: 1,
                target: 0
            },
            {
                responsivePriority: 10001,
                target: 4
            },
            {
                responsivePriority: 2,
                target: -2
            }
        ]
    });
});
</script>