<?= $this->extend('Templates/template'); ?>

<?= $this->section('content'); ?>
<!-- /.row -->

<?= $this->include('Rmptr/addData'); ?>
<div class="row">
    <!-- Area Chart -->
    <div class="col-xl-12 col-lg-12">

        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Daftar <?= $PageTitle ?> A.N. Pasien <?= $Rmpmsk['rs_rmpp_nm'] ?>, Tgl Masuk IGD <?= $Rmpmsk['rs_rmpmsk_tgl'] ?>, Jam Masuk IGD <?= $Rmpmsk['rs_rmpmsk_jam'] ?>, No. RM : <?= $Rmpmsk['rs_rmpp_rm'] ?></h3>
                <div class="card-tools">
                    <?php
                    if ($MethodForm1 != "updateData") {
                    ?>
                        <button class='btn bg-gradient-success' role="button" aria-pressed="true" style="float: right;" onclick="showForm('<?= $IdForm ?>', 'block')"><i class="fas fa-plus"></i>
                            TAMBAH</button>
                    <?php
                    }
                    ?>

                    <a href="/rmpmsk" class='btn bg-gradient-danger mx-1' style="float: right;"><i class="fas fa-reply"></i>
                        KEMBALI</a>
                    <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
                    <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table id="datatableKirana1" class="table responsive table-bordered table-striped w-100">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Tanggal Dan Jam Pemeriksaan</th>
                            <th>Tanda Vital (Vital Sign)</th>
                            <th>Jalan Nafas (Airway)</th>
                            <th>Pernafasan (Breathing)</th>
                            <th>Sirkulasi (Circulation)</th>
                            <th>Kesadaran (Disability)</th>
                            <th>DOA</th>
                            <th>Karegori ATS</th>
                            <th>Keluhan Utama</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 0;
                        foreach ($Rmptr as $tk) : $no++ ?>
                            <tr>
                                <td><?= $no ?></td>
                                <td>
                                    Tanggal : <?= $tk['rs_rmptr_tgl'] ?><br>
                                    Jam : <?= $tk['rs_rmptr_jam'] ?>
                                </td>
                                <td class="text-nowrap">
                                    Tekanan Darah : <?= $tk['rs_rmptr_td'] ?> mmHg<br>
                                    Frek. Nadi : <?= $tk['rs_rmptr_fnd'] ?> x/mnt<br>
                                    Frek. Nafas : <?= $tk['rs_rmptr_fnf'] ?> x/mnt<br>
                                    Suhu : <?= $tk['rs_rmptr_sh'] ?> &#7506;c<br>
                                    Riwayat Alergi Makanan : <?= $tk['rs_rmptr_ram'] ?><br>
                                    Obat : <?= $tk['rs_rmptr_rao'] ?><br>
                                </td>
                                <td><?= $tk['rs_rmptr_jn'] ?></td>
                                <td>
                                    <?= $tk['rs_rmptr_pfr'] ?>
                                    <?= $tk['rs_rmptr_whz'] ?>
                                    <?= $tk['rs_rmptr_hn'] ?>
                                    <?= $tk['rs_rmptr_sia'] ?>
                                </td>
                                <td>
                                    <?= $tk['rs_rmptr_pfn'] ?>
                                    <?= $tk['rs_rmptr_sis'] ?>
                                    <?= $tk['rs_rmptr_dia'] ?>
                                    <?= $tk['rs_rmptr_hj'] ?>
                                    <?= $tk['rs_rmptr_na'] ?>
                                    <?= $tk['rs_rmptr_pc'] ?>
                                    <?= $tk['rs_rmptr_ak'] ?>
                                </td>
                                <td><?= $tk['rs_rmptr_ks'] ?></td>
                                <td><?= $tk['rs_rmptr_doa'] ?></td>
                                <td><?= $tk['rs_rmptr_ats'] ?></td>
                                <td class="text-nowrap"><?= $tk['rs_rmptr_ku'] ?></td>
                                <td>
                                    <button class="btn bg-gradient-warning" title="Ubah Data Triage Pasien" onclick="callHref('/<?= $BasePage ?>/editData/<?= $tk['rs_rmptr_id_ex'] ?>')">
                                        <i class='fas fa-pen'></i>
                                    </button>
                                    <?php
                                    if ($MethodForm1 != "updateData") {
                                    ?>
                                        <button class="btn bg-gradient-danger" title="Hapus Data Triage Pasien" onclick="callOther('Menghapus Data Triage Pasien', '<?= $BasePage ?>/deleteData/<?= $tk['rs_rmptr_id_ex'] ?>')">
                                            <i class='fas fa-trash'></i></button>
                                    <?php
                                    }
                                    ?>
                                </td>
                            </tr>
                        <?php endforeach ?>
                    </tbody>
                </table>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
</div>
<script>
    function addFill(idComp = '', fill = '') {
        document.getElementById(idComp).value = fill;
    }
</script>
<script>
    $(document).ready(function() {
        $('#datatableKirana1').DataTable({
            "order": [
                [0, "asc"]
            ],
            pageLength: 10,
            responsive: true,
            fixedHeader: true,
            keys: true,
            columnDefs: [{
                    responsivePriority: 1,
                    target: 0
                },
                {
                    responsivePriority: 10001,
                    target: 4
                },
                {
                    responsivePriority: 2,
                    target: -2
                }
            ]
        });
    });
</script>

<?= $this->endSection(); ?>