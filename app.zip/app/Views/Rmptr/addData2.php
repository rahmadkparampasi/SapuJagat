<form method="POST" class="form-valide h-250" action="/<?= $BasePage ?>/<?= $MethodForm ?>" id="<?= $IdForm ?>" enctype="multipart/form-data" style="<?php
                                                                                                                                                        if ($MethodForm1 == "updateData") {
                                                                                                                                                            echo 'display: block;';
                                                                                                                                                        } else {
                                                                                                                                                            echo 'display: none;';
                                                                                                                                                        } ?>" id="<?= $IdForm ?>">
    <?php
    if ($MethodForm1 == "updateData") {
        echo "<input type='hidden' name='rs_rmptr_id_ex' id='rs_rmptr_id_ex'>";
    }
    ?>
    <div class="row">
        <div class="col-md-4">
            <!-- Widget: user widget style 1 -->
            <div class="card card-widget widget-user">
                <!-- Add the bg color to the header using any of the bg-* classes -->
                <div class="widget-user-header bg-info h-auto">
                    <h3 class="widget-user-username"><?= $Rmpmsk['rs_rmpp_nm'] ?></h3>
                    <h5 class="widget-user-desc">No. RM : <?= $Rmpmsk['rs_rmpp_rm'] ?></h5>
                </div>
                <div class="card-footer py-0">
                    <div class="row d-flex justify-content-center py-1">
                        <div class="col-sm-4 border-right">
                            <div class="description-block">
                                <h5 class="description-header">Tanggal Masuk RS</h5>
                                <span class="description-text"><?= $Rmpmsk['rs_rmpmsk_tgl'] ?></span>
                            </div>
                            <!-- /.description-block -->
                        </div>
                        <!-- /.col -->
                        <div class="col-sm-4">
                            <div class="description-block">
                                <h5 class="description-header">Jam Masuk RS</h5>
                                <span class="description-text"><?= $Rmpmsk['rs_rmpmsk_jam'] ?></span>
                            </div>
                            <!-- /.description-block -->
                        </div>
                        <!-- /.col -->
                    </div>
                    <div class="row">
                        <div class="col-sm-4 border-right">
                            <div class="description-block">
                                <h5 class="description-header">Tanggal Lahir</h5>
                                <span class="description-text"><?= $Rmpmsk['rs_rmpp_tgl_lhr'] ?></span>
                            </div>
                            <!-- /.description-block -->
                        </div>
                        <!-- /.col -->
                        <div class="col-sm-4 border-right">
                            <div class="description-block">
                                <h5 class="description-header">Jenis Kelamin</h5>
                                <span class="description-text"><?= $Rmpmsk['rs_rmpp_jk'] ?></span>
                            </div>
                            <!-- /.description-block -->
                        </div>
                        <!-- /.col -->
                        <div class="col-sm-4">
                            <div class="description-block">
                                <h5 class="description-header">Alamat</h5>
                                <span class="description-text"><?= $Rmpmsk['rs_rmpp_alt'] ?></span>
                            </div>
                            <!-- /.description-block -->
                        </div>
                        <!-- /.col -->
                    </div>
                    <!-- /.row -->
                </div>
            </div>
            <!-- /.widget-user -->
        </div>
        <div class="col-md-8">
            <div class="card card-row card-success">
                <div class="card-header">
                    <h3 class="card-title">
                        AUSTRALIAN TRIAGE SCALE (ATS)
                    </h3>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label for="rs_rmptr_ku">Keluhan Utama</label>
                        <textarea cols="30" rows="2" type="text" class="form-control" id="rs_rmptr_ku" name="rs_rmptr_ku" required></textarea>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <div class="content-wrapper kanban mx-0 my-2 h-auto">
        <section class="content">
            <div class="container-fluid my-2">
                <div class="card card-row">
                    <div class="card-header">
                        <h3 class="card-title">
                            PEMERIKSAAN (EXAMINATION)
                            <br>
                            <br>
                        </h3>
                    </div>
                    <div class="card-body">
                        <div class="card card-info card-outline">

                            <div class="card-body">
                                <br>
                                <b>JALAN NAFAS (Airway)</b>
                                <br>
                                <br>
                            </div>
                        </div>
                        <div class="card card-info card-outline">

                            <div class="card-body">
                                <br>
                                <br>
                                <br>
                                <br>
                                <b>PERNAFASAN (Breathing)</b>
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
                            </div>
                        </div>
                        <hr>
                        <div class="card card-info card-outline">

                            <div class="card-body">
                                <br>
                                <br>
                                <br>
                                <br>
                                <b>SIRKULASI (Circulation)</b>
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
                            </div>
                        </div>
                        <hr>
                        <div class="card card-info card-outline">

                            <div class="card-body">
                                <br>
                                <b>KESADARAN (Disability)</b>
                                <br>
                                <br>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card card-row card-danger">
                    <div class="card-header">
                        <h3 class="card-title">
                            RESUSITASI
                            <br>
                            <br>
                        </h3>
                    </div>
                    <div class="card-body">
                        <div class="card card-danger card-outline">
                            <div class="card-body">
                                <br>
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_jn" name="rs_rmptr_jn" value="SR">
                                    <label for="rs_rmptr_jn" class="custom-control-label">Sumbatan (Obstruction)</label>
                                </div>
                                <br>
                            </div>
                        </div>
                        <div class="card card-danger card-outline">
                            <div class="card-body">
                                <br>
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_hn" name="rs_rmptr_hn" value="1">
                                    <label for="rs_rmptr_hn" class="custom-control-label">Henti Nafas (Breathing Arrest)</label>
                                </div>
                                <br>
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_pfr" name="rs_rmptr_pfr" value="FR">
                                    <label for="rs_rmptr_pfr" class="custom-control-label">Frek. Nafas (RR) < 10x/mnt </label>
                                </div>
                                <br>
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_sia" name="rs_rmptr_sia" value="1">
                                    <label for="rs_rmptr_sia" class="custom-control-label">Sianosis </label>
                                </div>
                                <br>
                                <br>
                                <br>
                                <br>

                            </div>
                        </div>
                        <hr>
                        <div class="card card-danger card-outline">
                            <div class="card-body">
                                <br>
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_hj" name="rs_rmptr_hj" value="1">
                                    <label for="rs_rmptr_hj" class="custom-control-label">Henti Jantung (Cardiac Arrest)</label>
                                </div>
                                <br>
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_na" name="rs_rmptr_na" value="NTT">
                                    <label for="rs_rmptr_na" class="custom-control-label">Nadi Tidak Terasa </label>
                                </div>
                                <br>
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_pc" name="rs_rmptr_pc" value="1">
                                    <label for="rs_rmptr_pc" class="custom-control-label">Pucat </label>
                                </div>
                                <br>
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_ak" name="rs_rmptr_ak" value="1">
                                    <label for="rs_rmptr_ak" class="custom-control-label">Akral Dingin </label>
                                </div>
                                <br>
                                <br>
                            </div>
                        </div>
                        <hr>
                        <div class="card card-danger card-outline">
                            <div class="card-body">
                                <br>
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_ks" name="rs_rmptr_ks" value="KSR">
                                    <label for="rs_rmptr_ks" class="custom-control-label">GCS < 9</label>
                                </div>
                                <br>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card card-row card-warning">
                    <div class="card-header">
                        <h3 class="card-title">
                            EMERGENCY
                            <br>
                            <br>
                        </h3>
                    </div>
                    <div class="card-body">
                        <div class="card card-warning card-outline">
                            <div class="card-body">
                                <br>
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_jn1" name="rs_rmptr_jn" value="BE">
                                    <label for="rs_rmptr_jn1" class="custom-control-label">Bebas</label>
                                </div>
                                <br>
                            </div>
                        </div>

                        <div class="card card-warning card-outline">
                            <div class="card-body">
                                <br>
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_pfr1" name="rs_rmptr_pfr" value="FE">
                                    <label for="rs_rmptr_pfr1" class="custom-control-label">Frek. Nafas (RR) > 32x/mnt </label>
                                </div>
                                <br>
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_whz" name="rs_rmptr_whz" value="WE">
                                    <label for="rs_rmptr_whz" class="custom-control-label">Wheezing </label>
                                </div>
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
                            </div>
                        </div>
                        <hr>
                        <div class="card card-warning card-outline">

                            <div class="card-body">
                                <br>
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_na1" name="rs_rmptr_na" value="NTL">
                                    <label for="rs_rmptr_na1" class="custom-control-label">Nadi Teraba Lemah </label>
                                </div>
                                <br>
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_pfn" name="rs_rmptr_pfn" value="FU">
                                    <label for="rs_rmptr_pfn" class="custom-control-label">Frek. Nadi (HR) < 50x/mnt atau &#8805; 150x/mnt </label>
                                </div>
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
                            </div>
                        </div>
                        <hr>
                        <div class="card card-warning card-outline">
                            <div class="card-body">
                                <br>
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_ks1" name="rs_rmptr_ks" value="KSE">
                                    <label for="rs_rmptr_ks1" class="custom-control-label">GCS 9 - 12</label>
                                </div>
                                <br>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card card-row">
                    <div class="card-header">
                        <h3 class="card-title">
                            TANDA VITAL (Vital Sign)
                            <br>
                            <br>
                        </h3>
                    </div>
                    <div class="card-body">
                        <div class="card card-info card-outline">

                            <div class="card-body">

                                <div class="form-group">
                                    <label for="rs_rmptr_td">Tekanan Darah (mmHg)</label>
                                    <input type="text" class="form-control" id="rs_rmptr_td" name="rs_rmptr_td">
                                </div>
                                <div class="form-group">
                                    <label for="rs_rmptr_fnd">Frek. Nadi (x/mnt)</label>
                                    <input type="text" class="form-control" id="rs_rmptr_fnd" name="rs_rmptr_fnd">
                                </div>

                                <div class="form-group">
                                    <label for="rs_rmptr_fnf">Frek. Nafas (x/mnt)</label>
                                    <input type="text" class="form-control" id="rs_rmptr_fnf" name="rs_rmptr_fnf">
                                </div>

                                <div class="form-group">
                                    <label for="rs_rmptr_sh">Suhu (derajat celcius)</label>
                                    <input type="number" step=".1" class="form-control" id="rs_rmptr_sh" name="rs_rmptr_sh">
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="card card-info card-outline">
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="rs_rmptr_ram">Riwayat Alergi Makanan</label>
                                    <input type="text" class="form-control" id="rs_rmptr_ram" name="rs_rmptr_ram">
                                </div>
                                <br>
                                <br>
                                <div class="form-group">
                                    <label for="rs_rmptr_rao">Obat</label>
                                    <input type="text" class="form-control" id="rs_rmptr_rao" name="rs_rmptr_rao">
                                </div>

                                <br>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card card-row card-warning">
                    <div class="card-header">
                        <h3 class="card-title">
                            URGENT
                            <br>
                            <br>
                        </h3>
                    </div>
                    <div class="card-body">
                        <div class="card card-warning card-outline">
                            <div class="card-body">
                                <br>
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_jn2" name="rs_rmptr_jn" value="BU">
                                    <label for="rs_rmptr_jn2" class="custom-control-label">Bebas</label>
                                </div>
                                <br>
                            </div>
                        </div>

                        <div class="card card-warning card-outline">

                            <div class="card-body">
                                <br>
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_pfr2" name="rs_rmptr_pfr" value="FU">
                                    <label for="rs_rmptr_pfr2" class="custom-control-label">Frek. Nafas (RR) 24 - 32x/mnt </label>
                                </div>
                                <br>
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_whz1" name="rs_rmptr_whz" value="WU">
                                    <label for="rs_rmptr_whz1" class="custom-control-label">Wheezing </label>
                                </div>
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
                            </div>
                        </div>
                        <hr>
                        <div class="card card-warning card-outline">

                            <div class="card-body">
                                <br>
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_pfn1" name="rs_rmptr_pfn" value="FU">
                                    <label for="rs_rmptr_pfn1" class="custom-control-label">Frek. Nadi (HR) 120 - 150x/mnt </label>
                                </div>
                                <br>
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_sis" name="rs_rmptr_sis" value="SU">
                                    <label for="rs_rmptr_sis" class="custom-control-label">TD Sistol &#8805; 160 mmHg </label>
                                </div>
                                <br>
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_dia" name="rs_rmptr_dia" value="DU">
                                    <label for="rs_rmptr_dia" class="custom-control-label">TD Diastole &#8805; 100 mmHg </label>
                                </div>
                                <br>
                                <br>
                                <br>
                                <br>
                            </div>
                        </div>
                        <hr>
                        <div class="card card-warning card-outline">
                            <div class="card-body">
                                <br>
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_ks2" name="rs_rmptr_ks" value="KSU">
                                    <label for="rs_rmptr_ks2" class="custom-control-label">GCS > 12</label>
                                </div>
                                <br>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card card-row card-success">
                    <div class="card-header">
                        <h3 class="card-title">
                            LESS URGENT
                            <br>
                            <br>
                        </h3>
                    </div>
                    <div class="card-body">
                        <div class="card card-success card-outline">
                            <div class="card-body">
                                <br>
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_jn3" name="rs_rmptr_jn" value="BLU">
                                    <label for="rs_rmptr_jn3" class="custom-control-label">Bebas</label>
                                </div>
                                <br>
                            </div>
                        </div>

                        <div class="card card-success card-outline">
                            <div class="card-body">
                                <br>
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_pfr3" name="rs_rmptr_pfr" value="FLU">
                                    <label for="rs_rmptr_pfr3" class="custom-control-label">Frek. Nafas (RR) 21 - 32x/mnt </label>
                                </div>
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
                            </div>
                        </div>
                        <hr>
                        <div class="card card-success card-outline">
                            <div class="card-body">
                                <br>
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_pfn2" name="rs_rmptr_pfn" value="FLU">
                                    <label for="rs_rmptr_pfn2" class="custom-control-label">Frek. Nadi (HR) 100 - 120x/mnt </label>
                                </div>
                                <br>
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_sis1" name="rs_rmptr_sis" value="SLU">
                                    <label for="rs_rmptr_sis1" class="custom-control-label">TD Sistol < 160 mmHg </label>
                                </div>
                                <br>
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_dia1" name="rs_rmptr_dia" value="DLU">
                                    <label for="rs_rmptr_dia1" class="custom-control-label">TD Diastole < 100 mmHg </label>
                                </div>
                                <br>
                                <br>
                                <br>
                                <br>
                            </div>
                        </div>
                        <hr>
                        <div class="card card-success card-outline">
                            <div class="card-body">
                                <br>
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_ks3" name="rs_rmptr_ks" value="KSLU">
                                    <label for="rs_rmptr_ks3" class="custom-control-label">GCS 15</label>
                                </div>
                                <br>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card card-row card-success">
                    <div class="card-header">
                        <h3 class="card-title">
                            NON URGENT
                            <br>
                            <br>
                        </h3>
                    </div>
                    <div class="card-body">
                        <div class="card card-succeess card-outline">
                            <div class="card-body">
                                <br>
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_jn4" name="rs_rmptr_jn" value="BNU">
                                    <label for="rs_rmptr_jn4" class="custom-control-label">Bebas</label>
                                </div>
                                <br>
                            </div>
                        </div>
                        <div class="card card-success card-outline">

                            <div class="card-body">
                                <br>
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_pfr4" name="rs_rmptr_pfr" value="FNU">
                                    <label for="rs_rmptr_pfr4" class="custom-control-label">Frek. Nafas (RR) 16 - 20x/mnt </label>
                                </div>
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
                            </div>
                        </div>
                        <hr>
                        <div class="card card-success card-outline">

                            <div class="card-body">
                                <br>
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_pfn3" name="rs_rmptr_pfn" value="FNU">
                                    <label for="rs_rmptr_pfn3" class="custom-control-label">Frek. Nadi (HR) 80 - 100x/mnt </label>
                                </div>
                                <br>
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_sis2" name="rs_rmptr_sis" value="SNU">
                                    <label for="rs_rmptr_sis2" class="custom-control-label">TD Sistol < 120 mmHg </label>
                                </div>
                                <br>
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_dia2" name="rs_rmptr_dia" value="DNU">
                                    <label for="rs_rmptr_dia2" class="custom-control-label">TD Diastole < 50 mmHg </label>
                                </div>
                                <br>
                                <br>
                                <br>
                                <br>
                            </div>
                        </div>
                        <hr>
                        <div class="card card-success card-outline">
                            <div class="card-body">
                                <br>
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_ks4" name="rs_rmptr_ks" value="KSNU">
                                    <label for="rs_rmptr_ks4" class="custom-control-label">GCS 15</label>
                                </div>
                                <br>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </section>
    </div>
    <div class="row">
        <div class="col-md-4">
            <!-- Widget: user widget style 1 -->
            <div class="card card-row card-danger">
                <div class="card-header">
                    <h3 class="card-title">
                        KEMATIAN
                    </h3>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <div class="custom-control custom-radio">
                            <input class="custom-control-input" type="radio" id="rs_rmptr_doa" name="rs_rmptr_doa" value="1">
                            <label for="rs_rmptr_doa" class="custom-control-label">DOA</label>
                        </div>
                    </div>

                </div>
            </div>
            <div class="card card-row card-primary">
                <div class="card-header">
                    <h3 class="card-title">
                        TANGGAL DAN WAKTU
                    </h3>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label for="rs_rmptr_tgl">Tanggal Pemeriksaan</label>
                        <div class="input-group date" data-target-input="nearest">

                            <input type="date" id="rs_rmptr_tgl" name="rs_rmptr_tgl" required class="form-control">
                            <div class="input-group-append">
                                <div class="input-group-text"><i class="far fa-calendar"></i></div>
                            </div>
                        </div>
                    </div>
                    <div class="bootstrap-timepicker">
                        <div class="form-group">
                            <label for="rs_rmptr_jam">Jam Pemeriksaan</label>
                            <div class="input-group date" id="timepicker" data-target-input="nearest">
                                <input type="text" class="form-control datetimepicker-input" data-target="#timepicker" id="rs_rmptr_jam" name="rs_rmptr_jam" required>
                                <div class="input-group-append" data-target="#timepicker" data-toggle="datetimepicker">
                                    <div class="input-group-text"><i class="far fa-clock"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.widget-user -->
        </div>
        <div class="col-md-8">
            <div class="card card-row card-success">
                <div class="card-header">
                    <h3 class="card-title">
                        KATEGORI ATS
                    </h3>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-2">
                            Kategori ATS
                        </div>
                        <div class="col-lg-4">
                            Maksimum Waktu Tunggu
                        </div>
                        <div class="col-lg-6">
                            Keterangan
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-lg-2">
                            <div class="form-group">
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_ats" name="rs_rmptr_ats" value="1">
                                    <label for="rs_rmptr_ats" class="custom-control-label">Kategori 1</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            Segera
                        </div>
                        <div class="col-lg-6">
                            Resusitasi
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-lg-2">
                            <div class="form-group">
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_ats2" name="rs_rmptr_ats" value="2">
                                    <label for="rs_rmptr_ats2" class="custom-control-label">Kategori 2</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            10 Menit
                        </div>
                        <div class="col-lg-6">
                            Emergency / Gawat Darurat
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-lg-2">
                            <div class="form-group">
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_ats3" name="rs_rmptr_ats" value="3">
                                    <label for="rs_rmptr_ats3" class="custom-control-label">Kategori 3</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            30 Menit
                        </div>
                        <div class="col-lg-6">
                            Urgent / Darurat
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-lg-2">
                            <div class="form-group">
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_ats4" name="rs_rmptr_ats" value="4">
                                    <label for="rs_rmptr_ats4" class="custom-control-label">Kategori 4</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            60 Menit
                        </div>
                        <div class="col-lg-6">
                            Semi Darurat
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-lg-2">
                            <div class="form-group">
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmptr_ats5" name="rs_rmptr_ats" value="5">
                                    <label for="rs_rmptr_ats5" class="custom-control-label">Kategori 5</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            120 Menit
                        </div>
                        <div class="col-lg-6">
                            Tidak Darurat
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <div class="card card-primary">
        <div class="card-footer">
            <button type="submit" class="btn bg-gradient-primary"><?= $ButtonMethod ?></button>
            <?php
            if ($MethodForm1 == "updateData") {
            ?>
                <a href="/<?= $UrlForm ?>" class='btn bg-gradient-danger' aria-pressed="true">BATAL</a>
            <?php
            } else {
            ?>
                <button type="button" class="btn bg-gradient-danger" onclick="closeForm('<?= $IdForm ?>', '<?= $IdForm ?>')">BATAL</button>
            <?php
            }
            ?>
        </div>
    </div>
</form>
<script>
    $(function() {
        //Timepicker
        $('#timepicker').datetimepicker({
            format: 'HH:mm',
            use24hours: true
        })
    });
</script>