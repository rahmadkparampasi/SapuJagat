<div class="card">
    <div class="card-header">
        <h3 class="card-title">Daftar Kategori Barang <?= $Rmji['rs_rmji_nm'] ?></h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
        <table id="datatableKirana<?= $IdForm ?>" class="table responsive table-bordered table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Deskripsi</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 0;
                foreach ($Rmkb as $tk) : $no++ ?>
                <tr>
                    <td><?= $no ?></td>
                    <td>
                        <button class="btn bg-bg-gradient-lightblue"
                            onclick="loadTabRmjk('<?= $tk['rs_rmkb_id_ex'] ?>')">
                            <?= $tk['rs_rmkb_nm'] ?>
                        </button>
                    </td>
                    <td>
                        <?php
                            if ($tk['rs_rmkb_sts'] == "1") {
                            ?>
                        <button class="btn bg-gradient-success" title="Kategori Barang Aktif"
                            onclick="addWF('Menonaktifkan <?= $tk['rs_rmkb_nm'] ?> Dalam Data Kategori Barang', '<?= $BasePage ?>/block/<?= $tk['rs_rmkb_id_ex'] ?>', loadTabRmkb, '<?= $rs_rmkb_rmji ?>')">
                            <i class='fas fa-check'></i>
                        </button>
                        <?php
                            } else {
                            ?>
                        <button class="btn bg-gradient-danger" title="Kategori Barang Tidak Aktif"
                            onclick="addWF('Mengaktifkan <?= $tk['rs_rmkb_nm'] ?> Dalam Data Kategori Barang', '<?= $BasePage ?>/unblock/<?= $tk['rs_rmkb_id_ex'] ?>', loadTabRmkb, '<?= $rs_rmkb_rmji ?>')">
                            <i class='fas fa-ban'></i>
                        </button>
                        <?php
                            }
                            ?>
                    </td>

                </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    </div>
    <div class="card-footer">
        <button class='btn bg-gradient-info' role="button" aria-pressed="true" style="float: right;"
            data-target="#modalAddChildRmkb" data-toggle="modal"
            onclick="addFill('rs_rmkb_rmji', '<?= $Rmji['rs_rmji_id_ex'] ?>')"><i class="fas fa-plus"></i>
            TAMBAH</button>

    </div>
    <!-- /.card-body -->
</div>
<!-- /.card -->

<?= $this->include('Rmkb/modalAddChild'); ?>
<script>
$(document).ready(function() {
    $('#datatableKirana<?= $IdForm ?>').DataTable({
        "order": [
            [0, "asc"]
        ],
        pageLength: 100,
        responsive: true,
        fixedHeader: true,
        keys: true,
        columnDefs: [{
                responsivePriority: 1,
                target: 0
            },
            {
                responsivePriority: 10001,
                target: 4
            },
            {
                responsivePriority: 2,
                target: -2
            }
        ]
    });
});
</script>