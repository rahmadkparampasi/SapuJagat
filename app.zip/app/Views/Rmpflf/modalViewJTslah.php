<div class="modal fade bd-example-modal-lg" id="modalViewJTslah" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalLabel" aria-hidden="true">
    <form class="form-horizontal form-valide" method="POST" action="/rmpflf/<?= $MethodForm ?>" id="formTabPflf">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabelPdf">Form Jasa Tuslah </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    
                    <div class="form-group row">
                        <label class="col-sm-12 col-form-label">Nama Tuslah</label>
                        <div class="col-sm-12">
                            <div class="input-group m-b">
                                <input type="text" name="" id="" class="form-control" value="">
                            </div>
                        </div>
                    </div>


                    <div class="form-group row">
                        <label class="col-sm-12 col-form-label">Jumlah</label>
                        <div class="col-sm-12">
                            <div class="input-group m-b">
                                <input type="number" name="" id="" class="form-control" value="">
                            </div>
                        </div>
                    </div> 
                </div>

                <div class="modal-footer">
                    <div class="item form-group">
                        <button type="submit" class="btn bg-gradient-primary">SIMPAN</button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal"
                            onclick="destroyTdkC()">TUTUP</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <script>
    $(function() {
        $(document).ready(function() {
            var formTabPlabt = $('#formTabPlabt');
            formTabPlabt.submit(function(e) {
                showAnimated();
                $('#formTabPlabt :input').prop("disabled", false);
                $(this).attr('disabled', 'disabled');

                e.preventDefault();
                $.ajax({
                    type: formTabPlabt.attr('method'),
                    url: formTabPlabt.attr('action'),
                    enctype: 'multipart/form-data',
                    data: new FormData(this),
                    contentType: false,
                    processData: false,
                    dataType: 'json',
                    success: function(data) {
                        hideAnimated();
                        if (data.response == "success") {
                            swal.fire({
                                title: "Terima Kasih",
                                text: data.message,
                                icon: data.response
                            }).then(function() {
                                window.location =
                                    '/<?= $UrlForm ?>';
                            });
                        } else {
                            hideAnimated();
                            swal.fire({
                                title: "Tidak Dapat Melanjutkan Proses",
                                text: data.message,
                                icon: data.response
                            });
                        }
                    },
                    error: function(xhr) {
                        hideAnimated();
                        console.log(xhr);
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: xhr.responseJSON.message,
                            icon: "error"
                        });
                    }
                });
            });
        });
    });
    </script>
</div>