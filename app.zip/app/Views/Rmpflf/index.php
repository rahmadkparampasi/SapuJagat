<hr>
<div> 
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-info <?= $eEdit ?>" style="float: right;" data-target="#modalViewJTslah" data-toggle="modal"><i class="fas fa-plus"></i>
                Jasa Tuslah</button>
        </div>
    </div>
    <table id="dtKformTabPlg" class="dtK table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Obat</th>
                <th>Aturan Pakai</th>
                <th>Kemasan Racikan</th>
                <th>Jumlah</th>
                <th>Petunjuk Racikan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
        <?php $no = 0;
            foreach ($Rmpflf as $tk) : $no++ ?>
                <tr>
                    <td><?= $no ?></td>
                    <td>
                        Tanggal : <?= $tk['rs_rmpplg_tgl'] ?><br>
                        Waktu : <?= $tk['rs_rmpplg_jam'] ?>
                    </td>
                    <td class="text-nowrap"><?= $tk['rs_rmck_nm'] ?></td>
                    <td><?= $tk['rs_rmkk_nm'] ?></td>
                    <td><?= $tk['rs_ppeg_nm'] ?></td>
                    <td><?= $tk['rs_rmpplg_diag'] ?></td>
                    <td>
                        <?php
                        if ($MethodForm1 != "updateData") {
                        ?>
                            <button class="btn bg-gradient-danger <?= $eEdit ?>" title="Hapus Data Pulang Pasien" onclick="callOther('Menghapus Data Pulang Pasien', '/rmpplg/deleteData/<?= $tk['rs_rmpplg_id_ex'] ?>')">
                                <i class='fas fa-trash'></i></button>
                        <?php
                        }
                        ?>
                    </td>
                </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>  
<?= $this->include('Rmpmskd/modalViewJTslah'); ?>