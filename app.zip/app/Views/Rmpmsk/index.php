<?= $this->extend('Templates/template'); ?>

<?= $this->section('content'); ?>
<!-- /.row -->
<div class="row">
    <!-- Area Chart -->
    <div class="col-xl-12 col-lg-12">
        <?= $this->include('Rmpmsk/addData'); ?>

        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Daftar <?= $PageTitle ?></h3>
                <div class="card-tools">
                    <?php
                    if ($MethodForm1 != "updateData") {
                    ?>
                    <button class='btn bg-gradient-primary mx-1' data-target="#modalViewRmpp" data-toggle="modal"
                        style="float: right;" onclick="showRmpp()"><i class="fas fa-file-archive"></i>
                        AMBIL REKAM MEDIK</button>

                    <button class='btn bg-gradient-success mx-1' style="float: right;"
                        onclick="showForm('<?= $IdForm ?>', 'block');"><i class="fas fa-plus"></i>
                        TAMBAH</button>

                    <?php
                    }
                    ?>
                    <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                            class="fas fa-minus"></i></button>
                    <button type="button" class="btn btn-tool" data-card-widget="remove"><i
                            class="fas fa-remove"></i></button>
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table id="datatableKirana" class="table responsive table-bordered table-striped w-100">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>No. RM</th>
                            <th class="text-nowrap">Nama Pasien</th>
                            <th class="text-nowrap">Tanggal Lahir</th>
                            <th class="text-nowrap">Jenis Kelamin</th>
                            <th>Aksi</th>
                            <th class="text-nowrap">Tanggal Masuk IGD</th>
                            <th class="text-nowrap">Jam Masuk IGD</th>
                            <th>Alamat</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 0;
                        foreach ($Rmpmsk as $tk) : $no++ ?>
                        <tr>
                            <td><?= $no ?></td>
                            <td>
                                <h2><span class="badge badge-success"><?= $tk['rs_rmpp_rm'] ?></span></h2>
                            </td>
                            <td><?= $tk['rs_rmpp_nm'] ?></td>
                            <td><?= $tk['rs_rmpp_tgl_lhr'] ?></td>
                            <td><?= $tk['rs_rmpp_jk'] ?></td>
                            <td>
                                <a href="/rmpmskd/viewData/<?= $tk['rs_rmpmsk_id_ex'] ?>"
                                    class="btn bg-gradient-info m-1" title="Triage Gawat Darurat"><i
                                        class="fa fa-user-injured"></i> Detail Pasien</a>
                            </td>
                            <td><?= $tk['rs_rmpmsk_tgl'] ?></td>
                            <td><?= $tk['rs_rmpmsk_jam'] ?></td>
                            <td class="text-nowrap"><?= $tk['rs_rmpmsk_alt'] ?></td>
                        </tr>
                        <?php endforeach ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th>No</th>
                            <th>No. RM</th>
                            <th>Nama Pasien</th>
                            <th>Tanggal Lahir</th>
                            <th>Jenis Kelamin</th>
                            <th>Tanggal Masuk IGD</th>
                            <th>Jam Masuk IGD</th>
                            <th>Aksi</th>
                            <th>Alamat</th>
                        </tr>
                    </tfoot>
                </table>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
</div>
<?= $this->include('Rmpmsk/modalViewRmpp'); ?>
<?= $this->include('Rmpmsk/modalChangeWktu'); ?>
<script>
function addFill(idComp = '', fill = '') {
    document.getElementById(idComp).value = fill;
}
</script>
<script>
$(document).ready(function() {
    $('#datatableKirana').DataTable({
        "order": [
            [0, "asc"]
        ],
        pageLength: 10,
        responsive: true,
        fixedHeader: false,
        keys: true,
        columnDefs: [{
                responsivePriority: 1,
                target: 0
            },
            {
                responsivePriority: 10001,
                target: 4
            },
            {
                responsivePriority: 2,
                target: -2
            }
        ]
    });
});
</script>

<?= $this->endSection(); ?>