<div class="modal fade bd-example-modal-lg" id="modalViewRmpp" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabelPdf">LIHAT DATA PASIEN REKAM MEDIK </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <table id="dt" class="table responsive table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Aksi</th>
                            <th class="text-nowrap">No. RM</th>
                            <th class="text-nowrap">Nama Pasien</th>
                            <th class="text-nowrap">Tanggal Lahir</th>
                            <th class="text-nowrap">Jenis Kelamin</th>
                            <th>Alamat</th>
                        </tr>
                    </thead>
                </table>

                <script type="text/javascript">
                    function showRmpp() {

                        var dt = $('#dt').DataTable({
                            ajax: "<?= base_url('rmpp/getRmppByJson') ?>",
                            "order": [
                                [0, "asc"]
                            ],
                            destroy: true,
                            pageLength: 10,
                            responsive: true,
                            fixedHeader: false,
                            keys: true,
                            language: {
                                paginate: {
                                    previous: "Sebelumnya",
                                    next: "Selanjutnya"
                                },
                                "emptyTable": "Data Pasien Belum Ada",
                            },
                            columns: [{
                                    "data": "no"
                                },
                                {
                                    "data": "button"
                                },
                                {
                                    "data": "rs_rmpp_rm"
                                },
                                {
                                    "data": "rs_rmpp_nm"
                                },
                                {
                                    "data": "rs_rmpp_tgl_lhr"
                                },
                                {
                                    "data": "rs_rmpp_jk"
                                },
                                {
                                    "data": "rs_rmpp_altktp"
                                },
                            ],
                            columnDefs: [{
                                className: "text-nowrap",
                                "targets": [6]
                            }]
                        });
                    }
                </script>
            </div>
            <div class="modal-footer">
                <div class="item form-group">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">TUTUP</button>
                </div>
            </div>
        </div>
    </div>
</div>