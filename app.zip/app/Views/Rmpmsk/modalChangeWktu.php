<div class="modal fade" id="modalChangeWktu" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">
        <form id="changeWktu" method="POST" action="/<?= $BasePage ?>/insertDataRmpp" enctype="multipart/form-data">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">TAMBAH WAKTU MASUK IGD</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <input type="hidden" name="rs_rmpmsk_rmpp" id="rs_rmpmsk_rmpp" value="">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">REGISTRASI PASIEN</h3>
                        </div>
                        <div class="card-body">

                            <div class="form-group">
                                <label for="rs_rmpmsk_tgl">Tanggal Masuk RS</label>
                                <input type="date" class="form-control" id="rs_rmpmsk_tgl" name="rs_rmpmsk_tgl" required>
                            </div>

                            <div class="bootstrap-timepicker">
                                <div class="form-group">
                                    <label for="rs_rmpmsk_jam">Jam Masuk RS</label>
                                    <div class="input-group date" id="timepickerMsk" data-target-input="nearest">
                                        <input type="text" class="form-control datetimepicker-input" data-target="#timepickerMsk" id="rs_rmpmsk_jam" name="rs_rmpmsk_jam" required>
                                        <div class="input-group-append" data-target="#timepickerMsk" data-toggle="datetimepicker">
                                            <div class="input-group-text"><i class="far fa-clock"></i></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /.card-body -->
                    </div>

                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">DATA UMUM PASIEN</h3>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="rs_rmpmsk_pr">Pernah Dirawat Di RS Sebelumnya</label>
                                        <select name="rs_rmpmsk_pr" id="rs_rmpmsk_pr" class="form-control" required>
                                            <option hidden>PILIH SALAH SATU PILIHAN </option>
                                            <option value="1">Tidak</option>
                                            <option value="2">Ya</option>
                                        </select>

                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="rs_rmpmsk_rd">Rawat Di</label>
                                        <input type="text" class="form-control" id="rs_rmpmsk_rd" name="rs_rmpmsk_rd">
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <label for="rs_rmpmsk_rjkd">Dikirim / Rujuk Dari</label>
                                        <input type="text" class="form-control" id="rs_rmpmsk_rjkd" name="rs_rmpmsk_rjkd">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="rs_rmpp_nm">Nama Pasien</label>
                                <input type="text" class="form-control" id="rs_rmpp_nm1" name="rs_rmpp_nm" disabled>
                            </div>

                            <div class="form-group">
                                <label for="rs_rmpp_rm">No. RM</label>
                                <input type="text" class="form-control" id="rs_rmpp_rm" name="rs_rmpp_rm" disabled>
                            </div>

                            <div class="form-group">
                                <label for="rs_rmpp_ind">No. Identitas (KTP / SIM / NIK)</label>
                                <input type="text" class="form-control" id="rs_rmpp_ind1" name="rs_rmpp_ind" disabled>
                            </div>

                            <div class="form-group">
                                <label for="rs_rmpmsk_alt">Alamat Saat Ini</label>
                                <textarea cols="30" rows="2" type="text" class="form-control" id="rs_rmpmsk_alt" name="rs_rmpmsk_alt"></textarea>
                            </div>

                            <div class="form-group">
                                <label for="rs_rmpmsk_rmsts">Status Pernikahan</label>
                                <select name="rs_rmpmsk_rmsts" id="rs_rmpmsk_rmsts" class="form-control">
                                    <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
                                    <?php foreach ($Rmsts as $tk) : ?>
                                        <option value="<?= $tk['rs_rmsts_id_ex'] ?>"><?= $tk['rs_rmsts_nm'] ?></option>
                                    <?php endforeach ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="rs_rmpmsk_rmpdk">Pendidikan</label>
                                <select name="rs_rmpmsk_rmpdk" id="rs_rmpmsk_rmpdk" class="form-control">
                                    <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
                                    <?php foreach ($Rmpdk as $tk) : ?>
                                        <option value="<?= $tk['rs_rmpdk_id_ex'] ?>"><?= $tk['rs_rmpdk_nm'] ?></option>
                                    <?php endforeach ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="rs_rmpmsk_rmkrj">Pekerjaan</label>
                                <select name="rs_rmpmsk_rmkrj" id="rs_rmpmsk_rmkrj" class="form-control">
                                    <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
                                    <?php foreach ($Rmkrj as $tk) : ?>
                                        <option value="<?= $tk['rs_rmkrj_id_ex'] ?>"><?= $tk['rs_rmkrj_nm'] ?></option>
                                    <?php endforeach ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="rs_rmpmsk_pp">Perlu Penerjemah</label>
                                <select name="rs_rmpmsk_pp" id="rs_rmpmsk_pp" class="form-control">
                                    <option hidden>PILIH SALAH SATU PILIHAN</option>
                                    <option value="0">Tidak</option>
                                    <option value="1">Ya</option>
                                </select>
                            </div>
                        </div>

                    </div>

                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">PENANGGUNG JAWAB / KELUARGA TERDEKAT</h3>
                        </div>
                        <div class="card-body">
                            <div class="form-group">
                                <label for="rs_rmpmskpj_pj">Ada Penganggung Jawab / Keluarga</label>
                                <select name="rs_rmpmskpj_pj" id="rs_rmpmskpj_pj" class="form-control" required>
                                    <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
                                    <option value="0">Tidak Ada</option>
                                    <option value="1">Ada</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="rs_rmpmskpj_n">Nama Penanggung Jawab</label>
                                <input type="text" class="form-control" id="rs_rmpmskpj_n" name="rs_rmpmskpj_n" required>
                            </div>

                            <div class="form-group">
                                <label for="rs_rmpmsk_pjind">No. Identitas Penanggung Jawab (SIM/KTP)</label>
                                <input type="text" class="form-control" id="rs_rmpmsk_pjind" name="rs_rmpmsk_pjind">
                            </div>

                            <div class="form-group">
                                <label for="rs_rmpmskpj_jk">Jenis Kelamin</label>
                                <select name="rs_rmpmskpj_jk" id="rs_rmpmskpj_jk" class="form-control" required>
                                    <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
                                    <option value="L">LAKI-LAKI</option>
                                    <option value="P">PEREMPUAN</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="rs_rmpmskpj_rmhub">Hubungan Dengan Pasien</label>
                                <select name="rs_rmpmskpj_rmhub" id="rs_rmpmskpj_rmhub" class="form-control" required>
                                    <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
                                    <?php foreach ($Rmhub as $tk) : ?>
                                        <option value="<?= $tk['rs_rmhub_id_ex'] ?>"><?= $tk['rs_rmhub_nm'] ?></option>
                                    <?php endforeach ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="rs_rmpmsk_pjalt">Alamat Tempat Tinggal</label>
                                <textarea cols="30" rows="2" type="text" class="form-control" id="rs_rmpmsk_pjalt" name="rs_rmpmsk_pjalt"></textarea>
                            </div>

                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="rs_rmpmsk_pjaltktp">Alamat KTP</label>
                                        <textarea cols="30" rows="1" type="text" class="form-control" id="rs_rmpmsk_pjaltktp" name="rs_rmpmsk_pjaltktp"></textarea>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="rs_rmpmsk_pjaltn">No.</label>
                                        <input type="text" class="form-control" id="rs_rmpmsk_pjaltn" name="rs_rmpmsk_pjaltn">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="rs_rmpmsk_pjaltr">RT / RW</label>
                                        <input type="text" class="form-control" id="rs_rmpmsk_pjaltr" name="rs_rmpmsk_pjaltr">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="rs_rmpmsk_pjaltkk">Kelurahan / Kecamatan</label>
                                        <input type="text" class="form-control" id="rs_rmpmsk_pjaltkk" name="rs_rmpmsk_pjaltkk">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="rs_rmpmsk_pjaltkp">Kota / Kode Pos</label>
                                        <input type="text" class="form-control" id="rs_rmpmsk_pjaltkp" name="rs_rmpmsk_pjaltkp">
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="rs_rmpmsk_pjaltth">Telepon / HP</label>
                                        <input type="text" class="form-control" id="rs_rmpmsk_pjaltth" name="rs_rmpmsk_pjaltth">
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="rs_rmpmskpj_rmpdk">Pendidikan</label>
                                <select name="rs_rmpmskpj_rmpdk" id="rs_rmpmskpj_rmpdk" class="form-control">
                                    <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
                                    <?php foreach ($Rmpdk as $tk) : ?>
                                        <option value="<?= $tk['rs_rmpdk_id_ex'] ?>"><?= $tk['rs_rmpdk_nm'] ?></option>
                                    <?php endforeach ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="rs_rmpmskpj_rmkrj">Pekerjaan</label>
                                <select name="rs_rmpmskpj_rmkrj" id="rs_rmpmskpj_rmkrj" class="form-control">
                                    <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
                                    <?php foreach ($Rmkrj as $tk) : ?>
                                        <option value="<?= $tk['rs_rmkrj_id_ex'] ?>"><?= $tk['rs_rmkrj_nm'] ?></option>
                                    <?php endforeach ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">DATA SOSIAL, EKONOMI DAN FUNGSIONAL</h3>
                        </div>
                        <div class="card-body">
                            <div class="form-group">
                                <label for="rs_rmpmsk_cp">Cara Pembayaran</label>
                                <select name="rs_rmpmsk_cp" id="rs_rmpmsk_cp" class="form-control" required>
                                    <option hidden value="">PILIH SALAH SATU PILIHAN</option>
                                    <option value="TN">Tunai</option>
                                    <option value="AS">ASURANSI</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="rs_rmpmsk_rma">Daftar Asuransi</label>
                                <select name="rs_rmpmsk_rma" id="rs_rmpmsk_rma" class="form-control">
                                    <option hidden value="">PILIH SALAH SATU PILIHAN</option>
                                    <?php foreach ($Rma as $tk) : ?>
                                        <option value="<?= $tk['rs_rma_id_ex'] ?>"><?= $tk['rs_rma_nm'] ?></option>
                                    <?php endforeach ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="rs_rmpmsk_anmr">Nomor Asuransi (Jika Ada)</label>
                                <input type="text" class="form-control" id="rs_rmpmsk_anmr" name="rs_rmpmsk_anmr">
                            </div>



                            <div class="form-group">
                                <label for="rs_rmpmsk_rmtgl">Tinggal Dengan Siapa</label>
                                <select name="rs_rmpmsk_rmtgl" id="rs_rmpmsk_rmtgl" class="form-control">
                                    <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
                                    <?php foreach ($Rmtgl as $tk) : ?>
                                        <option value="<?= $tk['rs_rmtgl_id_ex'] ?>"><?= $tk['rs_rmtgl_nm'] ?></option>
                                    <?php endforeach ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="rs_rmpmsk_rmab">Penggunaan Alat Bantu Diri</label>
                                <select name="rs_rmpmsk_rmab" id="rs_rmpmsk_rmab" class="form-control">
                                    <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
                                    <?php foreach ($Rmab as $tk) : ?>
                                        <option value="<?= $tk['rs_rmab_id_ex'] ?>"><?= $tk['rs_rmab_nm'] ?></option>
                                    <?php endforeach ?>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="item form-group">
                        <button type="submit" class="btn btn-success">SIMPAN</button>
                        <button type="button" class="btn btn-primary" data-dismiss="modal">BATAL</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<script>
    $(function() {
        //Timepicker
        $('#timepickerMsk').datetimepicker({
            format: 'HH:mm',
            use24hours: true
        })
    });
</script>

<script>
    $(function() {
        $(document).ready(function() {
            var changeWktu = $('#changeWktu');
            changeWktu.submit(function(e) {
                showAnimated();
                $('#changeWktu :input').prop("disabled", false);
                $(this).attr('disabled', 'disabled');

                e.preventDefault();
                $.ajax({
                    type: changeWktu.attr('method'),
                    url: changeWktu.attr('action'),
                    enctype: 'multipart/form-data',
                    data: new FormData(this),
                    contentType: false,
                    processData: false,
                    dataType: 'json',
                    success: function(data) {
                        hideAnimated();
                        if (data.response == "success") {
                            swal.fire({
                                title: "Terima Kasih",
                                text: data.message,
                                icon: data.response
                            }).then(function() {
                                window.location = '/<?= $UrlForm ?>';
                            });
                        } else {
                            hideAnimated();
                            swal.fire({
                                title: "Tidak Dapat Melanjutkan Proses",
                                text: data.message,
                                icon: data.response
                            });
                        }
                    },
                    error: function(xhr) {
                        hideAnimated();
                        console.log(xhr);
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: xhr.responseJSON.message,
                            icon: "error"
                        });
                    }
                });
            });
        });
    });
</script>