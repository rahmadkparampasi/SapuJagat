<div class="card card-primary" style="
    <?php
    if ($MethodForm1 == "updateData") {
        echo 'display: flex;';
    } else {
        echo 'display: none;';
    } ?>" id="<?= $IdForm ?>card">
    <div class="card-header">
        <h3 class="card-title">Form Tambah <?= $PageTitle ?></h3>
    </div>
    <!-- /.card-header -->
    <!-- form start -->
    <form method="POST" class="form-valide" action="/<?= $BasePage ?>/<?= $MethodForm ?>" id="<?= $IdForm ?>" enctype="multipart/form-data">
        <?php
        if ($MethodForm1 == "updateData") {
            echo "<input type='hidden' name='rs_rmtdkp_id_ex' id='rs_rmtdkp_id_ex'>";
        }
        ?>
        <input type='hidden' name='rs_rmtdkp_rmtdk' id='rs_rmtdkp_rmtdk' value="<?= $rs_rmtdkp_rmtdk ?>">
        <div class="card-body">
            <div class="form-group">
                <label for="rs_rmtdkp_p">Parameter</label>
                <input type="text" class="form-control" id="rs_rmtdkp_p" name="rs_rmtdkp_p" required>
            </div>
            <div class="form-group">
                <label for="rs_rmtdkp_nr">Nilai Rujukan</label>
                <input type="text" class="form-control" id="rs_rmtdkp_nr" name="rs_rmtdkp_nr" required>
            </div>
            <div class="form-group">
                <label for="rs_rmtdkp_rmsl">Satuan</label>
                <select class="form-control" id="rs_rmtdkp_rmsl" name="rs_rmtdkp_rmsl" required>
                    <option value="" hidden>Pilih Salah Satu Pilihan</option>
                    <?php foreach ($Rmsl as $tkd) : ?>
                        <option value="<?= $tkd['rs_rmsl_id_ex'] ?>"><?= $tkd['rs_rmsl_nm'] ?></option>
                    <?php endforeach ?>
                </select>
            </div>
            <div class="form-group">
                <label for="rs_rmtdkp_ind">Indeks</label>
                <input type="number" class="form-control" id="rs_rmtdkp_ind" name="rs_rmtdkp_ind" required>
            </div>
        </div>
        <!-- /.card-body -->

        <div class="card-footer">
            <button type="submit" class="btn bg-gradient-primary"><?= $ButtonMethod ?></button>
            <?php
            $MethodForm = substr($MethodForm, 0, 10);
            if ($MethodForm == "updateData") {
            ?>
                <a href="/<?= $BasePage ?>" class='btn bg-gradient-danger' aria-pressed="true">BATAL</a>
            <?php
            } else {
            ?>
                <button type="button" class="btn bg-gradient-danger" onclick="closeForm('<?= $IdForm ?>card', '<?= $IdForm ?>')">BATAL</button>

            <?php
            }
            ?>
        </div>
    </form>
</div>

<script>
    $(function() {
        $(document).ready(function() {
            var <?= $IdForm ?> = $('#<?= $IdForm ?>');
            <?= $IdForm ?>.submit(function(e) {
                showAnimated();
                $('#<?= $IdForm ?> :input').prop("disabled", false);
                $(this).attr('disabled', 'disabled');
                e.stopPropagation();
                e.preventDefault();
                $.ajax({
                    type: <?= $IdForm ?>.attr('method'),
                    url: <?= $IdForm ?>.attr('action'),
                    enctype: 'multipart/form-data',
                    data: new FormData(this),
                    contentType: false,
                    processData: false,
                    dataType: 'json',
                    success: function(data) {
                        hideAnimated();
                        if (data.response == "success") {
                            swal.fire({
                                title: "Terima Kasih",
                                text: data.message,
                                icon: data.response
                            }).then(function() {
                                showRmtdkp('<?= $rs_rmtdkp_rmtdk ?>');
                            });
                        } else {
                            hideAnimated();
                            swal.fire({
                                title: "Tidak Dapat Melanjutkan Proses",
                                text: data.message,
                                icon: data.response
                            });
                        }
                    },
                    error: function(xhr) {
                        hideAnimated();
                        console.log(xhr);
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: xhr.responseJSON.message,
                            icon: "error"
                        });
                    }
                });
            });
        });
    });
</script>