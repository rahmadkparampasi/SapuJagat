<?= $this->include('Rmtdkp/addData'); ?>
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Daftar Parameter <?= $PageTitle ?></h3>
        <div class="card-tools">
            <?php
            if ($MethodForm1 != "updateData") {
            ?>
                <button class='btn bg-gradient-success' role="button" aria-pressed="true" style="float: right;" onclick="showForm('<?= $IdForm ?>card')"><i class="fas fa-plus"></i>
                    TAMBAH</button>
            <?php
            }
            ?>
            <button class='btn bg-gradient-danger mx-1' role="button" aria-pressed="true" style="float: right;" onclick="closeRmtdkp()"><i class="fas fa-ban"></i>
                TUTUP</button>
        </div>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
        <table class="dtKd table responsive table-bordered table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Parameter</th>
                    <th>Nilai Rujukan</th>
                    <th>Satuan</th>
                    <th>Indeks</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 0;
                foreach ($Rmtdkp as $tk) : $no++ ?>
                    <tr>
                        <td><?= $no ?></td>
                        <td><?= $tk['rs_rmtdkp_p'] ?></td>
                        <td><?= $tk['rs_rmtdkp_nr'] ?></td>
                        <td><?= $tk['rs_rmsl_nm'] ?></td>
                        <td><?= $tk['rs_rmtdkp_ind'] ?></td>

                        <td>
                            <button class="btn bg-gradient-info" title="Parameter Tindakan" onclick="showRmtdkpk('<?= $tk['rs_rmtdkp_id_ex'] ?>')">
                                <i class='fas fa-procedures'></i> Kritis
                            </button>
                            <?php
                            if ($tk['rs_rmtdkp_sts'] == "1") {
                            ?>
                                <button class="btn bg-gradient-success" title="Parameter Tindakan Aktif" onclick="addWF('Menonaktifkan <?= $tk['rs_rmtdkp_p'] ?> Dalam Data Parameter Tindakan', '<?= $BasePage ?>/blockTdkP/<?= $tk['rs_rmtdkp_id_ex'] ?>', showRmtdkp, '<?= $rs_rmtdkp_rmtdk ?>')">
                                    <i class='fas fa-check'></i>
                                </button>
                            <?php
                            } else {
                            ?>
                                <button class="btn bg-gradient-danger" title="Parameter Tindakan Tidak Aktif" onclick="addWF('Mengaktifkan <?= $tk['rs_rmtdkp_p'] ?> Dalam Data Parameter Tindakan', '<?= $BasePage ?>/unblockTdkP/<?= $tk['rs_rmtdkp_id_ex'] ?>', showRmtdkp, '<?= $rs_rmtdkp_rmtdk ?>')">
                                    <i class='fas fa-ban'></i>
                                </button>
                            <?php
                            }
                            ?>
                        </td>
                    </tr>
                <?php endforeach ?>
            </tbody>

        </table>
    </div>
    <!-- /.card-body -->
</div>

<script>
    function addWF(m, l, f, v) {
        callOtherWF(m, l, f, '', v);
    }
    $(document).ready(function() {
        dTD('table.dtKd')
    });
</script>