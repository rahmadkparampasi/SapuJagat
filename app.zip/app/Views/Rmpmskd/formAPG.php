<form class="form-horizontal form-valide" style="display: none;" method="POST" action="/rmpapg/<?= $MethodForm ?>"
    id="formTabAPG">
    <h4 class="text-center">Form Data Anamnesis Permasalahan Gizi</h4>

    <div class="form-group row">
        <label for="rs_rmpapg_pbb" class="col-sm-2 col-form-label">Adakah Penurunan Berat Badan Signifikan Dalam 3 Bulan
            Terakhir :</label>
        <div class="col-sm-10">
            <select name="rs_rmpapg_pbb" id="rs_rmpapg_pbb" class="form-control" required>
                <option hidden value="">PILIH SALAH SATU PILIHAN</option>
                <option value="0">Tidak</option>
                <option value="1">Ya</option>
            </select>
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmpapg_imk" class="col-sm-2 col-form-label">Intake Makanan Kurang Karena Tidak Ada Nafsu Makan
            :</label>
        <div class="col-sm-10">
            <select name="rs_rmpapg_imk" id="rs_rmpapg_imk" class="form-control" required>
                <option hidden value="">PILIH SALAH SATU PILIHAN</option>
                <option value="0">Tidak</option>
                <option value="1">Ya</option>
            </select>
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmpapg_kk" class="col-sm-2 col-form-label">Kondisi Khusus</label>
        <div class="col-sm-10">
            <input type="text" name="rs_rmpapg_kk" id="rs_rmpapg_kk" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmpapg_skor" class="col-sm-2 col-form-label">Skor</label>
        <div class="col-sm-10">
            <input type="number" name="rs_rmpapg_skor" id="rs_rmpapg_skor" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmpapg_skord" class="col-sm-2 col-form-label">Jika Skor Diatas 2: </label>
        <div class="col-sm-10">
            <select name="rs_rmpapg_skord" id="rs_rmpapg_skord" class="form-control" required>
                <option hidden value="">PILIH SALAH SATU PILIHAN</option>
                <option value="0">Tidak</option>
                <option value="1">Ya</option>
            </select>
        </div>
    </div>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-primary">SIMPAN</button>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('formTabAPG', 'formTabAPG')">BATAL</button>
        </div>
    </div>
    <hr>
</form>

<div>
    <h4 class="text-center">Daftar Data Anamnesis Permasalahan Gizi</h4>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-success <?= $eEdit ?>" style="float: right;"
                onclick="showForm('formTabAPG', 'block'); resetForm('formTabAPG')"><i class="fas fa-plus"></i>
                Tambah</button>
        </div>
    </div>
    <table id="dtKformTabAPG" class="dtK table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Adakah Penurunan Berat Badan Signifikan Dalam 3 Bulan Terakhir :</th>
                <th>Intake Makanan Kurang Karena Tidak Ada Nafsu Makan :</th>
                <th>Kondisi Khusus</th>
                <th>Skor</th>
                <th>Jika Skor Diatas 2:</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Rmpapg as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td>
                <td>
                    <?= $tk['rs_rmpapg_pbb'] ?>
                </td>
                <td>
                    <?= $tk['rs_rmpapg_imk'] ?>
                </td>
                <td>
                    <p id="rs_rmpapg_kkc"><?= $tk['rs_rmpapg_kk'] ?></p> <button class="btn bg-gradient-primary"
                        onclick="copyTextTOC('rs_rmpapg_kkc')"><i class="fa fa-clipboard"></i></button>
                </td>
                <td>
                    <?= $tk['rs_rmpapg_skor'] ?>
                </td>
                <td>
                    <?= $tk['rs_rmpapg_skord'] ?>
                </td>
                <td>
                    <?php
                        if ($MethodForm1 != "updateData") {
                        ?>
                    <button class="btn bg-gradient-danger <?= $eEdit ?>"
                        title="Hapus Data Anamnesis Permasalahan Gizi Pasien"
                        onclick="callOther('Menghapus Data Anamnesis Permasalahan Gizi Pasien', '/rmpapg/deleteData/<?= $tk['rs_rmpapg_id_ex'] ?>')">
                        <i class='fas fa-trash'></i></button>
                    <?php
                        }
                        ?>
                </td>
            </tr>
            <?php endforeach ?>
        </tbody>

    </table>
</div>

<script>
$(function() {
    $(document).ready(function() {
        var formTabAPG = $('#formTabAPG');
        formTabAPG.submit(function(e) {
            showAnimated();
            $('#formTabAPG :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');

            e.preventDefault();
            $.ajax({
                type: formTabAPG.attr('method'),
                url: formTabAPG.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            window.location = '/<?= $UrlForm ?>';
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>