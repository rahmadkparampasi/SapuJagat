<div class="modal fade bd-example-modal-lg" id="modalViewRmIcdn" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabelPdf">LIHAT DATA ICD 9 </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <table id="dtkIcd9" class="table responsive table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Aksi</th>
                            <th>Kode</th>
                            <th>Tindakan</th>
                            <th>Uraian</th>
                        </tr>
                    </thead>
                </table>

                <script type="text/javascript">
                    function showRmIcdn(name = '', idEx = '') {

                        var dt = $('#dtkIcd9').DataTable({
                            ajax: "<?= base_url('rmicdn/getRmicdnByJson') ?>/" + name + "/" + idEx,
                            "order": [
                                [0, "asc"]
                            ],
                            destroy: true,
                            pageLength: 10,
                            responsive: true,
                            fixedHeader: false,
                            keys: true,
                            language: {
                                paginate: {
                                    previous: "Sebelumnya",
                                    next: "Selanjutnya"
                                },
                                "emptyTable": "Data ICD 9 Belum Ada",
                            },
                            columns: [{
                                    "data": "no"
                                },
                                {
                                    "data": "button"
                                },
                                {
                                    "data": "rs_rmicdn_kd"
                                },
                                {
                                    "data": "rs_rmicdn_nm"
                                },
                                {
                                    "data": "rs_rmicdn_ur"
                                },
                            ]
                        });
                    }

                    function destroyIcdn() {
                        $('#dtkIcd9').DataTable({
                            destroy: true,
                        });
                    }
                </script>
            </div>
            <div class="modal-footer">
                <div class="item form-group">
                    <button type="button" class="btn btn-danger" data-dismiss="modal" onclick="destroyIcdn()">TUTUP</button>
                </div>
            </div>
        </div>
    </div>
</div>