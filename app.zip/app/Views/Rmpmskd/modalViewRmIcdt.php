<div class="modal fade bd-example-modal-lg" id="modalViewRmIcdt" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabelPdf">LIHAT DATA ICD 10 </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <table id="dtkIcd10" class="table responsive table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Aksi</th>
                            <th class="text-nowrap">Kode</th>
                            <th class="text-nowrap">Diagnosa</th>
                        </tr>
                    </thead>
                </table>

                <script type="text/javascript">
                    function showRmIcdt(name = '', idEx = '') {

                        var dt = $('#dtkIcd10').DataTable({
                            ajax: "<?= base_url('rmicdt/getRmicdtByJson') ?>/" + name + "/" + idEx,
                            "order": [
                                [0, "asc"]
                            ],
                            destroy: true,
                            pageLength: 10,
                            responsive: true,
                            fixedHeader: false,
                            keys: true,
                            language: {
                                paginate: {
                                    previous: "Sebelumnya",
                                    next: "Selanjutnya"
                                },
                                "emptyTable": "Data ICD 10 Belum Ada",
                            },
                            columns: [{
                                    "data": "no"
                                },
                                {
                                    "data": "button"
                                },
                                {
                                    "data": "rs_rmicdt_kd"
                                },
                                {
                                    "data": "rs_rmicdt_nm"
                                },
                            ]
                        });
                    }

                    function destroyIcdt() {
                        $('#dtkIcd10').DataTable({
                            destroy: true,
                        });
                    }
                </script>
            </div>
            <div class="modal-footer">
                <div class="item form-group">
                    <button type="button" class="btn btn-danger" data-dismiss="modal" onclick="destroyIcdt()">TUTUP</button>
                </div>
            </div>
        </div>
    </div>
</div>