<form class="form-horizontal form-valide" style="display: none;" method="POST" action="/rmpaku/<?= $MethodForm ?>"
    id="formTabAKU">
    <h4 class="text-center">Form Data Anamnesis Keluhan Utama</h4>

    <div class="form-group row">
        <label for="rs_rmpaku_ku" class="col-sm-2 col-form-label">Anamnesis Keluhan Utama</label>
        <div class="col-sm-10">
            <textarea name="rs_rmpaku_ku" id="rs_rmpaku_ku" class="form-control w-100 " cols="30" rows="10"
                required></textarea>
        </div>
    </div>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-primary">SIMPAN</button>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('formTabAKU', 'formTabAKU')">BATAL</button>
        </div>
    </div>
    <hr>
</form>

<div>
    <h4 class="text-center">Daftar Data Anamnesis Keluhan Utama</h4>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-success <?= $eEdit ?>" style="float: right;"
                onclick="showForm('formTabAKU', 'block'); resetForm('formTabAKU')"><i class="fas fa-plus"></i>
                Tambah</button>
        </div>
    </div>
    <table id="dtKformTabAKU" class="dtK table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Anamnesis Keluhan Utama</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Rmpaku as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td>
                <td>
                    <p id="rs_rmpaku_kuc"><?= $tk['rs_rmpaku_ku'] ?></p> <button class="btn bg-gradient-primary"
                        onclick="copyTextTOC('rs_rmpaku_kuc')"><i class="fa fa-clipboard"></i> Salin Teks</button>
                </td>
                <td>
                    <?php
                        if ($MethodForm1 != "updateData") {
                        ?>
                    <button class="btn bg-gradient-danger <?= $eEdit ?>"
                        title="Hapus Data Anamnesis Keluhan Utama Pasien"
                        onclick="callOther('Menghapus Data Anamnesis Keluhan Utama Pasien', '/rmpaku/deleteData/<?= $tk['rs_rmpaku_id_ex'] ?>')">
                        <i class='fas fa-trash'></i></button>
                    <?php
                        }
                        ?>
                </td>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>

<script>
$(function() {
    $(document).ready(function() {
        var formTabAKU = $('#formTabAKU');
        formTabAKU.submit(function(e) {
            showAnimated();
            $('#formTabAKU :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');

            e.preventDefault();
            $.ajax({
                type: formTabAKU.attr('method'),
                url: formTabAKU.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            window.location = '/<?= $UrlForm ?>';
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>