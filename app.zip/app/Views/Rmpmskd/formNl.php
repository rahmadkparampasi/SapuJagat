<div class="row">
    <div class="col-lg-2 col-md-3 col-sm-12">
        <div class="nav flex-column nav-pills" id="v-pills-tab-icd" role="tablist" aria-orientation="vertical">
            <a class="nav-link" id="vTabNlFPar" data-toggle="pill" href="#vTabNlFItem" role="tab" aria-controls="vTabNlFItem" aria-selected="true" onclick="addSess('tabVParent', 'vTabNlFPar'); addSess('tabVItem', 'vTabNlFItem');">Fisik</a>
            <a class="nav-link" id="vTabNlNPar" data-toggle="pill" href="#vTabNlNItem" role="tab" aria-controls="vTabNlNItem" aria-selected="false" onclick="addSess('tabVParent', 'vTabNlNPar'); addSess('tabVItem', 'vTabNlNItem');">Nyeri</a>
            <a class="nav-link" id="vTabNlPPar" data-toggle="pill" href="#vTabNlPItem" role="tab" aria-controls="vTabNlPItem" aria-selected="false" onclick="addSess('tabVParent', 'vTabNlPPar'); addSess('tabVItem', 'vTabNlPItem');">Status Pediatric</a>
            <a class="nav-link" id="vTabNlDPar" data-toggle="pill" href="#vTabNlDItem" role="tab" aria-controls="vTabNlDItem" aria-selected="false" onclick="addSess('tabVParent', 'vTabNlDPar'); addSess('tabVItem', 'vTabNlDItem');">Diagnosis</a>
        </div>
    </div>
    <div class="col-lg-10 col-md-9 col-sm-12">
        <div class="tab-content" id="v-pills-tabContent-icd">
            <div class="tab-pane fade" id="vTabNlFItem" role="tabpanel" aria-labelledby="vTabNlFPar">
                <?= $this->include('/Rmpmskd/formNlF'); ?>
            </div>
            <div class="tab-pane fade" id="vTabNlNItem" role="tabpanel" aria-labelledby="vTabNlNPar">
                <?= $this->include('/Rmpmskd/formNlN'); ?>
            </div>
            <div class="tab-pane fade" id="vTabNlPItem" role="tabpanel" aria-labelledby="vTabNlPPar">
                <?= $this->include('/Rmpmskd/formNlS'); ?>
            </div>
            <div class="tab-pane fade" id="vTabNlDItem" role="tabpanel" aria-labelledby="vTabNlDPar">
                <?= $this->include('/Rmpmskd/formNlD'); ?>
            </div>
        </div>
    </div>
</div>