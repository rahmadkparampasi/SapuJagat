<form class="form-horizontal form-valide" style="display: none;" method="POST" action="/rmplpa/<?= $MethodForm ?>"
    id="formTabLPA">
    <h4 class="text-center">Form Data Hasil Patologi Anatomi</h4>

    <div class="form-group row">
        <label for="" class="col-sm-2 col-form-label">Tanggal</label>
        <div class="col-sm-10">
            <input type="date" id="" name="" required class="form-control">
        </div>
    </div>

    <div class="bootstrap-timepicker">
        <div class="form-group row">
            <label for="rs_rmpplg_jam" class="col-sm-2 col-form-label">Waktu</label>
            <div class="col-sm-10">
                <div class="input-group date" id="timepickerRmplpa" data-target-input="nearest">
                    <input type="text" class="form-control datetimepicker-input" data-target="#timepickerRmplpa"
                        id="rs_rmpplg_jam" name="rs_rmpplg_jam" required>
                    <div class="input-group-append" data-target="#timepickerRmplpa" data-toggle="datetimepicker">
                        <div class="input-group-text"><i class="far fa-clock"></i></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
    $(function() {
        //Timepicker
        $('#timepickerRmplpa').datetimepicker({
            format: 'HH:mm',
            use24hours: true
        })
    });
    </script>

    <div class="form-group row">
        <label for="" class="col-sm-2 col-form-label">Lokasi</label>
        <div class="col-sm-10">
            <input type="text" id="" name="" required class="form-control">
        </div>
    </div>

    <div class="form-group row">
        <label for="" class="col-sm-2 col-form-label">Didapat Dengan</label>
        <div class="col-sm-10">
            <input type="text" id="" name="" required class="form-control">
        </div>
    </div>

    <div class="form-group row">
        <label for="" class="col-sm-2 col-form-label">Cairan Fiksasi</label>
        <div class="col-sm-10">
            <textarea class="form- w-100" name="" id="" rows="3" cols="10"></textarea>
        </div>
    </div>

    <div class="form-group row">
        <label for="" class="col-sm-2 col-form-label">Diagnosa Klinik</label>
        <div class="col-sm-10">
            <textarea class="form- w-100" name="" id="" rows="3" cols="10"></textarea>
        </div>
    </div>

    <div class="form-group row">
        <label for="" class="col-sm-2 col-form-label">Keterangan Klinik</label>
        <div class="col-sm-10">
            <textarea class="form- w-100" name="" id="" rows="3" cols="10"></textarea>
        </div>
    </div>

    <div class="form-group row">
        <label for="" class="col-sm-2 col-form-label">Makroskopik</label>
        <div class="col-sm-10">
            <textarea class="form- w-100" name="" id="" rows="3" cols="10"></textarea>
        </div>
    </div>

    <div class="form-group row">
        <label for="" class="col-sm-2 col-form-label">Mikroskopik</label>
        <div class="col-sm-10">
            <textarea class="form- w-100" name="" id="" rows="3" cols="10"></textarea>
        </div>
    </div>

    <div class="form-group row">
        <label for="" class="col-sm-2 col-form-label">Kesimpulan</label>
        <div class="col-sm-10">
            <textarea class="form- w-100" name="" id="" rows="3" cols="10"></textarea>
        </div>
    </div>

    <div class="form-group row">
        <label for="" class="col-sm-2 col-form-label">Re-Evaluasi</label>
        <div class="col-sm-10">
            <textarea class="form- w-100" name="" id="" rows="3" cols="10"></textarea>
        </div>
    </div> 

    <div class="form-group row">
        <label for="rs_rmpplg_ppeg" class="col-sm-2 col-form-label">Dokter</label>
        <div class="col-sm-8">
            <input type="hidden" id="rs_rmpplg_ppeg" name="rs_rmpplg_ppeg" required class="form-control">
            <input type="text" id="rs_rmpplg_ppegnm" name="rs_rmpplg_ppegnm" required class="form-control" disabled>
        </div>
        <div class="col-sm-2">
            <button type="button" class='btn bg-gradient-primary mx-1' data-target="#modalViewPprC" data-toggle="modal"
                style="float: right;"
                onclick="showPprC('<?= $Rmpr['rs_rmpr_rmr'] ?>', 'rs_rmpplg_ppeg', 'rs_rmpplg_ppegnm')"><i
                    class="fas fa-file-archive"></i>
                AMBIL DOKTER</button>
        </div>
    </div>  
  
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-primary">SIMPAN</button>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('formTabLPA', 'formTabLPA')">BATAL</button>
        </div>
    </div>
    <hr>
</form>
 

<div>
    <h4 class="text-center">Daftar Hasil Patologi Anatomi</h4>
     <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-success <?= $eEdit ?>" style="float: right;"
                onclick="showForm('formTabLPA', 'block')"><i class="fas fa-plus"></i>
                Tambah</button>
        </div>
    </div>
    <table id="dtKformTabLPA" class="dtK table responsive table-bordered table-striped" width="100%" >
        <thead>
            <tr>
                <th>No</th>
                <th>Lokasi</th>
                <th>Didapat Dengan</th>
                <th>Fiksasi</th>
                <th>Diagnosa</th>
                <th>Keterangan</th>
                <!-- <th>Makroskopik</th>
                <th>Mikroskopik</th>
                <th>Kesimpulan</th>
                <th>Re-Evaluasi</th>
                <th>Dokter</th> -->
            </tr>
        </thead>
        <tbody> 
            <?php $no = 0;
            foreach ($Rmplabt as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td>
                <td>
                    Tanggal : <?= $tk['rs_rmplab_tgl'] ?><br>
                    Waktu : <?= $tk['rs_rmplab_jam'] ?>
                </td>
                
                <td><?= $tk['rs_rmtdk_nm'] ?></td>
                <td><?= $tk['rs_ppeg_nm'] ?></td>
                <td class="text-nowrap"><?= $tk['rs_rmplab_diag'] ?></td>
                <td>
                    
                </td>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>

<script>
$(function() {
    $(document).ready(function() {
        var formTabLPA = $('#formTabLPA');
        formTabLPA.submit(function(e) {
            showAnimated();
            $('#formTabLPA :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');

            e.preventDefault();
            $.ajax({
                type: formTabLPA.attr('method'),
                url: formTabLPA.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            window.location = '/<?= $UrlForm ?>';
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>