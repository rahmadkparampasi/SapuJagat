<form class="form-horizontal form-valide" style="display: none;" method="POST" action="/rmpaksp/<?= $MethodForm ?>"
    id="formTabAKSP">
    <h4 class="text-center">Form Data Anamnesis Kondisi Sosial Dan Psikososial</h4>

    <div class="row">
        <div class="col-lg-6 col-md-12 col-sm-12">
            <div class=" row">
                <label for="rs_rmpaksp_ko" class="col-sm-2">Kondisi Sosial: </label>
                <div class="col-lg-2 col-md-4 col-sm-6">
                    <div class="form-group">
                        <div class="custom-control custom-checkbox">
                            <!-- Marah -->
                            <input class="custom-control-input" type="checkbox" id="rs_rmpaksp_ko1"
                                name="rs_rmpaksp_ko[]" value="Marah">
                            <label for="rs_rmpaksp_ko1" class="custom-control-label">Marah</label>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-4 col-sm-6">
                    <div class="form-group">
                        <div class="custom-control custom-checkbox">
                            <!-- Cemas -->
                            <input class="custom-control-input" type="checkbox" id="rs_rmpaksp_ko2"
                                name="rs_rmpaksp_ko[]" value="Cemas">
                            <label for="rs_rmpaksp_ko2" class="custom-control-label">Cemas</label>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-4 col-sm-6">
                    <div class="form-group">
                        <div class="custom-control custom-checkbox">
                            <!-- Takut -->
                            <input class="custom-control-input" type="checkbox" id="rs_rmpaksp_ko3"
                                name="rs_rmpaksp_ko[]" value="Takut">
                            <label for="rs_rmpaksp_ko3" class="custom-control-label">Takut</label>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-4 col-sm-6">
                    <div class="form-group">
                        <div class="custom-control custom-checkbox">
                            <!-- Kecenderungan Bunuh Diri -->
                            <input class="custom-control-input" type="checkbox" id="rs_rmpaksp_ko4"
                                name="rs_rmpaksp_ko[]" value="Kecenderungan Bunuh Diri">
                            <label for="rs_rmpaksp_ko4" class="custom-control-label">Kecenderungan Bunuh Diri</label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="form-group row">
        <label for="rs_rmpaksp_ln" class="col-sm-2 col-form-label">Lainnya</label>
        <div class="col-sm-10">
            <input type="text" name="rs_rmpaksp_ln" id="rs_rmpaksp_ln" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmpaksp_mp" class="col-sm-2 col-form-label">Masalah Perilaku</label>
        <div class="col-sm-10">
            <textarea name="rs_rmpaksp_mp" id="rs_rmpaksp_mp" cols="30" rows="2" class="form-control w-100"></textarea>
        </div>
    </div>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-primary">SIMPAN</button>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('formTabAKSP', 'formTabAKSP')">BATAL</button>
        </div>
    </div>
    <hr>
</form>

<div>
    <h4 class="text-center">Daftar Data Anamnesis Kondisi Sosial Dan Psikososial</h4>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-success <?= $eEdit ?>" style="float: right;"
                onclick="showForm('formTabAKSP', 'block'); resetForm('formTabAKSP')"><i class="fas fa-plus"></i>
                Tambah</button>
        </div>
    </div>
    <table id="dtKformTabAKSP" class="dtK table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Kondisi Sosial</th>
                <th>Kondisi Lainnya</th>
                <th>Masalah Perilaku</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Rmpaksp as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td>
                <td><?= $tk['rs_rmpaksp_ko'] ?></td>
                <td><?= $tk['rs_rmpaksp_ln'] ?></td>
                <td>
                    <p id="rs_rmpaksp_mpc"><?= $tk['rs_rmpaksp_mp'] ?></p> <button class="btn bg-gradient-primary"
                        onclick="copyTextTOC('rs_rmpaksp_mpc')"><i class="fa fa-clipboard"></i></button>
                </td>
                <td>
                    <?php
                        if ($MethodForm1 != "updateData") {
                        ?>
                    <button class="btn bg-gradient-danger <?= $eEdit ?>"
                        title="Hapus Data Anamnesis Edukasi Pasien Dan Keluarga Pasien"
                        onclick="callOther('Menghapus Data Anamnesis Kondisi Sosial Dan Psikososial', '/rmpaksp/deleteData/<?= $tk['rs_rmpaksp_id_ex'] ?>')">
                        <i class='fas fa-trash'></i></button>
                    <?php
                        }
                        ?>
                </td>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>

<script>
$(function() {
    $(document).ready(function() {
        var formTabAKSP = $('#formTabAKSP');
        formTabAKSP.submit(function(e) {
            showAnimated();
            $('#formTabAKSP :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');

            e.preventDefault();
            $.ajax({
                type: formTabAKSP.attr('method'),
                url: formTabAKSP.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            window.location = '/<?= $UrlForm ?>';
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>