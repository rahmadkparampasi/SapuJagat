<div>
    <h4 class="text-center">Daftar Layanan Radiologi</h4>
    <table id="dtKformTabRL" class="dtK table responsive table-bordered table-striped" width="100%" data-page-length="5">
        <thead>
            <tr>
                <th>No</th>
                <th>Tanggal Dan Waktu</th>
                <th>Pemberi Layanan</th>
                <th>Tindakan</th>
                <th>Dokter</th>
                <th>Diagnosa</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Rmpradt as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td>
                <td>
                    Tanggal : <?= $tk['rs_rmprad_tgl'] ?><br>
                    Waktu : <?= $tk['rs_rmprad_jam'] ?>
                </td>
                <td>
                    <div class="row">
                        <div class="col-12">


                            <button type="button" class='btn bg-gradient-primary mx-1 my-2 btn-block <?= $eEdit ?>'
                                onclick="loadChildFormRL('rmpradtw', '<?= $tk['rs_rmpradt_id_ex'] ?>', '<?= $tk['rs_rmprad_tgl'] ?>', '<?= $tk['rs_rmprad_jam'] ?>', '<?= $tk['rs_rmtdk_nm'] ?>'); "><i
                                    class="fas fa-user-nurse"></i>
                                DETAIL</button><br>
                            <button type="button" class='btn bg-gradient-success mx-1 my-2 btn-block <?= $eEdit ?>'
                                onclick="loadChildFormRHR('rmpradth', '<?= $tk['rs_rmpradt_id_ex'] ?>', '<?= $tk['rs_rmprad_tgl'] ?>', '<?= $tk['rs_rmprad_jam'] ?>', '<?= $tk['rs_rmtdk_nm'] ?>'); "><i
                                    class="fas fa-file-medical-alt"></i>
                                HASIL RADIOLOGI</button><br>
                        </div>

                    </div>
                </td>
                <td><?= $tk['rs_rmtdk_nm'] ?></td>
                <td><?= $tk['rs_ppeg_nm'] ?></td>
                <td class="text-nowrap"><?= $tk['rs_rmprad_diag'] ?></td>
                <td>
                    
                </td>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>
<div id="ChildFormRL">

</div>
<div id="ChildFormRHR">

</div>
<script>
function clearBoxRL() {
    document.getElementById('ChildFormRL').innerHTML = "";
}

function loadChildFormRL(link = '', idEx = '', t = '', j = '', p = '') {
    $.ajax({
        url: "/" + link + "/viewData/" + idEx + "/" + t + "/" + j + "/" + p ,
        success: function(data) {

            $('#ChildFormRL').html(data);
        }
    });
}
function clearBoxRHR() {
    document.getElementById('ChildFormRHR').innerHTML = "";
}

function loadChildFormRHR(link = '', idEx = '', t = '', j = '', p = '') {
    $.ajax({
        url: "/" + link + "/viewData/" + idEx + "/" + t + "/" + j + "/" + p ,
        success: function(data) {

            $('#ChildFormRHR').html(data);
        }
    });
}
$(function() {
    $(document).ready(function() {
        var formTabRL = $('#formTabRL');
        formTabRL.submit(function(e) {
            showAnimated();
            $('#formTabRL :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');

            e.preventDefault();
            $.ajax({
                type: formTabRL.attr('method'),
                url: formTabRL.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            window.location = '/<?= $UrlForm ?>';
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>