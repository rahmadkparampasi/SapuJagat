<a class="d-block w-100" data-toggle="collapse" href="#collapseRm" onclick="addSess('tabAccor', 'collapseRm');">
    <div class="card-header">
        <div class="row">
            <div class="col-12">
                <h4 class="card-title w-100">
                    Rekam Medis
                </h4>
            </div>
            <div class="col-12">
                <ul class="nav nav-pills">
                    <li class="nav-item"><a class="nav-link" href="#TabItemTri" id="TabParTri" data-toggle="tab" onclick="addSess('tabParent', 'TabParTri'); addSess('tabItem', 'TabItemTri');addSess('tabVParent', ''); addSess('tabVItem', '');"><i class="fa fa-hospital-alt"></i> Triage</a>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="#TabItemA" id="TabParA" data-toggle="tab" onclick="addSess('tabParent', 'TabParA'); addSess('tabItem', 'TabItemA');addSess('tabVParent', 'vTabAUPar'); addSess('tabVItem', 'vTabAUItem');"><i class="fa fa-hospital-alt"></i> Anamnesis</a>
                    </li>

                    <li class="nav-item"><a class="nav-link" href="#TabItemPrk" id="TabParPrk" data-toggle="tab" onclick="addSess('tabParent', 'TabParPrk'); addSess('tabItem', 'TabItemPrk');addSess('tabVParent', 'vTabPrkUTPar'); addSess('tabVItem', 'vTabPrkUTItem'); showV('vTabPrkUTPar', 'vTabPrkUTItem'); "><i class="fa fa-stethoscope"></i> Pemeriksaan</a>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="#TabItemNl" id="TabParNl" data-toggle="tab" onclick="addSess('tabParent', 'TabParNl'); addSess('tabItem', 'TabItemNl');addSess('tabVParent', 'vTabNlFPar'); addSess('tabVItem', 'vTabNlFItem'); showV('vTabNlFPar', 'vTabNlFItem'); "><i class="fa fa-diagnoses"></i> Penilaian</a>
                    </li>

                    <li class="nav-item"><a class="nav-link" href="#TabItemIcd" id="TabParIcd" data-toggle="tab" onclick="addSess('tabParent', 'TabParIcd'); addSess('tabItem', 'TabItemIcd');addSess('tabVParent', 'vTabDiagPar'); addSess('tabVItem', 'vTabDiagItem'); showV('vTabDiagPar', 'vTabDiagItem'); "><i class="fa fa-file-medical-alt"></i> ICD</a>
                    </li>

                    <li class="nav-item"><a class="nav-link" href="#TabItemPrcn" id="TabParPrcn" data-toggle="tab" onclick="addSess('tabParent', 'TabParPrcn'); addSess('tabItem', 'TabItemPrcn');addSess('tabVParent', 'vTabRtPar'); addSess('tabVItem', 'vTabRtItem'); showV('vTabRtPar', 'vTabRtItem'); "><i class="fa fa-clinic-medical"></i> Perencanaan</a>
                    </li>

                    <li class="nav-item"><a class="nav-link" href="#TabItemCppt" id="TabParCppt" data-toggle="tab" onclick="addSess('tabParent', 'TabParCppt'); addSess('tabItem', 'TabItemCppt');addSess('tabVParent', ''); addSess('tabVItem', '');"><i class="fa fa-book-medical"></i> CPPT</a>
                    </li>

                    <li class="nav-item"><a class="nav-link" href="#TabItemEdu" id="TabParEdu" data-toggle="tab" onclick="addSess('tabParent', 'TabParEdu'); addSess('tabItem', 'TabItemEdu');addSess('tabVParent', ''); addSess('tabVItem', '');"><i class="fa fa-newspaper"></i> Edukasi</a>
                    </li>

                    


                </ul>
            </div>
        </div>
    </div><!-- /.card-header -->
</a>
<div id="collapseRm" class="collapse" data-parent="#accordion">
    <div class="card-body">
        <div class="tab-content">
            <div class="tab-pane" id="TabItemTri">
                <?= $this->include('Rmpmskd/formTri'); ?>
            </div>
            <div class="tab-pane" id="TabItemA">
                <?= $this->include('Rmpmskd/formA'); ?>
            </div>
            <div class="tab-pane" id="TabItemPrk">
                <?= $this->include('Rmpmskd/formPrk'); ?>
            </div>
            <div class="tab-pane" id="TabItemNl">
                <?= $this->include('Rmpmskd/formNl'); ?>
            </div>

            <div class="tab-pane" id="TabItemCppt">
                <?= $this->include('Rmpmskd/formCppt'); ?>
            </div>
            <div class="tab-pane" id="TabItemPrcn">
                <?= $this->include('Rmpmskd/formPrcn'); ?>
            </div>
            <div class="tab-pane" id="TabItemIcd">
                <?= $this->include('Rmpmskd/formIcd'); ?>
            </div>

            <div class="tab-pane" id="TabItemEdu">
                <?= $this->include('Rmpmskd/formEd'); ?>
            </div>
            <!-- /.tab-pane -->


        </div>
        <!-- /.tab-content -->

    </div><!-- /.card-body -->
</div>