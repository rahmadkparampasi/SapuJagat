<form class="form-horizontal form-valide" style="display: none;" method="POST" action="/rmparo/<?= $MethodForm ?>"
    id="formTabARO">
    <h4 class="text-center">Form Data Anamnesis Riwayat Pemberian Obat</h4>

    <div class="form-group row">
        <label for="rs_rmparo_nm" class="col-sm-2 col-form-label">Nama Obat</label>
        <div class="col-sm-10">
            <input type="text" name="rs_rmparo_nm" id="rs_rmparo_nm" class="form-control" required>
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmparo_ds" class="col-sm-2 col-form-label">Dosis Obat</label>
        <div class="col-sm-10">
            <input type="text" name="rs_rmparo_ds" id="rs_rmparo_ds" class="form-control" required>
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmparo_lm" class="col-sm-2 col-form-label">Lama Penggunaan Obat</label>
        <div class="col-sm-10">
            <input type="text" name="rs_rmparo_lm" id="rs_rmparo_lm" class="form-control" required>
        </div>
    </div>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-primary">SIMPAN</button>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('formTabARO', 'formTabARO')">BATAL</button>
        </div>
    </div>
    <hr>
</form>

<div>
    <h4 class="text-center">Daftar Data Anamnesis Riwayat Pemberian Obat</h4>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-success <?= $eEdit ?>" style="float: right;"
                onclick="showForm('formTabARO', 'block'); resetForm('formTabARO')"><i class="fas fa-plus"></i>
                Tambah</button>
        </div>
    </div>
    <table id="dtKformTabARO" class="dtK table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Obat</th>
                <th>Dosis Obat</th>
                <th>Lama Penggunaan Obat</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Rmparo as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td>
                <td>
                    <p id="rs_rmparo_nmc"><?= $tk['rs_rmparo_nm'] ?></p> <button class="btn bg-gradient-primary"
                        onclick="copyTextTOC('rs_rmparo_nmc')"><i class="fa fa-clipboard"></i></button>
                </td>
                <td>
                    <p id="rs_rmparo_dsc"><?= $tk['rs_rmparo_ds'] ?></p> <button class="btn bg-gradient-primary"
                        onclick="copyTextTOC('rs_rmparo_dsc')"><i class="fa fa-clipboard"></i></button>
                </td>
                <td>
                    <p id="rs_rmparo_lmc"><?= $tk['rs_rmparo_lm'] ?></p> <button class="btn bg-gradient-primary"
                        onclick="copyTextTOC('rs_rmparo_lmc')"><i class="fa fa-clipboard"></i></button>
                </td>
                <td>
                    <?php
                        if ($MethodForm1 != "updateData") {
                        ?>
                    <button class="btn bg-gradient-danger <?= $eEdit ?>"
                        title="Hapus Data Anamnesis Riwayat Pemberian Obat Pasien"
                        onclick="callOther('Menghapus Data Anamnesis Riwayat Pemberian Obat Pasien', '/rmparo/deleteData/<?= $tk['rs_rmparo_id_ex'] ?>')">
                        <i class='fas fa-trash'></i></button>
                    <?php
                        }
                        ?>
                </td>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>

<script>
$(function() {
    $(document).ready(function() {
        var formTabARO = $('#formTabARO');
        formTabARO.submit(function(e) {
            showAnimated();
            $('#formTabARO :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');

            e.preventDefault();
            $.ajax({
                type: formTabARO.attr('method'),
                url: formTabARO.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            window.location = '/<?= $UrlForm ?>';
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>