<form class="form-horizontal form-valide" style="display: none;" method="POST" action="/rmparp/<?= $MethodForm ?>"
    id="formTabARP">
    <h4 class="text-center">Form Data Anamnesis Riwayat Perjalanan Penyakit</h4>

    <div class="form-group row">
        <label for="rs_rmparp_rp" class="col-sm-2 col-form-label">Anamnesis Riwayat Perjalanan Penyakit</label>
        <div class="col-sm-10">
            <textarea name="rs_rmparp_rp" id="rs_rmparp_rp" class="form-control w-100 " cols="30" rows="10"
                required></textarea>
        </div>
    </div>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-primary">SIMPAN</button>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('formTabARP', 'formTabARP')">BATAL</button>
        </div>
    </div>
    <hr>
</form>

<div>
    <h4 class="text-center">Daftar Data Anamnesis Riwayat Perjalanan Penyakit</h4>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-success <?= $eEdit ?>" style="float: right;"
                onclick="showForm('formTabARP', 'block'); resetForm('formTabARP')"><i class="fas fa-plus"></i>
                Tambah</button>
        </div>
    </div>
    <table id="dtKformTabARP" class="dtK table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Anamnesis Riwayat Perjalanan Penyakit</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Rmparp as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td>
                <td>
                    <p id="rs_rmparp_rpc"><?= $tk['rs_rmparp_rp'] ?></p> <button class="btn bg-gradient-primary"
                        onclick="copyTextTOC('rs_rmparp_rpc')"><i class="fa fa-clipboard"></i> Salin Teks</button>
                </td>
                <td>
                    <?php
                        if ($MethodForm1 != "updateData") {
                        ?>
                    <button class="btn bg-gradient-danger <?= $eEdit ?>"
                        title="Hapus Data Anamnesis Riwayat Perjalanan Penyakit Pasien"
                        onclick="callOther('Menghapus Data Anamnesis Riwayat Perjalanan Penyakit Pasien', '/rmparp/deleteData/<?= $tk['rs_rmparp_id_ex'] ?>')">
                        <i class='fas fa-trash'></i></button>
                    <?php
                        }
                        ?>
                </td>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>

<script>
$(function() {
    $(document).ready(function() {
        var formTabARP = $('#formTabARP');
        formTabARP.submit(function(e) {
            showAnimated();
            $('#formTabARP :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');

            e.preventDefault();
            $.ajax({
                type: formTabARP.attr('method'),
                url: formTabARP.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            window.location = '/<?= $UrlForm ?>';
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>