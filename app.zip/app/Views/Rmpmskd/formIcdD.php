<form class="form-horizontal form-valide" style="display: none;" method="POST" action="/rmpdia/<?= $MethodForm ?>"
    id="formTabIcdDia">
    <h4 class="text-center">Form Data Diagnosa (ICD 10)</h4>

    <div class="form-group row">
        <label for="rs_rmpdia_pri" class="col-sm-2 col-form-label">Primary</label>
        <div class="col-sm-10">
            <select name="rs_rmpdia_pri" id="rs_rmpdia_pri" class="form-control" required>
                <option hidden value="">PILIH SALAH SATU PILIHAN</option>
                <option value="0">Tidak</option>
                <option value="1">Ya</option>
            </select>
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmpdia_icd" class="col-sm-2 col-form-label">Kode Dan Diagnosa ICD 10</label>
        <div class="col-sm-8">
            <input type="text" name="rs_rmpdia_icd" id="rs_rmpdia_icd" class="form-control " required>
            <input type="hidden" name="rs_rmpdia_rmicdt" id="rs_rmpdia_rmicdt" class="form-control " required>
        </div>
        <div class="col-sm-2">
            <button type="button" class='btn bg-gradient-primary mx-1' data-target="#modalViewRmIcdt"
                data-toggle="modal" style="float: right;" onclick="showRmIcdt('rs_rmpdia_icd', 'rs_rmpdia_rmicdt')"><i
                    class="fas fa-file-archive"></i>
                AMBIL ICD 10</button>
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmpdia_dia" class="col-sm-2 col-form-label">Masukan Diagnosa</label>
        <div class="col-sm-10">
            <textarea name="rs_rmpdia_dia" id="rs_rmpdia_dia" class="form-control w-100 " cols="30" rows="10"
                required></textarea>
        </div>
    </div>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-primary">SIMPAN</button>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('formTabIcdDia', 'formTabIcdDia')">BATAL</button>
        </div>
    </div>
    <hr>
</form>

<div>
    <h4 class="text-center">Daftar Data Diagnosa (ICD 10)</h4>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-success <?= $eEdit ?>" style="float: right;"
                onclick="showForm('formTabIcdDia', 'block'); resetForm('formTabIcdDia')"><i class="fas fa-plus"></i>
                Tambah</button>
        </div>
    </div>
    <table id="dtKformTabIcdDia" class="dtK table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Kode ICD 10</th>
                <th>Primary</th>
                <th>Diagnosis</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Rmpdia as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td>

                <td><?= $tk['rs_rmicdt_kd'] ?> - <?= $tk['rs_rmicdt_nm'] ?></td>
                <td><?= $tk['rs_rmpdia_pri'] ?></td>
                <td><?= $tk['rs_rmpdia_dia'] ?></td>
                <td>
                    <?php
                        if ($MethodForm1 != "updateData") {
                        ?>
                    <button class="btn bg-gradient-danger <?= $eEdit ?>" title="Hapus Data Diagnosa (ICD 10) Pasien"
                        onclick="callOther('Menghapus Data Diagnosa (ICD 10) Pasien', '<?= $BasePage ?>/deleteData/<?= $tk['rs_rmpdia_id_ex'] ?>')">
                        <i class='fas fa-trash'></i></button>
                    <?php
                        }
                        ?>
                </td>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>

<script>
$(function() {
    $(document).ready(function() {
        var formTabIcdDia = $('#formTabIcdDia');
        formTabIcdDia.submit(function(e) {
            showAnimated();
            $('#formTabIcdDia :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');

            e.preventDefault();
            $.ajax({
                type: formTabIcdDia.attr('method'),
                url: formTabIcdDia.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            window.location = '/<?= $UrlForm ?>';
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>