<form class="form-horizontal form-valide" style="display: none;" method="POST" action="/rmpara/<?= $MethodForm ?>"
    id="formTabARA">
    <h4 class="text-center">Form Data Anamnesis Riwayat Alergi</h4>

    <div class="form-group row">
        <label for="rs_rmpara_ra" class="col-sm-2 col-form-label">Anamnesis Riwayat Alergi</label>
        <div class="col-sm-10">
            <textarea name="rs_rmpara_ra" id="rs_rmpara_ra" class="form-control w-100 " cols="30" rows="10"
                required></textarea>
        </div>
    </div>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-primary">SIMPAN</button>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('formTabARA', 'formTabARA')">BATAL</button>
        </div>
    </div>
    <hr>
</form>

<div>
    <h4 class="text-center">Daftar Data Anamnesis Riwayat Alergi</h4>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-success <?= $eEdit ?>" style="float: right;"
                onclick="showForm('formTabARA', 'block'); resetForm('formTabARA')"><i class="fas fa-plus"></i>
                Tambah</button>
        </div>
    </div>
    <table id="dtKformTabARA" class="dtK table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Anamnesis Riwayat Alergi</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Rmpara as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td>
                <td>
                    <p id="rs_rmpara_rac"><?= $tk['rs_rmpara_ra'] ?></p> <button class="btn bg-gradient-primary"
                        onclick="copyTextTOC('rs_rmpara_rac')"><i class="fa fa-clipboard"></i> Salin Teks</button>
                </td>
                <td>
                    <?php
                        if ($MethodForm1 != "updateData") {
                        ?>
                    <button class="btn bg-gradient-danger <?= $eEdit ?>"
                        title="Hapus Data Anamnesis Riwayat Alergi Pasien"
                        onclick="callOther('Menghapus Data Anamnesis Riwayat Alergi Pasien', '/rmpara/deleteData/<?= $tk['rs_rmpara_id_ex'] ?>')">
                        <i class='fas fa-trash'></i></button>
                    <?php
                        }
                        ?>
                </td>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>

<script>
$(function() {
    $(document).ready(function() {
        var formTabARA = $('#formTabARA');
        formTabARA.submit(function(e) {
            showAnimated();
            $('#formTabARA :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');

            e.preventDefault();
            $.ajax({
                type: formTabARA.attr('method'),
                url: formTabARA.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            window.location = '/<?= $UrlForm ?>';
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>