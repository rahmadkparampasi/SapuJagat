<form class="form-horizontal form-valide" style="display: none;" method="POST" action="/rmplab/<?= $MethodForm ?>"
    id="formTabPLab">
    <h4 class="text-center">Form Data Laboratorium Pasien</h4>

    <div class="form-group row">
        <label for="rs_rmplab_tgl" class="col-sm-2 col-form-label">Tanggal</label>
        <div class="col-sm-10">
            <input type="date" id="rs_rmplab_tgl" name="rs_rmplab_tgl" required class="form-control">
        </div>
    </div>
    <div class="bootstrap-timepicker">
        <div class="form-group row">
            <label for="rs_rmplab_jam" class="col-sm-2 col-form-label">Waktu</label>
            <div class="col-sm-10">
                <div class="input-group date" id="timepickerRmplab" data-target-input="nearest">
                    <input type="text" class="form-control datetimepicker-input" data-target="#timepickerRmplab"
                        id="rs_rmplab_jam" name="rs_rmplab_jam" required>
                    <div class="input-group-append" data-target="#timepickerRmplab" data-toggle="datetimepicker">
                        <div class="input-group-text"><i class="far fa-clock"></i></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
    $(function() {
        //Timepicker
        $('#timepickerRmplab').datetimepicker({
            format: 'HH:mm',
            use24hours: true
        })
    });
    </script>

    <div class="form-group row">
        <label for="rs_rmplab_ppeg" class="col-sm-2 col-form-label">Dokter Perujuk</label>
        <div class="col-sm-8">
            <input type="hidden" id="rs_rmplab_ppeg" name="rs_rmplab_ppeg" required class="form-control">
            <input type="text" id="rs_ppeg_nm" name="rs_ppeg_nm" required class="form-control" disabled>
        </div>
        <div class="col-sm-2">
            <button type="button" class='btn bg-gradient-primary mx-1' data-target="#modalViewPprC" data-toggle="modal"
                style="float: right;"
                onclick="showPprC('<?= $Rmpr['rs_rmpr_rmr'] ?>', 'rs_rmplab_ppeg', 'rs_ppeg_nm')"><i
                    class="fas fa-file-archive"></i>
                AMBIL DOKTER</button>
        </div>
    </div>

    <div class="form-group row">
        <label for="rs_rmplab_rmr" class="col-sm-2 col-form-label">Tujuan Laboratorium</label>
        <div class="col-sm-10">
            <select name="rs_rmplab_rmr" id="rs_rmplab_rmr" class="form-control"
                onfocus="ambilDataSelect('rs_rmplab_rmr', '/rmr/getAllForSelectByPrt/<?= $setRmr['setRmrLab'] ?>', 'Pilih Salah Satu Pilihan', toRemove=[], removeMessage=[], '')">
                <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
            </select>
        </div>
    </div>

    <div class="form-group row">
        <label for="rs_rmplab_diag" class="col-sm-2 col-form-label">Diagnosis</label>
        <div class="col-sm-10">
            <textarea class="form-control w-100" name="rs_rmplab_diag" id="rs_rmplab_diag" rows="3"
                cols="10"></textarea>
        </div>
    </div>

    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-primary">SIMPAN</button>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('formTabPLab', 'formTabPLab')">BATAL</button>
        </div>
    </div>
    <hr>
</form>

<div>
    <h4 class="text-center">Daftar Data Laboratorium Pasien</h4>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-success <?= $eEdit ?>" style="float: right;"
                onclick="showForm('formTabPLab', 'block')"><i class="fas fa-plus"></i>
                Tambah</button>
        </div>
    </div>
    <table id="dtKformTabPLab" class="dtK table responsive table-bordered table-striped" width="100%" >
        <thead>
            <tr>
                <th>No</th>
                <th>Tanggal Dan Waktu</th>
                <th>Laboratorium</th>
                <th>Tindakan</th>
                <th>Dokter Perujuk</th>
                <th>Diagnosis</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Rmplab as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td>
                <td class="text-nowrap">
                    Tanggal : <?= $tk['rs_rmplab_tgl'] ?><br>
                    Waktu : <?= $tk['rs_rmplab_jam'] ?>
                </td>
                <td class="text-nowrap"><?= $tk['rs_rmr_nm'] ?></td>
                <td class="text-nowrap">
                    <div class="row">
                        <div class="col-12">


                            <button type="button" class='btn bg-gradient-primary mx-1 my-2 btn-block <?= $eEdit ?>'
                                data-target="#modalViewRmTdkC" data-toggle="modal" style="float: right;"
                                onclick="showRmTdkC('<?= $tk['rs_rmr_id_ex'] ?>'); addFill('rs_rmplabt_rmplab', '<?= $tk['rs_rmplab_id_ex'] ?>'); cAF('formTabPlabt', '/rmplabt/<?= $MethodForm ?>')"><i
                                    class="fas fa-file-archive"></i>
                                AMBIL TINDAKAN</button>
                        </div>
                        <div class="col-12">
                            <table id="dtKformTabPlabt" class="dtK table responsive table-bordered table-striped" data-searching='false' data-paging='false' 
                                width="100%">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Tindakan</th>
                                        <th>Kategori</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $no1 = 0;
                                        foreach ($tk['rmplabt'] as $tkd) : $no1++ ?>
                                    <tr>
                                        <td><?= $no1 ?></td>
                                        <td><?= $tkd['rs_rmtdk_nm'] ?></td>
                                        <td><?= $tkd['rs_rmktdk_nm'] ?></td>
                                        <td></td>
                                    </tr>


                                    <?php endforeach ?>
                                </tbody>
                            </table>
                        </div>

                    </div>

                </td>
                <td class="text-nowrap"><?= $tk['rs_ppeg_nm'] ?></td>

                <td><?= $tk['rs_rmplab_diag'] ?></td>

                <td>
                    <?php
                        if ($MethodForm1 != "updateData") {
                        ?>
                    <button class="btn bg-gradient-danger <?= $eEdit ?>"
                        title="Hapus Data Permintaan Laboratorium Pasien"
                        onclick="callOther('Menghapus Data Permintaan Laboratorium Pasien', '/rmpl/deleteData/<?= $tk['rs_rmplab_id_ex'] ?>')">
                        <i class='fas fa-trash'></i></button>
                    <?php
                        }
                        ?>
                </td>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>

<script>
$(function() {
    $(document).ready(function() {
        var formTabPLab = $('#formTabPLab');
        formTabPLab.submit(function(e) {
            showAnimated();
            $('#formTabPLab :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');

            e.preventDefault();
            $.ajax({
                type: formTabPLab.attr('method'),
                url: formTabPLab.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            window.location = '/<?= $UrlForm ?>';
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>