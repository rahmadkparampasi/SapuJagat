<div>
    <h4 class="text-center">List Obat</h4> 
    <table id="dtKformTabFRPF" class="dtK table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>No. Resep</th>
                <th>Asal Resep / Unit</th>
                <th>Tanggal</th> 
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Rmpplg as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td> 
                <td class="text-nowrap"><?= $tk['rs_rmck_nm'] ?></td>
                <td><?= $tk['rs_rmkk_nm'] ?></td>
                <td><?= $tk['rs_ppeg_nm'] ?></td>
                <td><?= $tk['rs_rmpplg_diag'] ?></td>
              
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>
<hr>
<br><br>
 

<div>
    <h4 class="text-center">Daftar Obat</h4> 
    <table id="dtKformTabFRPF" class="dtK table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Obat</th>
                <th>Jumlah</th> 
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Rmpplg as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td> 
                <td class="text-nowrap"><?= $tk['rs_rmck_nm'] ?></td>
                <td><?= $tk['rs_rmkk_nm'] ?></td>
                <td><?= $tk['rs_ppeg_nm'] ?></td>
                <td><?= $tk['rs_rmpplg_diag'] ?></td> 
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>
<hr>
<br><br>


<form class="form-horizontal form-valide" style="display: none;" method="POST" action="/rmpplg/<?= $MethodForm ?>"
    id="formTabFRPF">
    <h4 class="text-center">Form Riwayat Retur</h4> 
    
    <div class="form-group row">
        <label for="" class="col-sm-2 col-form-label">Jumlah</label>
        <div class="col-sm-10">
            <input type="text" id="" name="" required class="form-control"> 
        </div> 
    </div> 

    <div class="form-group row">
        <label for="rs_rmplab_tgl" class="col-sm-2 col-form-label">Tanggal</label>
        <div class="col-sm-10">
            <input type="date" id="rs_rmplab_tgl" name="rs_rmplab_tgl" required class="form-control">
        </div>
    </div> 

    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-primary">SIMPAN</button>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('formTabFRPF', 'formTabFRPF')">BATAL</button>
        </div>
    </div>
    <hr>
</form> 
<div>
    <h4 class="text-center">Riwayat Retur</h4>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-success <?= $eEdit ?>" style="float: right;"
                onclick="showForm('formTabFRPF', 'block')"><i class="fas fa-plus"></i>
                Tambah</button>
        </div>
    </div>
    <table id="dtKformTabFRPF" class="dtK table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Jumlah</th>
                <th>Tanggal Retur</th> 
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Rmpplg as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td>
                <td>
                    Tanggal : <?= $tk['rs_rmpplg_tgl'] ?><br>
                    Waktu : <?= $tk['rs_rmpplg_jam'] ?>
                </td>
                <td class="text-nowrap"><?= $tk['rs_rmck_nm'] ?></td>
                <td><?= $tk['rs_rmkk_nm'] ?></td>
                <td><?= $tk['rs_ppeg_nm'] ?></td>
                <td><?= $tk['rs_rmpplg_diag'] ?></td>
                <td>
                    <?php
                        if ($MethodForm1 != "updateData") {
                        ?>
                    <button class="btn bg-gradient-danger <?= $eEdit ?>" title="Hapus Data Pulang Pasien"
                        onclick="callOther('Menghapus Data Pulang Pasien', '/rmpplg/deleteData/<?= $tk['rs_rmpplg_id_ex'] ?>')">
                        <i class='fas fa-trash'></i></button>
                    <?php
                        }
                        ?>
                </td>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>
<script>
$(function() {
    $(document).ready(function() {
        var formTabFRPF = $('#formTabFRPF');
        formTabFRPF.submit(function(e) {
            showAnimated();
            $('#formTabFRPF :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');

            e.preventDefault();
            $.ajax({
                type: formTabFRPF.attr('method'),
                url: formTabFRPF.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            window.location = '/<?= $UrlForm ?>';
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>

