<form class="form-horizontal form-valide" style="display: none;" method="POST" action="/rmpl/<?= $MethodForm ?>"
    id="formTabPl">
    <h4 class="text-center">Form Data Layanan Pasien</h4>

    <div class="form-group row">
        <label for="rs_rmpl_tgl" class="col-sm-2 col-form-label">Tanggal</label>
        <div class="col-sm-10">
            <input type="date" id="rs_rmpl_tgl" name="rs_rmpl_tgl" required class="form-control">
        </div>
    </div>
    <div class="bootstrap-timepicker">
        <div class="form-group row">
            <label for="rs_rmpl_jam" class="col-sm-2 col-form-label">Waktu</label>
            <div class="col-sm-10">
                <div class="input-group date" id="timepickerRmpl" data-target-input="nearest">
                    <input type="text" class="form-control datetimepicker-input" data-target="#timepickerRmpl"
                        id="rs_rmpl_jam" name="rs_rmpl_jam" required>
                    <div class="input-group-append" data-target="#timepickerRmpl" data-toggle="datetimepicker">
                        <div class="input-group-text"><i class="far fa-clock"></i></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
    $(function() {
        //Timepicker
        $('#timepickerRmpl').datetimepicker({
            format: 'HH:mm',
            use24hours: true
        })
    });
    </script>
    <div class="form-group row">
        <label for="rs_rmpl_rmtdk" class="col-sm-2 col-form-label">Tindakan</label>
        <div class="col-sm-8">
            <input type="hidden" id="rs_rmpl_rmtdk" name="rs_rmpl_rmtdk" required class="form-control">
            <input type="text" id="rs_rmpl_rmtdknm" name="rs_rmpl_rmtdknm" required class="form-control" disabled>
        </div>
        <div class="col-sm-2">
            <button type="button" class='btn bg-gradient-primary mx-1' data-target="#modalViewRmTdk" data-toggle="modal"
                style="float: right;"
                onclick="showRmTdk('rs_rmpl_rmtdknm', 'rs_rmpl_rmtdk', '<?= $Rmpr['rs_rmpr_rmr'] ?>')"><i
                    class="fas fa-file-archive"></i>
                AMBIL TINDAKAN</button>
        </div>
    </div>




    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-primary">SIMPAN</button>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('formTabPl', 'formTabPl')">BATAL</button>
        </div>
    </div>
    <hr>
</form>

<div>
    <h4 class="text-center">Daftar Data Layanan Pasien</h4>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-success <?= $eEdit ?>" style="float: right;"
                onclick="showForm('formTabPl', 'block')"><i class="fas fa-plus"></i>
                Tambah</button>
        </div>
    </div>
    <table id="dtKformTabPl" class="dtK table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Tanggal Dan Waktu</th>
                <th>Tindakan</th>
                <th>Tenaga Medis</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Rmpl as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td>
                <td>
                    Tanggal : <?= $tk['rs_rmpl_tgl'] ?><br>
                    Waktu : <?= $tk['rs_rmpl_jam'] ?>
                </td>
                <td><?= $tk['rs_rmtdk_nm'] ?></td>
                <td>
                    <div class="row">
                        <div class="col-12">
                            <button type="button" class='btn bg-gradient-primary mx-1 my-2 btn-block <?= $eEdit ?>'
                                data-target="#modalViewPpr" data-toggle="modal" style="float: right;"
                                onclick="showPpr('<?= $Rmpr['rs_rmpr_rmr'] ?>'); addFill('rs_rmplp_rmpl', '<?= $tk['rs_rmpl_id_ex'] ?>')"><i
                                    class="fas fa-file-archive"></i>
                                TAMBAH TENAGA MEDIS</button>
                        </div>
                        <div class="col-12">
                            <table id="dtKformTabPl" class="dtK table responsive table-bordered table-striped"
                                width="100%">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>NIP</th>
                                        <th>Nama</th>
                                        <th>Kategori</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $no1 = 0;
                                        foreach ($tk['rmplp'] as $tkd) : $no1++ ?>
                                    <tr>
                                        <td><?= $no1 ?></td>
                                        <td><?= $tkd['rs_ppeg_nip'] ?></td>
                                        <td><?= $tkd['rs_ppeg_nm'] ?></td>
                                        <td><?= $tkd['rs_pkp_nm'] ?></td>
                                        <td></td>
                                    </tr>


                                    <?php endforeach ?>
                                </tbody>
                            </table>
                        </div>

                    </div>

                </td>
                <td>
                    <?php
                        if ($MethodForm1 != "updateData") {
                        ?>
                    <button class="btn bg-gradient-danger <?= $eEdit ?>" title="Hapus Data Layanan Pasien"
                        onclick="callOther('Menghapus Data Layanan Pasien', '/rmpl/deleteData/<?= $tk['rs_rmpl_id_ex'] ?>')">
                        <i class='fas fa-trash'></i></button>
                    <?php
                        }
                        ?>
                </td>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>

<script>
$(function() {
    $(document).ready(function() {
        var formTabPl = $('#formTabPl');
        formTabPl.submit(function(e) {
            showAnimated();
            $('#formTabPl :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');

            e.preventDefault();
            $.ajax({
                type: formTabPl.attr('method'),
                url: formTabPl.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            window.location = '/<?= $UrlForm ?>';
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>