<div class="row">
    <div class="col-lg-2 col-md-3 col-sm-12">
        <div class="nav flex-column nav-pills" id="v-pills-tab-icd" role="tablist" aria-orientation="vertical">
            <a class="nav-link" id="vTabDiagPar" data-toggle="pill" href="#vTabDiagItem" role="tab" aria-controls="vTabDiagItem" aria-selected="true" onclick="addSess('tabVParent', 'vTabDiagPar'); addSess('tabVItem', 'vTabDiagItem');">Diagnosa (ICD 10)</a>
            <a class="nav-link" id="vTabTindPar" data-toggle="pill" href="#vTabTindItem" role="tab" aria-controls="vTabTindItem" aria-selected="false" onclick="addSess('tabVParent', 'vTabTindPar'); addSess('tabVItem', 'vTabTindItem');">Tindakan (ICD 9 CM)</a>
            <a class="nav-link" id="vTabMatiPar" data-toggle="pill" href="#vTabMatiItem" role="tab" aria-controls="vTabMatiItem" aria-selected="false" onclick="addSess('tabVParent', 'vTabMatiPar'); addSess('tabVItem', 'vTabMatiItem');">Penyebab Kematian</a>
        </div>
    </div>
    <div class="col-lg-10 col-md-9 col-sm-12">
        <div class="tab-content" id="v-pills-tabContent-icd">
            <div class="tab-pane fade" id="vTabDiagItem" role="tabpanel" aria-labelledby="vTabDiagPar">
                <?= $this->include('/Rmpmskd/formIcdD'); ?>
            </div>
            <div class="tab-pane fade" id="vTabTindItem" role="tabpanel" aria-labelledby="vTabTindPar">
                <?= $this->include('/Rmpmskd/formIcdT'); ?>
            </div>
            <div class="tab-pane fade" id="vTabMatiItem" role="tabpanel" aria-labelledby="vTabMatiPar">
                <?= $this->include('/Rmpmskd/formIcdMt'); ?>
            </div>
        </div>
    </div>
</div>