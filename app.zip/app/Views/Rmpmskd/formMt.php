<form class="form-horizontal form-valide" style="display: none;" method="POST" action="/rmprmt/<?= $MethodForm ?>"
    id="formTabMt">
    <h4 class="text-center">Form Data Mutu</h4>

    <div class="form-group row">
        <label for="rs_rmprmt_mmt" class="col-sm-2 col-form-label">Kasus</label>
        <div class="col-sm-10">
            <select name="rs_rmprmt_mmt" id="rs_rmprmt_mmt" class="form-control" required>
                <option hidden>PILIH SALAH SATU JENIS MUTU</option>
                <?php foreach ($Rmmt as $tk) : ?>
                <option value="<?= $tk['rs_rmmt_id_ex'] ?>"><?= $tk['rs_rmmt_nm'] ?></option>
                <?php endforeach ?>
            </select>
        </div>
    </div>

    <div class="form-group row">
        <label for="rs_rmprmt_tgl" class="col-sm-2 col-form-label">Tanggal</label>
        <div class="col-sm-10">
            <input type="date" id="rs_rmprmt_tgl" name="rs_rmprmt_tgl" required class="form-control">
        </div>
    </div>

    <div class="form-group row">
        <label for="rs_rmprmt_ket" class="col-sm-2 col-form-label">Keterangan</label>
        <div class="col-sm-10">
            <textarea class="form-control w-100" name="rs_rmprmt_ket" id="rs_rmprmt_ket" rows="3" cols="10"></textarea>
        </div>
    </div>


    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-primary">SIMPAN</button>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('formTabMt', 'formTabMt')">BATAL</button>
        </div>
    </div>
    <hr>
</form>

<div>
    <h4 class="text-center">Daftar Data Mutu</h4>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-success <?= $eEdit ?>" style="float: right;"
                onclick="showForm('formTabMt', 'block')"><i class="fas fa-plus"></i>
                Tambah</button>
        </div>
    </div>
    <table id="dtKformTabMt" class="dtK table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Tanggal</th>
                <th>Mutu</th>
                <th>Keterangan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Rmprmt as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td>
                <td>
                    Tanggal : <?= $tk['rs_rmprmt_tgl'] ?>
                </td>
                <td class="text-nowrap"><?= $tk['rs_rmmt_nm'] ?></td>
                <td><?= $tk['rs_rmprmt_ket'] ?></td>
                <td>
                    <?php
                        if ($MethodForm1 != "updateData") {
                        ?>
                    <button class="btn bg-gradient-danger <?= $eEdit ?>" title="Hapus Data Mutu Pasien"
                        onclick="callOther('Menghapus Data Mutu Pasien', '/rmprmt/deleteData/<?= $tk['rs_rmprmt_id_ex'] ?>')">
                        <i class='fas fa-trash'></i></button>
                    <?php
                        }
                        ?>
                </td>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>

<script>
$(function() {
    $(document).ready(function() {
        var formTabMt = $('#formTabMt');
        formTabMt.submit(function(e) {
            showAnimated();
            $('#formTabMt :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');

            e.preventDefault();
            $.ajax({
                type: formTabMt.attr('method'),
                url: formTabMt.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            window.location = '/<?= $UrlForm ?>';
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>