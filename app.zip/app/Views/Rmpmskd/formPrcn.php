<div class="row">
    <div class="col-lg-2 col-md-3 col-sm-12">
        <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
            <a class="nav-link" id="vTabRtPar" data-toggle="pill" href="#vTabRtItem" role="tab"
                aria-controls="vTabRtItem" aria-selected="true"
                onclick="addSess('tabVParent', 'vTabRtPar'); addSess('tabVItem', 'vTabRtItem');">Rencana & Terapi</a>
            <a class="nav-link" id="vTabJkPar" data-toggle="pill" href="#vTabJkItem" role="tab"
                aria-controls="vTabJkItem" aria-selected="false"
                onclick="addSess('tabVParent', 'vTabJkPar'); addSess('tabVItem', 'vTabJkItem');">Jadwal Kontrol</a>
            <a class="nav-link" id="vTabJtPar" data-toggle="pill" href="#vTabJtItem" role="tab"
                aria-controls="vTabJtItem" aria-selected="false"
                onclick="addSess('tabVParent', 'vTabJtPar'); addSess('tabVItem', 'vTabJtItem');">Jadwal Tindakan
                Invasif</a>
        </div>
    </div>
    <div class="col-lg-10 col-md-9 col-sm-12">
        <div class="tab-content" id="v-pills-tabContent">
            <div class="tab-pane fade" id="vTabRtItem" role="tabpanel" aria-labelledby="vTabRtPar">
                <?= $this->include('/Rmpmskd/formPcrnRt'); ?>
            </div>
            <div class="tab-pane fade" id="vTabJkItem" role="tabpanel" aria-labelledby="vTabJkPar">
                <?= $this->include('/Rmpmskd/formPcrnJk'); ?>
            </div>
            <div class="tab-pane fade" id="vTabJtItem" role="tabpanel" aria-labelledby="vTabJtPar">
                <?= $this->include('/Rmpmskd/formPcrnJt'); ?>
            </div>
        </div>
    </div>
</div>