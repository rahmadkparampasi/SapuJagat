<form class="form-horizontal form-valide" style="display: none;" method="POST" action="/rmprt/<?= $MethodForm ?>"
    id="formTabPcrnRt">
    <h4 class="text-center">Form Data Rencana & Terapi</h4>
    <div class="form-group row">
        <label for="rs_rmprt_t" class="col-sm-2 col-form-label">Tambahkan Rencana & Terapi</label>
        <div class="col-sm-10">
            <textarea name="rs_rmprt_t" id="rs_rmprt_t" class="form-control w-100 " cols="30" rows="10"></textarea>
        </div>
    </div>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-primary">SIMPAN</button>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('formTabPcrnRt', 'formTabPcrnRt')">BATAL</button>
        </div>
    </div>
    <hr>
</form>

<div>
    <h4 class="text-center">Daftar Data Rencana & Terapi</h4>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-success <?= $eEdit ?>" style="float: right;"
                onclick="showForm('formTabPcrnRt', 'block')"><i class="fas fa-plus"></i>
                Tambah</button>
        </div>
    </div>
    <table id="dtKformTabPcrnRt" class="dtK table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Rencana Dan Terapi</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Rmprt as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td>

                <td><?= $tk['rs_rmprt_t'] ?></td>
                <td>
                    <?php
                        if ($MethodForm1 != "updateData") {
                        ?>
                    <button class="btn bg-gradient-danger <?= $eEdit ?>" title="Hapus Data Rencana Dan Terapi Pasien"
                        onclick="callOther('Menghapus Data Rencana Dan Terapi Pasien', '<?= $BasePage ?>/deleteData/<?= $tk['rs_rmprt_id_ex'] ?>')">
                        <i class='fas fa-trash'></i></button>
                    <?php
                        }
                        ?>
                </td>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>

<script>
$(function() {
    $(document).ready(function() {
        var formTabPcrnRt = $('#formTabPcrnRt');
        formTabPcrnRt.submit(function(e) {
            showAnimated();
            $('#formTabPcrnRt :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');

            e.preventDefault();
            $.ajax({
                type: formTabPcrnRt.attr('method'),
                url: formTabPcrnRt.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            window.location = '/<?= $UrlForm ?>';
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>