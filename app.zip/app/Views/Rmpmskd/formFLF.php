<div>
    <h4 class="text-center">Daftar Data Layanan Farmasi</h4>
    <div class="form-group row">  
    <table id="dtKformTabPRes" class="table display responsive table-bordered table-striped w-100 nowrap">
        <thead>
            <tr>
                <th>No</th>
                <th>Tanggal Dan Waktu</th>
                <th>Kode Order</th>  
                <th>Detail</th> 
                <th>Pemberi Resep</th>
                <th>Gangguan Fungsi Ginjal</th>
                <th>Menyusui</th>
                <th>Hamil</th> 
                <th>CITO</th> 
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Rmpres as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td>
                <td>
                    Tanggal : <?= $tk['rs_rmpres_tgl'] ?><br>
                    Waktu : <?= $tk['rs_rmpres_jam'] ?>
                </td>
                <td class="text-nowrap"><?= $tk['rs_rmpres_kd'] ?></td> 
                <td>
                    <div class="row">
                        <div class="col-12">  
                            
                            <button type="button" class='btn bg-gradient-primary mx-1 my-2 btn-block <?= $eEdit ?>'
                                onclick="loadChildFormFlf('rmpflf')"><i
                                    class="fas fa-file-medical"></i>
                                Detail</button><br>
                           
                        </div> 
                    </div> 
                </td> 
                <td class="text-nowrap"><?= $tk['rs_rmpres_res'] ?></td>
                <td><?= $tk['rs_rmpres_fg'] ?></td>
                <td><?= $tk['rs_rmpres_ms'] ?></td>
                <td><?= $tk['rs_rmpres_hml'] ?></td> 
                <td><?= $tk['rs_rmpres_ct'] ?></td> 
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
    </div>
</div>
<div id="ChildFormFlf">

</div>
 
<script> 
function clearBox() {
    document.getElementById('ChildFormFlf').innerHTML = "";
} 

function loadChildFormFlf(link = '', idEx = '', k = '', t = '', j = '', r = '') {
    $.ajax({
        url: "/" + link + "/viewData/" + idEx + "/" + k + "/" + t + "/" + j + "/" + r,
        success: function(data) {

            $('#ChildFormFlf').html(data);
        }
    });
}
 
    $(function() {
        $(document).ready(function() {
            var formTabPlg = $('#formTabPlg');
            formTabPlg.submit(function(e) {
                showAnimated();
                $('#formTabPlg :input').prop("disabled", false);
                $(this).attr('disabled', 'disabled');

                e.preventDefault();
                $.ajax({
                    type: formTabPlg.attr('method'),
                    url: formTabPlg.attr('action'),
                    enctype: 'multipart/form-data',
                    data: new FormData(this),
                    contentType: false,
                    processData: false,
                    dataType: 'json',
                    success: function(data) {
                        hideAnimated();
                        if (data.response == "success") {
                            swal.fire({
                                title: "Terima Kasih",
                                text: data.message,
                                icon: data.response
                            }).then(function() {
                                window.location = '/<?= $UrlForm ?>';
                            });
                        } else {
                            hideAnimated();
                            swal.fire({
                                title: "Tidak Dapat Melanjutkan Proses",
                                text: data.message,
                                icon: data.response
                            });
                        }
                    },
                    error: function(xhr) {
                        hideAnimated();
                        console.log(xhr);
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: xhr.responseJSON.message,
                            icon: "error"
                        });
                    }
                });
            });
        });
    });
</script>