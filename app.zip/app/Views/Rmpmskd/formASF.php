<form class="form-horizontal form-valide" style="display: none;" method="POST" action="/rmpasf/<?= $MethodForm ?>"
    id="formTabASF">
    <h4 class="text-center">Form Data Anamnesis Status Fungsional</h4>

    <div class="form-group row">
        <label for="rs_rmpasf_ab" class="col-sm-2 col-form-label">Penggunaan Alat Bantu</label>
        <div class="col-sm-10">
            <select name="rs_rmpasf_ab" id="rs_rmpasf_ab" class="form-control" required>
                <option hidden value="">PILIH SALAH SATU PILIHAN</option>
                <option value="T">Tongkat</option>
                <option value="K">Kursi Roda</option>
                <option value="B">Brankard</option>
                <option value="W">Walker</option>
                <option value="L">Lainnya</option>
            </select>
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmpasf_absb" class="col-sm-2 col-form-label">Alat Bantu Lainnya, Sebutkan:</label>
        <div class="col-sm-10">
            <input type="text" name="rs_rmpasf_absb" id="rs_rmpasf_absb" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmpasf_ct" class="col-sm-2 col-form-label">Cacat Tubuh</label>
        <div class="col-sm-5">
            <select name="rs_rmpasf_ct" id="rs_rmpasf_ct" class="form-control" required>
                <option hidden value="">PILIH SALAH SATU PILIHAN</option>
                <option value="1">Tidak Ada</option>
                <option value="2">Ada</option>
            </select>
        </div>
        <div class="col-sm-5">
            <input type="text" name="rs_rmpasf_ctsb" id="rs_rmpasf_ctsb" class="form-control" placeholder="Sebutkan">
        </div>
    </div>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-primary">SIMPAN</button>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('formTabASF', 'formTabASF')">BATAL</button>
        </div>
    </div>
    <hr>
</form>

<div>
    <h4 class="text-center">Daftar Data Anamnesis Status Fungsional</h4>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-success <?= $eEdit ?>" style="float: right;"
                onclick="showForm('formTabASF', 'block'); resetForm('formTabASF')"><i class="fas fa-plus"></i>
                Tambah</button>
        </div>
    </div>
    <table id="dtKformTabASF" class="dtK table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Penggunaan Alat Bantu</th>
                <th>Cacat Tubuh</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Rmpasf as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td>
                <td>
                    <p id="rs_rmpasf_abc"><?= $tk['rs_rmpasf_ab'] ?></p> <button class="btn bg-gradient-primary"
                        onclick="copyTextTOC('rs_rmpasf_abc')"><i class="fa fa-clipboard"></i></button>
                </td>
                <td>
                    <p id="rs_rmpasf_ctc"><?= $tk['rs_rmpasf_ct'] ?></p> <button class="btn bg-gradient-primary"
                        onclick="copyTextTOC('rs_rmpasf_ctc')"><i class="fa fa-clipboard"></i></button>
                </td>
                <td>
                    <?php
                        if ($MethodForm1 != "updateData") {
                        ?>
                    <button class="btn bg-gradient-danger <?= $eEdit ?>"
                        title="Hapus Data Anamnesis Status Fungsional Pasien"
                        onclick="callOther('Menghapus Data Anamnesis Status Fungsional Pasien', '/rmpasf/deleteData/<?= $tk['rs_rmpasf_id_ex'] ?>')">
                        <i class='fas fa-trash'></i></button>
                    <?php
                        }
                        ?>
                </td>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>

<script>
$(function() {
    $(document).ready(function() {
        var formTabASF = $('#formTabASF');
        formTabASF.submit(function(e) {
            showAnimated();
            $('#formTabASF :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');

            e.preventDefault();
            $.ajax({
                type: formTabASF.attr('method'),
                url: formTabASF.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            window.location = '/<?= $UrlForm ?>';
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>