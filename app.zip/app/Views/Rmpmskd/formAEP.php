<form class="form-horizontal form-valide" style="display: none;" method="POST" action="/rmpaep/<?= $MethodForm ?>"
    id="formTabAEP">
    <h4 class="text-center">Form Data Anamnesis Edukasi Pasien Dan Keluarga</h4>

    <div class="form-group row">
        <label for="rs_rmpaep_kpi" class="col-sm-2 col-form-label">Kesediaan Pasien/Keluarga Menerima Informasi:
        </label>
        <div class="col-sm-10">
            <select name="rs_rmpaep_kpi" id="rs_rmpaep_kpi" class="form-control" required>
                <option hidden value="">PILIH SALAH SATU PILIHAN</option>
                <option value="0">Tidak</option>
                <option value="1">Ya</option>
            </select>
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmpaep_he" class="col-sm-2 col-form-label">Terdapat Hambatan Dalam Edukasi :</label>
        <div class="col-sm-10">
            <select name="rs_rmpaep_he" id="rs_rmpaep_he" class="form-control" required>
                <option hidden value="">PILIH SALAH SATU PILIHAN</option>
                <option value="0">Tidak</option>
                <option value="1">Ya</option>
            </select>
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmpaep_dp" class="col-sm-2 col-form-label">Dibutuhkan Penerjemah :</label>
        <div class="col-sm-10">
            <select name="rs_rmpaep_dp" id="rs_rmpaep_dp" class="form-control" required>
                <option hidden value="">PILIH SALAH SATU PILIHAN</option>
                <option value="0">Tidak</option>
                <option value="1">Ya</option>
            </select>
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmpaep_dps" class="col-sm-2 col-form-label">Sebutkan Bahasa Penerjemah</label>
        <div class="col-sm-10">
            <input type="text" name="rs_rmpaep_dps" id="rs_rmpaep_dps" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmpaep_ke" class="col-sm-2 col-form-label">Kebutuhan Edukasi </label>
        <div class="col-sm-10">
            <textarea name="rs_rmpaep_ke" id="rs_rmpaep_ke" cols="30" rows="2" class="form-control w-100"></textarea>
        </div>
    </div>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-primary">SIMPAN</button>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('formTabAEP', 'formTabAEP')">BATAL</button>
        </div>
    </div>
    <hr>
</form>

<div>
    <h4 class="text-center">Daftar Data Anamnesis Edukasi Pasien Dan Keluarga</h4>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-success <?= $eEdit ?>" style="float: right;"
                onclick="showForm('formTabAEP', 'block'); resetForm('formTabAEP')"><i class="fas fa-plus"></i>
                Tambah</button>
        </div>
    </div>
    <table id="dtKformTabAEP" class="dtK table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Kesediaan Pasien/Keluarga Menerima Informasi</th>
                <th>Terdapat Hambatan Dalam Edukasi</th>
                <th>Dibutuhkan Penerjemah (Jika Ya, Sebutkan)</th>
                <th>Kebutuhan Edukasi</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Rmpaep as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td>
                <td><?= $tk['rs_rmpaep_kpi'] ?></td>
                <td><?= $tk['rs_rmpaep_he'] ?></td>
                <td><?= $tk['rs_rmpaep_dp'] ?></td>
                <td>
                    <p id="rs_rmpaep_kec"><?= $tk['rs_rmpaep_ke'] ?></p> <button class="btn bg-gradient-primary"
                        onclick="copyTextTOC('rs_rmpaep_kec')"><i class="fa fa-clipboard"></i></button>
                </td>
                <td>
                    <?php
                        if ($MethodForm1 != "updateData") {
                        ?>
                    <button class="btn bg-gradient-danger <?= $eEdit ?>"
                        title="Hapus Data Anamnesis Edukasi Pasien Dan Keluarga Pasien"
                        onclick="callOther('Menghapus Data Anamnesis Edukasi Pasien Dan Keluarga Pasien', '/rmpaep/deleteData/<?= $tk['rs_rmpaep_id_ex'] ?>')">
                        <i class='fas fa-trash'></i></button>
                    <?php
                        }
                        ?>
                </td>
            </tr>
            <?php endforeach ?>
        </tbody>
        <tfoot>
            <tr>
                <th>No</th>
                <th>Kesediaan Pasien/Keluarga Menerima Informasi</th>
                <th>Terdapat Hambatan Dalam Edukasi</th>
                <th>Dibutuhkan Penerjemah (Jika Ya, Sebutkan)</th>
                <th>Kebutuhan Edukasi</th>
                <th>Aksi</th>
            </tr>
        </tfoot>
    </table>
</div>

<script>
$(function() {
    $(document).ready(function() {
        var formTabAEP = $('#formTabAEP');
        formTabAEP.submit(function(e) {
            showAnimated();
            $('#formTabAEP :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');

            e.preventDefault();
            $.ajax({
                type: formTabAEP.attr('method'),
                url: formTabAEP.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            window.location = '/<?= $UrlForm ?>';
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>