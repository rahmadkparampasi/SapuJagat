<form class="form-horizontal form-valide" style="display: none;" method="POST" action="/rmped/<?= $MethodForm ?>"
    id="formTabEd">
    <h4 class="text-center">Form Data Edukasi</h4>

    <div class="form-group row">
        <label for="rs_rmped_anm" class="col-sm-2 col-form-label">Deskripsi Anamnesis</label>
        <div class="col-sm-10">
            <textarea name="rs_rmped_anm" id="rs_rmped_anm" class="form-control w-100 " cols="30" rows="10"
                required></textarea>
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmped_pp" class="col-sm-2 col-form-label">Riwayat Perjalanan Penyakit</label>
        <div class="col-sm-10">
            <textarea name="rs_rmped_pp" id="rs_rmped_pp" class="form-control w-100 " cols="30" rows="10"
                required></textarea>
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmped_pf" class="col-sm-2 col-form-label">Deskripsi Pemeriksaan Fisik</label>
        <div class="col-sm-10">
            <textarea name="rs_rmped_pf" id="rs_rmped_pf" class="form-control w-100 " cols="30" rows="10"
                required></textarea>
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmped_ed" class="col-sm-2 col-form-label">Edukasi / Follow Up</label>
        <div class="col-sm-10">
            <input type="text" name="rs_rmped_ed" id="rs_rmped_ed" class="form-control" required>
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmped_ug" class="col-sm-2 col-form-label">Segera Kembali ke Gawat Darurat Rumah Sakit Jika
            Terjadi</label>
        <div class="col-sm-10">
            <input type="text" name="rs_rmped_ug" id="rs_rmped_ug" class="form-control" required>
        </div>
    </div>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-primary">SIMPAN</button>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('formTabEd', 'formTabEd')">BATAL</button>
        </div>
    </div>
    <hr>
</form>

<div>
    <h4 class="text-center">Daftar Data Edukasi</h4>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-success <?= $eEdit ?>" style="float: right;"
                onclick="showForm('formTabEd', 'block'); resetForm('formTabEd')"><i class="fas fa-plus"></i>
                Tambah</button>
        </div>
    </div>
    <table id="dtKformTabEd" class="dtK table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Deskripsi Anamnesis</th>
                <th>Riwayat Perjalanan Penyakit</th>
                <th>Deskripsi Pemeriksaan Fisik</th>
                <th>Edukasi / Follow Up</th>
                <th>Segera Kembali ke Gawat Darurat Rumah Sakit Jika Terjadi</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Rmped as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td>
                <td><?= $tk['rs_rmped_anm'] ?></td>
                <td><?= $tk['rs_rmped_pp'] ?></td>
                <td><?= $tk['rs_rmped_pf'] ?></td>
                <td><?= $tk['rs_rmped_ed'] ?></td>
                <td><?= $tk['rs_rmped_ug'] ?></td>
                <td>
                    <?php
                        if ($MethodForm1 != "updateData") {
                        ?>
                    <button class="btn bg-gradient-danger <?= $eEdit ?>" title="Hapus Data Edukasi Pasien"
                        onclick="callOther('Menghapus Data Edukasi Pasien', '/rmped/deleteData/<?= $tk['rs_rmped_id_ex'] ?>')">
                        <i class='fas fa-trash'></i></button>
                    <?php
                        }
                        ?>
                </td>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>

<script>
$(function() {
    $(document).ready(function() {
        var formTabEd = $('#formTabEd');
        formTabEd.submit(function(e) {
            showAnimated();
            $('#formTabEd :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');

            e.preventDefault();
            $.ajax({
                type: formTabEd.attr('method'),
                url: formTabEd.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            window.location = '/<?= $UrlForm ?>';
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>