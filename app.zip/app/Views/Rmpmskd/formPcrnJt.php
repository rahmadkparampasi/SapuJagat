<form class="form-horizontal form-valide" style="display: none;" method="POST" action="/rmpjt/<?= $MethodForm ?>"
    id="formTabPcrnJt">
    <h4 class="text-center">Form Data Tindakan Invasif</h4>
    <div class="form-group row">
        <label for="rs_rmpjt_tgl" class="col-sm-2 col-form-label">Tanggal</label>
        <div class="col-sm-10">
            <input type="date" name="rs_rmpjt_tgl" id="rs_rmpjt_tgl" class="form-control">
        </div>
    </div>

    <div class="form-group row">
        <label for="rs_rmpjt_rmwk" class="col-sm-2 col-form-label">Waktu</label>
        <div class="col-sm-10">
            <select name="rs_rmpjt_rmwk" id="rs_rmpjt_rmwk" class="form-control"
                onfocus="ambilDataSelect('rs_rmpjt_rmwk', '/rmwk/getAllForSelect/', 'Pilih Salah Satu Pilihan', toRemove=[], removeMessage=[], '')">
                <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
            </select>
        </div>
    </div>

    <div class="form-group row">
        <label for="rs_rmpjt_rmr" class="col-sm-2 col-form-label">Ruangan / Unit</label>
        <div class="col-sm-10">
            <select name="rs_rmpjt_rmr" id="rs_rmpjt_rmr" class="form-control"
                onfocus="ambilDataSelect('rs_rmpjt_rmr', '/rmr/getAllForSelectByPrt/<?= $setRmr['setRmrPl'] ?>', 'Pilih Salah Satu Pilihan', toRemove=[], removeMessage=[], '')"
                onchange="ambilDataSelect('rs_rmpjt_rmtdk', '/rmrtdk/getAllForSelectByRmr/', 'Pilih Salah Satu Pilihan', toRemove=['rs_rmpjt_rmtdk', 'rs_rmpjt_rmtdk'], removeMessage=['Pilih Salah Satu Pilihan', 'Pilih Salah Satu Pilihan'], 'rs_rmpjt_rmr'); ambilDataSelect('rs_rmpjt_ppeg', '/ppr/getAllForSelectByRmr/', 'Pilih Salah Satu Pilihan', toRemove=['rs_rmpjt_ppeg', 'rs_rmpjt_ppeg'], removeMessage=['Pilih Salah Satu Pilihan', 'Pilih Salah Satu Pilihan'], 'rs_rmpjt_rmr');">
                <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
            </select>
        </div>
    </div>

    <div class="form-group row">
        <label for="rs_rmpjt_rmtdk" class="col-sm-2 col-form-label">Tindakan</label>
        <div class="col-sm-10">
            <select name="rs_rmpjt_rmtdk" id="rs_rmpjt_rmtdk" class="form-control">
                <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
            </select>
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmpjt_ppeg" class="col-sm-2 col-form-label">Dokter</label>
        <div class="col-sm-10">
            <select name="rs_rmpjt_ppeg" id="rs_rmpjt_ppeg" class="form-control">
                <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
            </select>
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmpjt_ket" class="col-sm-2 col-form-label">Keterangan</label>
        <div class="col-sm-10">
            <textarea name="rs_rmpjt_ket" id="rs_rmpjt_ket" class="form-control w-100 " cols="30" rows="10"></textarea>
        </div>
    </div>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-primary">SIMPAN</button>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('formTabPcrnJt', 'formTabPcrnJt')">BATAL</button>
        </div>
    </div>
    <hr>
</form>

<div>
    <h4 class="text-center">Daftar Data Tindakan Invasif</h4>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-success <?= $eEdit ?>" style="float: right;"
                onclick="showForm('formTabPcrnJt', 'block')"><i class="fas fa-plus"></i>
                Tambah</button>
        </div>
    </div>
    <table id="dtKformTabPcrnJt" class="dtK table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Tanggal Dan Waktu</th>
                <th>Ruangan / Unit</th>
                <th>Tindakan</th>
                <th>Dokter</th>
                <th>Keterangan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Rmpjt as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td>

                <td>Tanggal : <?= $tk['rs_rmpjt_tgl'] ?><br>Waktu : <?= $tk['rs_rmwk_nm'] ?></td>
                <td><?= $tk['rs_rmr_nm'] ?></td>
                <td><?= $tk['rs_rmtdk_nm'] ?></td>
                <td><?= $tk['rs_ppeg_nm'] ?></td>
                <td><?= $tk['rs_rmpjt_ket'] ?></td>
                <td>
                    <?php
                        if ($MethodForm1 != "updateData") {
                        ?>
                    <button class="btn bg-gradient-danger <?= $eEdit ?>" title="Hapus Data Tindakan Invasif Pasien"
                        onclick="callOther('Menghapus Data Tindakan Invasif Pasien', '<?= $BasePage ?>/deleteData/<?= $tk['rs_rmpjt_id_ex'] ?>')">
                        <i class='fas fa-trash'></i></button>
                    <?php
                        }
                        ?>
                </td>
            </tr>
            <?php endforeach ?>
        </tbody>

    </table>
</div>

<script>
$(function() {
    $(document).ready(function() {
        var formTabPcrnJt = $('#formTabPcrnJt');
        formTabPcrnJt.submit(function(e) {
            showAnimated();
            $('#formTabPcrnJt :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');

            e.preventDefault();
            $.ajax({
                type: formTabPcrnJt.attr('method'),
                url: formTabPcrnJt.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            window.location = '/<?= $UrlForm ?>';
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>