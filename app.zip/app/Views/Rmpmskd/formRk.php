<form class="form-horizontal form-valide" style="display: none;" method="POST" action="/rmprk/<?= $MethodForm ?>"
    id="formTabRk">
    <h4 class="text-center">Form Data Rujukan Keluar</h4>

    <div class="form-group row">
        <label for="rs_rmprk_tgl" class="col-sm-2 col-form-label">Tanggal</label>
        <div class="col-sm-10">
            <input type="date" id="rs_rmprk_tgl" name="rs_rmprk_tgl" required class="form-control">
        </div>
    </div>

    <div class="bootstrap-timepicker">
        <div class="form-group row">
            <label for="rs_rmprk_jam" class="col-sm-2 col-form-label">Waktu</label>
            <div class="col-sm-10">
                <div class="input-group date" id="timepickerRmprk" data-target-input="nearest">
                    <input type="text" class="form-control datetimepicker-input" data-target="#timepickerRmprk"
                        id="rs_rmprk_jam" name="rs_rmprk_jam" required>
                    <div class="input-group-append" data-target="#timepickerRmprk" data-toggle="datetimepicker">
                        <div class="input-group-text"><i class="far fa-clock"></i></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
    $(function() {
        //Timepicker
        $('#timepickerRmprk').datetimepicker({
            format: 'HH:mm',
            use24hours: true
        })
    });
    </script>

    <div class="form-group row">
        <label for="rs_rmprk_rmjr" class="col-sm-2 col-form-label">Jenis Rujukan</label>
        <div class="col-sm-10">
            <select name="rs_rmprk_rmjr" id="rs_rmprk_rmjr" class="form-control" required
                onfocus="ambilDataSelect('rs_rmprk_rmjr', '/rmjr/getAllForSelect/', 'Pilih Salah Satu Pilihan', toRemove=[], removeMessage=[], '')">
                <option hidden>PILIH SALAH SATU PILIHAN</option>
            </select>
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmprk_rmppk" class="col-sm-2 col-form-label">Tujuan PPK</label>
        <div class="col-sm-10">
            <select name="rs_rmprk_rmppk" id="rs_rmprk_rmppk" class="form-control" required
                onfocus="ambilDataSelect('rs_rmprk_rmppk', '/rmppk/getAllForSelect/', 'Pilih Salah Satu Pilihan', toRemove=[], removeMessage=[], '')">
                <option hidden>PILIH SALAH SATU PILIHAN</option>
            </select>
        </div>
    </div>

    <div class="form-group row">
        <label for="rs_rmprk_rmrr" class="col-sm-2 col-form-label">Tujuan Ruangan / Poli</label>
        <div class="col-sm-10">
            <select name="rs_rmprk_rmrr" id="rs_rmprk_rmrr" class="form-control" required
                onfocus="ambilDataSelect('rs_rmprk_rmrr', '/rmrr/getAllForSelect/', 'Pilih Salah Satu Pilihan', toRemove=[], removeMessage=[], '')">
                <option hidden>PILIH SALAH SATU PILIHAN</option>
            </select>
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmprk_rmicdt" class="col-sm-2 col-form-label">Diagnosa (ICD 10)</label>
        <div class="col-sm-8">
            <input type="text" name="rs_rmprk_rmicdtnm" id="rs_rmprk_rmicdtnm" class="form-control " disabled required>
            <input type="hidden" name="rs_rmprk_rmicdt" id="rs_rmprk_rmicdt" class="form-control " required>
        </div>
        <div class="col-sm-2">
            <button type="button" class='btn bg-gradient-primary mx-1' data-target="#modalViewRmIcdt"
                data-toggle="modal" style="float: right;"
                onclick="showRmIcdt('rs_rmprk_rmicdtnm', 'rs_rmprk_rmicdt')"><i class="fas fa-file-archive"></i>
                AMBIL ICD 10</button>
        </div>
    </div>

    <div class="form-group row">
        <label for="rs_rmprk_ppeg" class="col-sm-2 col-form-label">Dokter</label>
        <div class="col-sm-8">
            <input type="hidden" id="rs_rmprk_ppeg" name="rs_rmprk_ppeg" required class="form-control">
            <input type="text" id="rs_rmprk_ppegnm" name="rs_rmprk_ppegnm" required class="form-control" disabled>
        </div>
        <div class="col-sm-2">
            <button type="button" class='btn bg-gradient-primary mx-1' data-target="#modalViewPprC" data-toggle="modal"
                style="float: right;"
                onclick="showPprC('<?= $Rmpr['rs_rmpr_rmr'] ?>', 'rs_rmprk_ppeg', 'rs_rmprk_ppegnm')"><i
                    class="fas fa-file-archive"></i>
                AMBIL DOKTER</button>
        </div>
    </div>

    <div class="form-group row">
        <label for="rs_rmprk_ket" class="col-sm-2 col-form-label">Keterangan</label>
        <div class="col-sm-10">
            <textarea class="form-control w-100" name="rs_rmprk_ket" id="rs_rmprk_ket" rows="3" cols="10"></textarea>
        </div>
    </div>


    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-primary">SIMPAN</button>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('formTabRk', 'formTabRk')">BATAL</button>
        </div>
    </div>
    <hr>
</form>

<div>
    <h4 class="text-center">Daftar Data Rujukan Keluar</h4>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-success <?= $eEdit ?>" style="float: right;"
                onclick="showForm('formTabRk', 'block')"><i class="fas fa-plus"></i>
                Tambah</button>
        </div>
    </div>
    <table id="dtKformTabRk" class="dtK table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Tanggal Dan Waktu</th>
                <th>Jenis Rujukan</th>
                <th>PPK</th>
                <th>Tujuan Ruangan / Poli</th>
                <th>Diagnosa (ICD 10)</th>
                <th>Dokter</th>
                <th>Keterangan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Rmprk as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td>
                <td>
                    Tanggal : <?= $tk['rs_rmprk_tgl'] ?><br>
                    Waktu : <?= $tk['rs_rmprk_jam'] ?>
                </td>
                <td class="text-nowrap"><?= $tk['rs_rmjr_nm'] ?></td>
                <td><?= $tk['rs_rmppk_nm'] ?></td>
                <td><?= $tk['rs_rmrr_nm'] ?></td>
                <td><?= $tk['rs_rmicdt_kd'] ?> - <?= $tk['rs_rmicdt_nm'] ?></td>
                <td><?= $tk['rs_ppeg_nm'] ?></td>
                <td><?= $tk['rs_rmprk_ket'] ?></td>
                <td>
                    <?php
                        if ($MethodForm1 != "updateData") {
                        ?>
                    <button class="btn bg-gradient-danger <?= $eEdit ?>" title="Hapus Data Rujukan Keluar Pasien"
                        onclick="callOther('Menghapus Data Rujukan Keluar Pasien', '/rmprk/deleteData/<?= $tk['rs_rmprk_id_ex'] ?>')">
                        <i class='fas fa-trash'></i></button>
                    <?php
                        }
                        ?>
                </td>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>

<script>
$(function() {
    $(document).ready(function() {
        var formTabRk = $('#formTabRk');
        formTabRk.submit(function(e) {
            showAnimated();
            $('#formTabRk :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');

            e.preventDefault();
            $.ajax({
                type: formTabRk.attr('method'),
                url: formTabRk.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            window.location = '/<?= $UrlForm ?>';
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>