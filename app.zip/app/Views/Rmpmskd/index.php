<?= $this->extend('Templates/template'); ?>

<?= $this->section('content'); ?>
<!-- /.row -->


<div class="row">
    <!-- Area Chart -->
    <div class="col-md-3 col-sm-12">
        <!-- Widget: user widget style 1 -->
        <div class="card">
            <div class="card-body">
                <a href="/rmppd/viewData/<?= $Rmpmsk['rs_rmpp_id_ex'] ?>" class='btn btn-block bg-gradient-danger mx-1' style="float: right;"><i class="fas fa-reply" onclick="addSess('tabParent', 'TabTri')"></i>
                    KEMBALI</a>
            </div>
        </div>
        <div class="card card-widget widget-user">
            <!-- Add the bg color to the header using any of the bg-* classes -->
            <div class="widget-user-header bg-info h-auto">
                <h3 class="widget-user-username"><?= $Rmpmsk['rs_rmpp_nm'] ?></h3>
                <h5 class="widget-user-desc">No. RM : <h3><span class="badge badge-danger"><?= $Rmpmsk['rs_rmpp_rm'] ?></span></h3>
                </h5>
            </div>
            <div class="card-footer py-0">
                <div class="row py-1">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="description-block text-left">
                            <h5 class="description-header">Tanggal Masuk RS</h5>
                            <h5><span class="description-text badge badge-success"><?= $Rmpmsk['rs_rmpmsk_tgl'] ?></span>
                            </h5>
                        </div>
                        <!-- /.description-block -->
                    </div>
                    <!-- /.col -->
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="description-block text-left">
                            <h5 class="description-header">Jam Masuk RS</h5>
                            <h5><span class="description-text badge badge-primary"><?= $Rmpmsk['rs_rmpmsk_jam'] ?></span>
                            </h5>
                        </div>
                        <!-- /.description-block -->
                    </div>
                    <!-- /.col -->
                </div>
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="description-block text-left">
                            <h5 class="description-header">Tanggal Lahir</h5>
                            <h5><span class="description-text badge badge-info"><?= $Rmpmsk['rs_rmpp_tgl_lhr'] ?></span>
                            </h5>
                        </div>
                        <!-- /.description-block -->
                    </div>
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="description-block text-left">
                            <h5 class="description-header">Jenis Kelamin</h5>
                            <h5><span class="description-text badge badge-warning"><?= $Rmpmsk['rs_rmpp_jk'] ?></span>
                            </h5>
                        </div>
                        <!-- /.description-block -->
                    </div>
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="description-block text-left">
                            <h5 class="description-header">Alamat</h5>
                            <h5><?= $Rmpmsk['rs_rmpmsk_alt1'] ?></h5>
                        </div>
                        <!-- /.description-block -->
                    </div>
                </div>
                <!-- /.row -->
            </div>
        </div>
        <div class="card card-primary">
            <div class="card-header">
                <h3 class="card-title">Biodata</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <strong><i class="fas fa-id-card mr-1"></i> Identitas</strong>
                <p class="text-muted">

                    <?= $Rmpmsk['rs_rmi_nm'] ?>: <?= $Rmpmsk['rs_rmpp_ind'] ?>
                </p>
                <hr>

                <strong><i class="fas fa-calendar mr-1"></i> Tempat, Tanggal Lahir</strong>
                <p class="text-muted">

                    <?= $Rmpmsk['rs_rmpp_tmpt_lhr'] ?>,<?= $Rmpmsk['rs_rmpp_tgl_lhr'] ?>
                </p>
                <hr>

                <strong><i class="fas fa-map-marked mr-1"></i> Alamat KTP</strong>
                <p class="text-muted">

                    <?= $Rmpmsk['rs_rmpp_altktp'] ?>
                </p>
                <hr>

                <strong><i class="fas fa-heart mr-1"></i> Agama</strong>
                <p class="text-muted">

                    <?= $Rmpmsk['rs_rma_nm'] ?>
                </p>
                <hr>

                <strong><i class="fas fa-hand-holding-heart mr-1"></i> Status</strong>
                <p class="text-muted">
                    <?= $Rmpmsk['rs_rmsts_nm'] ?>
                </p>
                <hr>

                <strong><i class="fas fa-graduation-cap mr-1"></i> Pendidikan</strong>
                <p class="text-muted">
                    <?= $Rmpmsk['rs_rmpdk_nm'] ?>
                </p>
                <hr>

                <strong><i class="fas fa-briefcase mr-1"></i> Pekerjaan</strong>
                <p class="text-muted">
                    <?= $Rmpmsk['rs_rmkrj_nm'] ?>
                </p>
                <hr>

                <strong><i class="fas fa-language mr-1"></i> Bahasa</strong>
                <p class="text-muted">
                    <?= $Rmpmsk['rs_rmpp_bhs'] ?>
                </p>
                <hr>
                <strong><i class="fas fa-flag mr-1"></i> Suku / Bangsa</strong>
                <p class="text-muted">
                    <?= $Rmpmsk['rs_rmpp_sb'] ?>
                </p>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.widget-user -->
    </div>
    <?= $this->include('Rmpmskd/viewAccordion'); ?>

</div>

<?= $this->include('Rmpmskd/modalViewRmIcdt'); ?>
<?= $this->include('Rmpmskd/modalViewRmIcdn'); ?>
<?= $this->include('Rmpmskd/modalViewRmtdk'); ?>
<?= $this->include('Rmpmskd/modalViewRmtdkC'); ?>
<?= $this->include('Rmpmskd/modalViewPpr'); ?>
<?= $this->include('Rmpmskd/modalViewPprC'); ?>
<?= $this->include('Rmpmskd/modalViewKkt'); ?>
<?= $this->include('Rmpmskd/modalViewJTslah'); ?>
<script>
    function showV(tabVParent = '', tabVItem = '') {
        // console.log("session tabVParent " + sessionStorage.getItem("tabVParent"));
        if (sessionStorage.getItem("tabVParent") === null || sessionStorage.getItem("tabVParent") === "") {

            tabVPar = document.getElementById(tabVParent);
            tabVPar.classList.add("show");
            tabVPar.classList.add("active");
            tabVItem = document.getElementById(tabVItem);
            tabVItem.classList.add("show");
            tabVItem.classList.add("active");
        } else {
            if (tabVItem != sessionStorage.getItem("tabVItem") && tabVParent != sessionStorage.getItem("tabVParent")) {
                tabVPar = document.getElementById(tabVParent);
                tabVPar.classList.add("show");
                tabVPar.classList.add("active");
                tabVItem = document.getElementById(tabVItem);
                tabVItem.classList.add("show");
                tabVItem.classList.add("active");
            }
        }
    }

    function showAccor() {
        if (sessionStorage.getItem("tabAccor") === null || sessionStorage.getItem("tabAccor") === "") {
            tabAccor = document.getElementById("collapseRm");
            tabAccor.classList.add("show");
        } else {
            tabAccor = document.getElementById(sessionStorage.getItem("tabAccor"));
            tabAccor.classList.add("show");
        }
    }

    function closeModal(modal = '') {
        // console.log(modal);
        $('#' + modal).modal('hide');
    }
</script>
<script>
    $(document).ready(function() {
        showAccor();
        // console.log(sessionStorage.getItem("tabParent"));
        if (sessionStorage.getItem("tabParent") === null || sessionStorage.getItem("tabParent") === "") {
            tabPar = document.getElementById("TabParTri");
            tabPar.classList.add("active");
        } else {
            tabPar = document.getElementById(sessionStorage.getItem("tabParent"));
            if (tabPar!=null) {
                tabPar.classList.add("active");                
            }
        }

        if (sessionStorage.getItem("tabItem") === null || sessionStorage.getItem("tabItem") === "") {
            tabItem = document.getElementById("TabItemTri");
            tabItem.classList.add("active");
        } else {
            tabItem = document.getElementById(sessionStorage.getItem("tabItem"));
            if (tabItem!=null) {
                tabItem.classList.add("active");
            }
        }

        if (sessionStorage.getItem("tabVParent") === null || sessionStorage.getItem("tabVParent") === "") {} else {
            tabVPar = document.getElementById(sessionStorage.getItem("tabVParent"));
            tabVPar.classList.add("show");
            tabVPar.classList.add("active");
            tabVItem = document.getElementById(sessionStorage.getItem("tabVItem"));
            tabVItem.classList.add("show");
            tabVItem.classList.add("active");
        }

        $('#datatableKirana1').DataTable({
            "order": [
                [0, "asc"]
            ],
            pageLength: 10,
            responsive: true,
            fixedHeader: true,
            keys: true,
            columnDefs: [{
                    responsivePriority: 1,
                    target: 0
                },
                {
                    responsivePriority: 10001,
                    target: 4
                },
                {
                    responsivePriority: 2,
                    target: -2
                }
            ]
        });
    });
</script>

<?= $this->endSection(); ?>