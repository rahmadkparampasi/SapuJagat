<div class="modal fade bd-example-modal-lg" id="modalViewRmTdk" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabelPdf">LIHAT DATA TINDAKAN </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <table id="dtkRmtdk" class="table responsive table-bordered table-striped w-100">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Aksi</th>
                            <th class="text-nowrap">Nama Tindakan</th>
                            <th class="text-nowrap">Kategori Tindakan</th>
                        </tr>
                    </thead>
                </table>

                <script type="text/javascript">
                function showRmTdk(name = '', idEx = '', rs_rmpr_rmr = '') {

                    var dt = $('#dtkRmtdk').DataTable({
                        ajax: "<?= base_url('rmrtdk/getRmtdkByJson') ?>/" + rs_rmpr_rmr + "/" + name + "/" +
                            idEx,
                        "order": [
                            [0, "asc"]
                        ],
                        destroy: true,
                        pageLength: 10,
                        responsive: true,
                        fixedHeader: false,
                        keys: true,
                        language: {
                            paginate: {
                                previous: "Sebelumnya",
                                next: "Selanjutnya"
                            },
                            "emptyTable": "Data Tindakan Belum Ada",
                        },
                        columns: [{
                                "data": "no"
                            },
                            {
                                "data": "button"
                            },
                            {
                                "data": "rs_rmtdk_nm"
                            },
                            {
                                "data": "rs_rmktdk_nm"
                            },
                        ]
                    });
                }

                function destroyTdk() {
                    $('#dtkRmtdk').DataTable({
                        destroy: true,
                    });
                }
                </script>
            </div>
            <div class="modal-footer">
                <div class="item form-group">
                    <button type="button" class="btn btn-danger" data-dismiss="modal"
                        onclick="destroyTdk()">TUTUP</button>
                </div>
            </div>
        </div>
    </div>
</div>