<form class="form-horizontal form-valide" style="display: none;" method="POST" action="/rmpr/<?= $MethodForm ?>"
    id="formTabRmpr">
    <h4 class="text-center">Form Data Mutasi</h4>

    <div class="form-group row">
        <label for="rs_rmpr_tgl" class="col-sm-2 col-form-label">Tanggal</label>
        <div class="col-sm-10">
            <input type="date" id="rs_rmpr_tgl" name="rs_rmpr_tgl" required class="form-control">
        </div>
    </div>

    <div class="bootstrap-timepicker">
        <div class="form-group row">
            <label for="rs_rmpr_jam" class="col-sm-2 col-form-label">Waktu</label>
            <div class="col-sm-10">
                <div class="input-group date" id="timepickerRmpmpr" data-target-input="nearest">
                    <input type="text" class="form-control datetimepicker-input" data-target="#timepickerRmpmpr"
                        id="rs_rmpr_jam" name="rs_rmpr_jam" required>
                    <div class="input-group-append" data-target="#timepickerRmpmpr" data-toggle="datetimepicker">
                        <div class="input-group-text"><i class="far fa-clock"></i></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
    $(function() {
        //Timepicker
        $('#timepickerRmpmpr').datetimepicker({
            format: 'HH:mm',
            use24hours: true
        })
    });
    </script>

    <div class="form-group row">
        <label for="rs_rmpr_rmr" class="col-sm-2 col-form-label">Tujuan Unit</label>
        <div class="col-sm-8">
            <select name="rs_rmpr_rmr" id="rs_rmpr_rmr" class="form-control"
                onfocus="ambilDataSelect('rs_rmpr_rmr', '/setdftr/getAllForSelectRmrByRmr/<?= $setRmr['setRmrIri'] ?>', 'Pilih Salah Satu Pilihan', toRemove=['rs_rmpr_rmr'], removeMessage=['Pilih Salah Satu Pilihan'], '')"
                onchange="addFill('rs_rmprtt_rmrkkt', ''); addFill('rs_rmr_nm', '')">
                <option hidden value="">PILIH SALAH SATU PILIHAN</option>
            </select>
        </div>
    </div>

    <div class="form-group row">
        <label for="rs_rmprtt_rmrkkt" class="col-sm-2 col-form-label">Tambahkan Kamar Dan Tempat Tidur</label>
        <div class="col-sm-8">
            <input type="hidden" id="rs_rmprtt_rmrkkt" name="rs_rmprtt_rmrkkt" required class="form-control">
            <input type="text" id="rs_rmr_nm" name="rs_rmr_nm" required class="form-control" disabled>
        </div>
        <div class="col-sm-2">
            <button type="button" class='btn bg-gradient-primary mx-1' data-target="#modalViewKkt" data-toggle="modal"
                style="float: right;"
                onclick="showKkt(document.getElementById('rs_rmpr_rmr').value, 'rs_rmprtt_rmrkkt', 'rs_rmr_nm')"><i
                    class="fas fa-file-archive"></i>AMBIL KAMAR</button>
        </div>
    </div>


    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-primary">SIMPAN</button>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('formTabRmpr', 'formTabRmpr')">BATAL</button>
        </div>
    </div>
    <hr>
</form>

<div>
    <h4 class="text-center">Daftar Data Mutasi</h4>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-success <?= $eEdit ?>" style="float: right;"
                onclick="showForm('formTabRmpr', 'block')"><i class="fas fa-plus"></i>
                Tambah</button>
        </div>
    </div>
    <table id="dtKformTabRmpr" class="dtK table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Tanggal Dan Waktu</th>
                <th>Jenis Rujukan</th>
                <th>PPK</th>
                <th>Tujuan Ruangan / Poli</th>
                <th>Diagnosa (ICD 10)</th>
                <th>Dokter</th>
                <th>Keterangan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Rmprk as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td>
                <td>
                    Tanggal : <?= $tk['rs_rmprk_tgl'] ?><br>
                    Waktu : <?= $tk['rs_rmprk_jam'] ?>
                </td>
                <td class="text-nowrap"><?= $tk['rs_rmjr_nm'] ?></td>
                <td><?= $tk['rs_rmppk_nm'] ?></td>
                <td><?= $tk['rs_rmrr_nm'] ?></td>
                <td><?= $tk['rs_rmicdt_kd'] ?> - <?= $tk['rs_rmicdt_nm'] ?></td>
                <td><?= $tk['rs_ppeg_nm'] ?></td>
                <td><?= $tk['rs_rmprk_ket'] ?></td>
                <td>
                    <?php
                        if ($MethodForm1 != "updateData") {
                        ?>
                    <button class="btn bg-gradient-danger <?= $eEdit ?>" title="Hapus Data Mutasi Pasien"
                        onclick="callOther('Menghapus Data Mutasi Pasien', '/rmprk/deleteData/<?= $tk['rs_rmprk_id_ex'] ?>')">
                        <i class='fas fa-trash'></i></button>
                    <?php
                        }
                        ?>
                </td>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>

<script>
$(function() {
    $(document).ready(function() {
        var formTabRmpr = $('#formTabRmpr');
        formTabRmpr.submit(function(e) {
            showAnimated();
            $('#formTabRmpr :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');

            e.preventDefault();
            $.ajax({
                type: formTabRmpr.attr('method'),
                url: formTabRmpr.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            window.location = '/<?= $UrlForm ?>';
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>