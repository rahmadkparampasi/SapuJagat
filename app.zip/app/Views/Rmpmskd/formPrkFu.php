<form class="form-horizontal form-valide" style="display: none;" method="POST" action="/rmpprkfu/<?= $MethodForm ?>"
    id="formTabPrkFu">
    <h4 class="text-center">Form Data Pemeriksaan Fungsional</h4>

    <div class="form-group row">
        <label for="rs_rmpprkfu_ab" class="col-sm-2 col-form-label">Alat Bantu</label>
        <div class="col-sm-10">
            <input type="text" name="rs_rmpprkfu_ab" id="rs_rmpprkfu_ab" class="form-control" required>
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmpprkfu_pro" class="col-sm-2 col-form-label">Prothesa</label>
        <div class="col-sm-10">
            <input type="text" name="rs_rmpprkfu_pro" id="rs_rmpprkfu_pro" class="form-control" required>
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmpprkfu_ct" class="col-sm-2 col-form-label">Cacat Tubuh</label>
        <div class="col-sm-10">
            <input type="text" name="rs_rmpprkfu_ct" id="rs_rmpprkfu_ct" class="form-control" required>
        </div>
    </div>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-primary">SIMPAN</button>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('formTabPrkFu', 'formTabPrkFu')">BATAL</button>
        </div>
    </div>
    <hr>
</form>

<div>
    <h4 class="text-center">Daftar Data Pemeriksaan Fungsional</h4>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-success <?= $eEdit ?>" style="float: right;"
                onclick="showForm('formTabPrkFu', 'block'); resetForm('formTabPrkFu')"><i class="fas fa-plus"></i>
                Tambah</button>
        </div>
    </div>
    <table id="dtKformTabPrkFu" class="dtK table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Alat Bantu</th>
                <th>Prothesa</th>
                <th>Cacat Tubuh</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Rmpprkfu as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td>
                <td><?= $tk['rs_rmpprkfu_ab'] ?></td>
                <td><?= $tk['rs_rmpprkfu_pro'] ?></td>
                <td><?= $tk['rs_rmpprkfu_ct'] ?></td>
                <td>
                    <?php
                        if ($MethodForm1 != "updateData") {
                        ?>
                    <button class="btn bg-gradient-danger <?= $eEdit ?>"
                        title="Hapus Data Pemeriksaan Fungsional Pasien"
                        onclick="callOther('Menghapus Data Pemeriksaan Fungsional Pasien', '/rmpprkfu/deleteData/<?= $tk['rs_rmpprkfu_id_ex'] ?>')">
                        <i class='fas fa-trash'></i></button>
                    <?php
                        }
                        ?>
                </td>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>

<script>
$(function() {
    $(document).ready(function() {
        var formTabPrkFu = $('#formTabPrkFu');
        formTabPrkFu.submit(function(e) {
            showAnimated();
            $('#formTabPrkFu :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');

            e.preventDefault();
            $.ajax({
                type: formTabPrkFu.attr('method'),
                url: formTabPrkFu.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            window.location = '/<?= $UrlForm ?>';
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>