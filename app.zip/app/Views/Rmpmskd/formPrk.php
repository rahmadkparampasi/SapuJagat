<div class="row">
    <div class="col-lg-2 col-md-3 col-sm-12">
        <div class="nav flex-column nav-pills" id="v-pills-tab-prk" role="tablist" aria-orientation="vertical">
            <a class="nav-link" id="vTabPrkUTPar" data-toggle="pill" href="#vTabPrkUTItem" role="tab" aria-controls="vTabPrkUTItem" aria-selected="true" onclick="addSess('tabVParent', 'vTabPrkUTPar'); addSess('tabVItem', 'vTabPrkUTItem');">Tanda Vital</a>
            <a class="nav-link" id="vTabPrkNPar" data-toggle="pill" href="#vTabPrkNItem" role="tab" aria-controls="vTabPrkNItem" aria-selected="true" onclick="addSess('tabVParent', 'vTabPrkNPar'); addSess('tabVItem', 'vTabPrkNItem');">Nutrisi</a>
            <a class="nav-link" id="vTabPrkFuPar" data-toggle="pill" href="#vTabPrkFuItem" role="tab" aria-controls="vTabPrkFuItem" aria-selected="true" onclick="addSess('tabVParent', 'vTabPrkFuPar'); addSess('tabVItem', 'vTabPrkFuItem');">Fungsional</a>
            <a class="nav-link" id="vTabPrkFPar" data-toggle="pill" href="#vTabPrkFItem" role="tab" aria-controls="vTabPrkFItem" aria-selected="true" onclick="addSess('tabVParent', 'vTabPrkFPar'); addSess('tabVItem', 'vTabPrkFItem');">Fisik</a>
        </div>
    </div>
    <div class="col-lg-10 col-md-9 col-sm-12">
        <div class="tab-content" id="v-pills-tabContent-prk">
            <div class="tab-pane fade" id="vTabPrkUTItem" role="tabpanel" aria-labelledby="vTabPrkUTPar">
                <?= $this->include('/Rmpmskd/formPrkT'); ?>
            </div>
            <div class="tab-pane fade" id="vTabPrkNItem" role="tabpanel" aria-labelledby="vTabPrkNPar">
                <?= $this->include('/Rmpmskd/formPrkN'); ?>
            </div>
            <div class="tab-pane fade" id="vTabPrkFuItem" role="tabpanel" aria-labelledby="vTabPrkFuPar">
                <?= $this->include('/Rmpmskd/formPrkFu'); ?>
            </div>
            <div class="tab-pane fade" id="vTabPrkFItem" role="tabpanel" aria-labelledby="vTabPrkFPar">
                <?= $this->include('/Rmpmskd/formPrkF'); ?>
            </div>
        </div>
    </div>
</div>