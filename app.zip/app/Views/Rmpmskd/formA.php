<div class="row">
    <div class="col-lg-2 col-md-3 col-sm-12">
        <div class="nav flex-column nav-pills" id="v-pills-tab-icd" role="tablist" aria-orientation="vertical">
            <a class="nav-link" id="vTabAUPar" data-toggle="pill" href="#vTabAUItem" role="tab" aria-controls="vTabAUItem" aria-selected="true" onclick="addSess('tabVParent', 'vTabAUPar'); addSess('tabVItem', 'vTabAUItem');">Umum</a>
            <a class="nav-link" id="vTabARPPar" data-toggle="pill" href="#vTabARPItem" role="tab" aria-controls="vTabARPItem" aria-selected="false" onclick="addSess('tabVParent', 'vTabARPPar'); addSess('tabVItem', 'vTabARPItem');">Riwayat Perjalanan Penyakit</a>
            <a class="nav-link" id="vTabARAPar" data-toggle="pill" href="#vTabARAItem" role="tab" aria-controls="vTabARAItem" aria-selected="false" onclick="addSess('tabVParent', 'vTabARAPar'); addSess('tabVItem', 'vTabARAItem');">Riwayat Alergi</a>
            <a class="nav-link" id="vTabARPOPar" data-toggle="pill" href="#vTabARPOItem" role="tab" aria-controls="vTabARPOItem" aria-selected="false" onclick="addSess('tabVParent', 'vTabARPOPar'); addSess('tabVItem', 'vTabARPOItem');">Alergi Pemberian Obat</a>
            <a class="nav-link" id="vTabAKUPar" data-toggle="pill" href="#vTabAKUItem" role="tab" aria-controls="vTabAKUItem" aria-selected="false" onclick="addSess('tabVParent', 'vTabAKUPar'); addSess('tabVItem', 'vTabAKUItem');">Keluhan Utama</a>
            <a class="nav-link" id="vTabASFPar" data-toggle="pill" href="#vTabASFItem" role="tab" aria-controls="vTabASFItem" aria-selected="false" onclick="addSess('tabVParent', 'vTabASFPar'); addSess('tabVItem', 'vTabASFItem');">Status Fungsional</a>
            <a class="nav-link" id="vTabAKSPPar" data-toggle="pill" href="#vTabAKSPItem" role="tab" aria-controls="vTabAKSPItem" aria-selected="false" onclick="addSess('tabVParent', 'vTabAKSPPar'); addSess('tabVItem', 'vTabAKSPItem');">Kondisi Sosial & Psikososial</a>
            <a class="nav-link" id="vTabAEPKPar" data-toggle="pill" href="#vTabAEPKItem" role="tab" aria-controls="vTabAEPKItem" aria-selected="false" onclick="addSess('tabVParent', 'vTabAEPKPar'); addSess('tabVItem', 'vTabAEPKItem');">Edukasi Pasien & Keluarga</a>
            <a class="nav-link" id="vTabAPGPar" data-toggle="pill" href="#vTabAPGItem" role="tab" aria-controls="vTabAPGItem" aria-selected="false" onclick="addSess('tabVParent', 'vTabAPGPar'); addSess('tabVItem', 'vTabAPGItem');">Permasalahan Gizi</a>
        </div>
    </div>
    <div class="col-lg-10 col-md-9 col-sm-12">
        <div class="tab-content" id="v-pills-tabContent-icd">
            <div class="tab-pane fade" id="vTabAUItem" role="tabpanel" aria-labelledby="vTabAUPar">
                <?= $this->include('/Rmpmskd/formAU'); ?>
            </div>
            <div class="tab-pane fade" id="vTabARPItem" role="tabpanel" aria-labelledby="vTabARPPar">
                <?= $this->include('/Rmpmskd/formARP'); ?>
            </div>
            <div class="tab-pane fade" id="vTabARAItem" role="tabpanel" aria-labelledby="vTabARAPar">
                <?= $this->include('/Rmpmskd/formARA'); ?>
            </div>
            <div class="tab-pane fade" id="vTabARPOItem" role="tabpanel" aria-labelledby="vTabARPOPar">
                <?= $this->include('/Rmpmskd/formARO'); ?>
            </div>
            <div class="tab-pane fade" id="vTabAKUItem" role="tabpanel" aria-labelledby="vTabAKUPar">
                <?= $this->include('/Rmpmskd/formAKU'); ?>
            </div>
            <div class="tab-pane fade" id="vTabASFItem" role="tabpanel" aria-labelledby="vTabASFPar">
                <?= $this->include('/Rmpmskd/formASF'); ?>
            </div>
            <div class="tab-pane fade" id="vTabAKSPItem" role="tabpanel" aria-labelledby="vTabAKSPPar">
                <?= $this->include('/Rmpmskd/formAKSP'); ?>
            </div>
            <div class="tab-pane fade" id="vTabAEPKItem" role="tabpanel" aria-labelledby="vTabAEPKPar">
                <?= $this->include('/Rmpmskd/formAEP'); ?>
            </div>
            <div class="tab-pane fade" id="vTabAPGItem" role="tabpanel" aria-labelledby="vTabAPGPar">
                <?= $this->include('/Rmpmskd/formAPG'); ?>
            </div>
        </div>
    </div>
</div>