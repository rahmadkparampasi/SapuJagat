<form class="form-horizontal form-valide" style="display: none;" method="POST" action="/rmpau/<?= $MethodForm ?>"
    id="formTabAU">
    <h4 class="text-center">Form Data Anamnesis Umum</h4>

    <div class="form-group row">
        <label for="rs_rmpau_au" class="col-sm-2 col-form-label">Anamnesis Umum</label>
        <div class="col-sm-10">
            <textarea name="rs_rmpau_au" id="rs_rmpau_au" class="form-control w-100 " cols="30" rows="10"
                required></textarea>
        </div>
    </div>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-primary">SIMPAN</button>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('formTabAU', 'formTabAU')">BATAL</button>
        </div>
    </div>
    <hr>
</form>

<div>
    <h4 class="text-center">Daftar Data Anamnesis Umum</h4>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-success <?= $eEdit ?>" style="float: right;"
                onclick="showForm('formTabAU', 'block'); resetForm('formTabAU')"><i class="fas fa-plus"></i>
                Tambah</button>
        </div>
    </div>
    <table id="dtKformTabAU" class="dtK table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Anamnesis Umum</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Rmpau as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td>
                <td>
                    <p id="rs_rmpau_auc"><?= $tk['rs_rmpau_au'] ?></p> <button class="btn bg-gradient-primary"
                        onclick="copyTextTOC('rs_rmpau_auc')"><i class="fa fa-clipboard"></i> Salin Teks</button>
                </td>
                <td>
                    <?php
                        if ($MethodForm1 != "updateData") {
                        ?>
                    <button class="btn bg-gradient-danger <?= $eEdit ?>" title="Hapus Data Anamnesis Umum Pasien"
                        onclick="callOther('Menghapus Data Anamnesis Umum Pasien', '/rmpau/deleteData/<?= $tk['rs_rmpau_id_ex'] ?>')">
                        <i class='fas fa-trash'></i></button>
                    <?php
                        }
                        ?>
                </td>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>

<script>
$(function() {
    $(document).ready(function() {
        var formTabAU = $('#formTabAU');
        formTabAU.submit(function(e) {
            showAnimated();
            $('#formTabAU :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');

            e.preventDefault();
            $.ajax({
                type: formTabAU.attr('method'),
                url: formTabAU.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            window.location = '/<?= $UrlForm ?>';
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>