<div>
    <h4 class="text-center">Daftar Layanan Laboratorium</h4>
    <table id="dtKformTabLL" class="dtK table responsive table-bordered table-striped" width="100%" data-page-length="5">
        <thead>
            <tr>
                <th>No</th>
                <th>Tanggal Dan Waktu</th>
                <th>Pemberi Layanan</th>
                <th>Tindakan</th>
                <th>Dokter</th>
                <th>Diagnosa</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Rmplabt as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td>
                <td>
                    Tanggal : <?= $tk['rs_rmplab_tgl'] ?><br>
                    Waktu : <?= $tk['rs_rmplab_jam'] ?>
                </td>
                <td>
                    <div class="row">
                        <div class="col-12">


                            <button type="button" class='btn bg-gradient-primary mx-1 my-2 btn-block <?= $eEdit ?>'
                                onclick="loadChildFormLL('rmplabtw', '<?= $tk['rs_rmplabt_id_ex'] ?>', '<?= $tk['rs_rmplab_tgl'] ?>', '<?= $tk['rs_rmplab_jam'] ?>', '<?= $tk['rs_rmtdk_nm'] ?>'); "><i
                                    class="fas fa-user-nurse"></i>
                                DETAIL</button><br>
                        </div>

                    </div>
                </td>
                <td><?= $tk['rs_rmtdk_nm'] ?></td>
                <td><?= $tk['rs_ppeg_nm'] ?></td>
                <td class="text-nowrap"><?= $tk['rs_rmplab_diag'] ?></td>
                <td>
                    
                </td>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>
<div id="ChildFormLL">

</div>
<script>
function clearBoxLL() {
    document.getElementById('ChildFormLL').innerHTML = "";
}

function loadChildFormLL(link = '', idEx = '', t = '', j = '', p = '') {
    $.ajax({
        url: "/" + link + "/viewData/" + idEx + "/" + t + "/" + j + "/" + p ,
        success: function(data) {

            $('#ChildFormLL').html(data);
        }
    });
}
$(function() {
    $(document).ready(function() {
        var formTabLL = $('#formTabLL');
        formTabLL.submit(function(e) {
            showAnimated();
            $('#formTabLL :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');

            e.preventDefault();
            $.ajax({
                type: formTabLL.attr('method'),
                url: formTabLL.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            window.location = '/<?= $UrlForm ?>';
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>