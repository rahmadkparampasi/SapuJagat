<form class="form-horizontal form-valide" style="display: none;" method="POST" action="/rmpplg/<?= $MethodForm ?>"
    id="formTabPlg">
    <h4 class="text-center">Form Data Pulang</h4>

    <div class="form-group row">
        <label for="rs_rmpplg_tgl" class="col-sm-2 col-form-label">Tanggal</label>
        <div class="col-sm-10">
            <input type="date" id="rs_rmpplg_tgl" name="rs_rmpplg_tgl" required class="form-control">
        </div>
    </div>

    <div class="bootstrap-timepicker">
        <div class="form-group row">
            <label for="rs_rmpplg_jam" class="col-sm-2 col-form-label">Waktu</label>
            <div class="col-sm-10">
                <div class="input-group date" id="timepickerRmpplg" data-target-input="nearest">
                    <input type="text" class="form-control datetimepicker-input" data-target="#timepickerRmpplg"
                        id="rs_rmpplg_jam" name="rs_rmpplg_jam" required>
                    <div class="input-group-append" data-target="#timepickerRmpplg" data-toggle="datetimepicker">
                        <div class="input-group-text"><i class="far fa-clock"></i></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
    $(function() {
        //Timepicker
        $('#timepickerRmpplg').datetimepicker({
            format: 'HH:mm',
            use24hours: true
        })
    });
    </script>

    <div class="form-group row">
        <label for="rs_rmpplg_rmck" class="col-sm-2 col-form-label">Cara Keluar</label>
        <div class="col-sm-10">
            <select name="rs_rmpplg_rmck" id="rs_rmpplg_rmck" class="form-control" required
                onfocus="ambilDataSelect('rs_rmpplg_rmck', '/rmck/getAllForSelect/', 'Pilih Salah Satu Pilihan', toRemove=[], removeMessage=[], '')">
                <option hidden>PILIH SALAH SATU PILIHAN</option>
            </select>
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmpplg_rmkk" class="col-sm-2 col-form-label">Keadaan Keluar</label>
        <div class="col-sm-10">
            <select name="rs_rmpplg_rmkk" id="rs_rmpplg_rmkk" class="form-control" required
                onfocus="ambilDataSelect('rs_rmpplg_rmkk', '/rmkk/getAllForSelect/', 'Pilih Salah Satu Pilihan', toRemove=[], removeMessage=[], '')">
                <option hidden>PILIH SALAH SATU PILIHAN</option>
            </select>
        </div>
    </div>

    <div class="form-group row">
        <label for="rs_rmpplg_ppeg" class="col-sm-2 col-form-label">Dokter</label>
        <div class="col-sm-8">
            <input type="hidden" id="rs_rmpplg_ppeg" name="rs_rmpplg_ppeg" required class="form-control">
            <input type="text" id="rs_rmpplg_ppegnm" name="rs_rmpplg_ppegnm" required class="form-control" disabled>
        </div>
        <div class="col-sm-2">
            <button type="button" class='btn bg-gradient-primary mx-1' data-target="#modalViewPprC" data-toggle="modal"
                style="float: right;"
                onclick="showPprC('<?= $Rmpr['rs_rmpr_rmr'] ?>', 'rs_rmpplg_ppeg', 'rs_rmpplg_ppegnm')"><i
                    class="fas fa-file-archive"></i>
                AMBIL DOKTER</button>
        </div>
    </div>

    <div class="form-group row">
        <label for="rs_rmpplg_diag" class="col-sm-2 col-form-label">Keterangan</label>
        <div class="col-sm-10">
            <textarea class="form-control w-100" name="rs_rmpplg_diag" id="rs_rmpplg_diag" rows="3"
                cols="10"></textarea>
        </div>
    </div>


    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-primary">SIMPAN</button>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('formTabPlg', 'formTabPlg')">BATAL</button>
        </div>
    </div>
    <hr>
</form>

<div>
    <h4 class="text-center">Daftar Data Pulang</h4>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-success <?= $eEdit ?>" style="float: right;"
                onclick="showForm('formTabPlg', 'block')"><i class="fas fa-plus"></i>
                Tambah</button>
        </div>
    </div>
    <table id="dtKformTabPlg" class="dtK table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Tanggal Dan Waktu</th>
                <th>Cara Keluar</th>
                <th>Keadaan Keluar</th>
                <th>Dokter</th>
                <th>Diagnosa</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Rmpplg as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td>
                <td>
                    Tanggal : <?= $tk['rs_rmpplg_tgl'] ?><br>
                    Waktu : <?= $tk['rs_rmpplg_jam'] ?>
                </td>
                <td class="text-nowrap"><?= $tk['rs_rmck_nm'] ?></td>
                <td><?= $tk['rs_rmkk_nm'] ?></td>
                <td><?= $tk['rs_ppeg_nm'] ?></td>
                <td><?= $tk['rs_rmpplg_diag'] ?></td>
                <td>
                    <?php
                        if ($MethodForm1 != "updateData") {
                        ?>
                    <button class="btn bg-gradient-danger <?= $eEdit ?>" title="Hapus Data Pulang Pasien"
                        onclick="callOther('Menghapus Data Pulang Pasien', '/rmpplg/deleteData/<?= $tk['rs_rmpplg_id_ex'] ?>')">
                        <i class='fas fa-trash'></i></button>
                    <?php
                        }
                        ?>
                </td>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>

<script>
$(function() {
    $(document).ready(function() {
        var formTabPlg = $('#formTabPlg');
        formTabPlg.submit(function(e) {
            showAnimated();
            $('#formTabPlg :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');

            e.preventDefault();
            $.ajax({
                type: formTabPlg.attr('method'),
                url: formTabPlg.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            window.location = '/<?= $UrlForm ?>';
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>