<div class="modal fade bd-example-modal-lg" id="modalViewPprC" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabelPdf">LIHAT DATA PEGAWAI DALAM RUANGAN </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <table id="dtkPprC" class="table responsive table-bordered table-striped w-100">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Aksi</th>
                            <th>NIP</th>
                            <th>Nama Pegawai</th>
                            <th>Kategori Pegawai</th>
                        </tr>
                    </thead>
                </table>


                <script type="text/javascript">
                function showPprC(rs_rmpr_rmr = '', id = '', v = '') {

                    var dt = $('#dtkPprC').DataTable({
                        ajax: "<?= base_url('ppr/getPprByJson') ?>/" + rs_rmpr_rmr + "/" + id + "/" + v,
                        "order": [
                            [0, "asc"]
                        ],
                        destroy: true,
                        pageLength: 10,
                        responsive: true,
                        fixedHeader: false,
                        keys: true,
                        language: {
                            paginate: {
                                previous: "Sebelumnya",
                                next: "Selanjutnya"
                            },
                            "emptyTable": "Data Pegawai Dalam Ruangan Belum Ada",
                        },
                        columns: [{
                                "data": "no"
                            },
                            {
                                "data": "buttonFill"
                            },
                            {
                                "data": "rs_ppeg_nip"
                            },
                            {
                                "data": "rs_ppeg_nm"
                            },
                            {
                                "data": "rs_pkp_nm"
                            },
                        ]
                    });
                }

                function destroyPprC() {
                    $('#dtkPprC').DataTable({
                        destroy: true,
                    });
                }
                </script>
            </div>
            <div class="modal-footer">
                <div class="item form-group">
                    <button type="button" class="btn btn-danger" data-dismiss="modal"
                        onclick="destroyPprC()">TUTUP</button>
                </div>
            </div>
        </div>
    </div>
</div>