<form class="form-horizontal form-valide" style="display: none;" method="POST" action="/rmpprkn/<?= $MethodForm ?>"
    id="formTabPrkN">
    <h4 class="text-center">Form Data Pemeriksaan Nutrisi</h4>

    <div class="form-group row">
        <label for="rs_rmpprkn_bb" class="col-sm-2 col-form-label">Berat Badan (Kg)</label>
        <div class="col-sm-10">
            <input type="number" step=".1" name="rs_rmpprkn_bb" id="rs_rmpprkn_bb" class="form-control" required>
            <p for="rs_rmpprkn_bb" class="text-muted">Dapat Menginputkan Angka Desimal, Dengan Pemisah Menggunakan Titik
                (.)</p>
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmpprkn_tb" class="col-sm-2 col-form-label">Tinggi Badan (Cm)</label>
        <div class="col-sm-10">
            <input type="number" step=".1" name="rs_rmpprkn_tb" id="rs_rmpprkn_tb" class="form-control" required>
            <p for="rs_rmpprkn_tb" class="text-muted">Dapat Menginputkan Angka Desimal, Dengan Pemisah Menggunakan Titik
                (.)</p>
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmpprkn_imt" class="col-sm-2 col-form-label">Indeks Masa Tubuh</label>
        <div class="col-sm-10">
            <input type="number" step=".01" name="rs_rmpprkn_imt" id="rs_rmpprkn_imt" class="form-control" required>
            <p for="rs_rmpprkn_imt" class="text-muted">Dapat Menginputkan Angka Desimal, Dengan Pemisah Menggunakan
                Titik (.)</p>
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmpprkn_lk" class="col-sm-2 col-form-label">Lingkar Kepala (Cm)</label>
        <div class="col-sm-10">
            <input type="number" step=".1" name="rs_rmpprkn_lk" id="rs_rmpprkn_lk" class="form-control" required>
            <p for="rs_rmpprkn_lk" class="text-muted">Dapat Menginputkan Angka Desimal, Dengan Pemisah Menggunakan Titik
                (.)</p>
        </div>
    </div>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-primary">SIMPAN</button>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('formTabPrkN', 'formTabPrkN')">BATAL</button>
        </div>
    </div>
    <hr>
</form>

<div>
    <h4 class="text-center">Daftar Data Pemeriksaan Nutrisi</h4>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-success <?= $eEdit ?>" style="float: right;"
                onclick="showForm('formTabPrkN', 'block'); resetForm('formTabPrkN')"><i class="fas fa-plus"></i>
                Tambah</button>
        </div>
    </div>
    <table id="dtKformTabPrkN" class="dtK table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Berat Badan</th>
                <th>Tinggi Badan</th>
                <th>Indeks Masa Tubuh</th>
                <th>Lingkar Kepala</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Rmpprkn as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td>
                <td><?= $tk['rs_rmpprkn_bb'] ?>Kg</td>
                <td><?= $tk['rs_rmpprkn_tb'] ?>Cm</td>
                <td><?= $tk['rs_rmpprkn_imt'] ?></td>
                <td><?= $tk['rs_rmpprkn_lk'] ?>Cm</td>
                <td>
                    <?php
                        if ($MethodForm1 != "updateData") {
                        ?>
                    <button class="btn bg-gradient-danger <?= $eEdit ?>" title="Hapus Data Pemeriksaan Nutrisi Pasien"
                        onclick="callOther('Menghapus Data Pemeriksaan Nutrisi Pasien', '/rmpprkn/deleteData/<?= $tk['rs_rmpprkn_id_ex'] ?>')">
                        <i class='fas fa-trash'></i></button>
                    <?php
                        }
                        ?>
                </td>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>

<script>
$(function() {
    $(document).ready(function() {
        var formTabPrkN = $('#formTabPrkN');
        formTabPrkN.submit(function(e) {
            showAnimated();
            $('#formTabPrkN :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');

            e.preventDefault();
            $.ajax({
                type: formTabPrkN.attr('method'),
                url: formTabPrkN.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            window.location = '/<?= $UrlForm ?>';
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>