<form class="form-horizontal form-valide" style="display: none;" method="POST" action="/rmpprkt/<?= $MethodForm ?>"
    id="formTabPrkT">
    <h4 class="text-center">Form Data Pemeriksaan Tanda Vital</h4>

    <div class="form-group row">
        <label for="rs_rmpprkt_tgl" class="col-sm-2 col-form-label">Tanggal Pemeriksaan</label>
        <div class="col-sm-10">
            <div class="input-group date" data-target-input="nearest">

                <input type="date" id="rs_rmpprkt_tgl" name="rs_rmpprkt_tgl" required class="form-control">
                <div class="input-group-append">
                    <div class="input-group-text"><i class="far fa-calendar"></i></div>
                </div>
            </div>
        </div>
    </div>

    <div class="bootstrap-timepicker">
        <div class="form-group row">
            <label for="rs_rmpprkt_jam" class="col-sm-2 col-form-label">Jam Pemeriksaan</label>
            <div class="col-sm-10">
                <div class="input-group date" id="timepickerPrkT" data-target-input="nearest">
                    <input type="text" class="form-control datetimepicker-input" data-target="#timepickerPrkT"
                        id="rs_rmpprkt_jam" name="rs_rmpprkt_jam" required>
                    <div class="input-group-append" data-target="#timepickerPrkT" data-toggle="datetimepicker">
                        <div class="input-group-text"><i class="far fa-clock"></i></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
    $(function() {
        //Timepicker
        $('#timepickerPrkT').datetimepicker({
            format: 'HH:mm',
            use24hours: true
        })
    });
    </script>

    <div class="form-group row">
        <label for="rs_rmpprkt_ku" class="col-sm-2 col-form-label">Keadaan Umum</label>
        <div class="col-sm-10">
            <input type="text" name="rs_rmpprkt_ku" id="rs_rmpprkt_ku" class="form-control " required>
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmpprkt_ks" class="col-sm-2 col-form-label">Kesadaran</label>
        <div class="col-sm-10">
            <input type="text" name="rs_rmpprkt_ks" id="rs_rmpprkt_ks" class="form-control " required>
        </div>
    </div>

    <div class="form-group row">
        <label for="rs_rmpprkt_sis" class="col-sm-2 col-form-label">Tekanan Darah (Sistolik / Diastolik) mmHg</label>
        <div class="col-sm-5">
            <input type="text" name="rs_rmpprkt_sis" id="rs_rmpprkt_sis" class="form-control " required placeholder="0">
        </div>
        <div class="col-sm-5">
            <input type="text" name="rs_rmpprkt_dias" id="rs_rmpprkt_dias" class="form-control " required
                placeholder="0">
        </div>
    </div>

    <div class="form-group row">
        <label for="rs_rmpprkt_sh" class="col-sm-2 col-form-label">Suhu (˚C)</label>
        <div class="col-sm-10">
            <input type="number" step=".1" name="rs_rmpprkt_sh" id="rs_rmpprkt_sh" class="form-control " required
                placeholder="˚C">
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmpprkt_fnd" class="col-sm-2 col-form-label">Frekuensi Nadi (X/Menit)</label>
        <div class="col-sm-10">
            <input type="number" name="rs_rmpprkt_fnd" id="rs_rmpprkt_fnd" class="form-control " required
                placeholder="0">
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmpprkt_fnf" class="col-sm-2 col-form-label">Frekuensi Nafas (X/Menit)</label>
        <div class="col-sm-10">
            <input type="number" name="rs_rmpprkt_fnf" id="rs_rmpprkt_fnf" class="form-control " required
                placeholder="0">
        </div>
    </div>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-primary">SIMPAN</button>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('formTabPrkT', 'formTabPrkT')">BATAL</button>
        </div>
    </div>
    <hr>
</form>

<div>
    <h4 class="text-center">Daftar Data Pemeriksaan Tanda Vital</h4>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-success <?= $eEdit ?>" style="float: right;"
                onclick="showForm('formTabPrkT', 'block'); resetForm('formTabPrkT')"><i class="fas fa-plus"></i>
                Tambah</button>
        </div>
    </div>
    <table id="dtKformTabPrkT" class="dtK table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Tanggal Dan Jam</th>
                <th>Keluhan Utama</th>
                <th>Kesadaran</th>
                <th>Tekanan Darah</th>
                <th>Suhu</th>
                <th>Frekuensi Nadi</th>
                <th>Frekuensi Nafas</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Rmpprkt as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td>

                <td>
                    Tanggal : <?= $tk['rs_rmpprkt_tgl'] ?><br>
                    Jam : <?= $tk['rs_rmpprkt_jam'] ?>
                </td>
                <td><?= $tk['rs_rmpprkt_ku'] ?></td>
                <td><?= $tk['rs_rmpprkt_ks'] ?></td>
                <td>Sistolik : <?= $tk['rs_rmpprkt_sis'] ?>mmHg<br>Diastolik: <?= $tk['rs_rmpprkt_dias'] ?>mmHg</td>
                <td><?= $tk['rs_rmpprkt_sh'] ?>˚C</td>
                <td><?= $tk['rs_rmpprkt_fnd'] ?>x/menit</td>
                <td><?= $tk['rs_rmpprkt_fnf'] ?>x/menit</td>
                <td>
                    <?php
                        if ($MethodForm1 != "updateData") {
                        ?>
                    <button class="btn bg-gradient-danger <?= $eEdit ?>"
                        title="Hapus Data Pemeriksaan Tanda Vital Pasien"
                        onclick="callOther('Menghapus Data Pemeriksaan Tanda Vital Pasien', '<?= $BasePage ?>/deleteData/<?= $tk['rs_rmpprkt_id_ex'] ?>')">
                        <i class='fas fa-trash'></i></button>
                    <?php
                        }
                        ?>
                </td>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>

<script>
$(function() {
    $(document).ready(function() {
        var formTabPrkT = $('#formTabPrkT');
        formTabPrkT.submit(function(e) {
            showAnimated();
            $('#formTabPrkT :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');

            e.preventDefault();
            $.ajax({
                type: formTabPrkT.attr('method'),
                url: formTabPrkT.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            window.location = '/<?= $UrlForm ?>';
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>