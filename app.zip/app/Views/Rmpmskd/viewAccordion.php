<div class="col-md-9 col-sm-12" id="accordion">
    <div class="callout callout-info">
        <h5><i class="fas fa-info"></i> Catatan:</h5>
        <p>Tombol : <button class="btn bg-gradient-primary"><i class="fa fa-clipboard"></i></button> Berwarna Biru
            Untuk Kebutuhan Menyalin Teks</p>
    </div>
    <div class="card card-success card-outline">
        <?= $this->include('Rmpmskd/viewNavPills'); ?>
    </div>
    <div class="card card-success card-outline">
        <a class="d-block w-100" data-toggle="collapse" href="#collapseTdk" onclick="addSess('tabAccor', 'collapseTdk');">
            <div class="card-header">
                <h4 class="card-title w-100">
                    Layanan
                </h4>
            </div>
        </a>
        <div id="collapseTdk" class="collapse" data-parent="#accordion">
            <div class="card-body">
                <?= $this->include('Rmpmskd/formPl'); ?>
            </div>
        </div>
    </div>
    <div class="card card-success card-outline">
        <a class="d-block w-100" data-toggle="collapse" href="#collapseLab" onclick="addSess('tabAccor', 'collapseLab');">
            <div class="card-header">
                <h4 class="card-title w-100">
                    Laboratorium
                </h4>
            </div>
        </a>
        <div id="collapseLab" class="collapse" data-parent="#accordion">
            <div class="card-body">
                <?= $this->include('Rmpmskd/formLab'); ?>
            </div>
        </div>
    </div>
    <div class="card card-success card-outline">
        <a class="d-block w-100" data-toggle="collapse" href="#collapseRad" onclick="addSess('tabAccor', 'collapseRad');">
            <div class="card-header">
                <h4 class="card-title w-100">
                    Radiologi
                </h4>
            </div>
        </a>
        <div id="collapseRad" class="collapse" data-parent="#accordion">
            <div class="card-body">
                <?= $this->include('Rmpmskd/formRad'); ?>
            </div>
        </div>
    </div>
    <div class="card card-success card-outline">
        <a class="d-block w-100" data-toggle="collapse" href="#collapseRes" onclick="addSess('tabAccor', 'collapseRes');">
            <div class="card-header">
                <h4 class="card-title w-100">
                    E-Resep
                </h4>
            </div>
        </a>
        <div id="collapseRes" class="collapse" data-parent="#accordion">
            <div class="card-body">
                <?= $this->include('Rmpmskd/formRes'); ?>
            </div>
        </div>
    </div>
    <div class="card card-info card-outline">
        <a class="d-block w-100" data-toggle="collapse" href="#collapseMt" onclick="addSess('tabAccor', 'collapseMt');">
            <div class="card-header">
                <h4 class="card-title w-100">
                    Mutu
                </h4>
            </div>
        </a>
        <div id="collapseMt" class="collapse" data-parent="#accordion">
            <div class="card-body">
                <?= $this->include('Rmpmskd/formMt'); ?>
            </div>
        </div>
    </div>
    <div class="card card-success card-outline">
        <a class="d-block w-100" data-toggle="collapse" href="#collapseRmpr" onclick="addSess('tabAccor', 'collapseRmpr');">
            <div class="card-header">
                <h4 class="card-title w-100">
                    Mutasi
                </h4>
            </div>
        </a>
        <div id="collapseRmpr" class="collapse" data-parent="#accordion">
            <div class="card-body">
                <?= $this->include('Rmpmskd/formRmpr'); ?>
            </div>
        </div>
    </div>
    <div class="card card-success card-outline">
        <a class="d-block w-100" data-toggle="collapse" href="#collapseRk" onclick="addSess('tabAccor', 'collapseRk');">
            <div class="card-header">
                <h4 class="card-title w-100">
                    Rujukan Keluar
                </h4>
            </div>
        </a>
        <div id="collapseRk" class="collapse" data-parent="#accordion">
            <div class="card-body">
                <?= $this->include('Rmpmskd/formRk'); ?>
            </div>
        </div>
    </div>
    <div class="card card-success card-outline">
        <a class="d-block w-100" data-toggle="collapse" href="#collapseSls" onclick="addSess('tabAccor', 'collapseSls');">
            <div class="card-header">
                <h4 class="card-title w-100">
                    Selesai
                </h4>
            </div>
        </a>
        <div id="collapseSls" class="collapse" data-parent="#accordion">
            <div class="card-body">
                <?= $this->include('Rmpmskd/formSls'); ?>
            </div>
        </div>
    </div>
    <div class="card card-success card-outline">
        <a class="d-block w-100" data-toggle="collapse" href="#collapsePlg" onclick="addSess('tabAccor', 'collapsePlg');">
            <div class="card-header">
                <h4 class="card-title w-100">
                    Pasien Pulang
                </h4>
            </div>
        </a>
        <div id="collapsePlg" class="collapse" data-parent="#accordion">
            <div class="card-body">
                <?= $this->include('Rmpmskd/formPlg'); ?>
            </div>
        </div>
    </div>
    <div class="card card-primary card-outline">
        <a class="d-block w-100" data-toggle="collapse" href="#collapseFLF" onclick="addSess('tabAccor', 'collapseFLF');">
            <div class="card-header">
                <h4 class="card-title w-100">
                    Layanan Farmasi
                </h4>
            </div>
        </a>
        <div id="collapseFLF" class="collapse" data-parent="#accordion">
            <div class="card-body">
                <?= $this->include('Rmpmskd/formFLF'); ?>
            </div>
        </div>
    </div>
    <div class="card card-primary card-outline">
        <a class="d-block w-100" data-toggle="collapse" href="#collapseFRPF" onclick="addSess('tabAccor', 'collapseFRPF');">
            <div class="card-header">
                <h4 class="card-title w-100">
                    Retur Pelayanan Farmasi
                </h4>
            </div>
        </a>
        <div id="collapseFRPF" class="collapse" data-parent="#accordion">
            <div class="card-body">
                <?= $this->include('Rmpmskd/formFRPF'); ?>
            </div>
        </div>
    </div>
    <div class="card card-danger card-outline">
        <a class="d-block w-100" data-toggle="collapse" href="#collapseLL" onclick="addSess('tabAccor', 'collapseLL');">
            <div class="card-header">
                <h4 class="card-title w-100">
                    Layanan Laboratorium
                </h4>
            </div>
        </a>
        <div id="collapseLL" class="collapse" data-parent="#accordion">
            <div class="card-body">
                <?= $this->include('Rmpmskd/formLL'); ?>
            </div>
        </div>
    </div>
    <div class="card card-danger card-outline">
        <a class="d-block w-100" data-toggle="collapse" href="#collapseLPA" onclick="addSess('tabAccor', 'collapseLPA');">
            <div class="card-header">
                <h4 class="card-title w-100">
                    Hasil Patologi Anatomi
                </h4>
            </div>
        </a>
        <div id="collapseLPA" class="collapse" data-parent="#accordion">
            <div class="card-body">
                <?= $this->include('Rmpmskd/formLPA'); ?>
            </div>
        </div>
    </div>
    <div class="card card-danger card-outline">
        <a class="d-block w-100" data-toggle="collapse" href="#collapseIHC" onclick="addSess('tabAccor', 'collapseIHC');">
            <div class="card-header">
                <h4 class="card-title w-100">
                    Hasil IHC
                </h4>
            </div>
        </a>
        <div id="collapseIHC" class="collapse" data-parent="#accordion">
            <div class="card-body">
                <?= $this->include('Rmpmskd/formIHC'); ?>
            </div>
        </div>
    </div> 
    <div class="card card-danger card-outline">
        <a class="d-block w-100" data-toggle="collapse" href="#collapseLLM" onclick="addSess('tabAccor', 'collapseLLM');">
            <div class="card-header">
                <h4 class="card-title w-100">
                    Hasil Lab Mikro
                </h4>
            </div>
        </a>
        <div id="collapseLLM" class="collapse" data-parent="#accordion">
            <div class="card-body">
                <?= $this->include('Rmpmskd/formLLM'); ?>
            </div>
        </div>
    </div>
    <div class="card card-warning card-outline">
        <a class="d-block w-100" data-toggle="collapse" href="#collapseRL" onclick="addSess('tabAccor', 'collapseRL');">
            <div class="card-header">
                <h4 class="card-title w-100">
                    Layanan Radiologi
                </h4>
            </div>
        </a>
        <div id="collapseRL" class="collapse" data-parent="#accordion">
            <div class="card-body">
                <?= $this->include('Rmpmskd/formRL'); ?>
            </div>
        </div>
    </div>

    <div class="card card-primary">
        <div class="card-header">
            <h3 class="card-title">Kedatangan</h3>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
            <div class="row">
                <div class="col-6 border-right">
                    <strong><i class="fas fa-id-card mr-1"></i> Cara Pembayaran</strong>
                    <p class="text-muted">
                        <?= $Rmpmsk['rs_rmpmsk_cp'] ?>
                    </p>
                    <hr>
                </div>
                <div class="col-6">
                    <strong><i class="fas fa-id-card mr-1"></i> Tinggal Dengan Siapa</strong>
                    <p class="text-muted">
                        <?= $Rmpmsk['rs_rmtgl_nm'] ?>
                    </p>
                    <hr>
                </div>
                <div class="col-6 border-right">
                    <strong><i class="fas fa-id-card mr-1"></i> Pernah Dirawat di RS Sebelumnya:</strong>
                    <p class="text-muted">
                        <?= $Rmpmsk['rs_rmpmsk_pr'] ?>
                    </p>
                    <hr>
                </div>
                <div class="col-6">
                    <strong><i class="fas fa-map-marked mr-1"></i> Dikirim / Rujuk Dari : </strong>
                    <p class="text-muted">
                        <?= $Rmpmsk['rs_rmpmsk_rjkd'] ?>
                    </p>
                    <hr>
                </div>
                <div class="col-6 border-right">
                    <strong><i class="fas fa-id-card mr-1"></i> Perlu Penerjemah</strong>
                    <p class="text-muted">
                        <?= $Rmpmsk['rs_rmpmsk_pp'] ?>
                    </p>
                    <hr>
                </div>
                <div class="col-6">
                    <strong><i class="fas fa-id-card mr-1"></i> Alat Bantu</strong>
                    <p class="text-muted">
                        <?= $Rmpmsk['rs_rmab_nm'] ?>
                    </p>
                    <hr>
                </div>
                <div class="col-6 border-right">
                    <strong><i class="fas fa-map-marked mr-1"></i> Alamat Saat Ini</strong>
                    <p class="text-muted">
                        <?= $Rmpmsk['rs_rmpmsk_alt'] ?>
                    </p>
                    <hr>
                </div>
                <div class="col-6">
                    <strong><i class="fas fa-id-card mr-1"></i> Penanggung Jawab</strong>
                    <p class="text-muted">
                        <?= $Rmpmsk['rs_rmpmsk_pj'] ?>
                    </p>
                    <hr>
                </div>
                <?php
                    if ($Rmpmsk['rs_rmpmsk_pj']=="1"||$Rmpmskpj!=null) {
                ?>
                    <div class="col-6 border-right">
                        <strong><i class="fas fa-map-marked mr-1"></i> Nama Penanggung Jawab</strong>
                        <p class="text-muted">
                            <?= $Rmpmskpj['rs_rmpmskpj_n'] ?>
                        </p>
                        <hr>
                    </div>
                    <div class="col-6">
                        <strong><i class="fas fa-map-marked mr-1"></i> Identitas Penanggung Jawab</strong>
                        <p class="text-muted">
                            <?= $Rmpmskpj['rs_rmi_nm'] ?>: <?= $Rmpmskpj['rs_rmpmskpj_ind'] ?>
                        </p>
                        <hr>
                    </div>
                    <div class="col-6 border-right">
                        <strong><i class="fas fa-id-card mr-1"></i> Jenis Kelamin Penanggung Jawab</strong>
                        <p class="text-muted">
                            <?= $Rmpmskpj['rs_rmpmskpj_jk'] ?>
                        </p>
                        <hr>
                    </div>
                    <div class="col-6">
                        <strong><i class="fas fa-map-marked mr-1"></i> Hubungan Penanggung Jawab</strong>
                        <p class="text-muted">
                            <?= $Rmpmskpj['rs_rmhub_nm'] ?>
                        </p>
                        <hr>
                    </div>
                    <div class="col-6 border-right">
                        <strong><i class="fas fa-id-card mr-1"></i> Alamat Sementara Penanggung Jawab</strong>
                        <p class="text-muted">
                            <?= $Rmpmskpj['rs_rmpmskpj_alt'] ?>
                        </p>
                        <hr>
                    </div>
                    <div class="col-6">
                        <strong><i class="fas fa-map-marked mr-1"></i> Alamat KTP Penanggung Jawab</strong>
                        <p class="text-muted">
                            <?= $Rmpmskpj['rs_rmpmskpj_altktp'] ?>
                        </p>
                        <hr>
                    </div>
                    <div class="col-6 border-right">
                        <strong><i class="fas fa-id-card mr-1"></i> Pendidikan Penanggung Jawab</strong>
                        <p class="text-muted">
                            <?= $Rmpmskpj['rs_rmpdk_nm'] ?>
                        </p>
                        <hr>
                    </div>
                    <div class="col-6">
                        <strong><i class="fas fa-map-marked mr-1"></i> Pekerjaan Penanggung Jawab</strong>
                        <p class="text-muted">
                            <?= $Rmpmskpj['rs_rmkrj_nm'] ?>
                        </p>
                        <hr>
                    </div>
                <?php
                    }
                ?>
                
            </div>
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->
</div>