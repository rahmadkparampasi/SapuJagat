<form class="form-horizontal form-valide" style="display: none;" method="POST" action="/rmpnln/<?= $MethodForm ?>"
    id="formTabNlN">
    <h4 class="text-center">Form Data Penilaian Nyeri</h4>

    <div class="row">
        <div class="col-lg-6 col-md-12 col-sm-12">
            <div class=" row">
                <label for="rs_rmpprkt_ku" class="col-sm-2">Nyeri: </label>
                <div class="col-lg-2 col-md-4 col-sm-6">
                    <div class="form-group">
                        <div class="custom-control custom-radio">
                            <input class="custom-control-input" type="radio" id="rs_rmpnln_ny1" name="rs_rmpnln_ny"
                                value="1">
                            <label for="rs_rmpnln_ny1" class="custom-control-label">
                                Ya</label>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-4 col-sm-6">
                    <div class="form-group">
                        <div class="custom-control custom-radio">
                            <input class="custom-control-input" type="radio" id="rs_rmpnln_ny2" name="rs_rmpnln_ny"
                                value="2">
                            <label for="rs_rmpnln_ny2" class="custom-control-label">
                                Tidak</label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-sm-12">
            <div class=" row">
                <label for="rs_rmpprkt_ku" class="col-lg-6 col-md-12 col-sm-4">Jika Nyeri, Tingkat Nyeri: </label>
                <div class="col-lg-3 col-md-4 col-sm-4">
                    <div class="form-group">
                        <div class="custom-control custom-radio">
                            <input class="custom-control-input" type="radio" id="rs_rmpnln_os1" name="rs_rmpnln_os"
                                value="AK">
                            <label for="rs_rmpnln_os1" class="custom-control-label">Akut</label>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-4">
                    <div class="form-group">
                        <div class="custom-control custom-radio">
                            <input class="custom-control-input" type="radio" id="rs_rmpnln_os2" name="rs_rmpnln_os"
                                value="KR">
                            <label for="rs_rmpnln_os2" class="custom-control-label">Kronis</label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-6 col-md-12 col-sm-12">
            <div class="form-group row">
                <label for="rs_rmpprkt_ku" class="col-4">Skala Nyeri: </label>
                <div class="col-lg-2 col-md-4 col-sm-6">
                    <input class="form-control" type="number" id="rs_rmpnln_sn" name="rs_rmpnln_sn">
                </div>
            </div>
        </div>
        <div class="col-md-6 col-sm-12">

            <label for="rs_rmpprkt_ku" class="col-lg-6 col-md-12 col-sm-4">Metode: </label>
            <div class=" row">
                <div class="col-lg-3 col-md-5 col-sm-4">
                    <div class="form-group">
                        <div class="custom-control custom-radio">
                            <input class="custom-control-input" type="radio" id="rs_rmpnln_mtd1" name="rs_rmpnln_mtd"
                                value="NRS">
                            <label for="rs_rmpnln_mtd1" class="custom-control-label">NRS</label>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-5 col-sm-4">
                    <div class="form-group">
                        <div class="custom-control custom-radio">
                            <input class="custom-control-input" type="radio" id="rs_rmpnln_mtd2" name="rs_rmpnln_mtd"
                                value="BPS">
                            <label for="rs_rmpnln_mtd2" class="custom-control-label">BPS</label>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-5 col-sm-4">
                    <div class="form-group">
                        <div class="custom-control custom-radio">
                            <input class="custom-control-input" type="radio" id="rs_rmpnln_mtd3" name="rs_rmpnln_mtd"
                                value="NIPS">
                            <label for="rs_rmpnln_mtd3" class="custom-control-label">NIPS</label>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-5 col-sm-4">
                    <div class="form-group">
                        <div class="custom-control custom-radio">
                            <input class="custom-control-input" type="radio" id="rs_rmpnln_mtd4" name="rs_rmpnln_mtd"
                                value="FLACC">
                            <label for="rs_rmpnln_mtd4" class="custom-control-label">FLACC</label>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-5 col-sm-4">
                    <div class="form-group">
                        <div class="custom-control custom-radio">
                            <input class="custom-control-input" type="radio" id="rs_rmpnln_mtd5" name="rs_rmpnln_mtd"
                                value="VAS">
                            <label for="rs_rmpnln_mtd5" class="custom-control-label">VAS</label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="form-group row">
        <label for="rs_rmpnln_pnct" class="col-sm-2 col-form-label">Pencetus</label>
        <div class="col-sm-10">
            <input class="form-control" type="text" id="rs_rmpnln_pnct" name="rs_rmpnln_pnct">
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmpnln_gmbr" class="col-sm-2 col-form-label">Gambaran</label>
        <div class="col-sm-10">
            <input class="form-control" type="text" id="rs_rmpnln_gmbr" name="rs_rmpnln_gmbr">
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmpnln_drs" class="col-sm-2 col-form-label">Durasi</label>
        <div class="col-sm-10">
            <input class="form-control" type="text" id="rs_rmpnln_drs" name="rs_rmpnln_drs">
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmpnln_lks" class="col-sm-2 col-form-label">Lokasi</label>
        <div class="col-sm-10">
            <input class="form-control" type="text" id="rs_rmpnln_lks" name="rs_rmpnln_lks">
        </div>
    </div>

    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-primary">SIMPAN</button>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('formTabNlN', 'formTabNlN')">BATAL</button>
        </div>
    </div>
    <hr>
</form>

<div>
    <h4 class="text-center">Daftar Data Penilaian Nyeri</h4>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-success <?= $eEdit ?>" style="float: right;"
                onclick="showForm('formTabNlN', 'block'); resetForm('formTabNlN')"><i class="fas fa-plus"></i>
                Tambah</button>
        </div>
    </div>
    <table id="dtKformTabNlN" class="dtK table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Nyeri</th>
                <th>Skala Nyeri</th>
                <th>Pencetus</th>
                <th>Gambaran</th>
                <th>Durasi</th>
                <th>Lokasi</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Rmpnln as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td>
                <td><?= $tk['rs_rmpnln_ny'] ?></td>
                <td><?= $tk['rs_rmpnln_sn'] ?></td>
                <td><?= $tk['rs_rmpnln_pnct'] ?></td>
                <td><?= $tk['rs_rmpnln_gmbr'] ?></td>
                <td><?= $tk['rs_rmpnln_drs'] ?></td>
                <td><?= $tk['rs_rmpnln_lks'] ?></td>
                <td>
                    <?php
                        if ($MethodForm1 != "updateData") {
                        ?>
                    <button class="btn bg-gradient-danger <?= $eEdit ?>" title="Hapus Data Penilaian Nyeri Pasien"
                        onclick="callOther('Menghapus Data Penilaian Nyeri Pasien', '/rmpnln/deleteData/<?= $tk['rs_rmpnln_id_ex'] ?>')">
                        <i class='fas fa-trash'></i></button>
                    <?php
                        }
                        ?>
                </td>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>

<script>
$(function() {
    $(document).ready(function() {
        var formTabNlN = $('#formTabNlN');
        formTabNlN.submit(function(e) {
            showAnimated();
            $('#formTabNlN :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');

            e.preventDefault();
            $.ajax({
                type: formTabNlN.attr('method'),
                url: formTabNlN.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            window.location = '/<?= $UrlForm ?>';
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>