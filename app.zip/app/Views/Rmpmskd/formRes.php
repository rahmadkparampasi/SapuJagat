<form class="form-horizontal form-valide" style="display: none;" method="POST" action="/rmpres/<?= $MethodForm ?>"
    id="formTabPRes">
    <h4 class="text-center">Form Data E-Resep Pasien</h4>

    <div class="form-group row">
        <label for="rs_rmpres_tgl" class="col-sm-2 col-form-label">Tanggal</label>
        <div class="col-sm-10">
            <input type="date" id="rs_rmpres_tgl" name="rs_rmpres_tgl" required class="form-control">
        </div>
    </div>
    <div class="bootstrap-timepicker">
        <div class="form-group row">
            <label for="rs_rmpres_jam" class="col-sm-2 col-form-label">Waktu</label>
            <div class="col-sm-10">
                <div class="input-group date" id="timepickerRmpres" data-target-input="nearest">
                    <input type="text" class="form-control datetimepicker-input" data-target="#timepickerRmpres"
                        id="rs_rmpres_jam" name="rs_rmpres_jam" required>
                    <div class="input-group-append" data-target="#timepickerRmpres" data-toggle="datetimepicker">
                        <div class="input-group-text"><i class="far fa-clock"></i></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
    $(function() {
        //Timepicker
        $('#timepickerRmpres').datetimepicker({
            format: 'HH:mm',
            use24hours: true
        })
    });
    </script>

    <div class="form-group row">
        <label for="rs_rmpres_ppeg" class="col-sm-2 col-form-label">Dokter DPJP</label>
        <div class="col-sm-8">
            <input type="hidden" id="rs_rmpres_ppeg" name="rs_rmpres_ppeg" required class="form-control">
            <input type="text" id="rs_ppeg_nmres" name="rs_ppeg_nmres" required class="form-control" disabled>
        </div>
        <div class="col-sm-2">
            <button type="button" class='btn bg-gradient-primary mx-1' data-target="#modalViewPprC" data-toggle="modal"
                style="float: right;"
                onclick="showPprC('<?= $Rmpr['rs_rmpr_rmr'] ?>', 'rs_rmpres_ppeg', 'rs_ppeg_nmres')"><i
                    class="fas fa-file-archive"></i>
                AMBIL DOKTER</button>
        </div>
    </div>

    <div class="form-group row">
        <label for="rs_rmpres_rmr" class="col-sm-2 col-form-label">Tujuan Depo Layanan</label>
        <div class="col-sm-10">
            <select name="rs_rmpres_rmr" id="rs_rmpres_rmr" class="form-control"
                onfocus="ambilDataSelect('rs_rmpres_rmr', '/rmr/getAllForSelectByPrt/<?= $setRmr['setRmrApt'] ?>', 'Pilih Salah Satu Pilihan', toRemove=[], removeMessage=[], '')">
                <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
            </select>
        </div>
    </div>

    <div class="form-group row">
        <label for="rs_rmpres_res" class="col-sm-2 col-form-label">Pemberi Resep (Asisten Dokter / Dokter DPJP)</label>
        <div class="col-sm-10">
            <textarea class="form-control w-100" name="rs_rmpres_res" id="rs_rmpres_res" rows="3" cols="10"></textarea>
        </div>
    </div>

    <div class="form-group row">
        <label for="rs_rmpres_bb" class="col-sm-2 col-form-label">Berat Badan</label>
        <div class="col-sm-10">
            <input type="number" step=".1" id="rs_rmpres_bb" name="rs_rmpres_bb" required class="form-control"
                placeholder="Kg">
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmpres_tb" class="col-sm-2 col-form-label">Tinggi Badan</label>
        <div class="col-sm-10">
            <input type="number" step=".1" id="rs_rmpres_tb" name="rs_rmpres_tb" required class="form-control"
                placeholder="Cm">
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmpres_ao" class="col-sm-2 col-form-label">Alergi Obat</label>
        <div class="col-sm-10">
            <input type="text" id="rs_rmpres_ao" name="rs_rmpres_ao" required class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmpres_fg" class="col-sm-2 col-form-label">Gangguan Fungsi Ginjal</label>
        <div class="col-sm-10">
            <select id="rs_rmpres_fg" name="rs_rmpres_fg" required class="form-control">
                <option hidden value="">PILIH SALAH SATU PILIHAN</option>
                <option value="1">Ya</option>
                <option value="0">Tidak</option>
            </select>
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmpres_ms" class="col-sm-2 col-form-label">Menyusui</label>
        <div class="col-sm-10">
            <select id="rs_rmpres_ms" name="rs_rmpres_ms" required class="form-control">
                <option hidden value="">PILIH SALAH SATU PILIHAN</option>
                <option value="1">Ya</option>
                <option value="0">Tidak</option>
            </select>
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmpres_hml" class="col-sm-2 col-form-label">Hamil</label>
        <div class="col-sm-10">
            <select id="rs_rmpres_hml" name="rs_rmpres_hml" required class="form-control">
                <option hidden value="">PILIH SALAH SATU PILIHAN</option>
                <option value="1">Ya</option>
                <option value="0">Tidak</option>
            </select>
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmpres_pp" class="col-sm-2 col-form-label">Resep Pasien Pulang</label>
        <div class="col-sm-10">
            <select id="rs_rmpres_pp" name="rs_rmpres_pp" required class="form-control">
                <option hidden value="">PILIH SALAH SATU PILIHAN</option>
                <option value="1">Ya</option>
                <option value="0">Tidak</option>
            </select>
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_rmpres_ct" class="col-sm-2 col-form-label">CITO</label>
        <div class="col-sm-10">
            <select id="rs_rmpres_ct" name="rs_rmpres_ct" required class="form-control">
                <option hidden value="">PILIH SALAH SATU PILIHAN</option>
                <option value="1">Ya</option>
                <option value="0">Tidak</option>
            </select>
        </div>
    </div>

    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-primary">SIMPAN</button>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('formTabPRes', 'formTabPRes')">BATAL</button>
        </div>
    </div>
    <hr>
</form>

<div>
    <h4 class="text-center">Daftar Data E-Resep Pasien</h4>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-success <?= $eEdit ?>" style="float: right;"
                onclick="showForm('formTabPRes', 'block')"><i class="fas fa-plus"></i>
                Tambah</button>
        </div>
    </div>
    <table id="dtKformTabPRes" class="table display responsive table-bordered table-striped w-100 nowrap">
        <thead>
            <tr>
                <th>No</th>
                <th>Tanggal Dan Waktu</th>
                <th>Kode Order</th>

                <th>Tubuh</th>
                <th>Obat</th>
                <th>Alergi Obat</th>
                <th>Dokter Perujuk</th>
                <th>Pemberi Resep</th>
                <th>Gangguan Fungsi Ginjal</th>
                <th>Menyusui</th>
                <th>Hamil</th>
                <th>Resep Pasien Pulang</th>
                <th>CITO</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Rmpres as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td>
                <td>
                    Tanggal : <?= $tk['rs_rmpres_tgl'] ?><br>
                    Waktu : <?= $tk['rs_rmpres_jam'] ?>
                </td>
                <td class="text-nowrap"><?= $tk['rs_rmpres_kd'] ?></td>
                <td>
                    Berat Badan : <?= $tk['rs_rmpres_bb'] ?> Kg<br>
                    Tinggi Badan : <?= $tk['rs_rmpres_tb'] ?> Cm
                </td>
                <td>
                    <div class="row">
                        <div class="col-12">


                            <button type="button" class='btn bg-gradient-primary mx-1 my-2 btn-block <?= $eEdit ?>'
                                onclick="loadChildFormRes('rmpresnr', '<?= $tk['rs_rmpres_id_ex'] ?>', '<?= $tk['rs_rmpres_kd'] ?>', '<?= $tk['rs_rmpres_tgl'] ?>', '<?= $tk['rs_rmpres_jam'] ?>', '<?= $tk['rs_rmpres_rmr'] ?>'); "><i
                                    class="fas fa-pills"></i>
                                NON RACIK</button><br>
                            <button type="button" class='btn bg-gradient-success mx-1 my-2 btn-block <?= $eEdit ?>'
                                onclick="loadChildFormRes('rmpresr', '<?= $tk['rs_rmpres_id_ex'] ?>', '<?= $tk['rs_rmpres_kd'] ?>', '<?= $tk['rs_rmpres_tgl'] ?>', '<?= $tk['rs_rmpres_jam'] ?>', '<?= $tk['rs_rmpres_rmr'] ?>'); "><i
                                    class="fas fa-prescription-bottle-alt"></i>
                                RACIK</button>
                        </div>

                    </div>

                </td>
                <td class="text-nowrap"><?= $tk['rs_rmpres_ao'] ?></td>
                <td class="text-nowrap"><?= $tk['rs_ppeg_nm'] ?></td>

                <td class="text-nowrap"><?= $tk['rs_rmpres_res'] ?></td>
                <td><?= $tk['rs_rmpres_fg'] ?></td>
                <td><?= $tk['rs_rmpres_ms'] ?></td>
                <td><?= $tk['rs_rmpres_hml'] ?></td>
                <td><?= $tk['rs_rmpres_pp'] ?></td>
                <td><?= $tk['rs_rmpres_ct'] ?></td>

                <td>
                    <?php
                        if ($MethodForm1 != "updateData") {
                        ?>
                    <button class="btn bg-gradient-danger <?= $eEdit ?>" title="Hapus Data Permintaan E-Resep Pasien"
                        onclick="callOther('Menghapus Data Permintaan E-Resep Pasien', '/rmprad/deleteData/<?= $tk['rs_rmpres_id_ex'] ?>')">
                        <i class='fas fa-trash'></i></button>
                    <?php
                        }
                        ?>
                </td>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>
<div id="ChildFormRes">

</div>

<script>
function clearBox() {
    document.getElementById('ChildFormRes').innerHTML = "";
}

function loadChildFormRes(link = '', idEx = '', k = '', t = '', j = '', r = '') {
    $.ajax({
        url: "/" + link + "/viewData/" + idEx + "/" + k + "/" + t + "/" + j + "/" + r,
        success: function(data) {

            $('#ChildFormRes').html(data);
        }
    });
}



$(function() {
    $(document).ready(function() {
        $('#dtKformTabPRes').DataTable({
            "order": [
                [0, "asc"]
            ],
            "language": languangeDT,
            pageLength: 10,
            responsive: true,
            fixedHeader: false,
            keys: true,

        });
        var formTabPRes = $('#formTabPRes');
        formTabPRes.submit(function(e) {
            showAnimated();
            $('#formTabPRes :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');

            e.preventDefault();
            $.ajax({
                type: formTabPRes.attr('method'),
                url: formTabPRes.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            window.location = '/<?= $UrlForm ?>';
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>