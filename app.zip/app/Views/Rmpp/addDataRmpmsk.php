<form method="POST" class="form-valide" action="/<?= $BasePage ?>/<?= $MethodForm ?>" id="<?= $IdForm ?>"
    enctype="multipart/form-data"
    style="<?= $display ?>">
    <input type="hidden" class="form-control" id="rs_rmpmsk_rmpp" name="rs_rmpmsk_rmpp" value="<?= $rs_rmpp_id_ex ?>">

    <div class="card card-primary">
        <div class="card-header">
            <h3 class="card-title">REGISTRASI PASIEN</h3>
        </div>

        <div class="card-body">

            <div class="form-group">
                <label for="rs_rmpmsk_tgl">Tanggal Pendaftaran</label>
                <input type="date" class="form-control" id="rs_rmpmsk_tgl" name="rs_rmpmsk_tgl" required>
            </div>

            <div class="bootstrap-timepicker">
                <div class="form-group">
                    <label for="rs_rmpmsk_jam">Jam Masuk RS</label>
                    <div class="input-group date" id="timepickerJamD" data-target-input="nearest">
                        <input type="text" class="form-control datetimepicker-input" data-target="#timepickerJamD"
                            id="rs_rmpmsk_jam" name="rs_rmpmsk_jam" required>
                        <div class="input-group-append" data-target="#timepickerJamD" data-toggle="datetimepicker">
                            <div class="input-group-text"><i class="far fa-clock"></i></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.card-body -->
    </div>
    <div class="card card-primary">
        <div class="card-header">
            <h3 class="card-title">DATA UMUM PASIEN</h3>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="rs_rmpmsk_pr">Pernah Dirawat Di RS Sebelumnya</label>
                        <select name="rs_rmpmsk_pr" id="rs_rmpmsk_pr" class="form-control" required>
                            <option hidden>PILIH SALAH SATU PILIHAN </option>
                            <option value="1">Tidak</option>
                            <option value="2">Ya</option>
                        </select>

                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="rs_rmpmsk_rd">Rawat Di</label>
                        <input type="text" class="form-control" id="rs_rmpmsk_rd" name="rs_rmpmsk_rd">
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="form-group">
                        <label for="rs_rmpmsk_rjkd">Dikirim / Rujuk Dari</label>
                        <input type="text" class="form-control" id="rs_rmpmsk_rjkd" name="rs_rmpmsk_rjkd">
                    </div>
                </div>
            </div>



            <div class="form-group">
                <label for="rs_rmpmsk_alt">Alamat Saat Ini</label>
                <textarea cols="30" rows="2" type="text" class="form-control" id="rs_rmpmsk_alt"
                    name="rs_rmpmsk_alt"></textarea>
            </div>

            <div class="form-group">
                <label for="rs_rmpmsk_rmsts">Status Pernikahan</label>
                <select name="rs_rmpmsk_rmsts" id="rs_rmpmsk_rmsts" class="form-control">
                    <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
                    <?php foreach ($Rmsts as $tk) : ?>
                    <option value="<?= $tk['rs_rmsts_id_ex'] ?>"><?= $tk['rs_rmsts_nm'] ?></option>
                    <?php endforeach ?>
                </select>
            </div>

            <div class="form-group">
                <label for="rs_rmpmsk_rmpdk">Pendidikan</label>
                <select name="rs_rmpmsk_rmpdk" id="rs_rmpmsk_rmpdk" class="form-control">
                    <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
                    <?php foreach ($Rmpdk as $tk) : ?>
                    <option value="<?= $tk['rs_rmpdk_id_ex'] ?>"><?= $tk['rs_rmpdk_nm'] ?></option>
                    <?php endforeach ?>
                </select>
            </div>

            <div class="form-group">
                <label for="rs_rmpmsk_rmkrj">Pekerjaan</label>
                <select name="rs_rmpmsk_rmkrj" id="rs_rmpmsk_rmkrj" class="form-control">
                    <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
                    <?php foreach ($Rmkrj as $tk) : ?>
                    <option value="<?= $tk['rs_rmkrj_id_ex'] ?>"><?= $tk['rs_rmkrj_nm'] ?></option>
                    <?php endforeach ?>
                </select>
            </div>



            <div class="form-group">
                <label for="rs_rmpmsk_pp">Perlu Penerjemah</label>
                <select name="rs_rmpmsk_pp" id="rs_rmpmsk_pp" class="form-control">
                    <option hidden>PILIH SALAH SATU PILIHAN</option>
                    <option value="0">Tidak</option>
                    <option value="1">Ya</option>
                </select>
            </div>
        </div>

    </div>

    <div class="card card-primary">
        <div class="card-header">
            <h3 class="card-title">PENANGGUNG JAWAB / KELUARGA TERDEKAT</h3>
        </div>
        <div class="card-body">
            <div class="form-group">
                <label for="rs_rmpmsk_pj">Ada Penganggung Jawab / Keluarga</label>
                <select name="rs_rmpmsk_pj" id="rs_rmpmsk_pj" class="form-control" required>
                    <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
                    <option value="0">Tidak Ada</option>
                    <option value="1">Ada</option>
                </select>
            </div>

            <div class="form-group">
                <label for="rs_rmpmskpj_n">Nama Penanggung Jawab</label>
                <input type="text" class="form-control" id="rs_rmpmskpj_n" name="rs_rmpmskpj_n">
            </div>

            <div class="form-group">
                <label for="rs_rmpmskpj_rmi">Jenis Identitas</label>
                <select name="rs_rmpmskpj_rmi" id="rs_rmpmskpj_rmi" class="form-control">
                    <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
                    <?php foreach ($Rmi as $tk) : ?>
                    <option value="<?= $tk['rs_rmi_id_ex'] ?>"><?= $tk['rs_rmi_nm'] ?></option>
                    <?php endforeach ?>
                </select>
            </div>

            <div class="form-group">
                <label for="rs_rmpmskpj_ind">No. Identitas Penanggung Jawab</label>
                <input type="text" class="form-control" id="rs_rmpmskpj_ind" name="rs_rmpmskpj_ind">
            </div>

            <div class="form-group">
                <label for="rs_rmpmskpj_jk">Jenis Kelamin</label>
                <select name="rs_rmpmskpj_jk" id="rs_rmpmskpj_jk" class="form-control" required>
                    <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
                    <option value="L">LAKI-LAKI</option>
                    <option value="P">PEREMPUAN</option>
                </select>
            </div>

            <div class="form-group">
                <label for="rs_rmpmskpj_rmhub">Hubungan Dengan Pasien</label>
                <select name="rs_rmpmskpj_rmhub" id="rs_rmpmskpj_rmhub" class="form-control" required>
                    <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
                    <?php foreach ($Rmhub as $tk) : ?>
                    <option value="<?= $tk['rs_rmhub_id_ex'] ?>"><?= $tk['rs_rmhub_nm'] ?></option>
                    <?php endforeach ?>
                </select>
            </div>

            <div class="form-group">
                <label for="rs_rmpmskpj_alt">Alamat Tempat Tinggal</label>
                <textarea cols="30" rows="2" type="text" class="form-control" id="rs_rmpmskpj_alt"
                    name="rs_rmpmskpj_alt"></textarea>
            </div>

            <div class="row">
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="rs_rmpmskpj_altktp">Alamat KTP</label>
                        <textarea cols="30" rows="1" type="text" class="form-control" id="rs_rmpmskpj_altktp"
                            name="rs_rmpmskpj_altktp"></textarea>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="rs_rmpmskpj_altn">No.</label>
                        <input type="text" class="form-control" id="rs_rmpmskpj_altn" name="rs_rmpmskpj_altn">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="rs_rmpmskpj_altr">RT / RW</label>
                        <input type="text" class="form-control" id="rs_rmpmskpj_altr" name="rs_rmpmskpj_altr">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="rs_rmpmskpj_altkk">Kelurahan / Kecamatan</label>
                        <input type="text" class="form-control" id="rs_rmpmskpj_altkk" name="rs_rmpmskpj_altkk">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="rs_rmpmskpj_altkp">Kota / Kode Pos</label>
                        <input type="text" class="form-control" id="rs_rmpmskpj_altkp" name="rs_rmpmskpj_altkp">
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="rs_rmpmskpj_altth">Telepon / HP</label>
                        <input type="text" class="form-control" id="rs_rmpmskpj_altth" name="rs_rmpmskpj_altth">
                    </div>
                </div>
            </div>

            <div class="form-group">
                <label for="rs_rmpmskpj_rmpdk">Pendidikan</label>
                <select name="rs_rmpmskpj_rmpdk" id="rs_rmpmskpj_rmpdk" class="form-control">
                    <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
                    <?php foreach ($Rmpdk as $tk) : ?>
                    <option value="<?= $tk['rs_rmpdk_id_ex'] ?>"><?= $tk['rs_rmpdk_nm'] ?></option>
                    <?php endforeach ?>
                </select>
            </div>

            <div class="form-group">
                <label for="rs_rmpmskpj_rmkrj">Pekerjaan</label>
                <select name="rs_rmpmskpj_rmkrj" id="rs_rmpmskpj_rmkrj" class="form-control">
                    <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
                    <?php foreach ($Rmkrj as $tk) : ?>
                    <option value="<?= $tk['rs_rmkrj_id_ex'] ?>"><?= $tk['rs_rmkrj_nm'] ?></option>
                    <?php endforeach ?>
                </select>
            </div>
        </div>
    </div>

    <div class="card card-primary">
        <div class="card-header">
            <h3 class="card-title">DATA SOSIAL, EKONOMI DAN FUNGSIONAL</h3>
        </div>
        <div class="card-body">
            <div class="form-group">
                <label for="rs_rmpmsk_cp">Cara Pembayaran</label>
                <select name="rs_rmpmsk_cp" id="rs_rmpmsk_cp" class="form-control" required>
                    <option hidden value="">PILIH SALAH SATU PILIHAN</option>
                    <option value="TN">Tunai</option>
                    <option value="AS">ASURANSI</option>
                </select>
            </div>
            <div class="form-group">
                <label for="rs_rmpmsk_rma">Daftar Asuransi</label>
                <select name="rs_rmpmsk_rma" id="rs_rmpmsk_rma" class="form-control">
                    <option hidden value="">PILIH SALAH SATU PILIHAN</option>
                    <?php foreach ($Rma as $tk) : ?>
                    <option value="<?= $tk['rs_rma_id_ex'] ?>"><?= $tk['rs_rma_nm'] ?></option>
                    <?php endforeach ?>
                </select>
            </div>

            <div class="form-group">
                <label for="rs_rmpmsk_anmr">Nomor Asuransi (Jika Ada)</label>
                <input type="text" class="form-control" id="rs_rmpmsk_anmr" name="rs_rmpmsk_anmr">
            </div>



            <div class="form-group">
                <label for="rs_rmpmsk_rmtgl">Tinggal Dengan Siapa</label>
                <select name="rs_rmpmsk_rmtgl" id="rs_rmpmsk_rmtgl" class="form-control">
                    <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
                    <?php foreach ($Rmtgl as $tk) : ?>
                    <option value="<?= $tk['rs_rmtgl_id_ex'] ?>"><?= $tk['rs_rmtgl_nm'] ?></option>
                    <?php endforeach ?>
                </select>
            </div>

            <div class="form-group">
                <label for="rs_rmpmsk_rmab">Penggunaan Alat Bantu Diri</label>
                <select name="rs_rmpmsk_rmab" id="rs_rmpmsk_rmab" class="form-control">
                    <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
                    <?php foreach ($Rmab as $tk) : ?>
                    <option value="<?= $tk['rs_rmab_id_ex'] ?>"><?= $tk['rs_rmab_nm'] ?></option>
                    <?php endforeach ?>
                </select>
            </div>
        </div>
        <!-- /.card-body -->
    </div>
    <div class="card card-primary">
        <div class="card-header">
            <h3 class="card-title">DATA TUJUAN LAYANAN</h3>
        </div>
        <div class="card-body">
            <div class="form-group">
                <label for="rs_setdftr_rmrIns">Tujuan Instalasi</label>
                <select name="rs_setdftr_rmrIns" id="rs_setdftr_rmrIns" class="form-control" required
                    onfocus="ambilDataSelect('rs_setdftr_rmrIns', '/setdftr/getAllForSelectNP/', 'Pilih Salah Satu Pilihan', toRemove=[], removeMessage=[], '')"
                    onchange="ambilDataSelect('rs_setdftr_rmrUnt', '/setdftr/getAllForSelectWP/', 'Pilih Salah Satu Pilihan', toRemove=['rs_setdftr_rmrUnt'], removeMessage=['Pilih Salah Satu Pilihan'], 'rs_setdftr_rmrIns'); hidePlhKmr()">
                    <option hidden value="">PILIH SALAH SATU PILIHAN</option>

                </select>
            </div>
            <div class="form-group">
                <label for="rs_setdftr_rmrUnt">Tujuan Unit</label>
                <select name="rs_setdftr_rmrUnt" id="rs_setdftr_rmrUnt" class="form-control" required
                    onchange="ambilDataSelect('rs_rmpr_rmr', '/setdftr/getAllForSelectRmr/', 'Pilih Salah Satu Pilihan', toRemove=['rs_rmpr_rmr'], removeMessage=['Pilih Salah Satu Pilihan'], 'rs_setdftr_rmrUnt'); plhKmr('plhKmr', 'rs_setdftr_rmrUnt');">
                    <option hidden value="">PILIH SALAH SATU PILIHAN</option>

                </select>
            </div>
            <div class="form-group">
                <label for="rs_rmpr_rmr">Tujuan Ruangan</label>
                <select name="rs_rmpr_rmr" id="rs_rmpr_rmr" class="form-control"
                    onchange="ambilDataSelect('rs_rmpmsk_rmsmf', '/rmrsmf/getAllForSelect/', 'Pilih Salah Satu Pilihan', toRemove=['rs_rmpmsk_rmsmf'], removeMessage=['Pilih Salah Satu Pilihan'], 'rs_rmpr_rmr'); ambilDataSelect('rs_rmpmsk_ppeg', '/ppr/getAllForSelectByRmr/', 'Pilih Salah Satu Pilihan', toRemove=['rs_rmpmsk_ppeg'], removeMessage=['Pilih Salah Satu Pilihan'], 'rs_rmpr_rmr'); addFill('rs_rmprtt_rmrkkt', ''); addFill('rs_rmr_nm', ''); ">
                    <option hidden value="">PILIH SALAH SATU PILIHAN</option>

                </select>
            </div>
            <div class="form-group">
                <label for="rs_rmpmsk_rmsmf">Staf Medis Fungsional</label>
                <select name="rs_rmpmsk_rmsmf" id="rs_rmpmsk_rmsmf" class="form-control">
                    <option hidden value="">PILIH SALAH SATU PILIHAN</option>

                </select>
            </div>
            <div class="form-group">
                <label for="rs_rmpmsk_ppeg">Dokter</label>
                <select name="rs_rmpmsk_ppeg" id="rs_rmpmsk_ppeg" class="form-control">
                    <option hidden value="">PILIH SALAH SATU PILIHAN</option>

                </select>
            </div>

            <div class="form-group" id="plhKmr" style="display: none;">
                <label for="rs_rmprtt_rmrkkt">Tambahkan Kamar Dan Tempat Tidur</label>
                <div class="row">
                    <div class="col-10">
                        <input type="hidden" id="rs_rmprtt_rmrkkt" name="rs_rmprtt_rmrkkt" required class="form-control">
                        <input type="text" id="rs_rmr_nm" name="rs_rmr_nm" required class="form-control" disabled>
                    </div>
                    <div class="col-2">
                        <button type="button" class='btn bg-gradient-primary mx-1' data-target="#modalViewKkt"
                            data-toggle="modal" style="float: right;"
                            onclick="showKkt(document.getElementById('rs_rmpr_rmr').value, 'rs_rmprtt_rmrkkt', 'rs_rmr_nm')"><i
                                class="fas fa-file-archive"></i> AMBIL KAMAR</button>
                    </div>
                </div>
            </div>

            

        </div>
        <!-- /.card-body -->

        <div class="card-footer">
            <button type="submit" class="btn bg-gradient-primary"><?= $ButtonMethod ?></button>
            <?php
            $MethodForm = substr($MethodForm, 0, 10);
            if ($MethodForm == "updateData") {
            ?>
            <a href="/<?= $BasePage ?>" class='btn bg-gradient-danger' aria-pressed="true">BATAL</a>
            <?php
            } else {
            ?>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('<?= $IdForm ?>', '<?= $IdForm ?>')">BATAL</button>

            <?php
            }
            ?>
        </div>
    </div>
</form>

<script>
function plhKmr(iV = '', iD = '') {
    let idFormShowV = document.getElementById(iV);
    let idFormShowD = document.getElementById(iD);

    var rs_rmprtt_rmrkkt = document.getElementById('rs_rmprtt_rmrkkt');
    var rs_rmr_nm = document.getElementById('rs_rmr_nm');

    if (idFormShowD.value == '<?= $setRmr['setPlhKmr'] ?>') {
        idFormShowV.style.display = "block";
        rs_rmprtt_rmrkkt.value = '';
        rs_rmr_nm.value = '';
    }else{
        idFormShowV.style.display = "none";
        rs_rmprtt_rmrkkt.value  = '';
        rs_rmr_nm.value  = '';
    }   
}

function hidePlhKmr() {
    let idFormShowV = document.getElementById('plhKmr');
    idFormShowV.style.display = "none";
    
}
$(function() {
    //Timepicker
    $('#timepickerJamD').datetimepicker({
        format: 'HH:mm',
        use24hours: true
    })
});
</script>