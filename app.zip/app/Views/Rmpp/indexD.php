<?= $this->extend('Templates/template'); ?>

<?= $this->section('content'); ?>
<!-- /.row -->

<div class="row">
    <div class="col-md-3 col-sm-12">
        <!-- Widget: user widget style 1 -->
        <div class="card">
            <div class="card-body">
                <a href="/rmpp" class='btn btn-block bg-gradient-danger mx-1' style="float: right;"><i class="fas fa-reply"></i>
                    KEMBALI</a>
            </div>
        </div>
        <div class="card card-widget widget-user">
            <!-- Add the bg color to the header using any of the bg-* classes -->
            <div class="widget-user-header bg-info h-auto">
                <h3 class="widget-user-username"><?= $Rmpp['rs_rmpp_nm'] ?></h3>
                <h5 class="widget-user-desc">No. RM : <h3><span class="badge badge-danger"><?= $Rmpp['rs_rmpp_rm'] ?></span></h3>
                </h5>
            </div>
            <div class="card-footer py-0">

                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="description-block text-left">
                            <h5 class="description-header">Tanggal Lahir</h5>
                            <h5><span class="description-text badge badge-info"><?= $Rmpp['rs_rmpp_tgl_lhr'] ?></span>
                            </h5>
                        </div>
                        <!-- /.description-block -->
                    </div>
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="description-block text-left">
                            <h5 class="description-header">Jenis Kelamin</h5>
                            <h5><span class="description-text badge badge-warning"><?= $Rmpp['rs_rmpp_jk'] ?></span>
                            </h5>
                        </div>
                        <!-- /.description-block -->
                    </div>
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="description-block text-left">
                            <h5 class="description-header">Alamat</h5>
                            <h5><?= $Rmpp['rs_rmpp_altktp1'] ?></h5>
                        </div>
                        <!-- /.description-block -->
                    </div>

                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <br>
                        <?php
                        if ($Rmpp['rs_rmpp_tgl_lhr'] != "BELUM ADA TANGGAL LAHIR") {
                        ?>
                            <a href="/rmppd/ctkKrt/<?= $rs_rmpp_id_ex ?>" target="_blank" class='btn btn-block bg-gradient-primary mx-1' style="float: right;"><i class="fas fa-id-card"></i>
                                CETAK KARTU RM</a>
                        <?php

                        }
                        ?>

                        <!-- /.description-block -->
                        <br>
                        <br>
                        <button class="btn btn-primary btn-block" title="Ubah Nama Pengguna" data-target="#modalChangeRmpp" data-toggle="modal"><i class="fa fa-pencil-alt"></i> Lengkapi Biodata</button>
                        <br>
                    </div>
                </div>
                <!-- /.row -->
            </div>
        </div>
        <div class="card card-primary">
            <div class="card-header">
                <h3 class="card-title">Biodata</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <strong><i class="fas fa-id-card mr-1"></i> Identitas</strong>
                <p class="text-muted">

                    <?= $Rmpp['rs_rmi_nm'] ?>: <?= $Rmpp['rs_rmpp_ind'] ?>
                </p>
                <hr>

                <strong><i class="fas fa-calendar mr-1"></i> Tempat, Tanggal Lahir</strong>
                <p class="text-muted">

                    <?= $Rmpp['rs_rmpp_tmpt_lhr'] ?>,<?= $Rmpp['rs_rmpp_tgl_lhr'] ?>
                </p>
                <hr>

                <strong><i class="fas fa-map-marked mr-1"></i> Alamat KTP</strong>
                <p class="text-muted">

                    <?= $Rmpp['rs_rmpp_altktp'] ?>
                </p>
                <hr>

                <strong><i class="fas fa-heart mr-1"></i> Agama</strong>
                <p class="text-muted">

                    <?= $Rmpp['rs_rmag_nm'] ?>
                </p>
                <hr>

                <strong><i class="fas fa-hand-holding-heart mr-1"></i> Golongan Darah</strong>
                <p class="text-muted">
                    <?= $Rmpp['rs_rmgd_nm'] ?>
                </p>
                <hr>



                <strong><i class="fas fa-language mr-1"></i> Bahasa</strong>
                <p class="text-muted">
                    <?= $Rmpp['rs_rmpp_bhs'] ?>
                </p>
                <hr>
                <strong><i class="fas fa-flag mr-1"></i> Suku / Bangsa</strong>
                <p class="text-muted">
                    <?= $Rmpp['rs_rmpp_sb'] ?>
                </p>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.widget-user -->
    </div>

    <div class="col-md-9 col-sm-12" id="accordion">

        <?= $this->include('Rmpp/addDataRmpmsk'); ?>


        <div class="callout callout-info">
            <h5><i class="fas fa-info"></i> Catatan:</h5>
            <p>Tombol : <button class="btn bg-gradient-primary"><i class="fa fa-clipboard"></i></button> Berwarna Biru
                Untuk Kebutuhan Menyalin Teks</p>
        </div>
        <div class="card card-success card-outline">
            <a class="d-block w-100" data-toggle="collapse" href="#collapseRmpmsk" onclick="addSess('tabAccor', 'collapseRmpmsk');">
                <div class="card-header">


                    <div class="card-tools">
                        <button class='btn bg-gradient-success mx-3' style="float: right;" onclick="showForm('<?= $IdForm ?>', 'block');"><i class="fas fa-plus"></i>
                            TAMBAH</button>
                    </div>

                    <div class="card-tools">
                        <button class='btn bg-gradient-info mx-3' style="float: right;" onclick="showForm('<?= $IdForm ?>', 'block');"><i class="fas fa-file-alt"></i>
                            Cetak Laporan</button>
                    </div>

                    <div class="col-xl-4 col-lg-4"> 
                        <div class="card-tools row ">
                            <select class="form-control mx-1" required id="method">
                                <option hidden value="">Cetak Laporan Berdasarkan</option>
                                <option value="">Berdasarkan Nama</option>
                                <option value="">Berdasarkan Nomor Rekam Medik</option>
                                <option value="">Berdasarkan Identitas</option>
                            </select>
                        </div> 
                    </div>

                    <div class="row">
                        <div class="col-12">
                            <h4 class="card-title w-100">
                                Rekam Medis
                            </h4>
                        </div>
                        <div class="col-12">
                            <ul class="nav nav-pills">
                                <li class="nav-item"><a class="nav-link" href="#TabItemTimeLine" id="TabParTimeLine" data-toggle="tab" onclick="addSess('tabParent', 'TabParTimeLine'); addSess('tabItem', 'TabItemTimeLine');addSess('tabVParent', ''); addSess('tabVItem', '');"><i class="fa fa-history"></i> Histori</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div><!-- /.card-header -->
            </a>
            <div id="collapseRmpmsk" class="collapse" data-parent="#accordion">
                <div class="card-body">
                    <div class="tab-content">
                        <div class="tab-pane" id="TabItemTimeLine">
                            <?= $this->include('Rmpp/formTimeLine'); ?>
                        </div>
                    </div>
                    <!-- /.tab-content -->

                </div><!-- /.card-body -->
            </div>
        </div>
    </div>
</div>
<?= $this->include('Rmpp/modalViewKkt'); ?>
<?= $this->include('Rmpp/modalChangeRmpp'); ?>
<script>
    function showTabPane() {
        if (sessionStorage.getItem("tabParent") === null || sessionStorage.getItem("tabParent") === "") {
            tabPar = document.getElementById("TabParTri");
            tabPar.classList.add("active");
        } else {
            tabPar = document.getElementById(sessionStorage.getItem("tabParent"));
            tabPar.classList.add("active");
        }

        if (sessionStorage.getItem("tabItem") === null || sessionStorage.getItem("tabItem") === "") {
            tabItem = document.getElementById("TabItemTri");
            tabItem.classList.add("active");
        } else {
            tabItem = document.getElementById(sessionStorage.getItem("tabItem"));
            tabItem.classList.add("active");
        }

        if (sessionStorage.getItem("tabVParent") === null || sessionStorage.getItem("tabVParent") === "") {} else {
            tabVPar = document.getElementById(sessionStorage.getItem("tabVParent"));
            tabVPar.classList.add("show");
            tabVPar.classList.add("active");
            tabVItem = document.getElementById(sessionStorage.getItem("tabVItem"));
            tabVItem.classList.add("show");
            tabVItem.classList.add("active");
        }
    }

    function showAccor() {
        if (sessionStorage.getItem("tabAccor") === null || sessionStorage.getItem("tabAccor") === "") {
            tabAccor = document.getElementById("collapseRmpmsk");
            tabAccor.classList.add("show");
        } else {
            tabAccor = document.getElementById(sessionStorage.getItem("tabAccor"));
            tabAccor.classList.add("show");
        }
    }
    $(document).ready(function() {
        showAccor();
        showTabPane();
    });
</script>

<?= $this->endSection(); ?>