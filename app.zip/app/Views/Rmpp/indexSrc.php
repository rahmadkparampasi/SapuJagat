<?php $no = 0;
foreach ($Rmpp as $tk) : $no++ ?>
<div class="col-lg-3 col-6">
    <!-- small card -->
    <div class="small-box bg-<?= $tk['color'] ?>">
        <div class="inner">
            <h4><?= $tk['rs_rmpp_nm'] ?></h4>
            <h5>No. RM : <?= $tk['rs_rmpp_rm'] ?></h5>

            <p><i class="fa fa-id-card"></i> <?= $tk['rs_rmi_nm'] ?> : <?= $tk['rs_rmpp_ind'] ?></p>
            <p><i class="fa fa-birthday-cake"></i> TTL : <?= $tk['rs_rmpp_tmpt_lhr'] ?>, <?= $tk['rs_rmpp_tgl_lhr'] ?>
            <p><i class="fa fa-restroom"></i> Jenis Kelamin : <?= $tk['rs_rmpp_jk'] ?>
            </p>
        </div>
        <div class="icon">
            <i class="fas fa-<?= $tk['icon'] ?>"></i>
        </div>
        <a href="/rmppd/viewData/<?= $tk['rs_rmpp_id_ex'] ?>" target="_blank" class="small-box-footer">
            Lanjutkan... <i class="fas fa-arrow-circle-right"></i>
        </a>
    </div>
</div>
<?php endforeach ?>