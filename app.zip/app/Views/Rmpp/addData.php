<form method="POST" class="form-valide" action="/<?= $BasePage ?>/<?= $MethodForm ?>" id="<?= $IdForm ?>"
    enctype="multipart/form-data"
    style="<?php
                                                                                                                                                if ($MethodForm1 == "updateData") {
                                                                                                                                                    echo 'display: block;';
                                                                                                                                                } else {
                                                                                                                                                    echo 'display: none;';
                                                                                                                                                } ?>">

    <div class="card card-primary">
        <div class="card-header">
            <h3 class="card-title">DATA UMUM PASIEN</h3>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="rs_rmpp_nm">Nama Pasien</label>
                        <input type="text" class="form-control" id="rs_rmpp_nm" name="rs_rmpp_nm" required>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="rs_rmpp_jk">JENIS KELAMIN</label>
                        <select name="rs_rmpp_jk" id="rs_rmpp_jk" class="form-control" required>
                            <option hidden value="">PILIH SALAH SATU PILIHAN</option>
                            <option value="L">LAKI-LAKI</option>
                            <option value="P">PEREMPUAN</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="rs_rmpp_ind">No. Identitas</label>
                        <input type="text" class="form-control" id="rs_rmpp_ind" name="rs_rmpp_ind">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="rs_rmpp_rmi">Jenis Identitas</label>
                        <select name="rs_rmpp_rmi" id="rs_rmpp_rmi" class="form-control">
                            <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
                            <?php foreach ($Rmi as $tk) : ?>
                            <option value="<?= $tk['rs_rmi_id_ex'] ?>"><?= $tk['rs_rmi_nm'] ?></option>
                            <?php endforeach ?>
                        </select>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="rs_rmpp_tmpt_lhr">Tempat Lahir</label>
                        <input type="text" class="form-control" id="rs_rmpp_tmpt_lhr" name="rs_rmpp_tmpt_lhr">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="rs_rmpp_tgl_lhr">Tanggal Lahir</label>
                        <input type="date" class="form-control" id="rs_rmpp_tgl_lhr" name="rs_rmpp_tgl_lhr">
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="rs_rmpp_altktp">Alamat KTP</label>
                        <textarea cols="30" rows="1" type="text" class="form-control" id="rs_rmpp_altktp"
                            name="rs_rmpp_altktp"></textarea>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="rs_rmpp_altn">No.</label>
                        <input type="text" class="form-control" id="rs_rmpp_altn" name="rs_rmpp_altn">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="rs_rmpp_altr">RT / RW</label>
                        <input type="text" class="form-control" id="rs_rmpp_altr" name="rs_rmpp_altr">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="rs_rmpp_altkk">Kelurahan / Kecamatan</label>
                        <input type="text" class="form-control" id="rs_rmpp_altkk" name="rs_rmpp_altkk">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="rs_rmpp_altkp">Kota / Kode Pos</label>
                        <input type="text" class="form-control" id="rs_rmpp_altkp" name="rs_rmpp_altkp">
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="rs_rmpp_altth">Telepon / HP</label>
                        <input type="text" class="form-control" id="rs_rmpp_altth" name="rs_rmpp_altth">
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="rs_rmpp_rmag">Agama</label>
                        <select name="rs_rmpp_rmag" id="rs_rmpp_rmag" class="form-control" required>
                            <option hidden value="">PILIH SALAH SATU PILIHAN</option>
                            <?php foreach ($Rmag as $tk) : ?>
                            <option value="<?= $tk['rs_rmag_id_ex'] ?>"><?= $tk['rs_rmag_nm'] ?></option>
                            <?php endforeach ?>
                        </select>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="rs_rmpp_rmgd">Golongan Darah</label>
                        <select name="rs_rmpp_rmgd" id="rs_rmpp_rmgd" class="form-control" required>
                            <option hidden value="">PILIH SALAH SATU PILIHAN</option>
                            <?php foreach ($Rmgd as $tk) : ?>
                            <option value="<?= $tk['rs_rmgd_id_ex'] ?>"><?= $tk['rs_rmgd_nm'] ?></option>
                            <?php endforeach ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="rs_rmpp_bhs">Bahasa Yang Digunakan</label>
                        <input type="text" class="form-control" id="rs_rmpp_bhs" name="rs_rmpp_bhs">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="rs_rmpp_sb">Suku Bangsa</label>
                        <input type="text" class="form-control" id="rs_rmpp_sb" name="rs_rmpp_sb">
                    </div>
                </div>
            </div>


        </div>
    </div>

    <div class="card card-primary">

        <!-- /.card-body -->

        <div class="card-footer">
            <button type="submit" class="btn bg-gradient-primary"><?= $ButtonMethod ?></button>
            <?php
            $MethodForm = substr($MethodForm, 0, 10);
            if ($MethodForm == "updateData") {
            ?>
            <a href="/<?= $BasePage ?>" class='btn bg-gradient-danger' aria-pressed="true">BATAL</a>
            <?php
            } else {
            ?>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('<?= $IdForm ?>', '<?= $IdForm ?>')">BATAL</button>

            <?php
            }
            ?>
        </div>
    </div>
</form>

<script>
$(function() {
    //Timepicker
    $('#timepickerJamD').datetimepicker({
        format: 'HH:mm',
        use24hours: true
    })
});
</script>