<!DOCTYPE html>
<html lang="en">

<head>
    <!-- meta & tittle -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RSUD Kolonodale | <?= $WebTitle; ?></title>
    <meta name="title" content="<?= $WebTitle; ?>">
    <meta name="description" content="<?= $PageTitle; ?>">
    <link rel="icon" href="/favicon.png" type="image/png">

    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="/vendors/script/fontawesome-free/css/all.min.css">
    <!-- Theme style -->
    <!-- loading -->
    <!-- <link rel="stylesheet" href="/vendors/include/loading.css" media="all"> -->
    <style>
        * {
            font-family: 'Source Sans Pro', sans-serif;
        }

        @page {
            margin: 0;
            size: auto;
        }



        h1 {
            page-break-before: always;
        }


        h1,
        h2,
        h3,
        h4,
        h5 {
            page-break-after: avoid;
        }


        table,
        figure {
            page-break-inside: avoid;
        }


        @page: right {
            @bottom-right {
                content: counter(page);
            }
        }

        @page: left {
            @bottom-left {
                content: counter(page);
            }
        }

        @page: left {
            @bottom-left {
                content: "Page "counter(page) " of "counter(pages);
            }
        }


        body {
            counter-reset: chapternum;
        }

        h1.chapter:before {
            counter-increment: chapternum;
            content: counter(chapternum) ". ";
        }


        body {
            counter-reset: chapternum figurenum;
        }

        h1 {
            counter-reset: figurenum;
        }

        h1.title:before {
            counter-increment: chapternum;
            content: counter(chapternum) ". ";
        }

        figcaption:before {
            counter-increment: figurenum;
            content: counter(chapternum) "-"counter(figurenum) ". ";
        }


        h1 {
            string-set: doctitle content();
        }

        .fn {
            float: footnote;
        }


        .fn {
            counter-increment: footnote;
        }

        h1 {
            counter-reset: footnote;
        }


        .fn::footnote-call {
            content: counter(footnote);
            font-size: 9pt;
            vertical-align: super;
            line-height: none;
        }

        .fn::footnote-marker {
            font-weight: bold;
        }

        .tH {
            background-color: rgba(155, 194, 230, 1) !important;
            text-align: center;
        }

        .tHn {

            text-align: center;
        }
        .textBio{
            font-size: 7.39pt; 
            font-weight: bold;
            padding-left: 84px;
        }
        .textBC{
            font-size: 10pt; 
            font-weight: bold;
            text-align: center;
        }
    </style>
    <!-- jquery -->
    <script src="/vendors/script/jquery/3.3.1/jquery.min.js"></script>
</head>

<body>
    <div class="border-primary" style="height: 292; width: 19mm; margin: 0%; padding: 0%; border: 1px solid #000;">
        
        <div class="" style="width: 100%; height: 120mm; padding-top: 0mm; padding-left: 20px; font-size: 40px;">TES</div>
        
    </div>

    <script>
        $(document).ready(function() {
            window.print();
            // setTimeout(function() {
            //     window.close();
            // }, 10);
        });
    </script>
</body>

</html>