<?= $this->extend('Templates/template'); ?>

<?= $this->section('content'); ?>
<!-- /.row -->

<div class="row">
    <div class="col-xl-12 col-lg-12">
        <?= $this->include('Rmpp/addData'); ?>
    </div>
    <div class="col-12">
        <div class="callout callout-info">
            <h5><i class="fas fa-info"></i> Catatan:</h5>
            <ol>

                <li>Warna : <span class="btn bg-warning"></i></span> Pada Pasien Mengartikan Bahwa Pasien Sedang Dirawat
                </li>
                <li>Warna : <span class="btn bg-success"></i></span> Pada Pasien Mengartikan Bahwa Pasien Tidak Sedang
                    Dirawat</li>
            </ol>
        </div>
    </div>
    <!-- Area Chart -->
    <div class="col-xl-12 col-lg-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Daftar <?= $PageTitle ?></h3>
                <div class="card-tools row w-50">
                    <select class="form-control col mx-2" required id="method">
                        <option hidden value="">Pilih Cara Pencarian</option>
                        <option value="rs_rmpp_nm">Berdasarkan Nama</option>
                        <option value="rs_rmpp_rm">Berdasarkan Nomor Rekam Medik</option>
                        <option value="rs_rmpp_ind">Berdasarkan Identitas</option>
                    </select>
                    <input type="text" class="form-control col mx-2" placeholder="Masukan Nomor Rekam Medik" required
                        id="value" />
                    <button class='btn bg-gradient-primary col-2' role="button"
                        onclick="loadSrc(document.getElementById('method').value, document.getElementById('value').value);"><i
                            class="fas fa-search"></i>
                        CARI</button>
                    <button class='btn bg-gradient-success mx-3' style="float: right;"
                        onclick="showForm('<?= $IdForm ?>', 'block');"><i class="fas fa-plus"></i>
                        TAMBAH</button>

                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <div class="row" id="listRmpp">
                </div>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
</div>
<script>
function loadSrc(m = '', v = '') {
    $.ajax({
        url: "/rmpp/viewSearch/" + m + "/" + v,
        success: function(data) {

            $('#listRmpp').html(data);
            addFill('value', '')
        }
    });
}
$(document).ready(function() {
    $("#value").on('keyup', function(event) {
        if (event.keyCode === 13) {
            loadSrc($("#method").val(), $("#value").val())
        }
    });
});
</script>

<?= $this->endSection(); ?>