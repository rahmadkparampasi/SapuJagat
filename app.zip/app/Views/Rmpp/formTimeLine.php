 <!-- The timeline -->
 <div class="timeline timeline-inverse">
     <!-- timeline time label -->
     <?php foreach ($Rmpp['Rmpmsk'] as $tk) : ?>
     <div class="time-label">
         <span class="bg-<?= $tk['color'] ?>">
             <?= $tk['rs_rmpmsk_tgl'] ?>
         </span>
         <span class="bg-<?= $tk['color'] ?>">
             <?= $tk['rs_rmpmsk_jam'] ?>
         </span>
     </div>
     <!-- timeline item -->
     <div>
         <i class="fas fa-info bg-primary"></i>

         <div class="timeline-item">

             <h3 class="timeline-header"><a href="#">Detail</a></h3>

             <div class="timeline-body">
                 <h5>Masuk : <?= $tk['rs_rmpmsk_tgl'] ?> Pukul <?= $tk['rs_rmpmsk_jam'] ?></h5>
                 <h5>Keluar :
                     <?php
                            if ($tk['rs_rmpplg_tgl'] !== null && $tk['rs_rmprk_tgl'] !== null) {
                            ?>
                     <?= $tk['rs_rmpplg_tgl'] ?><?= $tk['rs_rmprk_tgl'] ?> Pukul
                     <?= $tk['rs_rmpplg_jam'] ?><?= $tk['rs_rmprk_jam'] ?>
                     <?php
                            } else {
                            ?>
                     Belum Keluar
                     <?php
                            }
                            ?>
                 </h5>
                 <hr>
                 <h5 class="text-<?= $tk['colorSts'] ?>"><?= $tk['sts'] ?></h5>
                 <hr>
                 <h5>Cara Pembayaran : <?= $tk['rs_rmpmsk_cp'] ?></h5>
             </div>
             <div class="timeline-footer">
                 <a href="/rmpmskd/viewData/<?= $tk['rs_rmpmsk_id_ex'] ?>" class="btn btn-primary btn-sm">Lebih
                     Lanjut</a>
             </div>
         </div>
     </div>
     <!-- END timeline item -->
     <div>
         <i class="fas fa-ambulance bg-primary"></i>
         <div class="timeline-item">

             <h3 class="timeline-header"><a href="#"></a> Tujuan Ruangan / Unit</h3>
             <div class="timeline-body">
                 <?php foreach ($tk['Rmpr'] as $tkd) : ?>
                 <?= $tkd['rs_rmpr_tgl'] ?> - <?= $tkd['rs_rmpr_jam'] ?>
                 <h4><?= $tkd['rs_rmr_nm'] ?><?= $tkd['rs_rmk_nm'] ?><?= $tkd['rs_rmrkk_nm'] ?><?= $tkd['rs_rmrkkt_nm'] ?>
                 </h4>
                 <hr>
                 <?php endforeach ?>
             </div>
         </div>
     </div>
     <!-- END timeline item -->
     <div>
         <i class="fas fa-money-bill-wave bg-primary"></i>
         <div class="timeline-item">

             <h3 class="timeline-header"><a href="#"></a> Tagihan / Pembayaran</h3>
             <div class="col-12">
                 <div class="callout callout-info">
                     <h5><i class="fas fa-info"></i> Catatan:</h5>
                     <ol>

                         <li>Warna : <span class="btn bg-danger"></i></span> Berarti Tagihan Pasien Tertunda Karena
                             Belum Mencapai Jam Yang Telah Ditentukan
                         </li>
                         <li>Warna : <span class="btn bg-warning"></i></span> Berarti Tagihan Pasien Dapat Bayarkan
                         </li>
                         <li>Warna : <span class="btn bg-success"></i></span> Berarti Tagihan Pasien Sudah Dibayarkan
                         </li>
                     </ol>
                 </div>
             </div>
             <div class="timeline-body">
                 <?php foreach ($tk['Rmpl'] as $tkd) : ?>
                 <h4><?= $tkd['rs_rmtdk_nm'] ?></h4>
                 <?= $tkd['rs_rmtdk_h'] ?>

                 <hr>
                 <?php endforeach ?>

                 <?php foreach ($tk['Rmprtt'] as $tkd) : ?>
                 <h4><?= $tkd['rs_rmr_nm'] ?><?= $tkd['rs_rmk_nm'] ?><?= $tkd['rs_rmrkk_nm'] ?><?= $tkd['rs_rmrkkt_nm'] ?>
                 </h4>
                 <?= $tkd['rs_rmprtt_tgl'] ?> - <?= $tkd['rs_rmprtt_jam'] ?>
                 <?= $tkd['rs_rmtrfr_h'] ?>
                 <hr>
                 <?php endforeach ?>
             </div>
         </div>
     </div>


     <?php endforeach ?>

     <!-- /.timeline-label -->


 </div>