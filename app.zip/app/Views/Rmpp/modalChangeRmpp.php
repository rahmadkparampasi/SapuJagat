<div class="modal fade bd-example-modal-lg" id="modalChangeRmpp" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <form id="changeRmpp" method="POST" action="/<?= $BasePage; ?>/updateData/<?= $rs_rmpp_id_ex; ?>" enctype="multipart/form-data">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabelPdf">FORM UBAH DATA PASIEN </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <div class="form-group row">
                        <label class="col-sm-12 col-form-label">Nama Pasien</label>
                        <div class="col-sm-12">
                            <div class="input-group m-b">
                                <input type="text" class="form-control" id="rs_rmpp_nm" name="rs_rmpp_nm" required>
                            </div>
                            <small class="text-danger">* Wajib Diisi</small>
                        </div>
                    </div>

                    <div class=" form-group row">
                        <label class="col-sm-12 col-form-label">Jenis Kelamin</label>
                        <div class="col-sm-12">
                            <div class="input-group m-b">
                                <select name="rs_rmpp_jk" id="rs_rmpp_jk" class="form-control" required>
                                    <option hidden value="">PILIH SALAH SATU PILIHAN</option>
                                    <option value="L">LAKI-LAKI</option>
                                    <option value="P">PEREMPUAN</option>
                                </select>
                            </div>
                            <small class="text-danger">* Wajib Diisi</small>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-12 col-form-label">Nomor Identitas</label>
                        <div class="col-sm-12">
                            <div class="input-group m-b">
                                <input type="text" class="form-control" id="rs_rmpp_ind" name="rs_rmpp_ind" required>
                            </div>
                            <small class="text-danger">* Wajib Diisi</small>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-12 col-form-label">Jenis Identitas</label>
                        <div class="col-sm-12">
                            <div class="input-group m-b">
                                <select name="rs_rmpp_rmi" id="rs_rmpp_rmi" class="form-control" required>
                                    <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
                                    <?php foreach ($Rmi as $tk) : ?>
                                    <option value="<?= $tk['rs_rmi_id_ex'] ?>"><?= $tk['rs_rmi_nm'] ?></option>
                                    <?php endforeach ?>
                                </select>
                            </div>
                            <small class="text-danger">* Wajib Diisi</small>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-12 col-form-label">Tempat Lahir</label>
                        <div class="col-sm-12">
                            <div class="input-group m-b">
                                <input type="text" class="form-control" id="rs_rmpp_tmpt_lhr" name="rs_rmpp_tmpt_lhr" required>
                            </div>
                            <small class="text-danger">* Wajib Diisi</small>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-12 col-form-label">Tanggal Lahir</label>
                        <div class="col-sm-12">
                            <div class="input-group m-b">
                                <input type="date" class="form-control" id="rs_rmpp_tgl_lhr" name="rs_rmpp_tgl_lhr" required>
                            </div>
                        </div>
                        <small class="text-danger">* Wajib Diisi</small>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-12 col-form-label">Alamat KTP</label>
                        <div class="col-sm-12">
                            <div class="input-group m-b">
                                <textarea cols="30" rows="1" type="text" class="form-control" id="rs_rmpp_altktp" name="rs_rmpp_altktp" required></textarea>
                            </div>
                            <small class="text-danger">* Wajib Diisi</small>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-12 col-form-label">No. Rumah</label>
                        <div class="col-sm-12">
                            <div class="input-group m-b">
                                <input type="text" class="form-control" id="rs_rmpp_altn" name="rs_rmpp_altn">
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-12 col-form-label">RT / RW</label>
                        <div class="col-sm-12">
                            <div class="input-group m-b">
                                <input type="text" class="form-control" id="rs_rmpp_altr" name="rs_rmpp_altr">
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-12 col-form-label">Kelurahan / Kecamatan</label>
                        <div class="col-sm-12">
                            <div class="input-group m-b">
                                <input type="text" class="form-control" id="rs_rmpp_altkk" name="rs_rmpp_altkk">
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-12 col-form-label">Kota / Kode Pos</label>
                        <div class="col-sm-12">
                            <div class="input-group m-b">
                                <input type="text" class="form-control" id="rs_rmpp_altkp" name="rs_rmpp_altkp">
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-12 col-form-label">Telepon / HP</label>
                        <div class="col-sm-12">
                            <div class="input-group m-b">
                                <input type="text" class="form-control" id="rs_rmpp_altth" name="rs_rmpp_altth">
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-12 col-form-label">Agama</label>
                        <div class="col-sm-12">
                            <div class="input-group m-b">
                                <select name="rs_rmpp_rmag" id="rs_rmpp_rmag" class="form-control">
                                    <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
                                    <?php foreach ($Rmag as $tk) : ?>
                                        <option value="<?= $tk['rs_rmag_id_ex'] ?>"><?= $tk['rs_rmag_nm'] ?></option>
                                    <?php endforeach ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-12 col-form-label">Golongan Darah</label>
                        <div class="col-sm-12">
                            <div class="input-group m-b">
                                <select name="rs_rmpp_rmgd" id="rs_rmpp_rmgd" class="form-control">
                                    <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
                                    <?php foreach ($Rmgd as $tk) : ?>
                                        <option value="<?= $tk['rs_rmgd_id_ex'] ?>"><?= $tk['rs_rmgd_nm'] ?></option>
                                    <?php endforeach ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-12 col-form-label">Bahasa Yang Digunakan</label>
                        <div class="col-sm-12">
                            <div class="input-group m-b">
                                <input type="text" class="form-control" id="rs_rmpp_bhs" name="rs_rmpp_bhs" value="<?= $Rmpp['rs_rmpp_bhs'] ?>">
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-12 col-form-label">Suku Bangsa</label>
                        <div class="col-sm-12">
                            <div class="input-group m-b">
                                <input type="text" class="form-control" id="rs_rmpp_sb" name="rs_rmpp_sb" value="<?= $Rmpp['rs_rmpp_sb'] ?>">
                            </div>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <div class="item form-group">
                            <button type="submit" class="btn btn-success">SIMPAN</button>
                            <button type="button" class="btn btn-danger" data-dismiss="modal">BATAL</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
    $(function() {
        $(document).ready(function() {
            var changeRmpp = $('#changeRmpp');
            changeRmpp.submit(function(e) {
                showAnimated();
                $('#changeRmpp :input').prop("disabled", false);
                $(this).attr('disabled', 'disabled');

                e.preventDefault();
                $.ajax({
                    type: changeRmpp.attr('method'),
                    url: changeRmpp.attr('action'),
                    enctype: 'multipart/form-data',
                    data: new FormData(this),
                    contentType: false,
                    processData: false,
                    dataType: 'json',
                    success: function(data) {
                        hideAnimated();
                        if (data.response == "success") {
                            swal.fire({
                                title: "Terima Kasih",
                                text: data.message,
                                icon: data.response
                            }).then(function() {
                                window.location = '/<?= $UrlForm ?>';
                            });
                        } else {
                            hideAnimated();
                            swal.fire({
                                title: "Tidak Dapat Melanjutkan Proses",
                                text: data.message,
                                icon: data.response
                            });
                        }
                    },
                    error: function(xhr) {
                        hideAnimated();
                        console.log(xhr);
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: xhr.responseJSON.message,
                            icon: "error"
                        });
                    }
                });
            });
        });
    });
</script>