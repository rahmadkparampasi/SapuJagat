<form method="POST" class="form-valide" action="/<?= $BasePage ?>/<?= $MethodForm."File" ?>" id="<?= $IdForm ?>"
    enctype="multipart/form-data"
    style="<?php
                                                                                                                                                if ($MethodForm1 == "updateData") {
                                                                                                                                                    echo 'display: block;';
                                                                                                                                                } else {
                                                                                                                                                    echo 'display: none;';
                                                                                                                                                } ?>">

    <div class="card card-primary">
        <div class="card-header">
            <h3 class="card-title">DATA UMUM PASIEN</h3>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="form-group">
                        <label for="file">Berkas</label>
                        <input type="file" class="form-control" id="file" name="file" accept=".xls" required>
                    </div>
                </div>
                
            </div>


        </div>
    </div>

    <div class="card card-primary">

        <!-- /.card-body -->

        <div class="card-footer">
            <button type="submit" class="btn bg-gradient-primary"><?= $ButtonMethod ?></button>
            <?php
            $MethodForm = substr($MethodForm, 0, 10);
            if ($MethodForm == "updateData") {
            ?>
            <a href="/<?= $BasePage ?>" class='btn bg-gradient-danger' aria-pressed="true">BATAL</a>
            <?php
            } else {
            ?>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('<?= $IdForm ?>', '<?= $IdForm ?>')">BATAL</button>

            <?php
            }
            ?>
        </div>
    </div>
</form>