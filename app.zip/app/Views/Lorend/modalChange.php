<div class="modal fade" id="modalAddChange" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form id="addChange" method="POST" action="/lorend/updateData" enctype="multipart/form-data">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="">UBAH RENCANA KEBUTUHAN BARANG</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="rs_lorend_rmbnm_n">NAMA BARANG</label>
                        <input type="hidden" class="form-control" id="rs_lorend_id_ex_n" name="rs_lorend_id_ex_n" required>
                        <input type="text" class="form-control" id="rs_lorend_rmbnm_n" name="rs_lorend_rmbnm_n" required disabled>
                    </div>
                    <div class="form-group">
                        <label for="rs_lorend_j_n">JUMLAH BELI</label>
                        <input type="number" class="form-control" id="rs_lorend_j_n" name="rs_lorend_j_n" required>
                    </div>
                    <div class="form-group">
                        <label for="rs_lorend_hrg_n">HARGA BELI</label>
                        <input type="number" class="form-control" id="rs_lorend_hrg_n" name="rs_lorend_hrg_n" step=".01" required>
                    </div>
                    
                </div>
                <div class="modal-footer">
                    <div class="item form-group">
                        <button type="submit" class="btn btn-success">SIMPAN</button>
                        <button type="button" class="btn btn-primary" data-dismiss="modal">BATAL</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
$(function() {
    $(document).ready(function() {
        var addChange = $('#addChange');
        addChange.submit(function(e) {
            showAnimated();
            //$('#addChildRmr :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');
            e.stopPropagation();
            e.preventDefault();
            $.ajax({
                type: addChange.attr('method'),
                url: addChange.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            window.location = '/<?= $UrlForm ?>';
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>