<div class="modal fade bd-example-modal-lg" id="modalViewRmb" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabelPdf">LIHAT DATA OBAT </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <table id="dtkRmb" class="table responsive table-bordered table-striped w-100">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Aksi</th>
                            <th>Nama</th>
                            <th>Nama Generik</th>
                            <th>Kategori</th>
                            <th>Satuan</th>
                            <th>Merek</th>
                            <th>Penyedia</th>
                            <th>Harga Beli</th>
                        </tr>
                    </thead>
                </table>

                <script type="text/javascript">
                function showRmb(name = '', idEx = '', hrg = '') {

                    var dt = $('#dtkRmb').DataTable({
                        ajax: "<?= base_url('rmb/getAllRmbByJson') ?>/" + name + "/" +idEx+ "/" +hrg,
                        "order": [
                            [0, "asc"]
                        ],
                        destroy: true,
                        pageLength: 10,
                        responsive: true,
                        fixedHeader: false,
                        keys: true,
                        language: {
                            paginate: {
                                previous: "Sebelumnya",
                                next: "Selanjutnya"
                            },
                            "emptyTable": "Data Tindakan Belum Ada",
                        },
                        columns: [{
                                "data": "no"
                            },
                            {
                                "data": "button"
                            },
                            {
                                "data": "rs_rmb_nm"
                            },
                            {
                                "data": "rs_rmgz_nm"
                            },
                            {
                                "data": "rs_rmjk_nm"
                            },
                            {
                                "data": "rs_rmst_nm"
                            },
                            {
                                "data": "rs_rmmrk_nm"
                            },
                            {
                                "data": "rs_rmpyd_nm"
                            },
                            {
                                "data": "rs_rmb_hb"
                            },
                        ]
                    });
                }

                function destroyRmb() {
                    $('#dtkRmb').DataTable({
                        destroy: true,
                    });
                }
                </script>
            </div>
            <div class="modal-footer">
                <div class="item form-group">
                    <button type="button" class="btn btn-danger" data-dismiss="modal"
                        onclick="destroyRmb()">TUTUP</button>
                </div>
            </div>
        </div>
    </div>
</div>