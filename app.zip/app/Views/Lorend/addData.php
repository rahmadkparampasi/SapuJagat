<div class="card card-primary" style="
    <?php
    if ($MethodForm1 == "updateData") {
        echo 'display: flex;';
    } else {
        echo 'display: none;';
    } ?>" id="<?= $IdForm ?>card">
    <div class="card-header">
        <h3 class="card-title">Form Tambah <?= $PageTitle ?></h3>
    </div>
    <!-- /.card-header -->
    <!-- form start -->
    <form method="POST" class="form-valide" action="/<?= $BasePage ?>/<?= $MethodForm ?>" id="<?= $IdForm ?>"
        enctype="multipart/form-data">
        <?php
        if ($MethodForm1 == "updateData") {
            echo "<input type='hidden' name='rs_lorend_id_ex' id='rs_lorend_id_ex'>";
        }
        ?>
        <input type='hidden' name='rs_lorend_loren' id='rs_lorend_loren' value="<?= $rs_lorend_loren ?>">
        <div class="card-body">
            <div class="form-group">
                <label for="rs_lorend_rmb">Obat</label>
                <div class="row">
                    <div class="col-sm-10">
                        <input type="hidden" id="rs_lorend_rmb" name="rs_lorend_rmb" required class="form-control">
                        <input type="text" id="rs_lorend_rmbnm" name="rs_lorend_rmbnm" required class="form-control" disabled>
                    </div>
                    <div class="col-sm-2">
                        <button type="button" class='btn bg-gradient-primary mx-1' data-target="#modalViewRmb" data-toggle="modal"
                            style="float: right;"
                            onclick="showRmb('rs_lorend_rmbnm', 'rs_lorend_rmb', 'rs_lorend_hrg')"><i
                                class="fas fa-file-archive"></i>
                            AMBIL OBAT</button>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label for="rs_lorend_j">Jumlah Beli</label>
                <input type="number" class="form-control" id="rs_lorend_j" name="rs_lorend_j" required>
            </div>

            <div class="form-group">
                <label for="rs_lorend_hrg">Harga Beli</label>
                <input type="number" class="form-control" id="rs_lorend_hrg" name="rs_lorend_hrg" step=".01">
            </div>
        </div>
        
        <!-- /.card-body -->

        <div class="card-footer">
            <button type="submit" class="btn bg-gradient-primary"><?= $ButtonMethod ?></button>
            <?php
            $MethodForm = substr($MethodForm, 0, 10);
            if ($MethodForm == "updateData") {
            ?>
            <a href="/<?= $BasePage ?>" class='btn bg-gradient-danger' aria-pressed="true">BATAL</a>
            <?php
            } else {
            ?>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('<?= $IdForm ?>card', '<?= $IdForm ?>')">BATAL</button>

            <?php
            }
            ?>
        </div>
    </form>
</div>
<script>
    function getKode() {
        <?php
        $MethodForm = substr($MethodForm, 0, 10);
        if ($MethodForm != "updateData") {
        ?>
            ambilDataText('rs_loren_kd', '/loren/getKd/', ['rs_loren_kd'], 'rs_loren_thn');
        
        <?php
        } else {
        ?>
        var rs_loren_thn = document.getElementById('rs_loren_thn').value;
        var rs_loren_thn_old = document.getElementById('rs_loren_thn_old').value;

        if (rs_loren_thn!=rs_loren_thn_old) {
            ambilDataText('rs_loren_kd', '/loren/getKd/', ['rs_loren_kd'], 'rs_loren_thn');
        }else{
            document.getElementById('rs_loren_kd').value = document.getElementById('rs_loren_kd_old').value;
        }
        
        <?php
        }
        ?>
        
    }
</script>