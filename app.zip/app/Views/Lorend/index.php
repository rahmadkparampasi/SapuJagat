<?= $this->extend('Templates/template'); ?>

<?= $this->section('content'); ?>
<!-- /.row -->

<div class="row">
    <!-- Area Chart -->
    <div class="col-xl-12 col-lg-12">
        <?= $this->include('Lorend/addData'); ?>
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Daftar <?= $PageTitle ?></h3>
                <div class="card-tools">
                    <?php
                    if ($MethodForm1 != "updateData") {
                    ?>
                        <?php
                        if ($Loren['rs_loren_fix'] == "0") {
                        ?>
                            <button class='btn bg-gradient-success' role="button" aria-pressed="true" style="float: right;"
                                onclick="showForm('<?= $IdForm ?>card')"><i class="fas fa-plus"></i>
                                TAMBAH</button>
                        <?php
                        }
                        ?>
                    <?php
                    }
                    ?>
                    <a href="/loren" class='btn bg-gradient-danger mx-1' role="button" aria-pressed="true" style="float: right;"><i class="fas fa-reply"></i> KEMBALI</a>
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table id="datatableKirana" class="dtK table responsive table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Nama Generik</th>
                            <th>Kategori</th>
                            <th>Merek</th>
                            <th>Penyedia</th>
                            <th>Harga Beli</th>
                            <th>Jumlah Beli</th>
                            <th>Satuan</th>
                            <th>Total Harga Beli</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 0;
                        foreach ($Lorend as $tk) : $no++ ?>
                        <tr>
                            <td><?= $no ?></td>
                            <td><?= $tk['rs_rmb_nm'] ?></td>
                            <td class="text-wrap"><?= $tk['rs_rmgz_nm'] ?></td>
                            <td><?= $tk['rs_rmjk_nm'] ?></td>
                            <td><?= $tk['rs_rmmrk_nm'] ?></td>
                            <td><?= $tk['rs_rmpyd_nm'] ?></td>
                            <td><?= $tk['rs_lorend_hrg_n'] ?></td>
                            <td><?= $tk['rs_lorend_j'] ?></td>
                            <td><?= $tk['rs_rmst_nm'] ?></td>
                            <td><?= $tk['ttlHrg'] ?></td>
                            <td>    
                                <?php
                                if ($Loren['rs_loren_fix'] == "0") {
                                ?>
                                <button class="btn bg-gradient-warning m-1" title="Ubah Rencana Kebutuhan Barang Detail" data-target="#modalAddChange"
                                    data-toggle="modal"
                                    onclick="addFill('rs_lorend_id_ex_n', '<?= $tk['rs_lorend_id_ex'] ?>'); addFill('rs_lorend_rmbnm_n', '<?= $tk['rs_rmb_nm'] ?>'); addFill('rs_lorend_hrg_n', '<?= $tk['rs_lorend_hrg'] ?>'); addFill('rs_lorend_j_n', '<?= $tk['rs_lorend_j'] ?>')">
                                    <i class='fas fa-pencil-alt '></i>
                                </button>                
                                
                                <button class="btn bg-gradient-danger m-1" title="Hapus Rencana Kebutuhan Barang Detail"
                                    onclick="callOther('Menghapus <?= $tk['rs_rmb_nm'] ?> Dalam Rencana Kebutuhan Barang Detail', '/<?= $BasePage ?>/deleteData/<?= $tk['rs_lorend_id_ex'] ?>')">
                                    <i class='fas fa-trash'></i>
                                </button>
                                <?php
                                }
                                ?>
                            </td>
                        </tr>
                        <?php endforeach ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th colspan="9" class='text-nowrap text-center font-weight-bold'>TOTAL HARGA RENCANA KEBUTUHAN BARANG</th>
                            <th colspan="2" class="font-weight-bold"><?= $ttl; ?></th>
                        </tr>
                    </tfoot>
                </table>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
</div>

<?= $this->include('Lorend/modalViewRmb'); ?>
<?= $this->include('Lorend/modalChange'); ?>

<?= $this->endSection(); ?>