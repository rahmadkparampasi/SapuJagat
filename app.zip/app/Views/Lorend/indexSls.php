<?= $this->extend('Templates/template'); ?>

<?= $this->section('content'); ?>
<!-- /.row -->

<div class="row">
    <!-- Area Chart -->
    <div class="col-xl-12 col-lg-12">
        <?= $this->include('Lorend/addData'); ?>
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Daftar <?= $PageTitle ?></h3>
                
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table id="datatableKirana" class="dtK table responsive table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Nama Generik</th>
                            <th>Kategori</th>
                            <th>Merek</th>
                            <th>Penyedia</th>
                            <th>Harga Beli</th>
                            <th>Jumlah Beli</th>
                            <th>Satuan</th>
                            <th>Total Harga Beli</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 0;
                        foreach ($Lorend as $tk) : $no++ ?>
                        <tr>
                            <td><?= $no ?></td>
                            <td><?= $tk['rs_rmb_nm'] ?></td>
                            <td class="text-wrap"><?= $tk['rs_rmgz_nm'] ?></td>
                            <td><?= $tk['rs_rmjk_nm'] ?></td>
                            <td><?= $tk['rs_rmmrk_nm'] ?></td>
                            <td><?= $tk['rs_rmpyd_nm'] ?></td>
                            <td><?= $tk['rs_lorend_hrg_n'] ?></td>
                            <td><?= $tk['rs_lorend_j'] ?></td>
                            <td><?= $tk['rs_rmst_nm'] ?></td>
                            <td><?= $tk['ttlHrg'] ?></td>
                            
                        </tr>
                        <?php endforeach ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th colspan="9" class='text-nowrap text-center font-weight-bold'>TOTAL HARGA RENCANA KEBUTUHAN BARANG</th>
                            <th colspan="2" class="font-weight-bold"><?= $ttl; ?></th>
                        </tr>
                    </tfoot>
                </table>
            </div>
            <!-- /.card-body -->
            <div class="card-footer">
                <div class="form-group row justify-content-center">
                    <div class="col-sm-2 col-sm-offset-2 justify-content-center">
                        <button type="submit" class="btn bg-gradient-primary" onclick="callOther('Penyelesaian Data Rencana Kebutuhan Barang, Kode : <?= $Loren['rs_loren_kd'] ?>, Tanggal : <?= $Loren['rs_loren_tgl'] ?>', '/loren/sls/<?= $rs_lorend_loren ?>', '/loren')">SELESAI</button>
                        <a href="/loren" class='btn bg-gradient-danger' aria-pressed="true">BATAL</a>
                    </div>
                </div>
                

               
            </div>
        </div>
        <!-- /.card -->
    </div>
</div>


<?= $this->endSection(); ?>