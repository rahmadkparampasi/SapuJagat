<?= $this->extend('Templates/template'); ?>

<?= $this->section('content'); ?>
<!-- /.row -->

<div class="row">
    <!-- Area Chart -->
    <div class="col-xl-12 col-lg-12">

        <div class="callout callout-info">
            <h5><i class="fas fa-info"></i> Catatan:</h5>
            <ol>
                <li>Tombol : <button class="btn bg-gradient-success"><i class="fa fa-check"></i></button> Mengartikan
                    Bahwa Jenis Mutu Aktif, Untuk Menonaktifkan Tekan Tombol Tersebut</li>
                <br>
                <li>Tombol : <button class="btn bg-gradient-danger"><i class="fa fa-ban"></i></button> Mengartikan Bahwa
                    Jenis Mutu Tidak Aktif, Untuk Mengaktifkan Tekan Tombol Tersebut</li>
            </ol>
        </div>
        <div class="row">
            <div class="col-lg-4 col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Daftar <?= $PageTitle ?></h3>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body" id="tabItemRmji">
                    </div>
                    <div class="card-footer">
                        <button class='btn bg-gradient-info' role="button" aria-pressed="true" style="float: right;"
                            data-target="#modalAddChildRmji" data-toggle="modal"><i class="fas fa-plus"></i>
                            TAMBAH</button>

                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <div class="col-lg-4 col-md-12" id="tabItemRmkb">

            </div>
            <div class="col-lg-4 col-md-12" id="tabItemRmjk"></div>
        </div>

    </div>
</div>

<script>
function addWF(m, l, f, v) {
    callOtherWF(m, l, f, '', v);
}

function loadTabRmji() {

    $.ajax({
        url: "/rmji/viewData/",
        success: function(data) {

            $('#tabItemRmji').html(data);
        }
    });
}

function loadTabRmkb(rs_rmkb_rmji) {

    $.ajax({
        url: "/rmkb/viewData/" + rs_rmkb_rmji,
        success: function(data) {

            $('#tabItemRmkb').html(data);
        }
    });
}

function loadTabRmjk(rs_rmjk_rmkb) {

    $.ajax({
        url: "/rmjk/viewData/" + rs_rmjk_rmkb,
        success: function(data) {

            $('#tabItemRmjk').html(data);
        }
    });
}


$(document).ready(function() {
    loadTabRmji();
});
</script>
<?= $this->endSection(); ?>