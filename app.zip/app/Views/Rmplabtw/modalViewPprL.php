<div class="modal fade bd-example-modal-lg" id="modalViewPprL" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalLabel" aria-hidden="true">
    <form class="form-horizontal form-valide" method="POST" action="/rmplabtwp/insertData" id="formTabPprL">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabelPdf">LIHAT DATA TENAGA MEDIS DALAM RUANGAN </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="rs_rmplabtwp_rmplabtw" name="rs_rmplabtwp_rmplabtw" />
                    <table id="dtkPprL" class="table responsive table-bordered table-striped w-100">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Aksi</th>
                                <th>NIP</th>
                                <th>Nama Pegawai</th>
                                <th>Kategori Pegawai</th>
                            </tr>
                        </thead>
                    </table>


                    <script type="text/javascript">
                    function showPprL(rs_rmpr_rmr = '') {

                        var dt = $('#dtkPprL').DataTable({
                            ajax: "<?= base_url('ppr/getPprByJson') ?>/" + rs_rmpr_rmr,
                            "order": [
                                [0, "asc"]
                            ],
                            destroy: true,
                            pageLength: 10,
                            responsive: true,
                            fixedHeader: false,
                            keys: true,
                            language: {
                                paginate: {
                                    previous: "Sebelumnya",
                                    next: "Selanjutnya"
                                },
                                "emptyTable": "Data Pegawai Dalam Ruangan Belum Ada",
                            },
                            columns: [{
                                    "data": "no"
                                },
                                {
                                    "data": "check"
                                },
                                {
                                    "data": "rs_ppeg_nip"
                                },
                                {
                                    "data": "rs_ppeg_nm"
                                },
                                {
                                    "data": "rs_pkp_nm"
                                },
                            ]
                        });
                    }

                    function destroyPprL() {
                        $('#dtkPprL').DataTable({
                            destroy: true,
                        });
                    }
                    </script>
                </div>
                <div class="modal-footer">
                    <div class="item form-group">
                        <button type="submit" class="btn bg-gradient-primary">SIMPAN</button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal"
                            onclick="destroyPprL()">TUTUP</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <script>
    $(function() {
        $(document).ready(function() {
            var formTabPprL = $('#formTabPprL');
            formTabPprL.submit(function(e) {
                showAnimated();
                $('#formTabPprL :input').prop("disabled", false);
                $(this).attr('disabled', 'disabled');

                e.preventDefault();
                $.ajax({
                    type: formTabPprL.attr('method'),
                    url: formTabPprL.attr('action'),
                    enctype: 'multipart/form-data',
                    data: new FormData(this),
                    contentType: false,
                    processData: false,
                    dataType: 'json',
                    success: function(data) {
                        hideAnimated();
                        if (data.response == "success") {
                            swal.fire({
                                title: "Terima Kasih",
                                text: data.message,
                                icon: data.response
                            }).then(function() {
                                $('#modalViewPprL').modal('hide');
                                $('body').removeClass('modal-open');
                                $('.modal-backdrop').remove();
                                loadChildFormLL('rmplabtw',
                                '<?= $rs_rmplabtw_rmplabt ?>',
                                '<?= $rs_rmplab_tgl ?>',
                                '<?= $rs_rmplab_jam ?>',
                                '<?= $rs_rmtdk_nm ?>');
                            });
                        } else {
                            hideAnimated();
                            swal.fire({
                                title: "Tidak Dapat Melanjutkan Proses",
                                text: data.message,
                                icon: data.response
                            });
                        }
                    },
                    error: function(xhr) {
                        hideAnimated();
                        console.log(xhr);
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: xhr.responseJSON.message,
                            icon: "error"
                        });
                    }
                });
            });
        });
    });
    </script>
</div>