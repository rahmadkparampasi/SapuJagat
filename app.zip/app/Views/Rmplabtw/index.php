<hr>
<form style="display: none;" id="<?= $IdForm ?>" class="form-valide" action="/<?= $BasePage ?>/<?= $MethodForm ?>"
    enctype="multipart/form-data" method="POST">
    <h4 class="text-center">Form <?= $PageTitle ?></h4>

    <div class="form-group row">
        <label for="rs_rmplabtw_tgl" class="col-sm-2 col-form-label">Tanggal</label>
        <div class="col-sm-10">
            <input type="date" id="rs_rmplabtw_tgl" name="rs_rmplabtw_tgl" required class="form-control">
        </div>
    </div>
    <div class="bootstrap-timepicker">
        <div class="form-group row">
            <label for="rs_rmplabtw_jam" class="col-sm-2 col-form-label">Waktu</label>
            <div class="col-sm-10">
                <div class="input-group date" id="timepickerRmplabtw" data-target-input="nearest">
                    <input type="text" class="form-control datetimepicker-input" data-target="#timepickerRmplabtw"
                        id="rs_rmplabtw_jam" name="rs_rmplabtw_jam" required>
                    <div class="input-group-append" data-target="#timepickerRmplabtw" data-toggle="datetimepicker">
                        <div class="input-group-text"><i class="far fa-clock"></i></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
    $(function() {
        //Timepicker
        $('#timepickerRmplabtw').datetimepicker({
            format: 'HH:mm',
            use24hours: true
        })
    });
    </script>

    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-primary"><?= $ButtonMethod ?></button>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('<?= $IdForm ?>', '<?= $IdForm ?>'); ">BATAL</button>
        </div>
    </div>
    <hr>
</form>

<div>
    <h4 class="text-center">Daftar <?= $PageTitle ?></h4>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <?php
                if ($Rmplabtw==null) {
            ?>
            <button type="submit" class="btn bg-gradient-success" style="float: right;"
                onclick="showForm('<?= $IdForm ?>', 'block');"><i class="fas fa-plus"></i>
                Tambah</button>
            <?php
                }
            ?>
            
        </div>
    </div>
    <table id="dtK<?= $IdForm ?>" class="table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Tanggal Dan Waktu</th>
                <th>Tenaga Medis</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Rmplabtw as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td>
                <td class="text-nowrap">
                    Tanggal : <?= $tk['rs_rmplabtw_tgl'] ?><br>
                    Waktu : <?= $tk['rs_rmplabtw_jam'] ?>
                </td>
                <td>

                    <button type="button" class='btn bg-gradient-success mx-1 my-2 btn-block'
                        data-target="#modalViewPprL" data-toggle="modal" style="float: right;"
                        onclick="showPprL('<?= $tk['rs_rmplab_rmr'] ?>'); addFill('rs_rmplabtwp_rmplabtw', '<?= $tk['rs_rmplabtw_id_ex'] ?>');"><i
                            class="fas fa-plus"></i></button>
                            <?php $no = 0;
                                foreach ($tk['Rmplabtwp'] as $tkd) : $no++ ?>
                                <p>
                                    <?= $no.". ". $tkd['rs_ppeg_nm'] ?>
                                    <button class="btn bg-gradient-danger" title="Hapus Data Tenaga Medis" onclick="cOWR('Menghapus Tenaga Medis Dalam Tindakan', '/rmplabtwp/deleteData/<?= $tkd['rs_rmplabtwp_id'] ?>')">
                                        <i class='fas fa-trash'></i>
                                    </button>
                                </p>
                            <?php endforeach ?>

                </td>
                
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
    <br>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="button" class="btn bg-gradient-danger" style="float: right;" onclick="clearBoxLL()"><i
                    class="fas fa-times"></i>
                Tutup</button>
        </div>
    </div>
</div>
<?= $this->include('Rmplabtw/modalViewPprL'); ?>
<script>
    function cOWR(p = '', l = '') {
        callOtherWF(p, l, callloadChildFormLL);
        
    }
    function callloadChildFormLL() {
        loadChildFormLL('rmplabtw',
                '<?= $rs_rmplabtw_rmplabt ?>',
                '<?= $rs_rmplab_tgl ?>',
                '<?= $rs_rmplab_jam ?>',
                '<?= $rs_rmtdk_nm ?>');
    }
$(function() {
    $(document).ready(function() {
        var <?= $IdForm ?> = $('#<?= $IdForm ?>');
        <?= $IdForm ?>.submit(function(e) {
            showAnimated();
            $('#<?= $IdForm ?> :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');

            e.preventDefault();
            $.ajax({
                type: <?= $IdForm ?>.attr('method'),
                url: <?= $IdForm ?>.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            loadChildFormLL('rmplabtw',
                                '<?= $rs_rmplabtw_rmplabt ?>',
                                '<?= $rs_rmplab_tgl ?>',
                                '<?= $rs_rmplab_jam ?>',
                                '<?= $rs_rmtdk_nm ?>');
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>

<script>
$(document).ready(function() {
    $('#dtK<?= $IdForm ?>').DataTable({
        "order": [
            [0, "asc"]
        ],
        pageLength: 10,
        responsive: true,
        fixedHeader: false,
        keys: true,
        columnDefs: [{
                responsivePriority: 1,
                target: 0
            },
            {
                responsivePriority: 10001,
                target: 4
            },
            {
                responsivePriority: 2,
                target: -2
            }
        ]
    });
});
</script>