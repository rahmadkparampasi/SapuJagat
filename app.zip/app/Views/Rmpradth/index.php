<hr>
<form style="display: none;" id="<?= $IdForm ?>" class="form-valide" action="/<?= $BasePage ?>/<?= $MethodForm ?>"
    enctype="multipart/form-data" method="POST">
    <h4 class="text-center">Form <?= $PageTitle ?></h4>
    <input type="hidden" id="rs_rmpradth_rmpradt" name="rs_rmpradth_rmpradt" required value="<?= $rs_rmpradth_rmpradt ?>">

    <div class="form-group row">
        <label for="rs_rmpradth_tgl" class="col-sm-2 col-form-label">Tanggal</label>
        <div class="col-sm-10">
            <input type="date" id="rs_rmpradth_tgl" name="rs_rmpradth_tgl" required class="form-control">
        </div>
    </div>
    <div class="bootstrap-timepicker">
        <div class="form-group row">
            <label for="rs_rmpradth_jam" class="col-sm-2 col-form-label">Waktu</label>
            <div class="col-sm-10">
                <div class="input-group date" id="timepickerRmpradth" data-target-input="nearest">
                    <input type="text" class="form-control datetimepicker-input" data-target="#timepickerRmpradth"
                        id="rs_rmpradth_jam" name="rs_rmpradth_jam" required>
                    <div class="input-group-append" data-target="#timepickerRmpradth" data-toggle="datetimepicker">
                        <div class="input-group-text"><i class="far fa-clock"></i></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
    $(function() {
        //Timepicker
        $('#timepickerRmpradth').datetimepicker({
            format: 'HH:mm',
            use24hours: true
        })
    });
    </script>

    <div class="form-group row">
        <label for="rs_rmpradth_ppeg" class="col-sm-2 col-form-label">Dokter</label>
        <div class="col-sm-8">
            <input type="hidden" id="rs_rmpradth_ppeg" name="rs_rmpradth_ppeg" required class="form-control">
            <input type="text" id="rs_rmpradth_ppegnm" name="rs_rmpradth_ppegnm" required class="form-control" disabled>
        </div>
        <div class="col-sm-2">
            <button type="button" class='btn bg-gradient-primary mx-1' data-target="#modalViewPprC" data-toggle="modal"
                style="float: right;"
                onclick="showPprC('<?= $rs_ppr_rmr ?>', 'rs_rmpradth_ppeg', 'rs_rmpradth_ppegnm')"><i
                    class="fas fa-file-archive"></i>
                AMBIL DOKTER</button>
        </div>
    </div>

    <div class="form-group row">
        <label for="rs_rmpradth_kls" class="col-sm-2 col-form-label">Klinis</label>
        <div class="col-sm-10">
            <input type="text" id="rs_rmpradth_kls" name="rs_rmpradth_kls" class="form-control">
        </div>
    </div>

    <div class="form-group row">
        <label for="rs_rmpradth_ksn" class="col-sm-2 col-form-label">Kesan</label>
        <div class="col-sm-10">
            <textarea id="rs_rmpradth_ksn" name="rs_rmpradth_ksn" class="form-control" rows="3"></textarea>
        </div>
    </div>
    
    <div class="form-group row">
        <label for="rs_rmpradth_usul" class="col-sm-2 col-form-label">Usul</label>
        <div class="col-sm-10">
            <textarea id="rs_rmpradth_usul" name="rs_rmpradth_usul" class="form-control" rows="3"></textarea>
        </div>
    </div>

    <div class="form-group row">
        <label for="rs_rmpradth_hp" class="col-sm-2 col-form-label">Hasil Pemeriksaan</label>
        <div class="col-sm-10">
            <textarea id="rs_rmpradth_hp" name="rs_rmpradth_hp" class="form-control" rows="3"></textarea>
        </div>
    </div>

    <div class="form-group row">
        <label for="rs_rmpradth_btk" class="col-sm-2 col-form-label">BTK</label>
        <div class="col-sm-10">
            <input type="text" id="rs_rmpradth_btk" name="rs_rmpradth_btk" class="form-control">
        </div>
    </div>

    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-primary"><?= $ButtonMethod ?></button>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('<?= $IdForm ?>', '<?= $IdForm ?>'); ">BATAL</button>
        </div>
    </div>
    <hr>
</form>

<div>
    <h4 class="text-center">Daftar <?= $PageTitle ?></h4>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <?php
                if ($Rmpradth==null) {
            ?>
            <button type="submit" class="btn bg-gradient-success" style="float: right;"
                onclick="showForm('<?= $IdForm ?>', 'block');"><i class="fas fa-plus"></i>
                Tambah</button>
            <?php
                }
            ?>
            
        </div>
    </div>
    <table id="dtK<?= $IdForm ?>" class="table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Tanggal Dan Waktu</th>
                <th>Dokter</th>
                <th>Klinis</th>
                <th>Kesan</th>
                <th>Usul</th>
                <th>Hasil Pemeriksaan</th>
                <th>BTK</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Rmpradth as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td>
                <td class="text-nowrap">
                    Tanggal : <?= $tk['rs_rmpradth_tgl'] ?><br>
                    Waktu : <?= $tk['rs_rmpradth_jam'] ?>
                </td>
                <td><?= $tk['rs_ppeg_nm'] ?></td>
                <td class="text-nowrap"><?= $tk['rs_rmpradth_kls'] ?></td>
                <td class="text-nowrap"><?= $tk['rs_rmpradth_ksn'] ?></td>
                <td class="text-nowrap"><?= $tk['rs_rmpradth_usul'] ?></td>
                <td class="text-nowrap"><?= $tk['rs_rmpradth_hp'] ?></td>
                <td><?= $tk['rs_rmpradth_btk'] ?></td>
                <td>

                </td>
                
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
    <br>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="button" class="btn bg-gradient-danger" style="float: right;" onclick="clearBoxRHR()"><i
                    class="fas fa-times"></i>
                Tutup</button>
        </div>
    </div>
</div>
<script>
    function cOWR(p = '', l = '') {
        callOtherWF(p, l, callloadChildFormRHR);
        
    }
    function callloadChildFormRHR() {
        loadChildFormRHR('rmpradth',
                '<?= $rs_rmpradth_rmpradt ?>',
                '<?= $rs_rmprad_tgl ?>',
                '<?= $rs_rmprad_jam ?>',
                '<?= $rs_rmtdk_nm ?>');
    }
$(function() {
    $(document).ready(function() {
        var <?= $IdForm ?> = $('#<?= $IdForm ?>');
        <?= $IdForm ?>.submit(function(e) {
            showAnimated();
            $('#<?= $IdForm ?> :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');

            e.preventDefault();
            $.ajax({
                type: <?= $IdForm ?>.attr('method'),
                url: <?= $IdForm ?>.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            loadChildFormRHR('rmpradth',
                                '<?= $rs_rmpradth_rmpradt ?>',
                                '<?= $rs_rmprad_tgl ?>',
                                '<?= $rs_rmprad_jam ?>',
                                '<?= $rs_rmtdk_nm ?>');
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>

<script>
$(document).ready(function() {
    $('#dtK<?= $IdForm ?>').DataTable({
        "order": [
            [0, "asc"]
        ],
        pageLength: 10,
        responsive: true,
        fixedHeader: false,
        keys: true,
        columnDefs: [{
                responsivePriority: 1,
                target: 0
            },
            {
                responsivePriority: 10001,
                target: 4
            },
            {
                responsivePriority: 2,
                target: -2
            }
        ]
    });
});
</script>