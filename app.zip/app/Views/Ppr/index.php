<div style="display: none;" id="<?= $IdForm ?>">
    <h4 class="text-center">Form <?= $PageTitle ?></h4>

    <table id="dtK<?= $IdForm ?>Ppeg" class="table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>Aksi</th>
                <th>No</th>
                <th>NIP</th>
                <th>Nama Lengkap</th>
                <th>Status Pegawai</th>
                <th>Kategori Pegawai</th>
            </tr>
        </thead>
    </table>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="button" class="btn bg-gradient-danger" onclick="closeForm('<?= $IdForm ?>', '<?= $IdForm ?>'); destroyIcdt()">BATAL</button>
        </div>
    </div>
    <hr>
</div>

<script>
    function loadPpeg() {
        var sS = getSS();
        $('#dtK<?= $IdForm ?>Ppeg').DataTable({
            destroy: true,
            ajax: "<?= base_url('ppeg/getPpegByJson') ?>" + "/" + sS.idExSRmr,
            paging: true,
            searching: true,
            pageLength: 10,
            responsive: true,
            fixedHeader: true,
            keys: true,
            language: {
                paginate: {
                    previous: "Sebelumnya",
                    next: "Selanjutnya"
                },
                "emptyTable": "Data Ruangan Belum Ada",
            },
            columns: [{
                    "data": "button"
                },
                {
                    "data": "no"
                },
                {
                    "data": "rs_ppeg_nip"
                },
                {
                    "data": "rs_ppeg_nm"
                },
                {
                    "data": "rs_psp_nm"
                },
                {
                    "data": "rs_pkp_nm"
                },
            ],
            columnDefs: [{
                className: "text-nowrap",
                "targets": [2]
            }]
        });
    }

    function destroyIcdt() {
        $('#dtK<?= $IdForm ?>Ppeg').DataTable({
            destroy: true,
        });
    }
</script>

<div>
    <h4 class="text-center">Daftar <?= $PageTitle ?></h4>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-success" style="float: right;" onclick="showForm('<?= $IdForm ?>', 'block'); loadPpeg()"><i class="fas fa-plus"></i>
                Tambah</button>
        </div>
    </div>
    <table id="dtK<?= $IdForm ?>" class="table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Lengkap</th>
                <th>Status Pegawai</th>
                <th>Kategori Pegawai</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Ppr as $tk) : $no++ ?>
                <tr>
                    <td><?= $no ?></td>
                    <td><?= $tk['rs_ppeg_nm'] ?></td>
                    <td><?= $tk['rs_psp_nm'] ?></td>
                    <td><?= $tk['rs_pkp_nm'] ?></td>
                    <td>
                        <button class="btn bg-gradient-danger" title="Hapus Data Pegawai Dari Ruangan" onclick="addWF('Menghapus Data Pegawai Dari Ruangan', '/<?= $BasePage ?>/deleteData/<?= $tk['rs_ppr_id'] ?>')">
                            <i class='fas fa-trash'></i></button>
                    </td>
                </tr>
            <?php endforeach ?>
        </tbody>
        <tfoot>
            <tr>
                <th>No</th>
                <th>Nama Lengkap</th>
                <th>Status Pegawai</th>
                <th>Kategori Pegawai</th>
                <th>Aksi</th>
            </tr>
        </tfoot>
    </table>
</div>

<script>
    $(function() {
        $(document).ready(function() {
            var <?= $IdForm ?> = $('#<?= $IdForm ?>');
            <?= $IdForm ?>.submit(function(e) {
                showAnimated();
                $('#<?= $IdForm ?> :input').prop("disabled", false);
                $(this).attr('disabled', 'disabled');

                e.preventDefault();
                $.ajax({
                    type: <?= $IdForm ?>.attr('method'),
                    url: <?= $IdForm ?>.attr('action'),
                    enctype: 'multipart/form-data',
                    data: new FormData(this),
                    contentType: false,
                    processData: false,
                    dataType: 'json',
                    success: function(data) {
                        hideAnimated();
                        if (data.response == "success") {
                            swal.fire({
                                title: "Terima Kasih",
                                text: data.message,
                                icon: data.response
                            }).then(function() {
                                window.location = '/<?= $UrlForm ?>';
                            });
                        } else {
                            hideAnimated();
                            swal.fire({
                                title: "Tidak Dapat Melanjutkan Proses",
                                text: data.message,
                                icon: data.response
                            });
                        }
                    },
                    error: function(xhr) {
                        hideAnimated();
                        console.log(xhr);
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: xhr.responseJSON.message,
                            icon: "error"
                        });
                    }
                });
            });
        });
    });
</script>

<script>
    $(document).ready(function() {
        $('#dtK<?= $IdForm ?>').DataTable({
            "order": [
                [0, "asc"]
            ],
            pageLength: 10,
            responsive: true,
            fixedHeader: false,
            keys: true,
            columnDefs: [{
                    responsivePriority: 1,
                    target: 0
                },
                {
                    responsivePriority: 10001,
                    target: 4
                },
                {
                    responsivePriority: 2,
                    target: -2
                }
            ]
        });
    });
</script>