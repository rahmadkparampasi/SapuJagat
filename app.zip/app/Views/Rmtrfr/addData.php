<form method="POST" class="form-valide" action="/<?= $BasePage ?>/<?= $MethodForm ?>" id="<?= $IdForm ?>" enctype="multipart/form-data" style="<?php
                                                                                                                                                if ($MethodForm1 == "updateData") {
                                                                                                                                                    echo 'display: block;';
                                                                                                                                                } else {
                                                                                                                                                    echo 'display: none;';
                                                                                                                                                } ?>">
    <div class="card card-primary">
        <div class="card-header">
            <h3 class="card-title">REGISTRASI PASIEN</h3>
        </div>
        <?php
        if ($MethodForm1 == "updateData") {
            echo "<input type='hidden' name='rs_rmtrfr_id_ex' id='rs_rmtrfr_id_ex'>";
        }
        ?>
        <div class="card-body">

            <div class="form-group">
                <label for="rs_rmtrfr_tgl">Tanggal SK</label>
                <input type="date" class="form-control" id="rs_rmtrfr_tgl" name="rs_rmtrfr_tgl" required>
            </div>
            <div class="form-group">
                <label for="rs_rmtrfr_sk">Nomor SK</label>
                <input type="text" class="form-control" id="rs_rmtrfr_sk" name="rs_rmtrfr_sk" required>
            </div>
            <div class="form-group">
                <label for="rs_rmtrfr_rmk">Kelas</label>
                <select name="rs_rmtrfr_rmk" id="rs_rmtrfr_rmk" class="form-control" required>
                    <option hidden value="">PILIH SALAH SATU PILIHAN </option>
                    <?php foreach ($Rmk as $tk) : ?>
                        <option value="<?= $tk['rs_rmk_id_ex'] ?>"><?= $tk['rs_rmk_nm'] ?></option>

                    <?php endforeach ?>
                </select>

            </div>
            <div class="form-group">
                <label for="rs_rmtrfr_srn">Tarif Sarana</label>
                <input type="number" class="form-control" id="rs_rmtrfr_srn" name="rs_rmtrfr_srn" required>
            </div>
            <div class="form-group">
                <label for="rs_rmtrfr_jp">Tarif Jasa Pelayanan</label>
                <input type="number" class="form-control" id="rs_rmtrfr_jp" name="rs_rmtrfr_jp" required>
            </div>
            <div class="form-group">
                <label for="rs_rmtrfr_jd">Tarif Jasa Dokter</label>
                <input type="number" class="form-control" id="rs_rmtrfr_jd" name="rs_rmtrfr_jd" required>
            </div>
            <div class="form-group">
                <label for="rs_rmtrfr_jpr">Tarif Jasa Perawat</label>
                <input type="number" class="form-control" id="rs_rmtrfr_jpr" name="rs_rmtrfr_jpr" required>
            </div>
            <div class="form-group">
                <label for="rs_rmtrfr_nm">Tarif Non Medis</label>
                <input type="number" class="form-control" id="rs_rmtrfr_nm" name="rs_rmtrfr_nm" required>
            </div>
            <div class="form-group">
                <label for="rs_rmtrfr_kns">Tarif Konsumsi</label>
                <input type="number" class="form-control" id="rs_rmtrfr_kns" name="rs_rmtrfr_kns" required>
            </div>


        </div>
        <div class="card-footer">
            <button type="submit" class="btn bg-gradient-primary"><?= $ButtonMethod ?></button>
            <?php
            $MethodForm = substr($MethodForm, 0, 10);
            if ($MethodForm == "updateData") {
            ?>
                <a href="/<?= $BasePage ?>" class='btn bg-gradient-danger' aria-pressed="true">BATAL</a>
            <?php
            } else {
            ?>
                <button type="button" class="btn bg-gradient-danger" onclick="closeForm('<?= $IdForm ?>card', '<?= $IdForm ?>')">BATAL</button>

            <?php
            }
            ?>
        </div>
        <!-- /.card-body -->
    </div>
</form>

<script>
    $(function() {
        //Timepicker
        $('#timepickerJamD').datetimepicker({
            format: 'HH:mm',
            use24hours: true
        })
    });
</script>