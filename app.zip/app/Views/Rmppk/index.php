<?= $this->extend('Templates/template'); ?>

<?= $this->section('content'); ?>
<!-- /.row -->

<div class="row">
    <!-- Area Chart -->
    <div class="col-xl-12 col-lg-12">
        <?= $this->include('Rmppk/addData'); ?>
        <div class="callout callout-info">
            <h5><i class="fas fa-info"></i> Catatan:</h5>
            <ol>
                <li>Tombol : <button class="btn bg-gradient-success"><i class="fa fa-check"></i></button> Mengartikan
                    Bahwa Pemberi Pelayanan Kesehatan Aktif, Untuk Menonaktifkan Tekan Tombol Tersebut</li>
                <br>
                <li>Tombol : <button class="btn bg-gradient-danger"><i class="fa fa-ban"></i></button> Mengartikan Bahwa
                    Pemberi Pelayanan Kesehatan Tidak Aktif, Untuk Mengaktifkan Tekan Tombol Tersebut</li>
            </ol>
        </div>
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Daftar <?= $PageTitle ?></h3>
                <div class="card-tools">
                    <?php
                    if ($MethodForm1 != "updateData") {
                    ?>
                    <button class='btn bg-gradient-success' role="button" aria-pressed="true" style="float: right;"
                        onclick="showForm('<?= $IdForm ?>card')"><i class="fas fa-plus"></i>
                        TAMBAH</button>
                    <?php
                    }
                    ?>
                    <a href="/rmref" class='btn bg-gradient-danger mx-1' style="float: right;"><i
                            class="fas fa-reply"></i>
                        KEMBALI</a>
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table id="datatableKirana" class="table responsive table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th class="text-nowrap">Kode Faskes</th>
                            <th>Kode Faskes BPJS</th>
                            <th>Nama Faskes</th>
                            <th>Jenis Faskes</th>
                            <th>Kepemilikan Faskes</th>
                            <th>Tipe Faskes</th>
                            <th>Kelas Faskes</th>
                            <th>Alamat</th>
                            <th>RT/RW</th>
                            <th>Kode Pos</th>
                            <th>Telepon</th>
                            <th>Fax</th>
                            <th>Kota / Kabupaten</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 0;
                        foreach ($Rmppk as $tk) : $no++ ?>
                        <tr>
                            <td><?= $no ?></td>
                            <td class="text-nowrap"><?= $tk['rs_rmppk_kf'] ?></td>
                            <td class="text-nowrap"><?= $tk['rs_rmppk_bpjs'] ?></td>
                            <td class="text-nowrap"><?= $tk['rs_rmppk_nm'] ?></td>
                            <td class="text-nowrap"><?= $tk['rs_rmjf_nm'] ?></td>
                            <td class="text-nowrap"><?= $tk['rs_rmkf_nm'] ?></td>
                            <td class="text-nowrap"><?= $tk['rs_rmtf_nm'] ?></td>
                            <td class="text-nowrap"><?= $tk['rs_rmcf_nm'] ?></td>
                            <td class="text-nowrap"><?= $tk['rs_rmppk_alt'] ?></td>
                            <td class="text-nowrap"><?= $tk['rs_rmppk_rt'] ?>/<?= $tk['rs_rmppk_rw'] ?></td>
                            <td class="text-nowrap"><?= $tk['rs_rmppk_pos'] ?></td>
                            <td class="text-nowrap"><?= $tk['rs_rmppk_telp'] ?></td>
                            <td class="text-nowrap"><?= $tk['rs_rmppk_fax'] ?></td>
                            <td class="text-nowrap"><?= $tk['rs_rmw_nm'] ?></td>
                            <td>
                                <?php
                                    if ($tk['rs_rmppk_sts'] == "1") {
                                    ?>
                                <button class="btn bg-gradient-success" title="Pemberi Pelayanan Kesehatan Aktif"
                                    onclick="callOther('Menonaktifkan <?= $tk['rs_rmppk_nm'] ?> Dalam Data Pemberi Pelayanan Kesehatan', '<?= $BasePage ?>/block/<?= $tk['rs_rmppk_id_ex'] ?>')">
                                    <i class='fas fa-check'></i>
                                </button>
                                <?php
                                    } else {
                                    ?>
                                <button class="btn bg-gradient-danger" title="Pemberi Pelayanan Kesehatan Tidak Aktif"
                                    onclick="callOther('Mengaktifkan <?= $tk['rs_rmppk_nm'] ?> Dalam Data Pemberi Pelayanan Kesehatan', '<?= $BasePage ?>/unblock/<?= $tk['rs_rmppk_id_ex'] ?>')">
                                    <i class='fas fa-ban'></i>
                                </button>
                                <?php
                                    }
                                    ?>
                            </td>
                            <td>
                                <button class="btn bg-gradient-warning" title="Ubah Pemberi Pelayanan Kesehatan"
                                    onclick="callHref('<?= $BasePage ?>/editData/<?= $tk['rs_rmppk_id_ex'] ?>')">
                                    <i class='fas fa-pen'></i>
                                </button>

                                <button class="btn bg-gradient-danger" title="Hapus Pemberi Pelayanan Kesehatan"
                                    onclick="callOther('Menghapus <?= $tk['rs_rmppk_nm'] ?> Dalam Pemberi Pelayanan Kesehatan', '<?= $BasePage ?>/deleteData/<?= $tk['rs_rmppk_id_ex'] ?>')">
                                    <i class='fas fa-trash'></i>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach ?>
                    </tbody>

                </table>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
</div>

<script>
$(document).ready(function() {
    $('#datatableKirana').DataTable({
        "order": [
            [0, "asc"]
        ],
        pageLength: 100,
        responsive: true,
        fixedHeader: true,
        keys: true,
        columnDefs: [{
                responsivePriority: 1,
                target: 0
            },
            {
                responsivePriority: 10001,
                target: 4
            },
            {
                responsivePriority: 2,
                target: -2
            }
        ]
    });
});
</script>

<?= $this->endSection(); ?>