<div class="card card-primary" style="
    <?php
    if ($MethodForm1 == "updateData") {
        echo 'display: flex;';
    } else {
        echo 'display: none;';
    } ?>" id="<?= $IdForm ?>card">
    <div class="card-header">
        <h3 class="card-title">Form Tambah <?= $PageTitle ?></h3>
    </div>
    <!-- /.card-header -->
    <!-- form start -->
    <form method="POST" class="form-valide" action="/<?= $BasePage ?>/<?= $MethodForm ?>" id="<?= $IdForm ?>"
        enctype="multipart/form-data">
        <?php
        if ($MethodForm1 == "updateData") {
            echo "<input type='hidden' name='rs_rmppk_id_ex' id='rs_rmppk_id_ex'>";
        }
        ?>
        <div class="card-body">
            <div class="form-group">
                <label for="rs_rmppk_kf">Kode Faskes</label>
                <input type="text" class="form-control" id="rs_rmppk_kf" name="rs_rmppk_kf">
            </div>
            <div class="form-group">
                <label for="rs_rmppk_bpjs">Kode Faskes BPJS</label>
                <input type="text" class="form-control" id="rs_rmppk_bpjs" name="rs_rmppk_bpjs">
            </div>
            <div class="form-group">
                <label for="rs_rmppk_nm">Nama Faskes</label>
                <input type="text" class="form-control" id="rs_rmppk_nm" name="rs_rmppk_nm" required>
            </div>
            <div class="form-group">
                <label for="rs_rmppk_rmjf">Jenis Faskes</label>
                <select class="form-control" id="rs_rmppk_rmjf" name="rs_rmppk_rmjf">
                    <option hidden value="">Pilih Salah Satu Pilihan</option>
                    <?php $no = 0;
                    foreach ($Rmjf as $tk) : $no++ ?>
                    <option value="<?= $tk['rs_rmjf_id_ex'] ?>"><?= $tk['rs_rmjf_nm'] ?></option>
                    <?php endforeach ?>
                </select>
            </div>
            <div class="form-group">
                <label for="rs_rmppk_rmkf">Kepemilikan Faskes</label>
                <select class="form-control" id="rs_rmppk_rmkf" name="rs_rmppk_rmkf">
                    <option hidden value="">Pilih Salah Satu Pilihan</option>
                    <?php $no = 0;
                    foreach ($Rmkf as $tk) : $no++ ?>
                    <option value="<?= $tk['rs_rmkf_id_ex'] ?>"><?= $tk['rs_rmkf_nm'] ?></option>
                    <?php endforeach ?>
                </select>
            </div>
            <div class="form-group">
                <label for="rs_rmppk_rmtf">Tipe Faskes</label>
                <select class="form-control" id="rs_rmppk_rmtf" name="rs_rmppk_rmtf">
                    <option hidden value="">Pilih Salah Satu Pilihan</option>
                    <?php $no = 0;
                    foreach ($Rmtf as $tk) : $no++ ?>
                    <option value="<?= $tk['rs_rmtf_id_ex'] ?>"><?= $tk['rs_rmtf_nm'] ?></option>
                    <?php endforeach ?>
                </select>
            </div>
            <div class="form-group">
                <label for="rs_rmppk_rmcf">Kelas Faskes</label>
                <select class="form-control" id="rs_rmppk_rmcf" name="rs_rmppk_rmcf">
                    <option hidden value="">Pilih Salah Satu Pilihan</option>
                    <?php $no = 0;
                    foreach ($Rmcf as $tk) : $no++ ?>
                    <option value="<?= $tk['rs_rmcf_id_ex'] ?>"><?= $tk['rs_rmcf_nm'] ?></option>
                    <?php endforeach ?>
                </select>
            </div>

            <div class="form-group">
                <label for="rs_rmppk_alt">Alamat Faskes</label>
                <textarea class="form-control" id="rs_rmppk_alt" name="rs_rmppk_alt" rows="10" cols="2"></textarea>
            </div>

            <div class="form-group">
                <label for="rs_rmppk_rt">RT/RW</label>
                <div class="row">

                    <input type="text" class="form-control col-6" id="rs_rmppk_rt" name="rs_rmppk_rt" placeholder="RT">
                    <input type="text" class="form-control col-6" id="rs_rmppk_rw" name="rs_rmppk_rw" placeholder="RW">
                </div>
            </div>
            <div class="form-group">
                <label for="rs_rmppk_pos">Kode Pos</label>
                <input type="text" class="form-control" id="rs_rmppk_pos" name="rs_rmppk_pos">
            </div>
            <div class="form-group">
                <label for="rs_rmppk_telp">Telepon</label>
                <input type="text" class="form-control" id="rs_rmppk_telp" name="rs_rmppk_telp">
            </div>
            <div class="form-group">
                <label for="rs_rmppk_fax">Fax</label>
                <input type="text" class="form-control" id="rs_rmppk_fax" name="rs_rmppk_fax">
            </div>


            <div class="form-group">
                <label for="rs_rmppk_rmw">Kabupaten / Kota</label>
                <select class="form-control" id="rs_rmppk_rmw" name="rs_rmppk_rmw">
                    <option hidden value="">Pilih Salah Satu Pilihan</option>
                    <?php $no = 0;
                    foreach ($Rmw as $tk) : $no++ ?>
                    <option value="<?= $tk['rs_rmw_id_ex'] ?>"><?= $tk['rs_rmw_nm'] ?></option>
                    <?php endforeach ?>
                </select>
            </div>
        </div>
        <!-- /.card-body -->

        <div class="card-footer">
            <button type="submit" class="btn bg-gradient-primary"><?= $ButtonMethod ?></button>
            <?php
            $MethodForm = substr($MethodForm, 0, 10);
            if ($MethodForm == "updateData") {
            ?>
            <a href="/<?= $BasePage ?>" class='btn bg-gradient-danger' aria-pressed="true">BATAL</a>
            <?php
            } else {
            ?>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('<?= $IdForm ?>card', '<?= $IdForm ?>')">BATAL</button>

            <?php
            }
            ?>
        </div>
    </form>
</div>