<table id="datatableKirana<?= $IdForm ?>" class="table responsive table-bordered table-striped">
    <thead>
        <tr>
            <th>No</th>
            <th>Deskripsi</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <?php $no = 0;
        foreach ($Rmji as $tk) : $no++ ?>
        <tr>
            <td><?= $no ?></td>
            <td>
                <button class="btn bg-bg-gradient-lightblue" onclick="loadTabRmkb('<?= $tk['rs_rmji_id_ex'] ?>')">
                    <?= $tk['rs_rmji_nm'] ?>
                </button>
            </td>
            <td>
                <?php
                    if ($tk['rs_rmji_sts'] == "1") {
                    ?>
                <button class="btn bg-gradient-success" title="Jenis Inventaris Aktif"
                    onclick="addWF('Menonaktifkan <?= $tk['rs_rmji_nm'] ?> Dalam Data Jenis Inventaris', '<?= $BasePage ?>/block/<?= $tk['rs_rmji_id_ex'] ?>', loadTabRmji)">
                    <i class='fas fa-check'></i>
                </button>
                <?php
                    } else {
                    ?>
                <button class="btn bg-gradient-danger" title="Jenis Inventaris Tidak Aktif"
                    onclick="addWF('Mengaktifkan <?= $tk['rs_rmji_nm'] ?> Dalam Data Jenis Inventaris', '<?= $BasePage ?>/unblock/<?= $tk['rs_rmji_id_ex'] ?>', loadTabRmji)">
                    <i class='fas fa-ban'></i>
                </button>
                <?php
                    }
                    ?>
            </td>
        </tr>
        <?php endforeach ?>
    </tbody>

</table>
<?= $this->include('Rmji/modalAddChild'); ?>
<script>
$(document).ready(function() {
    $('#datatableKirana<?= $IdForm ?>').DataTable({
        "order": [
            [0, "asc"]
        ],
        pageLength: 100,
        responsive: true,
        fixedHeader: true,
        keys: true,
        columnDefs: [{
                responsivePriority: 1,
                target: 0
            },
            {
                responsivePriority: 10001,
                target: 4
            },
            {
                responsivePriority: 2,
                target: -2
            }
        ]
    });
});
</script>