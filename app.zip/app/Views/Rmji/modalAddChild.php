<div class="modal fade" id="modalAddChildRmji" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form id="addChildRmji" method="POST" action="/rmji/insertData" enctype="multipart/form-data">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">TAMBAH JENIS INVENTARIS</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="rs_rmji_nm">DESKRIPSI</label>
                        <input type="text" class="form-control" id="rs_rmji_nm" name="rs_rmji_nm" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="item form-group">
                        <button type="submit" class="btn btn-success">SIMPAN</button>
                        <button type="button" class="btn btn-primary" data-dismiss="modal">BATAL</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
$(function() {
    $(document).ready(function() {
        var addChildRmji = $('#addChildRmji');
        addChildRmji.submit(function(e) {
            showAnimated();
            //$('#addChildRmr :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');
            e.stopPropagation();
            e.preventDefault();
            $.ajax({
                type: addChildRmji.attr('method'),
                url: addChildRmji.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            loadTabRmji();
                            $('#modalAddChildRmji').modal('hide');
                            document.getElementById("addChildRmji").reset();

                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>