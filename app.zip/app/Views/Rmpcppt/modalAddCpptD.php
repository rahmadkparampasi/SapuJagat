<div class="modal fade bd-example-modal-lg" id="modalAddCpptD" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <form id="AddCpptD" method="POST" action="/<?= $BasePage ?>/insertDataRmpcpptd/" enctype="multipart/form-data">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">CPPT DETAIL</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <input type="hidden" name="rs_rmpcpptd_rmpcppt" id="rs_rmpcpptd_rmpcppt" value="">

                    <input type="hidden" name="rs_rmpcpptd_id_ex" id="rs_rmpcpptd_id_ex" value="">

                    <div class="form-group">
                        <label for="rs_rmpcpptd_tgl">Tanggal CPPT</label>
                        <input type="date" class="form-control" id="rs_rmpcpptd_tgl" name="rs_rmpcpptd_tgl" required>
                    </div>


                    <div class="bootstrap-timepicker">
                        <div class="form-group">
                            <label for="rs_rmpcpptd_jam">Jam CPPT</label>
                            <div class="input-group date" id="timepickerMsk" data-target-input="nearest">
                                <input type="text" class="form-control datetimepicker-input" data-target="#timepickerMsk" id="rs_rmpcpptd_jam" name="rs_rmpcpptd_jam" required>
                                <div class="input-group-append" data-target="#timepickerMsk" data-toggle="datetimepicker">
                                    <div class="input-group-text"><i class="far fa-clock"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="rs_rmpcpptd_kode">Kode CPPT</label>
                        <select name="rs_rmpcpptd_kode" id="rs_rmpcpptd_kode" class="form-control" required>
                            <option hidden>PILIH SALAH SATU PILIHAN</option>
                            <option value="S">S</option>
                            <option value="O">O</option>
                            <option value="A">A</option>
                            <option value="P">P</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="rs_rmpcpptd_ket">Keterangan CPPT</label>
                        <textarea name="rs_rmpcpptd_ket" id="rs_rmpcpptd_ket" cols="30" rows="2" class="form-control" required></textarea>
                    </div>

                    <div class="form-group">
                        <label for="rs_rmpcpptd_inst">Instruksi CPPT</label>
                        <textarea name="rs_rmpcpptd_inst" id="rs_rmpcpptd_inst" cols="30" rows="2" class="form-control" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="item form-group">
                        <button type="submit" class="btn btn-success">SIMPAN</button>
                        <button type="button" class="btn btn-primary" data-dismiss="modal" onclick="resetForm('AddCpptD')">BATAL</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<script>
    $(function() {
        //Timepicker
        $('#timepickerMsk').datetimepicker({
            format: 'HH:mm',
            use24hours: true
        })
    });
</script>

<script>
    $(function() {
        $(document).ready(function() {
            var AddCpptD = $('#AddCpptD');
            AddCpptD.submit(function(e) {
                showAnimated();
                $('#AddCpptD :input').prop("disabled", false);
                $(this).attr('disabled', 'disabled');

                e.preventDefault();
                $.ajax({
                    type: AddCpptD.attr('method'),
                    url: AddCpptD.attr('action'),
                    enctype: 'multipart/form-data',
                    data: new FormData(this),
                    contentType: false,
                    processData: false,
                    dataType: 'json',
                    success: function(data) {
                        hideAnimated();
                        if (data.response == "success") {
                            swal.fire({
                                title: "Terima Kasih",
                                text: data.message,
                                icon: data.response
                            }).then(function() {
                                window.location = '/<?= $UrlForm ?>';
                            });
                        } else {
                            hideAnimated();
                            swal.fire({
                                title: "Tidak Dapat Melanjutkan Proses",
                                text: data.message,
                                icon: data.response
                            });
                        }
                    },
                    error: function(xhr) {
                        hideAnimated();
                        console.log(xhr);
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: xhr.responseJSON.message,
                            icon: "error"
                        });
                    }
                });
            });
        });
    });
</script>