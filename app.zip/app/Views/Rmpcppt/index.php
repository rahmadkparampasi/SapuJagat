<?= $this->extend('Templates/template'); ?>

<?= $this->section('content'); ?>
<!-- /.row -->

<div class="row">
    <!-- Area Chart -->
    <div class="col-xl-12 col-lg-12">
        <?= $this->include('Rmpcppt/addData'); ?>

        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Daftar <?= $PageTitle ?> A.N. Pasien <?= $Rmpmsk['rs_rmpp_nm'] ?>, Tgl Masuk IGD <?= $Rmpmsk['rs_rmpmsk_tgl'] ?>, Jam Masuk IGD <?= $Rmpmsk['rs_rmpmsk_jam'] ?>, No. RM : <?= $Rmpmsk['rs_rmpp_rm'] ?></h3>
                <div class="card-tools">
                    <?php

                    if ($MethodForm1 != "updateData") {
                    ?>
                        <button class='btn bg-gradient-success' role="button" aria-pressed="true" style="float: right;" onclick="showForm('<?= $IdForm ?>card')"><i class="fas fa-plus"></i>
                            TAMBAH</button>
                    <?php
                    }
                    ?>

                    <a href="/rmpmsk" class='btn bg-gradient-danger mx-1' style="float: right;"><i class="fas fa-reply"></i>
                        KEMBALI</a>
                    <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
                    <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table id="datatableKirana1" class="table responsive table-bordered table-striped w-100">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Tanggal CPPT</th>
                            <th>Aksi</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 0;
                        foreach ($Rmpcppt as $tk) : $no++ ?>
                            <tr>
                                <td><?= $no ?></td>
                                <td>
                                    Tanggal : <?= $tk['rs_rmpcppt_tgl'] ?>
                                </td>
                                <td>
                                    <button class="btn bg-gradient-warning" title="Ubah Data CPPT Pasien" onclick="callHref('/<?= $BasePage ?>/editData/<?= $tk['rs_rmpcppt_id_ex'] ?>')">
                                        <i class='fas fa-pen'></i>
                                    </button>
                                    <?php

                                    if ($MethodForm1 != "updateData") {
                                    ?>
                                        <button class="btn bg-gradient-danger" title="Hapus Data CPPT Pasien" onclick="callOther('Menghapus Data CPPT Pasien', '/<?= $BasePage ?>/deleteData/<?= $tk['rs_rmpcppt_id_ex'] ?>')">
                                            <i class='fas fa-trash'></i></button>
                                    <?php
                                    }
                                    ?>

                                </td>
                                <td class="text-nowrap">
                                    <table id="datatableKirana2" class="table responsive table-bordered table-striped w-100">
                                        <h4>CPPT</h4>
                                        <?php
                                        if ($MethodForm1 != "updateData") {
                                        ?>
                                            <button class='btn bg-gradient-primary my-2' role="button" aria-pressed="true" data-target="#modalAddCpptD" data-toggle="modal" onclick="resetForm('AddCpptD'); addFill('rs_rmpcpptd_rmpcppt', '<?= $tk['rs_rmpcppt_id_ex'] ?>')"><i class="fas fa-pen"></i>
                                                TAMBAH</button>
                                        <?php
                                        }
                                        ?>

                                        <thead>
                                            <tr>
                                                <th class="text-center">Tgl/Jam</th>
                                                <th class="text-center">Profesi</th>
                                                <th class="text-center">Hasil Pemeriksaan Analisa Dan Rencana Penatalaksanaan Pasien <br>(Ditulis Dalam Format SOAP/ADIME Disertai Dengan Target Yang Terukur, Evaluasi Hasil Tatalaksana Dituliskan Dalam Asesmen.)</th>
                                                <th class="text-center">Instruksi Tenaga Kesehatan (Termasuk Instruksi Pasca Bedah / Prosedur Ditulis Dengan Rinci Dan Jelas)</th>
                                                <th class="text-center">Verifikasi DPJP</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $no = 0;
                                            foreach ($tk['Rmpcpptd'] as $tkd) : $no++ ?>
                                                <tr>
                                                    <td><?= $tkd['rs_rmpcpptd_tgl_n'] ?> / <?= $tkd['rs_rmpcpptd_jam'] ?></td>
                                                    <td>Profesi</td>
                                                    <td><?= $tkd['rs_rmpcpptd_kode'] ?>: <?= $tkd['rs_rmpcpptd_ket'] ?></td>
                                                    <td><?= $tkd['rs_rmpcpptd_inst'] ?></td>
                                                    <td>Verifikasi DPJP</td>
                                                    <td>
                                                        <?php
                                                        if ($MethodForm1 != "updateData") {
                                                        ?>
                                                            <button class="btn bg-gradient-warning m-1" title="Ubah Data CPPT Detail Pasien" data-target="#modalAddCpptD" data-toggle="modal" onclick="resetForm('AddCpptD'); addFill('rs_rmpcpptd_rmpcppt', ''); addFill('rs_rmpcpptd_id_ex', '<?= $tkd['rs_rmpcpptd_id_ex'] ?>'); addFill('rs_rmpcpptd_tgl', '<?= $tkd['rs_rmpcpptd_tgl'] ?>'); addFill('rs_rmpcpptd_jam', '<?= $tkd['rs_rmpcpptd_jam'] ?>'); addFill('rs_rmpcpptd_kode', '<?= $tkd['rs_rmpcpptd_kode'] ?>'); addFill('rs_rmpcpptd_ket', '<?= $tkd['rs_rmpcpptd_ket'] ?>'); addFill('rs_rmpcpptd_inst', '<?= $tkd['rs_rmpcpptd_inst'] ?>');"><i class="fas fa-pen"></i></button>

                                                            <button class="btn bg-gradient-danger m-1" title="Hapus Data CPPT Detail Pasien" onclick="callOther('Menghapus Data CPPT Detail Pasien', '/<?= $BasePage ?>/deleteDataCpptD/<?= $tkd['rs_rmpcpptd_id_ex'] ?>')">
                                                                <i class='fas fa-trash'></i></button>
                                                        <?php
                                                        }
                                                        ?>

                                                    </td>
                                                </tr>
                                            <?php endforeach ?>
                                        </tbody>

                                    </table>
                                </td>

                            </tr>
                        <?php endforeach ?>
                    </tbody>
                </table>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
</div>
<?= $this->include('Rmpcppt/modalAddCpptD'); ?>
<script>
    function addFill(idComp = '', fill = '') {
        document.getElementById(idComp).value = fill;
    }
</script>
<script>
    $(document).ready(function() {
        $('#datatableKirana1').DataTable({
            "order": [
                [0, "asc"]
            ],
            pageLength: 10,
            responsive: true,
            fixedHeader: true,
            keys: true,
            columnDefs: [{
                    responsivePriority: 1,
                    target: 0
                },
                {
                    responsivePriority: 10001,
                    target: 4
                },
                {
                    responsivePriority: 2,
                    target: -2
                }
            ]
        });
        $('#datatableKirana2').DataTable({
            "order": [
                [0, "asc"]
            ],
            pageLength: 20,
            responsive: true,
            fixedHeader: true,
            keys: true
        });
    });
</script>

<?= $this->endSection(); ?>