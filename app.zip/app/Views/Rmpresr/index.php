<hr>
<form style="display: none;" id="<?= $IdForm ?>resR" class="form-valide" action="/<?= $BasePage ?>/<?= $MethodForm ?>"
    enctype="multipart/form-data" method="POST">
    <h4 class="text-center">Form <?= $PageTitle ?></h4>

    <table id="" class="dtK table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>

                <th>Nama Obat</th>
                <th>Jumlah</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody id="dynamic_field">
            <tr>
                <td>
                    <input type="hidden" id="rs_rmpresrb_rmb0" name="rs_rmpresrb_rmb[]" required class="form-control"
                        placeholder="Pilih Nama Obat">
                    <input type="text" id="rs_rmpresrb_rmbnm0" name="rs_rmpresrb_rmbnm[]" required class="form-control"
                        disabled>
                </td>
                <td>
                    <input type="text" id="rs_rmpresrb_jmlh" name="rs_rmpresrb_jmlh[]" required class="form-control">
                </td>
                <td>
                    <button type="button" class='btn bg-gradient-primary mx-1' data-target="#modalViewRmRmb"
                        data-toggle="modal"
                        onclick="showRmRmb( 'rs_rmpresrb_rmbnm0', 'rs_rmpresrb_rmb0', '<?= $rs_rmpres_rmr ?>')"><i
                            class="fas fa-file-archive"></i>
                        AMBIL OBAT</button>

                    <button type="button" class='btn bg-gradient-success mx-1' id="addResR" name="addResR"><i
                            class="fas fa-plus"></i></button>


                </td>
            </tr>
        </tbody>
    </table>
    <script>
    $(document).ready(function() {
        var i = 1;
        $('#addResR').click(function() {
            i++;
            $('#dynamic_field').append('<tr id="row' + i +
                '"><td><input type="hidden" id="rs_rmpresrb_rmb' + i +
                '" name="rs_rmpresrb_rmb[]" placeholder="Pilih Nama Obat" class="form-control" required /><input type="text" id="rs_rmpresrb_rmbnm' +
                i +
                '" name="rs_rmpresrb_rmbnm[]" class="form-control" required /></td><td><input type="text" id="rs_rmpresrb_jmlh' +
                i +
                '" name="rs_rmpresrb_jmlh[]" class="form-control" required  /></td><td><button type="button" class="btn bg-gradient-primary mx-1 " data-target="#modalViewRmRmb" data-toggle = "modal" onclick ="showRmRmb( \'rs_rmpresrb_rmbnm' +
                i + '\', \'rs_rmpresrb_rmb' + i +
                '\', \'<?= $rs_rmpres_rmr ?>\')" > <i class = "fas fa-file-archive"> </i> AMBIL OBAT </button><button type="button" name="remove" id="' +
                i +
                '" class="btn btn-danger btn_remove"><i class = "fas fa-times"> </i></button></td></tr>'
            );
        });

        $(document).on('click', '.btn_remove', function() {
            var button_id = $(this).attr("id");
            $('#row' + button_id + '').remove();
        });

    });
    </script>
    <div class="form-group row">
        <label for="rs_rmpresr_rmap" class="col-sm-2 col-form-label">Aturan Pakai</label>
        <div class="col-sm-10">
            <select name="rs_rmpresr_rmap" id="rs_rmpresr_rmap" class="form-control"
                onfocus="ambilDataSelect('rs_rmpresr_rmap', '/rmap/getAllForSelect/', 'Pilih Salah Satu Pilihan', toRemove=[], removeMessage=[], '')">
                <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
            </select>
        </div>
    </div>

    <div class="form-group row">
        <label for="rs_rmpresr_rmkr" class="col-sm-2 col-form-label">Kemasan Racikan</label>
        <div class="col-sm-10">
            <select name="rs_rmpresr_rmkr" id="rs_rmpresr_rmkr" class="form-control"
                onfocus="ambilDataSelect('rs_rmpresr_rmkr', '/rmkr/getAllForSelect/', 'Pilih Salah Satu Pilihan', toRemove=[], removeMessage=[], '')">
                <option hidden value="0">PILIH SALAH SATU PILIHAN</option>
            </select>
        </div>
    </div>

    <div class="form-group row">
        <label for="rs_rmpresr_jmlh" class="col-sm-2 col-form-label">Jumlah</label>
        <div class="col-sm-10">
            <input type="number" name="rs_rmpresr_jmlh" id="rs_rmpresr_jmlh" class="form-control" required>
        </div>
    </div>



    <div class="form-group row">
        <label for="rs_rmpresr_p" class="col-sm-2 col-form-label">Petunjuk Racikan</label>
        <div class="col-sm-10">
            <textarea name="rs_rmpresr_p" id="rs_rmpresr_p" class="form-control" rows="10" cols="2"></textarea>
        </div>
    </div>

    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-primary"><?= $ButtonMethod ?></button>
            <button type="button" class="btn bg-gradient-danger"
                onclick="closeForm('<?= $IdForm ?>resR', '<?= $IdForm ?>'); ">BATAL</button>
        </div>
    </div>
    <hr>
</form>

<div>
    <h4 class="text-center">Daftar <?= $PageTitle ?></h4>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="button" class="btn bg-gradient-success" style="float: right;"
                onclick="showForm('<?= $IdForm ?>resR', 'block');"><i class="fas fa-plus"></i>
                Tambah</button>
        </div>
    </div>
    <table id="dtK<?= $IdForm ?>" class="table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Obat</th>
                <th>Aturan Pakai</th>
                <th>Kemasan Racikan</th>
                <th>Jumlah</th>
                <th>Petunjuk Racikan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Rmpresr as $tk) : $no++ ?>
            <tr>
                <td><?= $no ?></td>
                <td>
                    <?php $no1 = 0;
                        foreach ($tk['Rmpresrb'] as $tkd) : $no1++ ?>
                    Obat: <?= $tkd['rs_rmb_nm'] ?><br>
                    Jumlah : <?= $tkd['rs_rmpresrb_jmlh'] ?><br><br>
                    <?php endforeach ?>
                </td>
                <td><?= $tk['rs_rmap_nm'] ?></td>
                <td><?= $tk['rs_rmkr_nm'] ?></td>
                <td><?= $tk['rs_rmpresr_jmlh'] ?></td>
                <td><?= $tk['rs_rmpresr_p'] ?></td>
                <td>
                    <button class="btn bg-gradient-danger" title="Hapus Data E-Resep Racik"
                        onclick="callOther('Menghapus Data E-Resep Racik', '/rmpresr/deleteData/<?= $tk['rs_rmpresr_id'] ?>')">
                        <i class='fas fa-trash'></i></button>

                </td>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
    <br>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="button" class="btn bg-gradient-danger" style="float: right;" onclick="clearBox()"><i
                    class="fas fa-times"></i>
                Tutup</button>
        </div>
    </div>
</div>
<?= $this->include('Rmpmskd/modalViewRmb'); ?>
<script>
$(function() {
    $(document).ready(function() {
        var <?= $IdForm ?>resR = $('#<?= $IdForm ?>resR');
        <?= $IdForm ?>resR.submit(function(e) {
            showAnimated();
            $('#<?= $IdForm ?>resR :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');

            e.preventDefault();
            $.ajax({
                type: <?= $IdForm ?>resR.attr('method'),
                url: <?= $IdForm ?>resR.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    hideAnimated();
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            loadChildFormRes('rmpresr',
                                '<?= $rs_rmpresr_rmpres ?>',
                                '<?= $rs_rmpres_kd ?>',
                                '<?= $rs_rmpres_tgl ?>',
                                '<?= $rs_rmpres_jam ?>',
                                '<?= $rs_rmpres_rmr ?>');
                        });
                    } else {
                        hideAnimated();
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    hideAnimated();
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>

<script>
$(document).ready(function() {
    $('#dtK<?= $IdForm ?>').DataTable({
        "order": [
            [0, "asc"]
        ],
        pageLength: 10,
        responsive: true,
        fixedHeader: false,
        keys: true,
        columnDefs: [{
                responsivePriority: 1,
                target: 0
            },
            {
                responsivePriority: 10001,
                target: 4
            },
            {
                responsivePriority: 2,
                target: -2
            }
        ]
    });
});
</script>