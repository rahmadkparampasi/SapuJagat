<div class="card card-primary" style="
    <?php
    if ($MethodForm1 == "updateData") {
        echo 'display: flex;';
    } else {
        echo 'display: none;';
    } ?>" id="<?= $IdForm ?>card">
    <div class="card-header">
        <h3 class="card-title">Form Tambah <?= $PageTitle ?></h3>
    </div>
    <!-- /.card-header -->
    <!-- form start -->
    <form method="POST" class="form-valide" action="/<?= $BasePage ?>/<?= $MethodForm ?>" id="<?= $IdForm ?>" enctype="multipart/form-data">
        <?php
        if ($MethodForm1 == "updateData") {
            echo "<input type='hidden' name='rs_rmtdk_id_ex' id='rs_rmtdk_id_ex'>";
        }
        ?>
        <div class="card-body">
            <div class="form-group">
                <label for="rs_rmtdk_nm">Nama Tindakan</label>
                <input type="text" class="form-control" id="rs_rmtdk_nm" name="rs_rmtdk_nm" required>
            </div>

            <div class="form-group">
                <label for="rs_rmtdk_rmktdk">Kategori Tindakan</label>
                <select name="rs_rmtdk_rmktdk" id="rs_rmtdk_rmktdk" class="form-control">
                    <option hidden value="">PILIH SALAH SATU PILIHAN</option>
                    <option value="TdkDipilih">Tidak Ada Tindakan</option>
                    <?php foreach ($Rmktdk as $tk) : ?>
                        <option value="<?= $tk['rs_rmktdk_id_ex'] ?>"><?= $tk['rs_rmktdk_nm'] ?></option>
                    <?php endforeach ?>

                </select>
            </div>

            <div class="form-group">
                <label for="rs_rmtdk_h">Tarif Tindakan</label>
                <input type="text" class="form-control" id="rs_rmtdk_h" name="rs_rmtdk_h" required>
            </div>
        </div>
        <!-- /.card-body -->

        <div class="card-footer">
            <button type="submit" class="btn bg-gradient-primary"><?= $ButtonMethod ?></button>
            <?php
            $MethodForm = substr($MethodForm, 0, 10);
            if ($MethodForm == "updateData") {
            ?>
                <a href="/<?= $BasePage ?>" class='btn bg-gradient-danger' aria-pressed="true">BATAL</a>
            <?php
            } else {
            ?>
                <button type="button" class="btn bg-gradient-danger" onclick="closeForm('<?= $IdForm ?>card', '<?= $IdForm ?>')">BATAL</button>

            <?php
            }
            ?>
        </div>
    </form>
</div>