 <form class="form-horizontal form-valide" style="display: none;" method="POST" action="/<?= $BasePage ?>/<?= $MethodForm ?>Ppsbb" id="tabPpsbb">
     <h4 class="text-center">Form Berkas Berkala</h4>

     <div class="form-group row">
         <label for="rs_ppsbb_pkbb" class="col-sm-2 col-form-label">Nama Berkas</label>
         <div class="col-sm-10">
             <select name="rs_ppsbb_pkbb" id="rs_ppsbb_pkbb" class="form-control" required>
                 <option hidden>PILIH SALAH SATU BERKAS</option>
                 <?php foreach ($Psbb as $tk) : ?>
                     <option value="<?= $tk['rs_psbb_id_ex'] ?>"><?= $tk['rs_psbb_nm'] ?></option>
                 <?php endforeach ?>
             </select>
         </div>
     </div>

     <div class="form-group row">
         <label for="rs_ppsbb_nmr" class="col-sm-2 col-form-label">Nomor Berkas</label>
         <div class="col-sm-10">
             <input type="text" class="form-control text-uppercase" id="rs_ppsbb_nmr" name="rs_ppsbb_nmr" required>
         </div>
     </div>

     <div class="form-group row">
         <label for="rs_ppsbb_tgl_s" class="col-sm-2 col-form-label">Tanggal Mulai</label>
         <div class="col-sm-10">
             <input type="date" class="form-control" id="rs_ppsbb_tgl_s" name="rs_ppsbb_tgl_s" required>
         </div>
     </div>

     <div class="form-group row">
         <label for="rs_ppsbb_tgl_e" class="col-sm-2 col-form-label">Tanggal Selesai</label>
         <div class="col-sm-10">
             <input type="date" class="form-control" id="rs_ppsbb_tgl_e" name="rs_ppsbb_tgl_e" required>
         </div>
     </div>

     <div class="form-group row">
         <label for="rs_ppsbb_ket" class="col-sm-2 col-form-label">Keterangan</label>
         <div class="col-sm-10">
             <textarea name="rs_ppsbb_ket" id="rs_ppsbb_ket" cols="30" rows="2" class="form-control"></textarea>
         </div>
     </div>

     <div class="form-group row">
         <label for="rs_ppsbb_fl" class="col-sm-2 col-form-label">Berkas</label>
         <div class="col-sm-10">
             <input type="file" class="form-control" id="rs_ppsbb_fl" name="rs_ppsbb_fl" accept=".pdf">
         </div>
     </div>


     <div class="form-group row">
         <div class="offset-sm-2 col-sm-10">
             <button type="submit" class="btn bg-gradient-primary">SIMPAN</button>
             <button type="button" class="btn bg-gradient-danger" onclick="closeForm('tabPpsbb', 'tabPpsbb')">BATAL</button>
         </div>
     </div>
     <hr>
 </form>
 <div>
     <h4 class="text-center">Daftar Data Berkas Berkala</h4>
     <div class="form-group row">
         <div class="offset-sm-2 col-sm-10">
             <button type="submit" class="btn bg-gradient-success" style="float: right;" onclick="showForm('tabPpsbb', 'block')"><i class="fas fa-plus"></i>
                 Tambah</button>
         </div>
     </div>
     <table id="dtK3" class="table responsive table-bordered table-striped" width="100%">
         <thead>
             <tr>
                 <th>No</th>
                 <th>Nama Berkas</th>
                 <th>Nomor Berkas</th>
                 <th>Tanggal Mulai Berlaku</th>
                 <th>Akhir Masa Berlaku</th>
                 <th>Keterangan</th>
                 <th>Aksi</th>
             </tr>
         </thead>
         <tbody>
             <?php $no = 0;
                foreach ($Ppsbb as $tk) : $no++ ?>
                 <tr>
                     <td><?= $no ?></td>
                     <td><?= $tk['rs_psbb_nm'] ?></td>
                     <td><?= $tk['rs_ppsbb_nmr'] ?>
                         <button class="btn bg-gradient-primary" title="Lihat Berkas Berkala Nomor <?= $tk['rs_ppsbb_nmr'] ?>" onclick="changeUrl('/uploads/<?= $tk['rs_ppsbb_fl'] ?>', 'Lihat Dokumen Berkas Berkala Nomor <?= $tk['rs_ppsbb_nmr'] ?>')" data-target="#modalViewPdf" data-toggle="modal"><i class='fas fa-eye'></i></button>
                     </td>
                     <td><?= $tk['rs_ppsbb_tgl_s'] ?></td>
                     <td><?= $tk['rs_ppsbb_tgl_e'] ?></td>
                     <td><?= $tk['rs_ppsbb_ket'] ?></td>
                     <td>
                         <button class="btn bg-gradient-danger" title="Hapus Data Berkas Berkala Pegawai" onclick="callOther('Menghapus Berkas Berkala <?= $tk['rs_psbb_nm'] ?> Dalam Data Berkas Berkala Pegawai <?= $Ppeg['rs_ppeg_nm'] ?>', '<?= $BasePage ?>/deleteDataPpsbb/<?= $tk['rs_ppsbb_id'] ?>/<?= $tk['rs_ppsbb_fl'] ?>')">
                             <i class='fas fa-trash'></i>
                         </button>
                     </td>
                 </tr>
             <?php endforeach ?>
         </tbody>
         <tfoot>
             <tr>
                 <th>No</th>
                 <th>Nama Berkas</th>
                 <th>Nomor Berkas</th>
                 <th>Tanggal Mulai Berlaku</th>
                 <th>Akhir Masa Berlaku</th>
                 <th>Keterangan</th>
                 <th>Aksi</th>
             </tr>
         </tfoot>
     </table>
 </div>

 <script>
     $(function() {
         $(document).ready(function() {
             var tabPpsbb = $('#tabPpsbb');
             tabPpsbb.submit(function(e) {
                 showAnimated();
                 $('#tabPpsbb :input').prop("disabled", false);
                 $(this).attr('disabled', 'disabled');

                 e.preventDefault();
                 $.ajax({
                     type: tabPpsbb.attr('method'),
                     url: tabPpsbb.attr('action'),
                     enctype: 'multipart/form-data',
                     data: new FormData(this),
                     contentType: false,
                     processData: false,
                     dataType: 'json',
                     success: function(data) {
                         hideAnimated();
                         if (data.response == "success") {
                             swal.fire({
                                 title: "Terima Kasih",
                                 text: data.message,
                                 icon: data.response
                             }).then(function() {
                                 window.location = '<?= $UrlForm ?>';
                             });
                         } else {
                             hideAnimated();
                             swal.fire({
                                 title: "Tidak Dapat Melanjutkan Proses",
                                 text: data.message,
                                 icon: data.response
                             });
                         }
                     },
                     error: function(xhr) {
                         hideAnimated();
                         console.log(xhr);
                         swal.fire({
                             title: "Tidak Dapat Melanjutkan Proses",
                             text: xhr.responseJSON.message,
                             icon: "error"
                         });
                     }
                 });
             });
         });
     });
 </script>

 <script>
     $(document).ready(function() {
         $('#dtK3').DataTable({
             "order": [
                 [0, "asc"]
             ],
             pageLength: 10,
             responsive: true,
             fixedHeader: true,
             keys: true,
             columnDefs: [{
                     responsivePriority: 1,
                     target: 0
                 },
                 {
                     responsivePriority: 10001,
                     target: 4
                 },
                 {
                     responsivePriority: 2,
                     target: -2
                 }
             ]
         });
     });
 </script>