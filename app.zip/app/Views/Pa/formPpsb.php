<form class="form-horizontal form-valide" style="display: none;" method="POST" action="/<?= $BasePage ?>/<?= $MethodForm ?>Ppsb" id="tabPpsb">
    <h4 class="text-center">Form Status Berkas</h4>

    <div class="form-group row">
        <label for="rs_ppsb_pkb" class="col-sm-2 col-form-label">Nama Berkas</label>
        <div class="col-sm-10">
            <select name="rs_ppsb_pkb" id="rs_ppsb_pkb" class="form-control" required>
                <option hidden>PILIH SALAH SATU BERKAS</option>
                <?php foreach ($Psb as $tk) : ?>
                    <option value="<?= $tk['rs_psb_id_ex'] ?>"><?= $tk['rs_psb_nm'] ?></option>
                <?php endforeach ?>
            </select>
        </div>
    </div>


    <div class="form-group row">
        <label for="rs_ppsb_nmr" class="col-sm-2 col-form-label">Nomor</label>
        <div class="col-sm-10">
            <input type="text" class="form-control text-uppercase" id="rs_ppsb_nmr" name="rs_ppsb_nmr" required>
        </div>
    </div>

    <div class="form-group row">
        <label for="rs_ppsb_ket" class="col-sm-2 col-form-label">Keterangan</label>
        <div class="col-sm-10">
            <textarea name="rs_ppsb_ket" id="rs_ppsb_ket" cols="30" rows="2" class="form-control"></textarea>
        </div>
    </div>

    <div class="form-group row">
        <label for="rs_ppsb_fl" class="col-sm-2 col-form-label">Berkas</label>
        <div class="col-sm-10">
            <input type="file" class="form-control" id="rs_ppsb_fl" name="rs_ppsb_fl" accept=".pdf">
        </div>
    </div>


    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-primary">SIMPAN</button>
            <button type="button" class="btn bg-gradient-danger" onclick="closeForm('tabPpsb', 'tabPpsb')">BATAL</button>
        </div>
    </div>
    <hr>
</form>
<div>
    <h4 class="text-center">Daftar Data Status Berkas</h4>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-success" style="float: right;" onclick="showForm('tabPpsb', 'block')"><i class="fas fa-plus"></i>
                Tambah</button>
        </div>
    </div>
    <table id="dtK4" class="table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Berkas</th>
                <th>Nomor Berkas</th>
                <th>Keterangan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Ppsb as $tk) : $no++ ?>
                <tr>
                    <td><?= $no ?></td>
                    <td>
                        <?= $tk['rs_psb_nm'] ?>
                    </td>
                    <td>
                        <?= $tk['rs_ppsb_nmr'] ?>
                        <button class="btn bg-gradient-primary" title="Lihat Status Berkas Nomor <?= $tk['rs_ppsb_nmr'] ?>" onclick="changeUrl('/uploads/<?= $tk['rs_ppsb_fl'] ?>', 'Lihat Dokumen Berkas Berkala Nomor <?= $tk['rs_ppsb_nmr'] ?>')" data-target="#modalViewPdf" data-toggle="modal"><i class='fas fa-eye'></i></button>
                    </td>
                    <td><?= $tk['rs_ppsb_ket'] ?></td>
                    <td>
                        <button class="btn bg-gradient-danger" title="Hapus Status Berkas Pegawai" onclick="callOther('Menghapus Status Berkas <?= $tk['rs_psb_nm'] ?> Dalam Data Status Berkas Pegawai <?= $Ppeg['rs_ppeg_nm'] ?>', '<?= $BasePage ?>/deleteDataPpsb/<?= $tk['rs_ppsb_id'] ?>/<?= $tk['rs_ppsb_fl'] ?>')">
                            <i class='fas fa-trash'></i>
                        </button>
                    </td>
                </tr>
            <?php endforeach ?>
        </tbody>
        <tfoot>
            <tr>
                <th>No</th>
                <th>Nama Berkas</th>
                <th>Nomor Berkas</th>
                <th>Keterangan</th>
                <th>Aksi</th>
            </tr>
        </tfoot>
    </table>
</div>

<script>
    $(function() {
        $(document).ready(function() {
            var tabPpsb = $('#tabPpsb');
            tabPpsb.submit(function(e) {
                showAnimated();
                $('#tabPpsb :input').prop("disabled", false);
                $(this).attr('disabled', 'disabled');

                e.preventDefault();
                $.ajax({
                    type: tabPpsb.attr('method'),
                    url: tabPpsb.attr('action'),
                    enctype: 'multipart/form-data',
                    data: new FormData(this),
                    contentType: false,
                    processData: false,
                    dataType: 'json',
                    success: function(data) {
                        hideAnimated();
                        if (data.response == "success") {
                            swal.fire({
                                title: "Terima Kasih",
                                text: data.message,
                                icon: data.response
                            }).then(function() {
                                window.location = '<?= $UrlForm ?>';
                            });
                        } else {
                            hideAnimated();
                            swal.fire({
                                title: "Tidak Dapat Melanjutkan Proses",
                                text: data.message,
                                icon: data.response
                            });
                        }
                    },
                    error: function(xhr) {
                        hideAnimated();
                        console.log(xhr);
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: xhr.responseJSON.message,
                            icon: "error"
                        });
                    }
                });
            });
        });
    });
</script>

<script>
    $(document).ready(function() {
        $('#dtK4').DataTable({
            "order": [
                [0, "asc"]
            ],
            pageLength: 10,
            responsive: true,
            fixedHeader: true,
            keys: true,
            columnDefs: [{
                    responsivePriority: 1,
                    target: 0
                },
                {
                    responsivePriority: 10001,
                    target: 4
                },
                {
                    responsivePriority: 2,
                    target: -2
                }
            ]
        });
    });
</script>