<div class="modal fade bd-example-modal-lg" id="modalUbahPeg" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <form id="changePpeg" method="POST" action="/<?= $BasePage; ?>/changePpeg/<?= $rs_ppeg_id_ex; ?>" enctype="multipart/form-data">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabelPdf">FORM UBAH DATA PEGAWAI </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <div class="form-group row">
                        <label class="col-sm-12 col-form-label">Nama Depan</label>
                        <div class="col-sm-12">
                            <div class="input-group m-b">
                                <input type="text" name="rs_ppeg_nmd" id="rs_ppeg_nmd" class="form-control" value="<?= $PpegU['rs_ppeg_nmd'] ?>">
                            </div>
                        </div>
                    </div>

                    <div class=" form-group row">
                        <label class="col-sm-12 col-form-label">Nama</label>
                        <div class="col-sm-12">
                            <div class="input-group m-b">
                                <input type="text" name="rs_ppeg_nm" id="rs_ppeg_nm" class="form-control" required value="<?= $PpegU['rs_ppeg_nm'] ?>">
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-12 col-form-label">Nama Belakang</label>
                        <div class="col-sm-12">
                            <div class="input-group m-b">
                                <input type="text" name="rs_ppeg_nmb" id="rs_ppeg_nmb" class="form-control" value="<?= $PpegU['rs_ppeg_nmb'] ?>">
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-12 col-form-label">NIP</label>
                        <div class="col-sm-12">
                            <div class="input-group m-b">
                                <input type="number" name="rs_ppeg_nip" id="rs_ppeg_nip" class="form-control" value="<?= $PpegU['rs_ppeg_nip'] ?>">
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-12 col-form-label">Tempat Lahir</label>
                        <div class="col-sm-12">
                            <div class="input-group m-b">
                                <input type="text" name="rs_ppeg_tmpt_lhr" id="rs_ppeg_tmpt_lhr" class="form-control" required value="<?= $PpegU['rs_ppeg_tmpt_lhr'] ?>">
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-12 col-form-label">Tanggal Lahir</label>
                        <div class="col-sm-12">
                            <div class="input-group m-b">
                                <input type="date" class="form-control" id="rs_ppeg_tgl_lhr" name="rs_ppeg_tgl_lhr" required value="<?= $PpegU['rs_ppeg_tgl_lhr'] ?>">
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-12 col-form-label">NIK</label>
                        <div class="col-sm-12">
                            <div class="input-group m-b">
                                <input type="number" name="rs_ppeg_nik" id="rs_ppeg_nik" class="form-control" required value="<?= $PpegU['rs_ppeg_nik'] ?>">
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-12 col-form-label">Alamat</label>
                        <div class="col-sm-12">
                            <div class="input-group m-b">
                                <input type="text" name="rs_ppeg_alt" id="rs_ppeg_alt" class="form-control" required value="<?= $PpegU['rs_ppeg_alt'] ?>">
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="rs_ppeg_jk">Jenis Kelamin</label>
                        <select name="rs_ppeg_jk" id="rs_ppeg_jk" class="form-control" required value="<?= $PpegU['rs_ppeg_jk'] ?>">
                            <option hidden>PILIH SALAH SATU PILIHAN</option>
                            <option value="L">LAKI-LAKI</option>
                            <option value="P">PEREMPUAN</option>
                        </select>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-12 col-form-label">NPWP</label>
                        <div class="col-sm-12">
                            <div class="input-group m-b">
                                <input type="text" name="rs_ppeg_npwp" id="rs_ppeg_npwp" class="form-control" value="<?= $PpegU['rs_ppeg_npwp'] ?>">
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-12 col-form-label">BPJS</label>
                        <div class="col-sm-12">
                            <div class="input-group m-b">
                                <input type="text" name="rs_ppeg_bpjs" id="rs_ppeg_bpjs" class="form-control" value="<?= $PpegU['rs_ppeg_bpjs'] ?>">
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-12 col-form-label">Nomor Handphone</label>
                        <div class="col-sm-12">
                            <div class="input-group m-b">
                                <input type="text" name="rs_ppeg_hp" id="rs_ppeg_hp" class="form-control" required value="<?= $PpegU['rs_ppeg_hp'] ?>">
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-12 col-form-label">Email</label>
                        <div class="col-sm-12">
                            <div class="input-group m-b">
                                <input type="email" name="rs_ppeg_mail" id="rs_ppeg_mail" class="form-control" required value="<?= $PpegU['rs_ppeg_mail'] ?>">
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-12 col-form-label">Agama</label>
                        <select name="rs_ppeg_rmag" id="rs_ppeg_rmag" class="form-control" required>
                            <option hidden>PILIH SALAH SATU PILIHAN</option>
                            <?php foreach ($Rmag as $tk): ?>
                                <option <?php if($Ppeg['rs_ppeg_rmag']==$tk['rs_rmag_id_ex']) echo "selected"; ?> value="<?= $tk['rs_rmag_id_ex'] ?>"><?= $tk['rs_rmag_nm'] ?></option>
                            <?php endforeach ?>
                            
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-12 col-form-label">Status Pernikahan</label>
                        <select name="rs_ppeg_rmsts" id="rs_ppeg_rmsts" class="form-control" required>
                            <option hidden>PILIH SALAH SATU PILIHAN</option>
                            <?php foreach ($Rmsts as $tk): ?>
                                <option <?php if($Ppeg['rs_ppeg_rmsts']==$tk['rs_rmsts_id_ex']) echo "selected"; ?> value="<?= $tk['rs_rmsts_id_ex'] ?>"><?= $tk['rs_rmsts_nm'] ?></option>
                            <?php endforeach ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-12 col-form-label">Golongan Darah</label>
                        <select name="rs_ppeg_rmgd" id="rs_ppeg_rmgd" class="form-control" required>
                            <option hidden>PILIH SALAH SATU PILIHAN</option>
                            <?php foreach ($Rmgd as $tk): ?>
                                <option <?php if($Ppeg['rs_ppeg_rmgd']==$tk['rs_rmgd_id_ex']) echo "selected"; ?> value="<?= $tk['rs_rmgd_id_ex'] ?>"><?= $tk['rs_rmgd_nm'] ?></option>
                            <?php endforeach ?>
                        </select>
                    </div>

                    <div class="modal-footer">
                        <div class="item form-group">
                            <button type="submit" class="btn btn-success">SIMPAN</button>
                            <button type="button" class="btn btn-danger" data-dismiss="modal">BATAL</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
    $(function() {
        $(document).ready(function() {
            var changePpeg = $('#changePpeg');
            changePpeg.submit(function(e) {
                showAnimated();
                $('#changePpeg :input').prop("disabled", false);
                $(this).attr('disabled', 'disabled');

                e.preventDefault();
                $.ajax({
                    type: changePpeg.attr('method'),
                    url: changePpeg.attr('action'),
                    enctype: 'multipart/form-data',
                    data: new FormData(this),
                    contentType: false,
                    processData: false,
                    dataType: 'json',
                    success: function(data) {
                        hideAnimated();
                        if (data.response == "success") {
                            swal.fire({
                                title: "Terima Kasih",
                                text: data.message,
                                icon: data.response
                            }).then(function() {
                                window.location = '/<?= $UrlForm ?>';
                            });
                        } else {
                            hideAnimated();
                            swal.fire({
                                title: "Tidak Dapat Melanjutkan Proses",
                                text: data.message,
                                icon: data.response
                            });
                        }
                    },
                    error: function(xhr) {
                        hideAnimated();
                        console.log(xhr);
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: xhr.responseJSON.message,
                            icon: "error"
                        });
                    }
                });
            });
        });
    });
</script>