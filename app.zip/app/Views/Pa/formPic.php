<div class="modal fade" id="modalFotoPegawai" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form id="ubahFotoPegawai" method="POST" action="/pa/changeFotoPeg/<?= $Ppeg['rs_ppeg_id_ex']; ?>"
            enctype="multipart/form-data">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">FORM UBAH FOTO PEGAWAI</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="text-input" class=" form-control-label">Foto Pegawai</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <div class="input-group mb-3">
                                <input type="file" class="form-control" name="rs_ppeg_pic" id="rs_ppeg_pic"
                                    accept=".jpg, .png, .jpeg, .bmp" onchange="readURL(this, 'rs_ppeg_pic_pre')">
                                <div class="input-group-append">
                                    <div class="input-group-text">
                                        <span class="fas fa-camera"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <small>Foto Yang Diunggah Tidak Dapat Lebih Dari 500Kb Dan Format Yang Didukung Hanya .jpg,
                            .png, .jpeg, .bmp</small>
                    </div>

                    <div class='form-group row justify-content-center'>
                        <div class='input-group-prepend bg-transparent'>
                            <span class='input-group-text bg-transparent border-0 img' id='basic-addon1'>
                                <img src='/images/user.png' class='rounded img-thumbnail' id="rs_ppeg_pic_pre"
                                    style='width: 250px; height: 250px; object-fit: cover;' />
                            </span>
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <div class="item form-group">
                        <button type="submit" class="btn btn-success">SIMPAN</button>
                        <button type="button" class="btn btn-primary" data-dismiss="modal">BATAL</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<script>
$(function() {
    $(document).ready(function() {
        var ubahFotoPegawai = $('#ubahFotoPegawai');
        ubahFotoPegawai.submit(function(e) {
            $('#ubahFotoPegawai :input').prop("disabled", false);
            $(this).attr('disabled', 'disabled');

            e.preventDefault();
            e.stopImmediatePropagation();
            $.ajax({
                type: ubahFotoPegawai.attr('method'),
                url: ubahFotoPegawai.attr('action'),
                enctype: 'multipart/form-data',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function(data) {
                    if (data.response == "success") {
                        swal.fire({
                            title: "Terima Kasih",
                            text: data.message,
                            icon: data.response
                        }).then(function() {
                            window.location = '/pa';
                        });
                    } else {
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: data.message,
                            icon: data.response
                        });
                    }
                },
                error: function(xhr) {
                    console.log(xhr);
                    swal.fire({
                        title: "Tidak Dapat Melanjutkan Proses",
                        text: xhr.responseJSON.message,
                        icon: "error"
                    });
                }
            });
        });
    });
});
</script>