<form class="form-horizontal form-valide" style="display: none;" method="POST" action="/<?= $BasePage ?>/<?= $MethodForm ?>Pps" id="tabPps">
    <h4 class="text-center">Form Data Sertifikat</h4>

    <div class="form-group row">
        <label for="rs_pps_jns" class="col-sm-2 col-form-label">Jenis Sertifikat</label>
        <div class="col-sm-10">
            <select name="rs_pps_jns" id="rs_pps_jns" class="form-control" required>
                <option hidden>PILIH SALAH SATU JENIS</option>
                <option value="PH">PENGHARGAAN</option>
                <option value="SM">SEMINAR</option>
                <option value="LM">LOMBA</option>
                <option value="MG">MAGANG</option>
                <option value="KH">KEAHLIAN</option>
                <option value="PR">PROFESI</option>
            </select>
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_pps_thn" class="col-sm-2 col-form-label">Tahun</label>
        <div class="col-sm-10">
            <input type="number" class="form-control" id="rs_pps_thn" name="rs_pps_thn" required>
        </div>
    </div>

    <div class="form-group row">
        <label for="rs_pps_inst" class="col-sm-2 col-form-label">Instansi / Lembaga</label>
        <div class="col-sm-10">
            <input type="text" class="form-control text-uppercase" id="rs_pps_inst" name="rs_pps_inst" required>
        </div>
    </div>

    <div class="form-group row">
        <label for="rs_pps_nmr" class="col-sm-2 col-form-label">Nomor (Jika Ada)</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="rs_pps_nmr" name="rs_pps_nmr">
        </div>
    </div>

    <div class="form-group row">
        <label for="rs_pps_ket" class="col-sm-2 col-form-label">Keterangan (Jika Ada)</label>
        <div class="col-sm-10">
            <textarea name="rs_pps_ket" id="rs_pps_ket" cols="30" rows="2" class="form-control"></textarea>
        </div>
    </div>


    <div class="form-group row">
        <label for="rs_pps_fl" class="col-sm-2 col-form-label">Berkas Sertifikat</label>
        <div class="col-sm-10">
            <input type="file" class="form-control" id="rs_pps_fl" name="rs_pps_fl" accept=".pdf">
        </div>
    </div>


    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-primary">SIMPAN</button>
            <button type="button" class="btn bg-gradient-danger" onclick="closeForm('tabPps', 'tabPps')">BATAL</button>
        </div>
    </div>
    <hr>
</form>
<div>
    <h4 class="text-center">Daftar Data Sertifikat</h4>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-success" style="float: right;" onclick="showForm('tabPps', 'block')"><i class="fas fa-plus"></i>
                Tambah</button>
        </div>
    </div>
    <table id="dtK2" class="table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Jenis Sertifikat</th>
                <th>Tahun</th>
                <th>Instansi</th>
                <th>Nomor</th>
                <th>Keterangan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Pps as $tk) : $no++ ?>
                <tr>
                    <td><?= $no ?></td>
                    <td>
                        <?php if ($tk['rs_pps_jns'] == "PH") {
                            echo "PENGHARGAAN";
                        } else if ($tk['rs_pps_jns'] == "SM") {
                            echo "SEMINAR";
                        } else if ($tk['rs_pps_jns'] == "LM") {
                            echo "LOMBA";
                        } else if ($tk['rs_pps_jns'] == "MG") {
                            echo "MAGANG";
                        } else if ($tk['rs_pps_jns'] == "KH") {
                            echo "KEAHLIAN";
                        } else if ($tk['rs_pps_jns'] == "PR") {
                            echo "PROFESI";
                        } ?>
                    </td>
                    <td><?= $tk['rs_pps_thn'] ?></td>
                    <td><?= $tk['rs_pps_inst'] ?></td>
                    <td>
                        <?= $tk['rs_pps_nmr'] ?>
                        <button class="btn bg-gradient-primary" title="Lihat Dokumen Sertifikat <?= $tk['rs_pps_jns'] ?>" onclick="changeUrl('/uploads/<?= $tk['rs_pps_fl'] ?>', 'Lihat Dokumen Sertifikat <?= $tk['rs_pps_jns'] ?>')" data-target="#modalViewPdf" data-toggle="modal"><i class='fas fa-eye'></i></button>
                    </td>
                    <td><?= $tk['rs_pps_ket'] ?></td>
                    <td>
                        <button class="btn bg-gradient-danger" title="Hapus Data Sertifikat Pegawai" onclick="callOther('Menghapus Data Sertifikat Dalam Data Sertifikat Pegawai <?= $Ppeg['rs_ppeg_nm'] ?>', '<?= $BasePage ?>/deleteDataPps/<?= $tk['rs_pps_id_ex'] ?>/<?= $tk['rs_pps_fl'] ?>')">
                            <i class='fas fa-trash'></i>
                        </button>
                    </td>
                </tr>
            <?php endforeach ?>
        </tbody>
        <tfoot>
            <tr>
                <th>No</th>
                <th>Jenis Sertifikat</th>
                <th>Tahun</th>
                <th>Instansi</th>
                <th>Nomor</th>
                <th>Keterangan</th>
                <th>Aksi</th>
            </tr>
        </tfoot>
    </table>
</div>

<script>
    $(function() {
        $(document).ready(function() {
            var tabPps = $('#tabPps');
            tabPps.submit(function(e) {
                showAnimated();
                $('#tabPps :input').prop("disabled", false);
                $(this).attr('disabled', 'disabled');

                e.preventDefault();
                $.ajax({
                    type: tabPps.attr('method'),
                    url: tabPps.attr('action'),
                    enctype: 'multipart/form-data',
                    data: new FormData(this),
                    contentType: false,
                    processData: false,
                    dataType: 'json',
                    success: function(data) {
                        hideAnimated();
                        if (data.response == "success") {
                            swal.fire({
                                title: "Terima Kasih",
                                text: data.message,
                                icon: data.response
                            }).then(function() {
                                window.location = '/<?= $UrlForm ?>';
                            });
                        } else {
                            hideAnimated();
                            swal.fire({
                                title: "Tidak Dapat Melanjutkan Proses",
                                text: data.message,
                                icon: data.response
                            });
                        }
                    },
                    error: function(xhr) {
                        hideAnimated();
                        console.log(xhr);
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: xhr.responseJSON.message,
                            icon: "error"
                        });
                    }
                });
            });
        });
    });
</script>

<script>
    $(document).ready(function() {
        $('#dtK2').DataTable({
            "order": [
                [0, "asc"]
            ],
            pageLength: 10,
            responsive: true,
            fixedHeader: true,
            keys: true,
            columnDefs: [{
                    responsivePriority: 1,
                    target: 0
                },
                {
                    responsivePriority: 10001,
                    target: 4
                },
                {
                    responsivePriority: 2,
                    target: -2
                }
            ]
        });
    });
</script>