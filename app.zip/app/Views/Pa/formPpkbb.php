<form class="form-horizontal form-valide" style="display: none;" method="POST" action="/<?= $BasePage ?>/<?= $MethodForm ?>Ppkbb" id="tabPpkbb">
    <h4 class="text-center">Form Kategori Berkas Berkala</h4>

    <div class="form-group row">
        <label for="rs_ppkbb_pkbb" class="col-sm-2 col-form-label">Nama Berkas</label>
        <div class="col-sm-10">
            <select name="rs_ppkbb_pkbb" id="rs_ppkbb_pkbb" class="form-control" required>
                <option hidden>PILIH SALAH SATU BERKAS</option>
                <?php foreach ($Pkbb as $tk) : ?>
                    <option value="<?= $tk['rs_pkbb_id_ex'] ?>"><?= $tk['rs_pkbb_nm'] ?></option>
                <?php endforeach ?>
            </select>
        </div>
    </div>


    <div class="form-group row">
        <label for="rs_ppkbb_nmr" class="col-sm-2 col-form-label">Nomor Berkas</label>
        <div class="col-sm-10">
            <input type="text" class="form-control text-uppercase" id="rs_ppkbb_nmr" name="rs_ppkbb_nmr" required>
        </div>
    </div>


    <div class="form-group row">
        <label for="rs_ppkbb_tgl_s" class="col-sm-2 col-form-label">Tanggal Mulai</label>
        <div class="col-sm-10">
            <input type="date" class="form-control" id="rs_ppkbb_tgl_s" name="rs_ppkbb_tgl_s" required>
        </div>
    </div>


    <div class="form-group row">
        <label for="rs_ppkbb_tgl_e" class="col-sm-2 col-form-label">Tanggal Selesai</label>
        <div class="col-sm-10">
            <input type="date" class="form-control" id="rs_ppkbb_tgl_e" name="rs_ppkbb_tgl_e" required>
        </div>
    </div>


    <div class="form-group row">
        <label for="rs_ppkbb_ket" class="col-sm-2 col-form-label">Keterangan</label>
        <div class="col-sm-10">
            <textarea name="rs_ppkbb_ket" id="rs_ppkbb_ket" cols="30" rows="2" class="form-control"></textarea>
        </div>
    </div>


    <div class="form-group row">
        <label for="rs_ppkbb_fl" class="col-sm-2 col-form-label">Berkas</label>
        <div class="col-sm-10">
            <input type="file" class="form-control" id="rs_ppkbb_fl" name="rs_ppkbb_fl" accept=".pdf">
        </div>
    </div>


    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-primary">SIMPAN</button>
            <button type="button" class="btn bg-gradient-danger" onclick="closeForm('tabPpkbb', 'tabPpkbb')">BATAL</button>
        </div>
    </div>
    <hr>
</form>
<div>
    <h4 class="text-center">Daftar Data Kategori Berkas Berkala</h4>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-success" style="float: right;" onclick="showForm('tabPpkbb', 'block')"><i class="fas fa-plus"></i>
                Tambah</button>
        </div>
    </div>
    <table id="dtK5" class="table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Berkas</th>
                <th>Nomor Berkas</th>
                <th>Tanggal Mulai Berlaku</th>
                <th>Akhir Masa Berlaku</th>
                <th>Keterangan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Ppkbb as $tk) : $no++ ?>
                <tr>
                    <td><?= $no ?></td>
                    <td>
                        <?= $tk['rs_pkbb_nm'] ?>
                    </td>
                    <td>
                        <?= $tk['rs_ppkbb_nmr'] ?>
                        <button class="btn bg-gradient-primary" title="Lihat Berkas Kategori Berkas Berkala Nomor <?= $tk['rs_ppkbb_nmr'] ?>" onclick="changeUrl('/uploads/<?= $tk['rs_ppkbb_fl'] ?>', 'Lihat Dokumen Kategori Berkas Berkala Nomor <?= $tk['rs_ppkbb_nmr'] ?>')" data-target="#modalViewPdf" data-toggle="modal"><i class='fas fa-eye'></i></button>
                    </td>
                    <td><?= $tk['rs_ppkbb_tgl_s'] ?></td>
                    <td><?= $tk['rs_ppkbb_tgl_e'] ?></td>
                    <td><?= $tk['rs_ppkbb_ket'] ?></td>
                    <td>
                        <button class="btn bg-gradient-danger" title="Hapus Kategori Berkas Berkala" onclick="callOther('Menghapus Kategori Berkas Berkala <?= $tk['rs_pkbb_nm'] ?> Dalam Data Kategori Berkas Berkala <?= $Ppeg['rs_ppeg_nm'] ?>', '<?= $BasePage ?>/deleteDataPpkbb/<?= $tk['rs_ppkbb_id'] ?>/<?= $tk['rs_ppkbb_fl'] ?>')">
                            <i class='fas fa-trash'></i>
                        </button>
                    </td>
                </tr>
            <?php endforeach ?>
        </tbody>
        <tfoot>
            <tr>
                <th>No</th>
                <th>Nama Berkas</th>
                <th>Nomor Berkas</th>
                <th>Tanggal Mulai Berlaku</th>
                <th>Akhir Masa Berlaku</th>
                <th>Keterangan</th>
                <th>Aksi</th>
            </tr>
        </tfoot>
    </table>
</div>

<script>
    $(function() {
        $(document).ready(function() {
            var tabPpkbb = $('#tabPpkbb');
            tabPpkbb.submit(function(e) {
                showAnimated();
                $('#tabPpkbb :input').prop("disabled", false);
                $(this).attr('disabled', 'disabled');

                e.preventDefault();
                $.ajax({
                    type: tabPpkbb.attr('method'),
                    url: tabPpkbb.attr('action'),
                    enctype: 'multipart/form-data',
                    data: new FormData(this),
                    contentType: false,
                    processData: false,
                    dataType: 'json',
                    success: function(data) {
                        hideAnimated();
                        if (data.response == "success") {
                            swal.fire({
                                title: "Terima Kasih",
                                text: data.message,
                                icon: data.response
                            }).then(function() {
                                window.location = '<?= $UrlForm ?>';
                            });
                        } else {
                            hideAnimated();
                            swal.fire({
                                title: "Tidak Dapat Melanjutkan Proses",
                                text: data.message,
                                icon: data.response
                            });
                        }
                    },
                    error: function(xhr) {
                        hideAnimated();
                        console.log(xhr);
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: xhr.responseJSON.message,
                            icon: "error"
                        });
                    }
                });
            });
        });
    });
</script>

<script>
    $(document).ready(function() {
        $('#dtK5').DataTable({
            "order": [
                [0, "asc"]
            ],
            pageLength: 10,
            responsive: true,
            fixedHeader: true,
            keys: true,
            columnDefs: [{
                    responsivePriority: 1,
                    target: 0
                },
                {
                    responsivePriority: 10001,
                    target: 4
                },
                {
                    responsivePriority: 2,
                    target: -2
                }
            ]
        });
    });
</script>