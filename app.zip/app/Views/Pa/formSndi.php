<div class="modal fade" id="modalSndiPeg" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form id="changePaPass" method="POST" action="/<?= $UrlForm ?>/changePaPass/<?= $Ppeg['rs_pa_id_ex']; ?>" enctype="multipart/form-data">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">FORM UBAH KATA SANDI</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <input type="hidden" name="rs_pa_id_ex" id="rs_pa_id_ex" value="<?= $Ppeg['rs_pa_id_ex']; ?>">

                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="text-input" class=" form-control-label">Kata Sandi Lama</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <div class="input-group mb-3">
                                <input type="password" class="form-control" placeholder="Kata Sandi" name="password_old" id="password_old">
                                <div class="input-group-append">
                                    <div class="input-group-text">
                                        <span class="fas fa-lock"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="text-input" class=" form-control-label">Kata Sandi Baru</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <div class="input-group mb-3">
                                <input type="password" class="form-control" placeholder="Kata Sandi" name="password_new" id="password_new">
                                <div class="input-group-append">
                                    <div class="input-group-text">
                                        <span class="fas fa-lock"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-3">
                            <label for="text-input" class=" form-control-label">Ulangi Kata Sandi Baru</label>
                        </div>
                        <div class="col-12 col-md-9">
                            <div class="input-group mb-3">
                                <input type="password" class="form-control" placeholder="Masukan Ulang Kata sandi" name="password_new1" id="password_new1">
                                <div class="input-group-append">
                                    <div class="input-group-text">
                                        <span class="fas fa-lock"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <small>Kata Sandi Hanya Boleh Diisikan Oleh Huruf Dan Angka. Tidak Boleh Menggunakan Simbol (.,'"
                        dll) serta Spasi</small>

                    <div class="row form-group">
                        <div class="col-12 col-md-9">
                            <input type="checkbox" onclick="showPassword()"> Tampilkan Sandi
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <div class="item form-group">
                        <button type="submit" class="btn btn-success">SIMPAN</button>
                        <button type="button" class="btn btn-primary" data-dismiss="modal">BATAL</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<script>
    function showPassword() {
        var password_old = document.getElementById("password_old");
        var password_new = document.getElementById("password_new");
        var password_new1 = document.getElementById("password_new1");
        if (password_old.type === "password") {
            password_old.type = "text";
            password_new.type = "text";
            password_new1.type = "text";
        } else {
            password_old.type = "password";
            password_new.type = "password";
            password_new1.type = "password";
        }
    }
</script>

<script>
    $(function() {
        $(document).ready(function() {
            var changePaPass = $('#changePaPass');
            changePaPass.submit(function(e) {
                showAnimated();
                $('#changePaPass :input').prop("disabled", false);
                $(this).attr('disabled', 'disabled');

                e.preventDefault();
                $.ajax({
                    type: changePaPass.attr('method'),
                    url: changePaPass.attr('action'),
                    enctype: 'multipart/form-data',
                    data: new FormData(this),
                    contentType: false,
                    processData: false,
                    dataType: 'json',
                    success: function(data) {
                        hideAnimated();
                        if (data.response == "success") {
                            swal.fire({
                                title: "Terima Kasih",
                                text: data.message,
                                icon: data.response
                            }).then(function() {
                                window.location = '/<?= $UrlForm ?>';
                            });
                        } else {
                            hideAnimated();
                            swal.fire({
                                title: "Tidak Dapat Melanjutkan Proses",
                                text: data.message,
                                icon: data.response
                            });
                        }
                    },
                    error: function(xhr) {
                        hideAnimated();
                        console.log(xhr);
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: xhr.responseJSON.message,
                            icon: "error"
                        });
                    }
                });
            });
        });
    });
</script>