<?= $this->extend('Templates/template'); ?>

<?= $this->section('content'); ?>
<!-- /.row -->

<div class="row">
    <div class="col-md-3">
        <!-- Profile Image -->
        <div class="card card-primary card-outline">
            <div class="card-body box-profile">
                <div class="text-center">
                    <img class="profile-user-img img-fluid img-circle" <?php
                                                                        if ($Ppeg['rs_ppeg_pic'] == "") {
                                                                        ?> src="/images/user.png" alt="User profile picture" <?php
                                                                                                                            } else {
                                                                                                                                ?> src="/uploads/<?= $Ppeg['rs_ppeg_pic']; ?>" alt="User profile picture" <?php
                                                                                                                                                                                                        }
                                                                                                                                                                                                            ?>>

                    <br>
                    <button class="btn bg-gradient-primary" title="Ubah Foto Profil" data-toggle="modal" data-target="#modalFotoPegawai"><i class="fas fa-camera"></i></button>
                </div>

                <h3 class="profile-username text-center"><?= $Ppeg['rs_ppeg_nm'] ?></h3>

                <p class="text-muted text-center">
                    <?php if ($Ppeg['rs_ppeg_nip'] != '') {
                        echo "NIP." . $Ppeg['rs_ppeg_nip'];
                    }
                    ?>



                <ul class="list-group list-group-unbordered mb-3">
                    <li class="list-group-item">
                        <c>NIK</c> <b class="float-right"><?= $Ppeg['rs_ppeg_nik'] ?></b>
                    </li>

                    <li class="list-group-item">
                        <c>NPWP</c> <b class="float-right"><?= $Ppeg['rs_ppeg_npwp'] ?></b>
                    </li>

                    <li class="list-group-item">
                        <c>BPJS</c> <b class="float-right"><?= $Ppeg['rs_ppeg_bpjs'] ?></b>
                    </li>

                    <li class="list-group-item">
                        <c>Tempat Lahir</c> <b class="float-right"><?= $Ppeg['rs_ppeg_tmpt_lhr'] ?></b>
                    </li>

                    <li class="list-group-item">
                        <c>Tanggal Lahir</c> <b class="float-right"><?= $Ppeg['rs_ppeg_tgl_lhr'] ?></b>
                    </li>

                    <li class="list-group-item">
                        <c>Status Pegawai</c> <b class="float-right"><?= $Ppeg['rs_psp_nm'] ?></b>
                    </li>

                    <li class="list-group-item">
                        <c>Kategori Pegawai</c> <b class="float-right"><?= $Ppeg['rs_pkp_nm'] ?></b>
                    </li>

                    <li class="list-group-item">
                        <c>Nama Pengguna</c> <b class="float-right"><?= $Ppeg['rs_pa_un'] ?></b>
                    </li>
                </ul>

                <button class="btn btn-primary btn-block" title="Ubah Nama Pengguna" data-target="#modalUbahPeg" data-toggle="modal"><i class="fa fa-pencil-alt"></i> Lengkapi Biodata</button>

                <button class="btn btn-success btn-block" title="Ubah Username Dan Password" data-target="#modalSndiPeg" data-toggle="modal"><i class="fa fa-key"></i> Ubah Kata Sandi</button>



            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->



        <!-- About Me Box -->
        <div class="card card-primary">
            <div class="card-header">
                <h3 class="card-title">Biodata</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <strong><i class="fas fa-heart mr-1"></i> Agama</strong>
                <p class="text-muted">

                    <?= $Ppeg['rs_rmag_nm'] ?>
                </p>
                <hr>

                <strong><i class="fas fa-mobile-alt mr-1"></i> No Handphone</strong>
                <p class="text-muted">
                    <?= $Ppeg['rs_ppeg_hp'] ?>
                </p>
                <hr>

                <strong><i class="fas fa-envelope-open-text mr-1"></i> Email</strong>
                <p class="text-muted">
                    <?= $Ppeg['rs_ppeg_mail'] ?>
                </p>
                <hr>

                <strong><i class="fas fa-map-marker-alt mr-1"></i> Alamat</strong>
                <p class="text-muted">
                    <?= $Ppeg['rs_ppeg_alt'] ?>
                </p>
                <hr>

                <strong><i class="fas fa-home mr-1"></i> Status Pernikahan</strong>
                <p class="text-muted">
                    <?= $Ppeg['rs_rmsts_nm'] ?>
                </p>
                <hr>

                <strong><i class="fas fa-tint mr-1"></i> Golongan Darah</strong>
                <p class="text-muted">
                    <?= $Ppeg['rs_rmgd_nm'] ?>
                </p>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>



    <!-- /.col -->
    <div class="col-md-9">
        <div class="card">
            <div class="card-header p-2">
                <ul class="nav nav-pills">
                    <li class="nav-item"><a class="nav-link active" href="#TabPpi" data-toggle="tab">Pendidikan</a>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="#TabPps" data-toggle="tab">Sertifikat</a>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="#TabPpsbb" data-toggle="tab">Berkas Berkala</a>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="#TabPpsb" data-toggle="tab">Status Berkas</a>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="#TabPpkbb" data-toggle="tab">Kategori Berkas Berkala</a>
                    </li>
                </ul>
            </div><!-- /.card-header -->



            <div class="card-body">
                <div class="tab-content">
                    <div class="active tab-pane" id="TabPpi">
                        <?= $this->include('Pa/formPpi'); ?>
                    </div>

                    <div class="tab-pane" id="TabPps">
                        <?= $this->include('Pa/formPps'); ?>
                    </div>

                    <div class="tab-pane" id="TabPpsbb">
                        <?= $this->include('Pa/formPpsbb'); ?>
                    </div>

                    <div class="tab-pane" id="TabPpsb">
                        <?= $this->include('Pa/formPpsb'); ?>
                    </div>

                    <div class="tab-pane" id="TabPpkbb">
                        <?= $this->include('Pa/formPpkbb'); ?>
                    </div>
                    <!-- /.tab-pane -->


                </div>
                <!-- /.tab-content -->

            </div><!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
    <!-- /.col -->
</div>
<!-- /.row -->

<?= $this->include('Templates/modalViewPdf'); ?>
<?= $this->include('Pa/formPpeg'); ?>
<?= $this->include('Pa/formPic'); ?>
<?= $this->include('Pa/formSndi'); ?>


<?= $this->endSection(); ?>