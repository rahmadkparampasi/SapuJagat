<form class="form-horizontal form-valide" style="display: none;" method="POST" action="/<?= $BasePage ?>/<?= $MethodForm ?>Ppi" id="tabPpi">
    <h4 class="text-center">Form Data Pendidikan</h4>
    <div class="form-group row">
        <label for="rs_ppi_t" class="col-sm-2 col-form-label">Tingkatan Pendidikan</label>
        <div class="col-sm-10">
            <select name="rs_ppi_t" id="rs_ppi_t" class="form-control" required>
                <option hidden>PILIH SALAH SATU TINGKATAN</option>
                <option value="SD">SD/MI</option>
                <option value="SMP">SMP/MTs</option>
                <option value="SMA">SMA/SMK/Ma</option>
                <option value="D1">Diploma 1</option>
                <option value="D2">Diploma 2</option>
                <option value="D3">Diploma 3</option>
                <option value="D4">Diploma 4</option>
                <option value="S1">Sarjana</option>
                <option value="S2">Magister</option>
                <option value="S3">Doktor</option>
                <option value="Pr">Pendidikan Profesi</option>
                <option value="Vk">Pendidikan Vokasi</option>
                <option value="Pk">Pendidikan Khusus</option>
            </select>
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_ppi_msk" class="col-sm-2 col-form-label">Tahun Masuk</label>
        <div class="col-sm-10">
            <input type="number" class="form-control" id="rs_ppi_msk" name="rs_ppi_msk" required>
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_ppi_klr" class="col-sm-2 col-form-label">Tahun Selesai</label>
        <div class="col-sm-10">
            <input type="number" class="form-control" id="rs_ppi_klr" name="rs_ppi_klr" required>
        </div>
    </div>
    <div class="form-group row">
        <label for="rs_ppi_inst" class="col-sm-2 col-form-label">Instansi / Lembaga</label>
        <div class="col-sm-10">
            <input type="text" class="form-control text-uppercase" id="rs_ppi_inst" name="rs_ppi_inst" required>
        </div>
    </div>

    <div class="form-group row">
        <label for="rs_ppi_nmr" class="col-sm-2 col-form-label">Nomor Ijazah</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="rs_ppi_nmr" name="rs_ppi_nmr" required>
        </div>
    </div>

    <div class="form-group row">
        <label for="rs_ppi_ket" class="col-sm-2 col-form-label">Keterangan (Jika Ada)</label>
        <div class="col-sm-10">
            <textarea name="rs_ppi_ket" id="rs_ppi_ket" cols="30" rows="2" class="form-control"></textarea>
        </div>
    </div>


    <div class="form-group row">
        <label for="rs_ppi_fl" class="col-sm-2 col-form-label">Berkas Ijazah</label>
        <div class="col-sm-10">
            <input type="file" class="form-control" id="rs_ppi_fl" name="rs_ppi_fl" accept=".pdf">
        </div>
    </div>


    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-primary">SIMPAN</button>
            <button type="button" class="btn bg-gradient-danger" onclick="closeForm('tabPpi', 'tabPpi')">BATAL</button>
        </div>
    </div>
    <hr>
</form>
<div>
    <h4 class="text-center">Daftar Data Pendidikan</h4>
    <div class="form-group row">
        <div class="offset-sm-2 col-sm-10">
            <button type="submit" class="btn bg-gradient-success" style="float: right;" onclick="showForm('tabPpi', 'block')"><i class="fas fa-plus"></i>
                Tambah</button>
        </div>
    </div>
    <table id="dtK1" class="table responsive table-bordered table-striped" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Tingkatan</th>
                <th>Waktu Pendidikan</th>
                <th>Instansi</th>
                <th>Nomor Ijazah</th>
                <th>Keterangan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0;
            foreach ($Ppi as $tk) : $no++ ?>
                <tr>
                    <td><?= $no ?></td>
                    <td>
                        <?php if ($tk['rs_ppi_t'] == "SD") {
                            echo "SD/MI";
                        } else if ($tk['rs_ppi_t'] == "SMP") {
                            echo "SMP/MTs";
                        } else if ($tk['rs_ppi_t'] == "SMA") {
                            echo "SMA/SMK/Ma";
                        } else if ($tk['rs_ppi_t'] == "D1") {
                            echo "Diploma 1";
                        } else if ($tk['rs_ppi_t'] == "D2") {
                            echo "Diploma 2";
                        } else if ($tk['rs_ppi_t'] == "D3") {
                            echo "Diploma 3";
                        } else if ($tk['rs_ppi_t'] == "D4") {
                            echo "Diploma 4";
                        } else if ($tk['rs_ppi_t'] == "S1") {
                            echo "Sarjana";
                        } else if ($tk['rs_ppi_t'] == "S2") {
                            echo "Magister";
                        } else if ($tk['rs_ppi_t'] == "S3") {
                            echo "Doktor";
                        } else if ($tk['rs_ppi_t'] == "Pr") {
                            echo "Pendidikan Profesi";
                        } else if ($tk['rs_ppi_t'] == "Vk") {
                            echo "Pendidikan Vokasi";
                        } else if ($tk['rs_ppi_t'] == "Pk") {
                            echo "Pendidikan Khusus";
                        }   ?>
                    </td>
                    <td><?= $tk['rs_ppi_msk'] ?> - <?= $tk['rs_ppi_klr'] ?></td>
                    <td><?= $tk['rs_ppi_inst'] ?></td>
                    <td>
                        <?= $tk['rs_ppi_nmr'] ?>
                        <button class="btn bg-gradient-primary" title="Lihat Dokumen Ijazah <?= $tk['rs_ppi_t'] ?>" onclick="changeUrl('/uploads/<?= $tk['rs_ppi_fl'] ?>', 'Lihat Dokumen Ijazah <?= $tk['rs_ppi_t'] ?>')" data-target="#modalViewPdf" data-toggle="modal"><i class='fas fa-eye'></i></button>
                    </td>
                    <td><?= $tk['rs_ppi_ket'] ?></td>
                    <td>
                        <button class="btn bg-gradient-danger" title="Hapus Data Ijazah Pegawai" onclick="callOther('Menghapus Data Ijazah Dalam Data Pendidikan Pegawai <?= $Ppeg['rs_ppeg_nm'] ?>', '<?= $BasePage ?>/deleteDataPpi/<?= $tk['rs_ppi_id_ex'] ?>/<?= $tk['rs_ppi_fl'] ?>')">
                            <i class='fas fa-trash'></i>
                        </button>
                    </td>
                </tr>
            <?php endforeach ?>
        </tbody>
        <tfoot>
            <tr>
                <th>No</th>
                <th>Tingkatan</th>
                <th>Waktu Pendidikan</th>
                <th>Instansi</th>
                <th>Nomor Ijazah</th>
                <th>Keterangan</th>
                <th>Aksi</th>
            </tr>
        </tfoot>
    </table>
</div>

<script>
    $(function() {
        $(document).ready(function() {
            var tabPpi = $('#tabPpi');
            tabPpi.submit(function(e) {
                showAnimated();
                $('#tabPpi :input').prop("disabled", false);
                $(this).attr('disabled', 'disabled');

                e.preventDefault();
                $.ajax({
                    type: tabPpi.attr('method'),
                    url: tabPpi.attr('action'),
                    enctype: 'multipart/form-data',
                    data: new FormData(this),
                    contentType: false,
                    processData: false,
                    dataType: 'json',
                    success: function(data) {
                        hideAnimated();
                        if (data.response == "success") {
                            swal.fire({
                                title: "Terima Kasih",
                                text: data.message,
                                icon: data.response
                            }).then(function() {
                                window.location = '<?= $UrlForm ?>';
                            });
                        } else {
                            hideAnimated();
                            swal.fire({
                                title: "Tidak Dapat Melanjutkan Proses",
                                text: data.message,
                                icon: data.response
                            });
                        }
                    },
                    error: function(xhr) {
                        hideAnimated();
                        console.log(xhr);
                        swal.fire({
                            title: "Tidak Dapat Melanjutkan Proses",
                            text: xhr.responseJSON.message,
                            icon: "error"
                        });
                    }
                });
            });
        });
    });
</script>

<script>
    $(document).ready(function() {
        $('#dtK1').DataTable({
            "order": [
                [0, "asc"]
            ],
            pageLength: 10,
            responsive: true,
            fixedHeader: true,
            keys: true,
            columnDefs: [{
                    responsivePriority: 1,
                    target: 0
                },
                {
                    responsivePriority: 10001,
                    target: 4
                },
                {
                    responsivePriority: 2,
                    target: -2
                }
            ]
        });
    });
</script>