<?= $this->extend('Templates/template'); ?>

<?= $this->section('content'); ?>
<!-- /.row -->

<div class="row">
    <!-- Area Chart -->
    <div class="col-xl-12 col-lg-12">
        <?= $this->include('Rmkr/addData'); ?>
        <div class="callout callout-info">
            <h5><i class="fas fa-info"></i> Catatan:</h5>
            <ol>
                <li>Tombol : <button class="btn bg-gradient-success"><i class="fa fa-check"></i></button> Mengartikan
                    Bahwa Jenis Kemasan Racikan Aktif, Untuk Menonaktifkan Tekan Tombol Tersebut</li>
                <br>
                <li>Tombol : <button class="btn bg-gradient-danger"><i class="fa fa-ban"></i></button> Mengartikan Bahwa
                    Jenis Kemasan Racikan Tidak Aktif, Untuk Mengaktifkan Tekan Tombol Tersebut</li>
            </ol>
        </div>
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Daftar <?= $PageTitle ?></h3>
                <div class="card-tools">
                    <?php
                    if ($MethodForm1 != "updateData") {
                    ?>
                    <button class='btn bg-gradient-success' role="button" aria-pressed="true" style="float: right;"
                        onclick="showForm('<?= $IdForm ?>card')"><i class="fas fa-plus"></i>
                        TAMBAH</button>
                    <?php
                    }
                    ?>
                    <a href="/rmref" class='btn bg-gradient-danger mx-1' style="float: right;"><i
                            class="fas fa-reply"></i>
                        KEMBALI</a>
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table id="datatableKirana" class="table responsive table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Deskripsi</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 0;
                        foreach ($Rmkr as $tk) : $no++ ?>
                        <tr>
                            <td><?= $no ?></td>
                            <td><?= $tk['rs_rmkr_nm'] ?></td>
                            <td>
                                <?php
                                    if ($tk['rs_rmkr_sts'] == "1") {
                                    ?>
                                <button class="btn bg-gradient-success" title="Jenis Kemasan Racikan Aktif"
                                    onclick="callOther('Menonaktifkan <?= $tk['rs_rmkr_nm'] ?> Dalam Data Jenis Kemasan Racikan', '<?= $BasePage ?>/block/<?= $tk['rs_rmkr_id_ex'] ?>')">
                                    <i class='fas fa-check'></i>
                                </button>
                                <?php
                                    } else {
                                    ?>
                                <button class="btn bg-gradient-danger" title="Jenis Kemasan Racikan Tidak Aktif"
                                    onclick="callOther('Mengaktifkan <?= $tk['rs_rmkr_nm'] ?> Dalam Data Jenis Kemasan Racikan', '<?= $BasePage ?>/unblock/<?= $tk['rs_rmkr_id_ex'] ?>')">
                                    <i class='fas fa-ban'></i>
                                </button>
                                <?php
                                    }
                                    ?>
                            </td>
                            <td>
                                <button class="btn bg-gradient-warning" title="Ubah Jenis Kemasan Racikan"
                                    onclick="callHref('<?= $BasePage ?>/editData/<?= $tk['rs_rmkr_id_ex'] ?>')">
                                    <i class='fas fa-pen'></i>
                                </button>

                                <button class="btn bg-gradient-danger" title="Hapus Jenis Kemasan Racikan"
                                    onclick="callOther('Menghapus <?= $tk['rs_rmkr_nm'] ?> Dalam Jenis Kemasan Racikan', '<?= $BasePage ?>/deleteData/<?= $tk['rs_rmkr_id_ex'] ?>')">
                                    <i class='fas fa-trash'></i>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th>No</th>
                            <th>Deskripsi</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </tfoot>
                </table>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
</div>

<script>
$(document).ready(function() {
    $('#datatableKirana').DataTable({
        "order": [
            [0, "asc"]
        ],
        pageLength: 100,
        responsive: true,
        fixedHeader: true,
        keys: true,
        columnDefs: [{
                responsivePriority: 1,
                target: 0
            },
            {
                responsivePriority: 10001,
                target: 4
            },
            {
                responsivePriority: 2,
                target: -2
            }
        ]
    });
});
</script>

<?= $this->endSection(); ?>