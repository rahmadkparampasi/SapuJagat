<?= $this->extend('Templates/template'); ?>

<?= $this->section('content'); ?>
<div class="row">
    <!-- Small boxes (Stat box) -->
    <div class="col-lg-3 col-6">
        <!-- small box -->
        <div class="small-box bg-info">
            <div class="inner">
            <h3><?= $Rmpp ?></h3>

            <h4>Pasien</h4>
            </div>
            <div class="icon">
            <i class="fa fa-user-injured"></i>
            </div>
            
        </div>
        <!-- /.info-box -->
    </div>
    <!-- Small boxes (Stat box) -->
    <div class="col-lg-3 col-6">
        <!-- small box -->
        <div class="small-box bg-success">
            <div class="inner">
            <h3><?= $Ppeg ?></h3>

            <h4>Pegawai</h4>
            </div>
            <div class="icon">
            <i class="fa fa-user-tie"></i>
            </div>
            
        </div>
        <!-- /.info-box -->
    </div>

</div>
<!-- /.row -->

<div class="row">
    <!-- Area Chart -->
    <div class="col-xl-12 col-lg-12">
        <div class="card shadow mb-4">
            <!-- Illustrations -->
            <!-- <div class="card shadow mb-4"> -->
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">SELAMAT DATANG</h6>
            </div>
            <div class="card-body">
                <div class="text-center">
                    <img class="img-fluid px-3 px-sm-4 mt-3 mb-4" style="width: 18rem;" src="/favicon.png" alt="">
                </div>
                <p style="text-align: center;"><strong>SISTEM INFORMASI MANAJEMEN RUMAH SAKIT</strong></p>
                <p style="text-align: center;"><strong>RUMAH SAKIT UMUM DAERAH KOLONODALE</strong></p>
            </div>
            <!-- </div> -->
        </div>
    </div>
</div>

<?= $this->endSection(); ?>