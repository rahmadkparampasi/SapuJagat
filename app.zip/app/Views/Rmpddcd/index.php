<?= $this->extend('Templates/template'); ?>

<?= $this->section('content'); ?>
<!-- /.row -->

<?= $this->include('Rmpddcd/addData'); ?>
<div class="row">
    <!-- Area Chart -->
    <div class="col-xl-12 col-lg-12">


        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Daftar <?= $PageTitle ?> A.N. Pasien <?= $Rmpmsk['rs_rmpp_nm'] ?>, Tgl Masuk IGD <?= $Rmpmsk['rs_rmpmsk_tgl'] ?>, Jam Masuk IGD <?= $Rmpmsk['rs_rmpmsk_jam'] ?>, No. RM : <?= $Rmpmsk['rs_rmpp_rm'] ?></h3>
                <div class="card-tools">
                    <?php
                    $MethodForm = substr($MethodForm, 0, 10);
                    if ($MethodForm != "updateData") {
                    ?>
                        <button class='btn bg-gradient-success' role="button" aria-pressed="true" style="float: right;" onclick="showForm('<?= $IdForm ?>', 'block')"><i class="fas fa-plus"></i>
                            TAMBAH</button>
                    <?php
                    }
                    ?>

                    <a href="/rmpmsk" class='btn bg-gradient-danger mx-1' style="float: right;"><i class="fas fa-reply"></i>
                        KEMBALI</a>
                    <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
                    <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table id="datatableKirana1" class="table responsive table-bordered table-striped w-100">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Tanggal Dan Jam Pemeriksaan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 0;
                        foreach ($Rmpddcd as $tk) : $no++ ?>
                            <tr>
                                <td><?= $no ?></td>
                                <td>
                                    Tanggal : <?= $tk['rs_rmpddcd_tgl'] ?><br>
                                    Jam : <?= $tk['rs_rmpddcd_tgl'] ?>
                                </td>
                                <td>
                                    <button class="btn bg-gradient-warning" title="Ubah Data Deteksi Dini Coronavirus Disease (Covid-19)" onclick="callHref('/<?= $BasePage ?>/editData/<?= $tk['rs_rmpddcd_id_ex'] ?>')">
                                        <i class='fas fa-pen'></i>
                                    </button>
                                    <?php
                                    $MethodForm = substr($MethodForm, 0, 10);
                                    if ($MethodForm != "updateData") {
                                    ?>
                                        <button class="btn bg-gradient-danger" title="Hapus Data Deteksi Dini Coronavirus Disease (Covid-19)" onclick="callOther('Menghapus Data Deteksi Dini Coronavirus Disease (Covid-19)', '/<?= $BasePage ?>/deleteData/<?= $tk['rs_rmpddcd_id_ex'] ?>')">
                                            <i class='fas fa-trash'></i></button>
                                    <?php
                                    }
                                    ?>
                                </td>
                            </tr>
                        <?php endforeach ?>
                    </tbody>
                </table>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
</div>
<script>
    function addFill(idComp = '', fill = '') {
        document.getElementById(idComp).value = fill;
    }
</script>
<script>
    $(document).ready(function() {
        $('#datatableKirana1').DataTable({
            "order": [
                [0, "asc"]
            ],
            pageLength: 10,
            responsive: true,
            fixedHeader: true,
            keys: true,
            columnDefs: [{
                    responsivePriority: 1,
                    target: 0
                },
                {
                    responsivePriority: 10001,
                    target: 4
                },
                {
                    responsivePriority: 2,
                    target: -2
                }
            ]
        });
    });
</script>

<?= $this->endSection(); ?>