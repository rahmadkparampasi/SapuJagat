<!-- /.card-header -->
<!-- form start -->
<form method="POST" class="form-valide h-250" action="/<?= $BasePage ?>/<?= $MethodForm ?>" id="<?= $IdForm ?>" enctype="multipart/form-data" style="
    <?php
    if ($MethodForm1 == "updateData") {
        echo 'display: block;';
    } else {
        echo 'display: none;';
    } ?>">
    <?php
    if ($MethodForm1 == "updateData") {
        echo "<input type='hidden' name='rs_rmpddcd_id_ex' id='rs_rmpddcd_id_ex'>";
    }
    ?>
    <div class="row">
        <div class="col-md-4">
            <!-- Widget: user widget style 1 -->
            <div class="card card-widget widget-user">
                <!-- Add the bg color to the header using any of the bg-* classes -->
                <div class="widget-user-header bg-info h-auto">
                    <h3 class="widget-user-username"><?= $Rmpmsk['rs_rmpp_nm'] ?></h3>
                    <h5 class="widget-user-desc">No. RM : <?= $Rmpmsk['rs_rmpp_rm'] ?></h5>
                </div>
                <div class="card-footer py-0">
                    <div class="row d-flex justify-content-center py-1">
                        <div class="col-sm-4 border-right">
                            <div class="description-block">
                                <h5 class="description-header">Tanggal Masuk RS</h5>
                                <span class="description-text"><?= $Rmpmsk['rs_rmpmsk_tgl'] ?></span>
                            </div>
                            <!-- /.description-block -->
                        </div>
                        <!-- /.col -->
                        <div class="col-sm-4">
                            <div class="description-block">
                                <h5 class="description-header">Jam Masuk RS</h5>
                                <span class="description-text"><?= $Rmpmsk['rs_rmpmsk_jam'] ?></span>
                            </div>
                            <!-- /.description-block -->
                        </div>
                        <!-- /.col -->
                    </div>
                    <div class="row">
                        <div class="col-sm-4 border-right">
                            <div class="description-block">
                                <h5 class="description-header">Tanggal Lahir</h5>
                                <span class="description-text"><?= $Rmpmsk['rs_rmpp_tgl_lhr'] ?></span>
                            </div>
                            <!-- /.description-block -->
                        </div>
                        <!-- /.col -->
                        <div class="col-sm-4 border-right">
                            <div class="description-block">
                                <h5 class="description-header">Jenis Kelamin</h5>
                                <span class="description-text"><?= $Rmpmsk['rs_rmpp_jk'] ?></span>
                            </div>
                            <!-- /.description-block -->
                        </div>
                        <!-- /.col -->
                        <div class="col-sm-4">
                            <div class="description-block">
                                <h5 class="description-header">Alamat</h5>
                                <span class="description-text"><?= $Rmpmsk['rs_rmpp_alt'] ?></span>
                            </div>
                            <!-- /.description-block -->
                        </div>
                        <!-- /.col -->
                    </div>
                    <!-- /.row -->
                </div>
            </div>
            <!-- /.widget-user -->
        </div>
        <div class="col-md-8">
            <div class="card card-row card-success">
                <div class="card-header">
                    <h3 class="card-title">
                        GEJALA (Waspada Pada Pasien Immunocompromisedd)
                    </h3>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label for="rs_rmpddcd_gdm">Gejala 1</label>
                        <select name="rs_rmpddcd_gdm" id="rs_rmpddcd_gdm" class="form-control">
                            <option hidden>PILIH SALAH SATU PILIHAN</option>
                            <option value="D>38C">Demam > 38°C</option>
                            <option value="RD<14H">Riwayat Demam < 14 hari</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="rs_rmpddcd_gth">Gejala 2</label>
                        <select name="rs_rmpddcd_gth" id="rs_rmpddcd_gth" class="form-control">
                            <option hidden>PILIH SALAH SATU PILIHAN</option>
                            <option value="B">Batuk</option>
                            <option value="P">Pilek</option>
                            <option value="NT">Nyeri Tenggorokan</option>
                            <option value="SN<14H">Sesak Nafas (Pneumonia Ringan) < 14 Hari</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="rs_rmpddcd_gispp">Gejala 3</label>
                        <select name="rs_rmpddcd_gispp" id="rs_rmpddcd_gispp" class="form-control">
                            <option hidden>PILIH SALAH SATU PILIHAN</option>
                            <option value="ISPAB">ISPA Berat</option>
                            <option value="PB<14H">Pneumonia Berat < 14 Hari</option>
                        </select>
                    </div>
                    <br>

                    <div class="row">
                        <div class="col-lg-3">
                            <div class="custom-control custom-radio">
                                <input class="custom-control-input" type="radio" id="rs_rmpddcd_grda" name="rs_rmpddcd_grda" value="RAD">
                                <label for="rs_rmpddcd_grda" class="custom-control-label">Pasien Remaja Atau Dewasa</label>
                            </div>
                        </div>
                        <div class="col-lg-9">
                            <div class="form-group">
                                <select name="rs_rmpddcd_gprad" id="rs_rmpddcd_gprad" class="form-control">
                                    <option hidden>PILIH SALAH SATU PILIHAN</option>
                                    <option value="0">Belum Dipilih</option>
                                    <option value="RR>30x/m">RR>30x/menit, distress pernapasan berat atau saturasi oksigen < 90% </option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <hr>

                    <div class="row">
                        <div class="col-lg-3">
                            <div class="custom-control custom-radio">
                                <input class="custom-control-input" type="radio" id="rs_rmpddcd_grda" name="rs_rmpddcd_grda" value="A">
                                <label for="rs_rmpddcd_grda" class="custom-control-label">Pasien Anak</label>
                            </div>
                        </div>

                        <div class="col-lg-4">
                            <div class="form-group">
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmpapgd_gcs1" name="rs_rmpapgd_gcs" value="38">
                                    <label for="rs_rmpapgd_gcs1" class="custom-control-label">Sianosis Sentral, saturasi < 90%</label>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4">
                            <div class="form-group">
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmpapgd_gcs2" name="rs_rmpapgd_gcs" value="910">
                                    <label for="rs_rmpapgd_gcs2" class="custom-control-label">Distres Pernapasan Berat</label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-3">
                        </div>
                        <div class="col-lg-4">
                            <div class="form-group">
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmpapgd_gcs1" name="rs_rmpapgd_gcs" value="38">
                                    <label for="rs_rmpapgd_gcs1" class="custom-control-label">Tanda Pneumonia Berat</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-5">
                            <div class="form-group">
                                <div class="form-group">
                                    <select name="rs_rmpapgd_dtgr" id="rs_rmpapgd_dtgr" class="form-control">
                                        <option hidden>PILIH SALAH SATU PILIHAN</option>
                                        <option value="0">Belum Dipilih</option>
                                        <option value="RR>30x/m">Ketidakmampuan Menyusui Atau Minum</option>
                                        <option value="RR>30x/m">Letargi</option>
                                        <option value="RR>30x/m">Penurunan Kesadaran Atau Kejang</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-3">
                        </div>
                        <div class="col-lg-4">
                            <div class="form-group">
                                <div class="custom-control custom-radio">
                                    <input class="custom-control-input" type="radio" id="rs_rmpapgd_gcs1" name="rs_rmpapgd_gcs" value="38">
                                    <label for="rs_rmpapgd_gcs1" class="custom-control-label">Tanda Lain Dari Pneumonia</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-5">
                            <div class="form-group">
                                <div class="form-group">
                                    <select name="rs_rmpapgd_dtgr" id="rs_rmpapgd_dtgr" class="form-control">
                                        <option hidden>PILIH SALAH SATU PILIHAN</option>
                                        <option value="0">Belum Dipilih</option>
                                        <option value="RR>30x/m">Takipnean < 2 Bulan ≥ 60x/menit</option>
                                        <option value="RR>30x/m">Takipnean 2-11 Bulan ≥ 50x/menit</option>
                                        <option value="RR>30x/m">Takipnean 1-5 Tahun ≥ 40x/menit</option>
                                        <option value="RR>30x/m">Takipnean > 5 Tahun ≥ 30x/menit</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>




                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card card-row card-secondary">
                <div class="card-header">
                    <h3 class="card-title">
                        FAKTOR RISIKO (Update selalu di situs http://infeksiemerging.kemkes.go.id)
                    </h3>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="rs_rmpadgd_ku">Riwayat Perjalanan Luar Negri</label>
                                <select name="rs_rmpadgd_ku" id="rs_rmpadgd_ku" class="form-control">
                                    <option hidden>PILIH SALAH SATU PILIHAN</option>
                                    <option value="0">Tidak</option>
                                    <option value="1">Iya</option>
                                </select>
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="rs_rmpadgd_fnf">Negara Tujuan</label>
                                <input type="text" class="form-control" id="rs_rmpadgd_fnf" name="rs_rmpadgd_fnf">
                            </div>
                        </div>

                        <div class="col-lg-12">
                            <div class="form-group">
                                <label for="rs_rmpadgd_ku">Riwayat Paparan Kontak Dengan Kasus Konfirmasi Atau Propable COVID-19</label>
                                <select name="rs_rmpadgd_ku" id="rs_rmpadgd_ku" class="form-control">
                                    <option hidden>PILIH SALAH SATU PILIHAN</option>
                                    <option value="0">a. Petugas kesehatan yang memeriksa, merawat, mengantar dan membersihkan ruangan di tempat perawatan kasus tanpa menggunakan APD sesuai standar.</option>
                                    <option value="1">b. Orang yang berada dalam suatu ruangan yang sama dengan kasus dengan kasus (termasuk tempat kerja, kelas, rumah, acara besar) dalam 2 hari sebelum kasus timbul gejala dan hingga 14 hari setelah kasus timbul gejala</option>
                                    <option value="1">c. Orang yang bepergian bersama (radius 1 meter) dengan segala jenis alat angkut/kendaraan dalam 2 hari sebelum kasus timbul gejala dan hingga 14 hari setelah kasus timbul gejala.</option>
                                </select>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <div class="card card-row card-info">
                <div class="card-header">
                    <h3 class="card-title">
                        CARA PENILAIAN
                    </h3>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-4">
                            <label for="rs_rmpadgd_ku">PDP</label>
                            <select name="rs_rmpadgd_kppk" id="rs_rmpadgd_kppk" class="form-control">
                                <option hidden>PILIH PDP</option>
                                <option value="A1+A2+B1">A1 + A2 + B1</option>
                                <option value="A1+A2+B2">A1 + A2 + B2</option>
                                <option value="A1+B3">A1 + B3</option>
                                <option value="A2+B3">A2 + B3</option>
                                <option value="A3">A3 dengan tidak ada penyebab lain berdasrkan gambaran klinis yang meyakinkan</option>
                            </select>
                        </div>
                        <div class="col-4">
                            <label for="rs_rmpadgd_ku">ODP</label>
                            <select name="rs_rmpadgd_kppk" id="rs_rmpadgd_kppk" class="form-control">
                                <option hidden>PILIH ODP</option>
                                <option value="A1 + B1">A1 + B1</option>
                                <option value="A2 + B1">A2 + B1</option>
                                <option value="A1 + B2">A1 + B2</option>
                                <option value="A2 + B2">A2 + B2</option>
                            </select>

                        </div>
                        <div class="col-4">
                            <label for="rs_rmpadgd_ku">OTG</label>
                            <select name="rs_rmpadgd_kppk" id="rs_rmpadgd_kppk" class="form-control">
                                <option hidden>PILIH OTG</option>
                                <option value="0">Belum Dipilih</option>
                                <option value="B3">B3</option>
                            </select>
                        </div>
                    </div>
                    <br>

                    <div class="col-12">
                        <div class="form-group">
                            <label for="rs_rmpadgd_ku">Jenis Gejala</label>
                            <select name="rs_rmpadgd_kppk" id="rs_rmpadgd_kppk" class="form-control">
                                <option hidden>PILIH SALAH SATU PILIHAN</option>
                                <option value="Gejala Ringan">Gejala Ringan</option>
                                <option value="Gejala Sedang">Gejala Sedang</option>
                                <option value="Gejala Berat">Gejala Berat</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card card-row card-success">
                <div class="card-header">
                    <h3 class="card-title">
                        Tindak Lanjut
                    </h3>
                </div>
                <div class="card-body">
                    <div class="card card-success card-outline">
                        <div class="card-body">
                            <label>OTG</label> = Rapid test sesuai algoritma, karantina rumah dan edukasi jarak jauh call center di BNPB (117), Kementrian Kesehatan (119 ext 9), dan kanal informasi lainnya (misal, DKI 11, telemedicine Gojek-Halodoc, dan sebagainya) Website BNPB : https://www.covid19.go.id/
                        </div>
                    </div>

                    <div class="card card-success card-outline">
                        <div class="card-body">
                            <label>ODP</label> = Ruang isolasi diantar petugas, Tatalaksana Kondisi pasien, cek rontgen thorax dan darah rutin, lapor satgas faskes dan DPJP dengan kriteria yang di maksud
                            jka diperlukan atas instruksi DPJP = Rapid test sesuai algoritma, tatalaksana risiko, komunikasi sesuai, pulang, karantina di RS darurat (khusus) jika ODP > 60 tahun dengan komorbid.
                            Notifikasi dinas kesehatan, diberikan lembar karantina
                        </div>
                    </div>

                    <div class="card card-success card-outline">
                        <div class="card-body">
                            <label>PDP</label> = Ruang isolasi diantar petugas, Tatalaksana Kondisi pasien, cek rotgen thorax dan darah rutin, lapor satgas faskes dan DPJP dengan kriterisa yang dimaksud dan hasil rotgen thorax dan darah rutin, komunikasi resiko, identifikasi dan pemantauan kontak erat, Notig=fikasi dinas kesehatan jika diperlukan, atas instruksi
                            DPJP = Rapid test sesuai algoritma
                            Gejala ringan -> Karantina Rumah
                            Gejala sedang -> Karantin RS khusus / RS Darurat
                            Gejala Berat -> Karantina RS rujukan
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-4">
            <div class="card card-row card-primary">
                <div class="card-header">
                    <h3 class="card-title">
                        Gejala Ringan
                    </h3>
                </div>
                <div class="card-body">
                    - Demam > 38°C <br>
                    - Batuk <br>
                    - Nyeri Tenggorokan <br>
                    - Hidung Tersumbat <br>
                    - Malaise <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card card-row card-warning">
                <div class="card-header">
                    <h3 class="card-title">
                        Gejala Sedang
                    </h3>
                </div>
                <div class="card-body">
                    - Demam > 38°C <br>
                    - Sesak napas, batuk menetap dan sakit tenggorokan <br>
                    - Pada anak : batuk dan takipneu <br>
                    - Anak dengan pneumonia ringan mengalamai batuk atau kesulitan bernapas + napas cepat : <br>
                    Frekuensi napas : <br>
                    • < 2 Bulan ≥ 60x/menit <br>
                        • 2-11 Bulan ≥ 50x/menit <br>
                        • 1-5 Tahun ≥ 40x/menit< <br>
                            - dan tidak ada tanda pneumonia berat <br>
                            <br>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card card-row card-danger">
                <div class="card-header">
                    <h3 class="card-title">
                        Gejala Berat
                    </h3>
                </div>
                <div class="card-body">
                    - Demam > 38°C yang menetap<br>
                    - ada infeksi saluran napas dengan tanda-tanda<br>
                    a. Peningkatan frekuensi napas (>30x/menit) hingga sesak napas <br>
                    b. Batuk<br>
                    - Penurunan kesadaran : <br>
                    - Dalam pemeriksaaan lanjut, ditemukan : <br>
                    • saturasi oksigen < 90% udara luar <br>
                        - Dalam pemeriksaaan darah : <br>
                        • Leukopenia<br>
                        • Peningkatan monosit, dan<br>
                        • Peningkatan limfosit atipik<br>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-12">
        <div class="card card-row card-primary">
            <div class="card-header">
                <h3 class="card-title">
                    TANGGAL DAN WAKTU
                </h3>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <label for="rs_rmpadgd_tgl">Tanggal</label>
                    <input type="date" class="form-control" id="rs_rmpadgd_tgl" name="rs_rmpadgd_tgl" required>
                </div>

                <div class="bootstrap-timepicker">
                    <div class="form-group">
                        <label for="rs_rmpadgd_jam">Jam</label>
                        <div class="input-group date" id="timepickerMsk" data-target-input="nearest">
                            <input type="text" class="form-control datetimepicker-input" data-target="#timepickerMsk" id="rs_rmpadgd_jam" name="rs_rmpadgd_jam" required>
                            <div class="input-group-append" data-target="#timepickerMsk" data-toggle="datetimepicker">
                                <div class="input-group-text"><i class="far fa-clock"></i></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- /.card-body -->
    <div class="card card-primary">
        <div class="card-footer">
            <button type="submit" class="btn bg-gradient-primary"><?= $ButtonMethod ?></button>

            <?php
            $MethodForm = substr($MethodForm, 0, 10);
            if ($MethodForm == "updateData") {
            ?>
                <a href="/<?= $UrlForm ?>" class='btn bg-gradient-danger' aria-pressed="true">BATAL</a>
            <?php
            } else {
            ?>
                <button type="button" class="btn bg-gradient-danger" onclick="closeForm('<?= $IdForm ?>', '<?= $IdForm ?>')">BATAL</button>
            <?php
            }
            ?>
        </div>
    </div>
</form>
<script>
    $(function() {
        //Timepicker
        $('#timepickerMsk').datetimepicker({
            format: 'HH:mm',
            use24hours: true
        })
    });
</script>