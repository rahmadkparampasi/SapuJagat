<?php namespace Config;

class Validation
{
	//--------------------------------------------------------------------
	// Setup
	//--------------------------------------------------------------------

	/**
	 * Stores the classes that contain the
	 * rules that are available.
	 *
	 * @var array
	 */
	public $ruleSets = [
		\CodeIgniter\Validation\Rules::class,
		\CodeIgniter\Validation\FormatRules::class,
		\CodeIgniter\Validation\FileRules::class,
		\CodeIgniter\Validation\CreditCardRules::class,
	];

	/**
	 * Specifies the views that are used to display the
	 * errors.
	 *
	 * @var array
	 */
	public $templates = [
		'list'   => 'CodeIgniter\Validation\Views\list',
		'single' => 'CodeIgniter\Validation\Views\single',
	];

	//--------------------------------------------------------------------
	// Rules
	//--------------------------------------------------------------------

	public $produk = [
		'stok_produk_nama' => [
			'required' => 'Nama Produk Wajib Diisi',
			'alpha' => 'Nama Produk Hanya Dapat Diisikan Huruf',
		],
		'stok_produk_jumlah' => [
			'required' => 'Jumlah Produk Wajib Diisi',
			'numeric' => 'Jumlah Produk Hanya Dapat Diisikan Angka',
		],
		'stok_produk_harga' => [
			'required' => 'Harga Produk Wajib Diisi',
			'numeric' => 'Harga Produk Hanya Dapat Diisikan Angka'
		],
	];
}
